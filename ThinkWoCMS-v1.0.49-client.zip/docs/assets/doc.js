/* ThinkWo CMS 开发文档脚本 */
(function () {
  'use strict';

  /* ---------- 1. 页内目录 + 滚动高亮 ---------- */
  function buildToc() {
    var heads = document.querySelectorAll('.doc h2, .doc h3');
    var box = document.querySelector('.toc');
    if (!heads.length || !box) return;

    var html = '<div class="t">本页目录</div>';
    var used = {};
    heads.forEach(function (h) {
      if (!h.id) {
        var base = 'sec-' + (h.textContent || '').trim().replace(/[^\u4e00-\u9fa5a-zA-Z0-9]+/g, '-').toLowerCase();
        var id = base, i = 1;
        while (used[id]) { id = base + '-' + (i++); }
        used[id] = 1;
        h.id = id;
      }
      html += '<a href="#' + h.id + '" class="' + (h.tagName === 'H3' ? 'lv3' : '') + '">' +
        (h.textContent || '').trim() + '</a>';
    });
    box.innerHTML = html;

    var links = box.querySelectorAll('a');
    var targets = [];
    links.forEach(function (a) {
      var el = document.getElementById(a.getAttribute('href').slice(1));
      if (el) targets.push({ el: el, a: a });
    });

    function onScroll() {
      var y = window.scrollY + 90, cur = null;
      targets.forEach(function (t) {
        if (t.el.offsetTop <= y) cur = t;
      });
      links.forEach(function (a) { a.classList.remove('on'); });
      if (cur) cur.a.classList.add('on');
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- 2. 代码块：语言标签 + 复制按钮 ---------- */
  function initCode() {
    document.querySelectorAll('.doc pre').forEach(function (pre) {
      var code = pre.querySelector('code');
      if (!code) return;
      var lang = pre.getAttribute('data-lang');
      if (lang) {
        var lab = document.createElement('span');
        lab.className = 'lang';
        lab.textContent = lang;
        pre.appendChild(lab);
      }
      var btn = document.createElement('button');
      btn.className = 'copy';
      btn.type = 'button';
      btn.textContent = '复制';
      btn.addEventListener('click', function () {
        var text = code.innerText;
        var done = function () {
          btn.textContent = '已复制';
          btn.classList.add('ok');
          setTimeout(function () { btn.textContent = '复制'; btn.classList.remove('ok'); }, 1600);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(done, function () { fallback(text, done); });
        } else {
          fallback(text, done);
        }
      });
      pre.appendChild(btn);
    });

    function fallback(text, done) {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); done(); } catch (e) {}
      document.body.removeChild(ta);
    }
  }

  /* ---------- 3. 移动端侧栏 ---------- */
  function initSide() {
    var btn = document.querySelector('.burger');
    var side = document.querySelector('.side');
    if (!btn || !side) return;
    btn.addEventListener('click', function () { side.classList.toggle('open'); });
    side.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') side.classList.remove('open');
    });
  }

  /* ---------- 4. 侧栏搜索（过滤链接） ---------- */
  function initSearch() {
    var input = document.querySelector('.topbar .search input');
    if (!input) return;
    var items = Array.prototype.slice.call(document.querySelectorAll('.side .grp .sub a'));

    input.addEventListener('input', function () {
      var kw = input.value.trim().toLowerCase();
      document.querySelectorAll('.side .grp').forEach(function (grp) {
        var any = false;
        grp.querySelectorAll('.sub a').forEach(function (a) {
          var hit = !kw || (a.textContent || '').toLowerCase().indexOf(kw) > -1;
          a.style.display = hit ? '' : 'none';
          if (hit) any = true;
        });
        if (kw) grp.style.display = any ? '' : 'none';
      });
    });

    input.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter') return;
      var first = items.filter(function (a) { return a.style.display !== 'none'; })[0];
      if (first) window.location.href = first.getAttribute('href');
    });
  }

  /* ---------- 5. 外链新窗口 ---------- */
  function initLinks() {
    document.querySelectorAll('.doc a[href^="http"]').forEach(function (a) {
      a.target = '_blank';
      a.rel = 'noopener';
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    buildToc();
    initCode();
    initSide();
    initSearch();
    initLinks();
  });
})();
