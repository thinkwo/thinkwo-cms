<?php

declare(strict_types=1);

namespace plugins\aiwriter;

use app\common\library\Plugin as PluginManager;

/**
 * AI 内容工厂 —— 插件入口
 *
 * 启用后：
 *  1. 向左后台菜单注入「AI 内容工厂」入口（admin_menu 钩子）
 *  2. 首次运行时自愈初始化：建表、生成后台控制器桥接文件、同步菜单
 *     （不修改主程序任何已有文件，只新增 app/admin/controller/Aiwriter.php 一个桥接类）
 */
class Plugin
{
    public static function register(): void
    {
        PluginManager::listen('admin_menu', static function () {
            return [[
                'title'  => 'AI 内容工厂',
                'name'   => 'aiwriter/index',
                'path'   => 'aiwriter/index',
                'icon'   => 'layui-icon-edit',
                'plugin' => 'aiwriter',
            ]];
        });

        try {
            self::bootstrap();
        } catch (\Throwable $e) {
            // 初始化异常不阻断整站
        }
    }

    /**
     * 首次启用自愈初始化（幂等）
     */
    public static function bootstrap(): void
    {
        $dir   = PluginManager::path('aiwriter');
        $lock  = $dir . 'installed.lock';
        $ctrl  = app()->getBasePath() . 'admin' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'Aiwriter.php';

        // 控制器被误删时自动补回
        if (!is_file($ctrl)) {
            self::writeController($ctrl);
        }

        if (is_file($lock)) {
            return;
        }

        Store::ensureTables();

        // 首次建库时塞一批示例选题（仅在题库为空时）
        try {
            if ((int)\think\facade\Db::name('aiwriter_topic')->count() === 0) {
                $seed = $dir . 'seed' . DIRECTORY_SEPARATOR . 'topics-cnc.txt';
                if (is_file($seed)) {
                    $lang = \app\common\library\Lang::defaultCode();
                    $now  = time();
                    $rows = [];
                    foreach (preg_split('/\r\n|\r|\n/', (string)file_get_contents($seed)) as $line) {
                        $kw = trim($line);
                        if ($kw === '' || str_starts_with($kw, '#')) {
                            continue;
                        }
                        $rows[] = [
                            'keyword'    => mb_substr($kw, 0, 180),
                            'lang'       => $lang,
                            'sort_id'    => 0,
                            'status'     => 0,
                            'createtime' => $now,
                            'updatetime' => $now,
                        ];
                    }
                    if ($rows) {
                        \think\facade\Db::name('aiwriter_topic')->insertAll($rows);
                    }
                }
            }
        } catch (\Throwable $e) {
            // 种子失败不影响使用
        }

        @file_put_contents($lock, date('c'));

        // 立刻把菜单同步进 admin_rule，避免要等版本号变化才出现
        try {
            \app\common\library\Menu::sync();
        } catch (\Throwable $e) {
            // 忽略
        }
    }

    /**
     * 生成后台控制器桥接文件（仅一个薄壳，业务逻辑全在插件内）
     */
    protected static function writeController(string $file): void
    {
        $code = <<<'PHP'
<?php

declare(strict_types=1);

namespace app\admin\controller;

/**
 * AI 内容工厂 —— 插件桥接控制器
 *
 * 本文件由 plugins/aiwriter 插件自动生成，仅用于把后台路由
 * aiwriter/* 接到插件内的实现上。请勿手工修改，插件会自动重建。
 */
class Aiwriter extends \plugins\aiwriter\Controller
{
}
PHP;

        @file_put_contents($file, $code);
    }
}
