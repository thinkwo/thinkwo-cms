<?php

declare(strict_types=1);

namespace plugins\aiwriter;

/**
 * 提示词工厂：初稿生成 / 按校准素材重写
 *
 * 设计要点（决定文章能不能被 Google 认成"有用的内容"）：
 *  - 强制输出结构化 JSON，避免解析时切 HTML
 *  - 明确禁止编造认证、客户名、数字；没有事实就写通用表述
 *  - 校准环节只做"把真实工厂细节织进去"，不改结构、不改标题
 */
class Prompts
{
    public static function langName(string $code): string
    {
        $map = [
            'en' => 'English', 'zh-cn' => 'Simplified Chinese', 'zh-tw' => 'Traditional Chinese',
            'de' => 'German', 'fr' => 'French', 'es' => 'Spanish', 'pt' => 'Portuguese',
            'it' => 'Italian', 'ru' => 'Russian', 'ja' => 'Japanese', 'ko' => 'Korean',
            'ar' => 'Arabic', 'nl' => 'Dutch', 'pl' => 'Polish', 'tr' => 'Turkish',
            'vi' => 'Vietnamese', 'th' => 'Thai', 'id' => 'Indonesian', 'hi' => 'Hindi',
            'sv' => 'Swedish', 'da' => 'Danish', 'fi' => 'Finnish', 'no' => 'Norwegian',
            'cs' => 'Czech', 'hu' => 'Hungarian', 'ro' => 'Romanian', 'uk' => 'Ukrainian',
            'he' => 'Hebrew', 'ms' => 'Malay', 'fa' => 'Persian',
        ];

        return $map[strtolower($code)] ?? 'English';
    }

    /**
     * 初稿
     *
     * @return array{0:string,1:string} [system, user]
     */
    public static function article(array $ctx): array
    {
        $brand   = (string)($ctx['brand'] ?? '');
        $keyword = (string)($ctx['keyword'] ?? '');
        $lang    = (string)($ctx['lang'] ?? 'en');
        $langName = self::langName($lang);
        $profile = trim((string)($ctx['profile'] ?? ''));
        $facts   = trim((string)($ctx['facts'] ?? ''));
        $words   = max(600, (int)($ctx['words'] ?? 1500));
        $sort    = trim((string)($ctx['sortName'] ?? ''));

        $system = 'You are a senior B2B content writer and SEO specialist for ' . ($brand !== '' ? $brand : 'a China-based custom manufacturing supplier') . '. '
            . 'You write for engineering buyers: design engineers, sourcing managers and procurement leads at OEMs. '
            . 'Your writing is concrete, technical and calm. You never use hype, never write "in today\'s fast-paced world", '
            . 'never invent certifications, customer names, awards or statistics. If a number is not provided to you, describe it qualitatively instead of making one up. '
            . 'You reply with a single valid JSON object and nothing else. No markdown fences, no commentary.';

        $system .= ' Write the entire article in ' . $langName . '.';

        $user = "Write a new SEO article.\n\n"
            . "Primary keyword: {$keyword}\n"
            . ($sort !== '' ? "Section of the site it belongs to: {$sort}\n" : '')
            . "Target length: about {$words} words (body text, excluding FAQ).\n"
            . ($profile !== '' ? "Company profile (authoritative facts you may rely on):\n{$profile}\n" : '')
            . ($facts !== '' ? "Verified factory facts (must be used naturally, never contradicted):\n{$facts}\n" : '')
            . "\nStructure requirements:\n"
            . "- A specific, benefit-oriented title under 62 characters that contains the keyword or a very close variant\n"
            . "- 2-3 short intro paragraphs that state the problem the buyer has and how the article helps\n"
            . "- 4-6 H2 sections. At least one section must contain a comparison or specification list (ul/li), one must cover cost drivers, one must cover quality inspection and tolerances, one must cover how to choose and audit a supplier\n"
            . "- At least one HTML table comparing options, materials or process capabilities\n"
            . "- A short conclusion with a soft call to action (request a quote / upload CAD), no exclamation marks\n"
            . "- 5 FAQ pairs written as questions buyers actually type into search engines\n"
            . "\nWriting rules:\n"
            . "- Sentences under 25 words. Active voice. No filler paragraphs.\n"
            . "- Do not repeat the keyword unnaturally; use close variants instead.\n"
            . "- content_html may only use these tags: h2, h3, p, ul, li, table, thead, tbody, tr, th, td, strong, em, br\n"
            . "- Do not output h1; the title field carries it.\n"
            . "\nReturn exactly this JSON shape:\n"
            . '{"title":"","slug":"","summary":"","seo_title":"","seo_keywords":"","seo_description":"","content_html":"","faq":[{"q":"","a":""}]}' . "\n"
            . 'slug: 3-6 lowercase english words, hyphen separated, no stop words. seo_description: 140-155 characters. summary: 1-2 sentences.';

        return [$system, $user];
    }

    /**
     * 按人工校准素材重写
     *
     * @return array{0:string,1:string} [system, user]
     */
    public static function calibrate(array $ctx): array
    {
        $brand    = (string)($ctx['brand'] ?? '');
        $keyword  = (string)($ctx['keyword'] ?? '');
        $lang     = (string)($ctx['lang'] ?? 'en');
        $langName = self::langName($lang);
        $facts    = trim((string)($ctx['facts'] ?? ''));
        $title    = (string)($ctx['title'] ?? '');
        $content  = (string)($ctx['content'] ?? '');
        $faq      = (string)($ctx['faq'] ?? '');
        $profile  = trim((string)($ctx['profile'] ?? ''));

        $system = 'You are a senior editor at ' . ($brand !== '' ? $brand : 'a custom manufacturing supplier') . '. '
            . 'You revise an existing draft so that it reads like it was written by engineers who actually run the factory. '
            . 'You keep the structure and the title. You never invent facts. You reply with a single valid JSON object only. '
            . 'The article is in ' . $langName . '.';

        $user = "Here is an existing draft.\n\n"
            . "Primary keyword: {$keyword}\n"
            . "Current title: {$title}\n\n"
            . ($profile !== '' ? "Company profile:\n{$profile}\n\n" : '')
            . "Draft body HTML:\n{$content}\n\n"
            . ($faq !== '' ? "Draft FAQ (one per line, question|answer):\n{$faq}\n\n" : '')
            . "Verified factory facts to weave in:\n{$facts}\n\n"
            . "Revision rules:\n"
            . "- Insert the verified facts where they naturally belong (specs, tolerances, lead times, equipment, inspection, MOQ, finishes). Do not dump them in one block.\n"
            . "- Where the draft is vague, replace mush with the fact. Where no fact exists, keep it general rather than inventing numbers.\n"
            . "- Add one or two sentences that only an operator would write (common customer mistakes, what usually goes wrong at the quoting stage).\n"
            . "- Keep the same H2/H3 outline unless a fact clearly belongs elsewhere. Keep total length within 15% of the original.\n"
            . "- Rewrite the FAQ answers so they reflect the facts; keep the same questions unless a fact makes one irrelevant.\n"
            . "- Keep the title unless it contradicts a fact.\n"
            . "\nReturn exactly this JSON shape:\n"
            . '{"title":"","slug":"","summary":"","seo_title":"","seo_keywords":"","seo_description":"","content_html":"","faq":[{"q":"","a":""}]}';

        return [$system, $user];
    }
}
