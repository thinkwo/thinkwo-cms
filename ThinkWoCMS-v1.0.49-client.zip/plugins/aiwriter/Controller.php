<?php

declare(strict_types=1);

namespace plugins\aiwriter;

use app\common\controller\Backend;
use app\common\library\Lang;
use app\common\library\Plugin as PluginManager;
use app\common\library\Settings;
use think\facade\Db;
use think\facade\View;

/**
 * AI 内容工厂 —— 后台控制器实现
 *
 * 路由入口由自动生成的 app\admin\controller\Aiwriter 桥接过来，
 * 页面模板放在插件目录 view/ 下（渲染时用绝对路径，无需往 app/admin/view 塞文件）。
 */
class Controller extends Backend
{
    /**
     * 只校验登录，具体动作不再逐条配权限
     */
    protected array $noNeedRight = ['*'];

    /**
     * 工作台：选题库 + 草稿箱
     */
    public function index()
    {
        $sorts = $this->sortTree();
        $langs = Lang::all();

        $sortMap = [];
        foreach ($sorts as $s) {
            $sortMap[(int)$s['id']] = $s['name'];
        }

        $topics = Store::topics();
        foreach ($topics as &$t) {
            $t['sort_name'] = (string)($sortMap[(int)$t['sort_id']] ?? '-');
            $t['lang_name'] = (string)($langs[(string)$t['lang']]['name'] ?? $t['lang']);
        }
        unset($t);

        $drafts = Store::drafts();
        foreach ($drafts as &$d) {
            $d['sort_name'] = (string)($sortMap[(int)$d['sort_id']] ?? '-');
            $d['lang_name'] = (string)($langs[(string)$d['lang']]['name'] ?? $d['lang']);
            $d['date']      = $d['updatetime'] ? date('Y-m-d H:i', (int)$d['updatetime']) : '-';
        }
        unset($d);

        return $this->tpl('index', [
            'meta_title' => 'AI 内容工厂',
            'topics'     => $topics,
            'drafts'     => $drafts,
            'stats'      => Store::stats(),
            'sortsJson'  => json_encode(array_map(static function ($s) {
                return ['id' => (int)$s['id'], 'name' => (string)$s['name'], 'lang' => (string)$s['lang'], 'depth' => (int)$s['depth']];
            }, $sorts), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP),
            'langsJson'  => json_encode(array_map(static function ($l) {
                return ['code' => (string)$l['code'], 'name' => (string)$l['name']];
            }, array_values($langs)), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP),
            'defaultLang' => Lang::defaultCode(),
            'cfgReady'   => Llm::ready(),
            'modelName'  => Llm::modelName(),
        ]);
    }

    /**
     * 导入选题（一行一个）
     */
    public function importTopics()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $text   = (string)$this->request->post('keywords', '');
        $sortId = (int)$this->request->post('sort_id', 0);
        $lang   = (string)$this->request->post('lang', Lang::defaultCode());

        if (trim($text) === '') {
            return $this->fail('请粘贴关键词，一行一个');
        }
        if ($lang === '') {
            $lang = Lang::defaultCode();
        }

        try {
            $res = Store::importTopics($text, $sortId, $lang);
        } catch (\Throwable $e) {
            return $this->fail('导入失败：' . $e->getMessage());
        }

        return $this->ok('已导入 ' . $res['added'] . ' 条，跳过重复 ' . $res['skipped'] . ' 条');
    }

    /**
     * 删除选题
     */
    public function deleteTopic()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }
        try {
            Db::name('aiwriter_topic')->where('id', $id)->delete();
        } catch (\Throwable $e) {
            return $this->fail('删除失败：' . $e->getMessage());
        }

        return $this->ok('已删除');
    }

    /**
     * 按选题生成初稿
     */
    public function generate()
    {
        $topicId = (int)$this->request->param('topic_id', 0);
        $topic   = Store::topic($topicId);
        if (!$topic) {
            return $this->fail('选题不存在');
        }

        $sortId = (int)$this->request->param('sort_id', 0);
        if ($sortId <= 0) {
            $sortId = (int)$topic['sort_id'];
        }
        $lang = (string)($topic['lang'] ?? '');
        if ($lang === '') {
            $lang = Lang::defaultCode();
        }

        @set_time_limit(0);
        @ini_set('max_execution_time', '300');

        $sortName = '';
        if ($sortId > 0) {
            try {
                $sortName = (string)(Db::name('sort')->where('id', $sortId)->value('name') ?? '');
            } catch (\Throwable $e) {
                $sortName = '';
            }
        }

        [$system, $user] = Prompts::article([
            'keyword'  => (string)$topic['keyword'],
            'lang'     => $lang,
            'sortName' => $sortName,
            'profile'  => $this->profile(),
            'brand'    => $this->brand(),
            'words'    => (int)PluginManager::config('aiwriter', 'words', 1500),
            'facts'    => '',
        ]);

        $res = Llm::chat($system, $user);
        if (!$res['ok']) {
            return $this->fail($res['error']);
        }

        $json    = Llm::parseJson($res['text']);
        $content = (string)($json['content_html'] ?? '');
        $title   = trim((string)($json['title'] ?? ''));
        if ($content === '') {
            // 模型没按 JSON 输出时兜底：原文当正文
            $content = (string)$res['text'];
        }
        if ($title === '') {
            $title = (string)$topic['keyword'];
        }

        $faqLines = Store::faqToLines($json['faq'] ?? []);

        try {
            $draftId = Store::createDraft([
                'topic_id'        => $topicId,
                'lang'            => $lang,
                'sort_id'         => $sortId,
                'title'           => mb_substr($title, 0, 190),
                'slug'            => (string)($json['slug'] ?? ''),
                'summary'         => mb_substr((string)($json['summary'] ?? ''), 0, 480),
                'content'         => $content,
                'faq'             => $faqLines,
                'seo_title'       => mb_substr((string)($json['seo_title'] ?? ''), 0, 190),
                'seo_keywords'    => mb_substr((string)($json['seo_keywords'] ?? ''), 0, 250),
                'seo_description' => mb_substr((string)($json['seo_description'] ?? ''), 0, 480),
                'words'           => str_word_count(strip_tags($content)),
            ]);

            Db::name('aiwriter_topic')->where('id', $topicId)->update([
                'status'     => 1,
                'draft_id'   => $draftId,
                'updatetime' => time(),
            ]);
        } catch (\Throwable $e) {
            return $this->fail('保存草稿失败：' . $e->getMessage());
        }

        return $this->ok('已生成：' . $title, ['id' => $draftId, 'title' => $title]);
    }

    /**
     * 编辑草稿
     */
    public function edit()
    {
        $id    = (int)$this->request->param('id', 0);
        $draft = Store::draft($id);
        if (!$draft) {
            return $this->fail('草稿不存在');
        }

        $langs = Lang::all();

        return $this->tpl('edit', [
            'meta_title'  => '编辑：' . $draft['title'],
            'row'         => $draft,
            'sortsJson'   => json_encode(array_map(static function ($s) {
                return ['id' => (int)$s['id'], 'name' => (string)$s['name'], 'lang' => (string)$s['lang'], 'depth' => (int)$s['depth']];
            }, $this->sortTree()), JSON_UNESCAPED_UNICODE),
            'langs'       => array_values($langs),
            'cfgReady'    => Llm::ready(),
            'modelName'   => Llm::modelName(),
        ]);
    }

    /**
     * 保存草稿
     */
    public function save()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $id    = (int)$this->request->post('id', 0);
        $draft = Store::draft($id);
        if (!$draft) {
            return $this->fail('草稿不存在');
        }

        $post = $this->request->post();

        // 只更新提交上来的字段，避免部分提交时把其它字段清空
        $limits = [
            'title'           => 190,
            'slug'            => 120,
            'summary'         => 480,
            'seo_title'       => 190,
            'seo_keywords'    => 250,
            'seo_description' => 480,
        ];

        $data = [];
        foreach ($limits as $field => $len) {
            if (!array_key_exists($field, $post)) {
                continue;
            }
            $val = trim((string)$post[$field]);
            if ($field === 'title' && $val === '') {
                return $this->fail('标题不能为空');
            }
            $data[$field] = $field === 'slug' ? $val : mb_substr($val, 0, $len);
        }

        if (array_key_exists('content', $post)) {
            $data['content'] = (string)$post['content'];
            $data['words']   = str_word_count(strip_tags($data['content']));
        }
        if (array_key_exists('faq', $post)) {
            $data['faq'] = (string)$post['faq'];
        }
        if (array_key_exists('facts', $post)) {
            $data['facts'] = (string)$post['facts'];
        }
        if (array_key_exists('lang', $post) && (string)$post['lang'] !== '') {
            $data['lang'] = (string)$post['lang'];
        }
        if (array_key_exists('sort_id', $post)) {
            $data['sort_id'] = (int)$post['sort_id'];
        }

        if (!$data) {
            return $this->ok('没有需要保存的改动');
        }

        try {
            Store::updateDraft($id, $data);
        } catch (\Throwable $e) {
            return $this->fail('保存失败：' . $e->getMessage());
        }

        return $this->ok('已保存');
    }

    /**
     * 按校准素材重写（把真实工厂细节织进正文）
     */
    public function regenerate()
    {
        $id    = (int)$this->request->param('id', 0);
        $draft = Store::draft($id);
        if (!$draft) {
            return $this->fail('草稿不存在');
        }

        $facts = trim((string)$this->request->post('facts', ''));
        if ($facts === '') {
            $facts = trim((string)($draft['facts'] ?? ''));
        }
        if ($facts === '') {
            return $this->fail('请先填写「校准素材」：真实参数、流程、客户常见错误等');
        }

        @set_time_limit(0);
        @ini_set('max_execution_time', '300');

        [$system, $user] = Prompts::calibrate([
            'keyword' => (string)($this->request->post('keyword', '') ?: $draft['title']),
            'lang'    => (string)$draft['lang'],
            'profile' => $this->profile(),
            'brand'   => $this->brand(),
            'facts'   => $facts,
            'title'   => (string)$draft['title'],
            'content' => (string)$draft['content'],
            'faq'     => (string)$draft['faq'],
        ]);

        $res = Llm::chat($system, $user);
        if (!$res['ok']) {
            return $this->fail($res['error']);
        }

        $json    = Llm::parseJson($res['text']);
        $content = (string)($json['content_html'] ?? '');
        if ($content === '') {
            return $this->fail('模型返回内容无法解析，请重试');
        }

        try {
            Store::updateDraft($id, [
                'title'           => mb_substr(trim((string)($json['title'] ?? '')) ?: (string)$draft['title'], 0, 190),
                'slug'            => (string)($json['slug'] ?? $draft['slug']),
                'summary'         => mb_substr((string)($json['summary'] ?? $draft['summary']), 0, 480),
                'content'         => $content,
                'faq'             => Store::faqToLines($json['faq'] ?? []) ?: (string)$draft['faq'],
                'seo_title'       => mb_substr((string)($json['seo_title'] ?? $draft['seo_title']), 0, 190),
                'seo_keywords'    => mb_substr((string)($json['seo_keywords'] ?? $draft['seo_keywords']), 0, 250),
                'seo_description' => mb_substr((string)($json['seo_description'] ?? $draft['seo_description']), 0, 480),
                'facts'           => $facts,
                'words'           => str_word_count(strip_tags($content)),
            ]);
        } catch (\Throwable $e) {
            return $this->fail('保存失败：' . $e->getMessage());
        }

        return $this->ok('已按校准素材重写，请核对后发布');
    }

    /**
     * 发布到内容表（status=1 前台可见，0 存草稿）
     */
    public function publish()
    {
        $id     = (int)$this->request->param('id', 0);
        $status = (int)$this->request->param('status', 1);
        $draft  = Store::draft($id);
        if (!$draft) {
            return $this->fail('草稿不存在');
        }

        $res = Store::publish($draft, $status);

        return $res['ok'] ? $this->ok($res['msg'], ['id' => $res['id']]) : $this->fail($res['msg']);
    }

    /**
     * 删除草稿（不影响已发布内容）
     */
    public function deleteDraft()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }
        try {
            Db::name('aiwriter_draft')->where('id', $id)->delete();
        } catch (\Throwable $e) {
            return $this->fail('删除失败：' . $e->getMessage());
        }

        return $this->ok('已删除');
    }

    /**
     * 连通性测试
     */
    public function test()
    {
        @set_time_limit(0);

        $res = Llm::chat('You are a ping responder.', 'Reply with exactly: OK');

        return $res['ok'] ? $this->ok('连接正常，模型：' . Llm::modelName() . '，返回：' . mb_substr(trim($res['text']), 0, 40)) : $this->fail($res['error']);
    }

    /* ------------------------------ 内部工具 ------------------------------ */

    /**
     * 用绝对路径渲染插件模板（不往 app/admin/view 塞文件）
     */
    protected function tpl(string $template, array $vars = []): string
    {
        View::assign($vars);

        return View::fetch(PluginManager::path('aiwriter') . 'view' . DIRECTORY_SEPARATOR . $template . '.html');
    }

    /**
     * 全部栏目（含其他语言），带层级深度
     */
    protected function sortTree(): array
    {
        try {
            $rows = Db::name('sort')->where('status', 1)->order('lang asc, sort asc, id asc')->select()->toArray();
        } catch (\Throwable $e) {
            return [];
        }

        $byId = [];
        foreach ($rows as $row) {
            $byId[(int)$row['id']] = $row;
        }

        foreach ($rows as &$row) {
            $depth = 0;
            $pid   = (int)$row['pid'];
            $guard = 0;
            while ($pid > 0 && isset($byId[$pid]) && $guard < 10) {
                $depth++;
                $pid = (int)$byId[$pid]['pid'];
                $guard++;
            }
            $row['depth'] = $depth;
        }
        unset($row);

        return $rows;
    }

    /**
     * 站点资料：优先插件配置，其次站点设置
     */
    protected function profile(): string
    {
        $p = trim((string)PluginManager::config('aiwriter', 'profile', ''));
        if ($p !== '') {
            return $p;
        }

        $lines = [];
        $name  = (string)Settings::get('site_name', '');
        $desc  = (string)Settings::get('site_description', '');
        $comp  = (string)Settings::get('company', '');
        $addr  = (string)Settings::get('address', '');

        if ($name !== '') {
            $lines[] = 'Brand: ' . $name;
        }
        if ($comp !== '') {
            $lines[] = 'Legal company: ' . $comp;
        }
        if ($desc !== '') {
            $lines[] = 'Positioning: ' . $desc;
        }
        if ($addr !== '') {
            $lines[] = 'Factory location: ' . $addr;
        }

        return implode("\n", $lines);
    }

    protected function brand(): string
    {
        $b = trim((string)PluginManager::config('aiwriter', 'brand', ''));
        if ($b !== '') {
            return $b;
        }

        return (string)Settings::get('site_name', '');
    }
}
