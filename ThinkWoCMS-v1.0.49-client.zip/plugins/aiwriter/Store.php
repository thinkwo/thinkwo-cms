<?php

declare(strict_types=1);

namespace plugins\aiwriter;

use app\common\library\HtmlCache;
use app\common\library\IndexNow;
use app\common\library\Lang;
use app\common\library\Pinyin;
use app\common\library\TwUrl;
use think\facade\Db;

/**
 * 数据存取：选题库 / 草稿箱 / 发布到内容表
 */
class Store
{
    public static function ensureTables(): void
    {
        $prefix = (string)config('database.connections.mysql.prefix');

        Db::execute("CREATE TABLE IF NOT EXISTS `{$prefix}aiwriter_topic` (
            `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
            `keyword` varchar(180) NOT NULL DEFAULT '' COMMENT '目标关键词/选题',
            `lang` varchar(10) NOT NULL DEFAULT 'en' COMMENT '目标语言',
            `sort_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
            `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0待生成 1已生成',
            `draft_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最近一次生成的草稿ID',
            `createtime` int(11) unsigned NOT NULL DEFAULT '0',
            `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`),
            UNIQUE KEY `uk_kw` (`lang`,`keyword`),
            KEY `idx_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI内容工厂选题库'");

        Db::execute("CREATE TABLE IF NOT EXISTS `{$prefix}aiwriter_draft` (
            `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
            `topic_id` int(11) unsigned NOT NULL DEFAULT '0',
            `lang` varchar(10) NOT NULL DEFAULT 'en',
            `sort_id` int(11) unsigned NOT NULL DEFAULT '0',
            `title` varchar(200) NOT NULL DEFAULT '',
            `slug` varchar(120) NOT NULL DEFAULT '',
            `summary` varchar(500) NOT NULL DEFAULT '',
            `content` mediumtext,
            `faq` text,
            `seo_title` varchar(200) NOT NULL DEFAULT '',
            `seo_keywords` varchar(255) NOT NULL DEFAULT '',
            `seo_description` varchar(500) NOT NULL DEFAULT '',
            `facts` text COMMENT '人工校准素材',
            `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0草稿 1已发布',
            `content_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发布到内容表后的ID',
            `words` int(11) unsigned NOT NULL DEFAULT '0',
            `createtime` int(11) unsigned NOT NULL DEFAULT '0',
            `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`),
            KEY `idx_status` (`status`),
            KEY `idx_topic` (`topic_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI内容工厂草稿箱'");
    }

    /* ------------------------------ 选题 ------------------------------ */

    public static function topics(int $limit = 300): array
    {
        try {
            return Db::name('aiwriter_topic')->order('status asc, id desc')->limit($limit)->select()->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    public static function topic(int $id): ?array
    {
        try {
            $row = Db::name('aiwriter_topic')->where('id', $id)->find();

            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * 批量导入选题：一行一个关键词
     *
     * @return array{added:int,skipped:int}
     */
    public static function importTopics(string $text, int $sortId, string $lang): array
    {
        $lines = preg_split('/\r\n|\r|\n/', $text) ?: [];
        $now   = time();
        $added = 0;
        $skip  = 0;

        foreach ($lines as $line) {
            $kw = trim($line);
            if ($kw === '') {
                continue;
            }
            $kw = mb_substr(preg_replace('/\s+/', ' ', $kw) ?? $kw, 0, 180);

            $exists = Db::name('aiwriter_topic')->where('lang', $lang)->where('keyword', $kw)->find();
            if ($exists) {
                $skip++;
                continue;
            }

            Db::name('aiwriter_topic')->insert([
                'keyword'    => $kw,
                'lang'       => $lang,
                'sort_id'    => $sortId,
                'status'     => 0,
                'createtime' => $now,
                'updatetime' => $now,
            ]);
            $added++;
        }

        return ['added' => $added, 'skipped' => $skip];
    }

    /* ------------------------------ 草稿 ------------------------------ */

    public static function drafts(int $limit = 100): array
    {
        try {
            return Db::name('aiwriter_draft')->field('id,topic_id,lang,sort_id,title,slug,summary,status,content_id,words,updatetime')
                ->order('id desc')->limit($limit)->select()->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    public static function draft(int $id): ?array
    {
        try {
            $row = Db::name('aiwriter_draft')->where('id', $id)->find();

            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * 新建草稿
     */
    public static function createDraft(array $data): int
    {
        $now = time();

        return (int)Db::name('aiwriter_draft')->insertGetId(array_merge([
            'topic_id'   => 0,
            'lang'       => Lang::defaultCode(),
            'sort_id'    => 0,
            'title'      => '',
            'slug'       => '',
            'summary'    => '',
            'content'    => '',
            'faq'        => '',
            'seo_title'  => '',
            'seo_keywords' => '',
            'seo_description' => '',
            'facts'      => '',
            'status'     => 0,
            'content_id' => 0,
            'words'      => 0,
            'createtime' => $now,
            'updatetime' => $now,
        ], $data));
    }

    public static function updateDraft(int $id, array $data): void
    {
        $data['updatetime'] = time();
        Db::name('aiwriter_draft')->where('id', $id)->update($data);
    }

    /**
     * FAQ 数组 → 文本（每行 问题|答案）
     */
    public static function faqToLines($faq): string
    {
        if (!is_array($faq)) {
            return '';
        }
        $out = [];
        foreach ($faq as $item) {
            if (!is_array($item)) {
                continue;
            }
            $q = trim((string)($item['q'] ?? $item['question'] ?? ''));
            $a = trim((string)($item['a'] ?? $item['answer'] ?? ''));
            if ($q === '' || $a === '') {
                continue;
            }
            $out[] = $q . '|' . str_replace(["\r", "\n"], ' ', $a);
        }

        return implode("\n", $out);
    }

    /**
     * 文本 → FAQ 数组
     */
    public static function linesToFaq(string $text): array
    {
        $faq = [];
        foreach (preg_split('/\r\n|\r|\n/', $text) ?: [] as $line) {
            $line = trim($line);
            if ($line === '' || !str_contains($line, '|')) {
                continue;
            }
            [$q, $a] = explode('|', $line, 2);
            $q = trim($q);
            $a = trim($a);
            if ($q !== '' && $a !== '') {
                $faq[] = ['q' => $q, 'a' => $a];
            }
        }

        return $faq;
    }

    /**
     * FAQ → 正文末尾的可见区块（同时利于 SEO 抓取与 GEO 引用）
     */
    public static function faqHtml(array $faq): string
    {
        if (!$faq) {
            return '';
        }
        $html = "\n<h2>FAQ</h2>\n";
        foreach ($faq as $item) {
            $q = htmlspecialchars((string)($item['q'] ?? ''), ENT_QUOTES, 'UTF-8');
            $a = htmlspecialchars((string)($item['a'] ?? ''), ENT_QUOTES, 'UTF-8');
            if ($q === '' || $a === '') {
                continue;
            }
            $html .= '<h3>' . $q . "</h3>\n<p>" . $a . "</p>\n";
        }

        return $html;
    }

    /**
     * 发布草稿到内容表
     *
     * @return array{ok:bool,msg:string,id:int}
     */
    public static function publish(array $draft, int $status = 0): array
    {
        $title = trim((string)$draft['title']);
        if ($title === '') {
            return ['ok' => false, 'msg' => '标题为空，不能发布', 'id' => 0];
        }

        $lang   = (string)($draft['lang'] ?? '') !== '' ? (string)$draft['lang'] : Lang::defaultCode();
        $sortId = (int)($draft['sort_id'] ?? 0);
        if ($sortId <= 0) {
            return ['ok' => false, 'msg' => '请先给草稿指定栏目', 'id' => 0];
        }

        $contentId = (int)($draft['content_id'] ?? 0);

        $slug = Pinyin::sanitize((string)($draft['slug'] ?? ''));
        if ($slug === '') {
            $slug = Pinyin::smartSlug($title);
        }
        $slug = Pinyin::unique('content', $slug, $lang, $contentId);

        $content = (string)($draft['content'] ?? '');
        $faq     = self::linesToFaq((string)($draft['faq'] ?? ''));
        if ($faq && !str_contains($content, '<h2>FAQ</h2>')) {
            $content .= self::faqHtml($faq);
        }

        $now  = time();
        $data = [
            'lang'            => $lang,
            'sort_id'         => $sortId,
            'title'           => $title,
            'slug'            => $slug,
            'summary'         => (string)($draft['summary'] ?? ''),
            'content'         => $content,
            'seo_title'       => (string)($draft['seo_title'] ?? ''),
            'seo_keywords'    => (string)($draft['seo_keywords'] ?? ''),
            'seo_description' => (string)($draft['seo_description'] ?? ''),
            'status'          => $status === 1 ? 1 : 0,
            'updatetime'      => $now,
        ];

        try {
            if ($contentId > 0 && Db::name('content')->where('id', $contentId)->find()) {
                Db::name('content')->where('id', $contentId)->update($data);
            } else {
                $data['views']        = 0;
                $data['publish_time'] = $status === 1 ? $now : 0;
                $data['createtime']   = $now;
                $contentId            = (int)Db::name('content')->insertGetId($data);
            }
        } catch (\Throwable $e) {
            return ['ok' => false, 'msg' => '写入内容表失败：' . $e->getMessage(), 'id' => 0];
        }

        self::updateDraft((int)$draft['id'], [
            'status'     => $status === 1 ? 1 : 0,
            'content_id' => $contentId,
            'slug'       => $slug,
        ]);

        if ($status === 1) {
            try {
                HtmlCache::clear();
            } catch (\Throwable $e) {
                // 忽略
            }

            try {
                if (IndexNow::enabled()) {
                    $row  = Db::name('content')->where('id', $contentId)->find() ?: [];
                    $sort = Db::name('sort')->where('id', $sortId)->find() ?: [];
                    IndexNow::push(TwUrl::detail($row, $sort), 'Added');
                }
            } catch (\Throwable $e) {
                // 忽略
            }
        }

        return [
            'ok'  => true,
            'msg' => $status === 1 ? '已发布到内容表（前台可见）' : '已保存为草稿（前台不可见）',
            'id'  => $contentId,
        ];
    }

    /**
     * 统计
     */
    public static function stats(): array
    {
        $out = ['topic' => 0, 'pending' => 0, 'draft' => 0, 'published' => 0];
        try {
            $out['topic']     = (int)Db::name('aiwriter_topic')->count();
            $out['pending']   = (int)Db::name('aiwriter_topic')->where('status', 0)->count();
            $out['draft']     = (int)Db::name('aiwriter_draft')->where('status', 0)->count();
            $out['published'] = (int)Db::name('aiwriter_draft')->where('status', 1)->count();
        } catch (\Throwable $e) {
            // 表还没建
        }

        return $out;
    }
}
