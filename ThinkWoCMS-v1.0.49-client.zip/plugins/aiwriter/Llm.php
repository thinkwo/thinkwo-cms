<?php

declare(strict_types=1);

namespace plugins\aiwriter;

use app\common\library\Plugin as PluginManager;

/**
 * LLM 调用封装（OpenAI 兼容协议）
 */
class Llm
{
    /**
     * 读插件配置
     */
    public static function cfg(string $key, $default = null)
    {
        return PluginManager::config('aiwriter', $key, $default);
    }

    public static function ready(): bool
    {
        return trim((string)self::cfg('api_key', '')) !== '';
    }

    public static function modelName(): string
    {
        $m = trim((string)self::cfg('model', 'gpt-4o-mini'));

        return $m !== '' ? $m : 'gpt-4o-mini';
    }

    /**
     * 单轮对话
     *
     * @return array{ok:bool,text:string,error:string,usage:array}
     */
    public static function chat(string $system, string $user): array
    {
        $key = trim((string)self::cfg('api_key', ''));
        if ($key === '') {
            return ['ok' => false, 'text' => '', 'error' => '未配置 API Key，请到「插件管理 → AI 内容工厂 → 设置」填写', 'usage' => []];
        }

        $base = rtrim(trim((string)self::cfg('api_base', 'https://api.openai.com/v1')), '/');
        if ($base === '') {
            $base = 'https://api.openai.com/v1';
        }
        // 允许用户直接填到 /chat/completions
        $url = str_contains($base, '/chat/completions') ? $base : $base . '/chat/completions';

        $payload = [
            'model'       => self::modelName(),
            'temperature' => (float)self::cfg('temperature', '0.7'),
            'max_tokens'  => max(800, (int)self::cfg('max_tokens', '4000')),
            'messages'    => [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => $user],
            ],
        ];
        if ((string)self::cfg('json_mode', '0') === '1') {
            $payload['response_format'] = ['type' => 'json_object'];
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $key,
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 240,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $body  = curl_exec($ch);
        $http  = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $error = (string)curl_error($ch);
        curl_close($ch);

        if ($body === false) {
            return ['ok' => false, 'text' => '', 'error' => '请求失败：' . ($error !== '' ? $error : '网络错误'), 'usage' => []];
        }

        $data = json_decode((string)$body, true);
        if (!is_array($data)) {
            return ['ok' => false, 'text' => '', 'error' => '接口返回非 JSON（HTTP ' . $http . '）：' . mb_substr((string)$body, 0, 200), 'usage' => []];
        }

        if (isset($data['error'])) {
            $msg = is_array($data['error']) ? (string)($data['error']['message'] ?? '接口返回错误') : (string)$data['error'];
            return ['ok' => false, 'text' => '', 'error' => 'HTTP ' . $http . '：' . $msg, 'usage' => []];
        }

        $text = '';
        if (isset($data['choices'][0]['message']['content'])) {
            $text = (string)$data['choices'][0]['message']['content'];
        } elseif (isset($data['choices'][0]['text'])) {
            $text = (string)$data['choices'][0]['text'];
        }

        if (trim($text) === '') {
            return ['ok' => false, 'text' => '', 'error' => '接口返回空内容（HTTP ' . $http . '）：' . mb_substr((string)$body, 0, 200), 'usage' => []];
        }

        return [
            'ok'    => true,
            'text'  => $text,
            'error' => '',
            'usage' => is_array($data['usage'] ?? null) ? $data['usage'] : [],
        ];
    }

    /**
     * 从模型输出里抠出 JSON（容忍 ```json 围栏与前后废话）
     */
    public static function parseJson(string $text): array
    {
        $raw = trim($text);
        $raw = preg_replace('/^```(?:json)?\s*/i', '', $raw) ?? $raw;
        $raw = preg_replace('/\s*```$/', '', $raw) ?? $raw;

        $data = json_decode(trim($raw), true);
        if (is_array($data)) {
            return $data;
        }

        $start = strpos($raw, '{');
        $end   = strrpos($raw, '}');
        if ($start !== false && $end !== false && $end > $start) {
            $json = substr($raw, $start, $end - $start + 1);
            $data = json_decode($json, true);
            if (is_array($data)) {
                return $data;
            }
        }

        return [];
    }
}
