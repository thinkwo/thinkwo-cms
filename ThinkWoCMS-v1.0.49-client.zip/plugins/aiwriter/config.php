<?php

declare(strict_types=1);

/**
 * AI 内容工厂 —— 配置项定义
 * 显示位置：后台「插件管理」→ AI 内容工厂 → 设置
 */
return [
    [
        'key'     => 'api_base',
        'title'   => 'API 地址',
        'label'   => 'API 地址',
        'type'    => 'text',
        'default' => 'https://api.openai.com/v1',
        'tip'     => 'OpenAI 兼容接口。/chat/completions 会自动拼在后面，填到 /v1 即可',
    ],
    [
        'key'     => 'api_key',
        'title'   => 'API Key',
        'label'   => 'API Key',
        'type'    => 'text',
        'default' => '',
        'tip'     => '必填。只存本站数据库，不会外传',
    ],
    [
        'key'     => 'model',
        'title'   => '模型名',
        'label'   => '模型名',
        'type'    => 'text',
        'default' => 'gpt-4o-mini',
        'tip'     => '按你的服务商填：gpt-4o-mini / deepseek-chat / claude-3-5-sonnet 等',
    ],
    [
        'key'     => 'temperature',
        'title'   => '温度（0-1）',
        'label'   => '温度（0-1）',
        'type'    => 'text',
        'default' => '0.7',
        'tip'     => '越高越发散，工业文建议 0.6-0.8',
    ],
    [
        'key'     => 'max_tokens',
        'title'   => '单篇最大 token',
        'label'   => '单篇最大 token',
        'type'    => 'text',
        'default' => '4000',
        'tip'     => '太小的值会导致正文被截断，建议 3500-6000',
    ],
    [
        'key'     => 'json_mode',
        'title'   => 'JSON 模式',
        'label'   => 'JSON 模式',
        'type'    => 'switch',
        'default' => '0',
        'tip'     => '服务商支持 response_format=json_object 时打开，结构更稳；不支持则保持关闭',
    ],
    [
        'key'     => 'profile',
        'title'   => '站点资料（生成时会喂给 AI）',
        'label'   => '站点资料（生成时会喂给 AI）',
        'type'    => 'textarea',
        'default' => '',
        'tip'     => '公司定位、工厂面积、设备、认证、服务范围、交期、MOQ 等。留空则用「站点设置」里的站点名与简介',
    ],
    [
        'key'     => 'brand',
        'title'   => '品牌名',
        'label'   => '品牌名',
        'type'    => 'text',
        'default' => '',
        'tip'     => '文章里自称的品牌名，留空则用站点名称',
    ],
];
