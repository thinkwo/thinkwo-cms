# plugins/ — 插件目录

ThinkWo CMS 的插件统一放在本目录，每个插件一个独立文件夹：

```
plugins/
  └─ demo-plugin/
       ├─ plugin.json      # 插件清单（名称、版本、作者、钩子声明）
       ├─ Plugin.php       # register() 静态方法，挂载钩子
       └─ ...              # 控制器 / 视图 / 配置
```

后台「插件管理」会自动扫描本目录；插件命名空间为 `plugins\{插件名}`，由
`app\common\library\Plugin` 通过 spl_autoload_register 自动加载。

开发规范详见《ThinkWo CMS 插件开发手册》。
