<?php

declare(strict_types=1);

namespace plugins\geo;

use app\common\library\Plugin as PluginManager;

/**
 * GEO（生成引擎优化）插件入口
 *
 * 启用后：
 *  1. 向左后台菜单注入「GEO 优化」入口（admin_menu 钩子）
 *  2. 首次运行时自愈初始化：生成后台控制器桥接文件、同步菜单、预生成三文件
 *     （不修改主程序任何已有文件，只新增 app/admin/controller/Geo.php 一个桥接类）
 *  3. 前台 head 钩子：JSON-LD 结构化数据注入 + llms.txt / robots.txt 懒生成
 */
class Plugin
{
    public static function register(): void
    {
        PluginManager::listen('admin_menu', static function () {
            return [[
                'title'  => 'GEO 优化',
                'name'   => 'geo/index',
                'path'   => 'geo/index',
                'icon'   => 'layui-icon-chart-screen',
                'plugin' => 'geo',
            ]];
        });

        PluginManager::listen('head', static function () {
            try {
                return Builder::head();
            } catch (\Throwable $e) {
                // 插件异常不阻断整站
                return '';
            }
        });

        try {
            self::bootstrap();
        } catch (\Throwable $e) {
            // 初始化异常不阻断整站
        }
    }

    /**
     * 首次启用自愈初始化（幂等）
     */
    public static function bootstrap(): void
    {
        $dir  = PluginManager::path('geo');
        $lock = $dir . 'installed.lock';
        $ctrl = app()->getBasePath() . 'admin' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'Geo.php';

        // 控制器被误删时自动补回（后台「GEO 优化」菜单必须有落点）
        if (!is_file($ctrl)) {
            self::writeController($ctrl);
        }

        // 菜单：按插件版本号补同步一次。
        // 与 installed.lock 解耦——老版本升级上来时 lock 已存在，
        // 若不看版本号就永远补不上左侧菜单。
        self::syncMenuOnce($dir);

        if (is_file($lock)) {
            return;
        }

        @file_put_contents($lock, date('c'));

        // 首次启用就生成三文件，省得等前台第一个访问
        try {
            Builder::rebuild();
        } catch (\Throwable $e) {
            // public 不可写等情况忽略，后台概览页会提示
        }
    }

    /**
     * 版本变化 / 菜单被删时同步一次菜单（写 admin_rule）
     */
    protected static function syncMenuOnce(string $dir): void
    {
        // 菜单只在后台用，前台请求不做多余查询
        try {
            if (app('http')->getName() !== 'admin') {
                return;
            }
        } catch (\Throwable $e) {
            return;
        }

        $manifest = json_decode((string)@file_get_contents($dir . 'plugin.json'), true);
        $version  = is_array($manifest) ? (string)($manifest['version'] ?? '') : '';
        $marker   = $dir . 'menu.ver';

        $changed = true;
        if ($version !== '' && is_file($marker) && trim((string)@file_get_contents($marker)) === $version) {
            // 版本没变：只在菜单记录丢失时补一次（用户误删 / 换库）
            $changed = false;
            try {
                $changed = !\think\facade\Db::name('admin_rule')->where('name', 'geo/index')->find();
            } catch (\Throwable $e) {
                return;
            }
        }
        if (!$changed) {
            return;
        }

        try {
            \app\common\library\Menu::sync();
        } catch (\Throwable $e) {
            return;
        }

        @file_put_contents($marker, $version);
    }

    /**
     * 生成后台控制器桥接文件（仅一个薄壳，业务逻辑全在插件内）
     */
    protected static function writeController(string $file): void
    {
        $code = <<<'PHP'
<?php

declare(strict_types=1);

namespace app\admin\controller;

/**
 * GEO 生成引擎优化 —— 插件桥接控制器
 *
 * 本文件由 plugins/geo 插件自动生成，仅用于把后台路由
 * geo/* 接到插件内的实现上。请勿手工修改，插件会自动重建。
 */
class Geo extends \plugins\geo\Controller
{
}
PHP;

        @file_put_contents($file, $code);
    }
}
