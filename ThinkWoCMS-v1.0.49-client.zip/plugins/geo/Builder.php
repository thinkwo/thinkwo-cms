<?php

declare(strict_types=1);

namespace plugins\geo;

use app\common\library\HtmlCache;
use app\common\library\Lang;
use app\common\library\Plugin as PluginManager;
use app\common\library\Seo;
use app\common\library\Settings;
use app\common\library\TwUrl;
use think\facade\Db;

/**
 * GEO 生成器
 *
 * 职责：
 *  1. head() —— 向前台 <head> 注入 JSON-LD 结构化数据（经 Seo::head() 的插件钩子）
 *  2. ensureFiles() —— 懒生成 public/llms.txt、public/llms-full.txt、public/robots.txt
 *     （内容或插件配置变化后，前台任意页面被访问时自动重新生成）
 */
class Builder
{
    /** AI / LLM 爬虫白名单（robots.txt 显式 Allow 段） */
    protected const AI_AGENTS = [
        'GPTBot', 'OAI-SearchBot', 'ChatGPT-User',
        'ClaudeBot', 'Claude-User', 'Claude-SearchBot',
        'PerplexityBot', 'Google-Extended', 'Applebot-Extended',
        'CCBot', 'meta-externalagent', 'Amazonbot', 'Bytespider', 'cohere-ai',
    ];

    /** 单页正文写入 llms-full.txt 的最大字符数 */
    protected const MAX_PAGE_TEXT = 12000;

    /** 再生节流窗口（秒） */
    protected const THROTTLE = 1800;

    /**
     * 配置覆盖（后台「保存并重建」时使用）
     *
     * Plugin::config() 在单次请求内有静态缓存，保存后立刻重建会读到旧配置，
     * 所以后台保存后先把新配置塞进来，重建完即生效。
     */
    protected static ?array $override = null;

    /**
     * head 钩子入口（返回值会原样输出进 <head>）
     *
     * JSON-LD 策略（纯补缺，绝不重复输出）：
     *  · 主程序已输出 Organization / WebSite / Breadcrumb / Product 时插件不重复；
     *    Organization 缺失（旧版主程序）→ 输出完整 Organization
     *  · 文章页主程序已输出 Article 时不重复，缺失则补
     *  · FAQPage 主程序从不输出 → 配置了常见问答即在默认语言首页注入
     *  · 组织简介建议填站点设置的 site_description、社交链接填 social_*，
     *    会自动进入主程序的 Organization 结构化数据
     */
    public static function head(): string
    {
        if (self::cfg('enable', '1') !== '1') {
            return '';
        }

        try {
            self::ensureFiles();
        } catch (\Throwable $e) {
            // 生成失败不影响页面
        }

        if (self::cfg('jsonld', '1') !== '1') {
            return '';
        }

        $out = self::ensureOrg();
        $out .= self::ensureArticle();
        $out .= self::ensureFaq();

        return $out;
    }

    /* ================================================================
     * JSON-LD
     * ================================================================ */

    /**
     * 主程序已注册的 JSON-LD 类型集合（小写 @type => true）
     */
    protected static function existingTypes(): array
    {
        $types = [];
        foreach ((array)Seo::get('jsonld', []) as $item) {
            if (is_array($item) && isset($item['@type'])) {
                $types[strtolower((string)$item['@type'])] = true;
            }
        }

        return $types;
    }

    /**
     * Organization：存在则增强（简介 + 权威链接），不存在则完整输出
     */
    protected static function ensureOrg(): string
    {
        $site = Settings::all();
        $name = self::cfg('org_name', (string)($site['site_name'] ?? ''));
        if ($name === '') {
            return '';
        }

        $list = (array)Seo::get('jsonld', []);
        $idx  = null;
        foreach ($list as $i => $item) {
            if (is_array($item) && strtolower((string)($item['@type'] ?? '')) === 'organization') {
                $idx = $i;
                break;
            }
        }

        $desc = self::cfg('org_desc', (string)($site['site_description'] ?? ''));
        $extra = [];
        foreach (self::parseLines(self::cfg('org_links')) as $row) {
            $u = (string)($row[0] ?? '');
            if (preg_match('#^https?://#i', $u)) {
                $extra[] = $u;
            }
        }

        // 旧版主程序没有 Organization → 插件输出完整版
        if ($idx === null) {
            $data = [
                '@context' => 'https://schema.org',
                '@type'    => 'Organization',
                'name'     => $name,
                'url'      => Seo::abs('/'),
            ];
            $logo = (string)($site['logo'] ?? '');
            if ($logo !== '') {
                $data['logo'] = Seo::abs($logo);
            }
            if ($desc !== '') {
                $data['description'] = $desc;
            }
            $phone = self::cfg('org_phone', (string)($site['phone'] ?? ''));
            $email = self::cfg('org_email', (string)($site['email'] ?? ''));
            $addr  = self::cfg('org_address', (string)($site['address'] ?? ''));
            if ($phone !== '') {
                $data['telephone'] = $phone;
            }
            if ($email !== '') {
                $data['email'] = $email;
            }
            if ($addr !== '') {
                $data['address'] = ['@type' => 'PostalAddress', 'streetAddress' => $addr];
            }
            $sameAs = [];
            foreach (['social_facebook', 'social_twitter', 'social_linkedin', 'social_youtube', 'social_instagram'] as $k) {
                $v = (string)($site[$k] ?? '');
                if (preg_match('#^https?://#i', $v)) {
                    $sameAs[] = $v;
                }
            }
            foreach ($extra as $u) {
                if (!in_array($u, $sameAs, true)) {
                    $sameAs[] = $u;
                }
            }
            if ($sameAs) {
                $data['sameAs'] = $sameAs;
            }

            return self::ld($data);
        }

        // 主程序已输出 Organization（v1.0.44+）→ 不重复输出。
        // 组织简介填站点设置 site_description、社交链接填 social_* 即可进入主程序版本。
        return '';
    }

    /**
     * 文章页 Article：主程序已输出则跳过，缺失（旧版）则补
     */
    protected static function ensureArticle(): string
    {
        if (Seo::get('og_type') !== 'article') {
            return '';
        }
        $types = self::existingTypes();
        if (!empty($types['article'])) {
            return '';
        }

        $canonical = (string)Seo::get('canonical', '');
        $headline  = (string)Seo::get('title', '');
        if ($canonical === '' || $headline === '') {
            return '';
        }

        $site = Settings::all();
        $name = self::cfg('org_name', (string)($site['site_name'] ?? ''));
        $data = [
            '@context'         => 'https://schema.org',
            '@type'            => 'Article',
            'headline'         => $headline,
            'mainEntityOfPage' => Seo::abs($canonical),
            'author'           => ['@type' => 'Organization', 'name' => $name],
            'publisher'        => ['@type' => 'Organization', 'name' => $name],
        ];
        $desc = (string)Seo::get('description', '');
        if ($desc !== '') {
            $data['description'] = $desc;
        }
        $image = (string)Seo::get('og_image', '');
        if ($image !== '') {
            $data['image'] = [Seo::abs($image)];
        }

        return self::ld($data);
    }

    /**
     * FAQPage：主程序不输出，配置了常见问答即在默认语言首页注入
     */
    protected static function ensureFaq(): string
    {
        $types = self::existingTypes();
        if (!empty($types['faqpage'])) {
            return '';
        }

        // 仅默认语言首页（首页 path 为空）
        $path = trim((string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'), '/');
        if ($path !== '') {
            return '';
        }

        $entities = [];
        foreach (self::parseLines(self::cfg('org_faq')) as $row) {
            $q = (string)($row[0] ?? '');
            $a = (string)($row[1] ?? '');
            if ($q === '' || $a === '') {
                continue;
            }
            $entities[] = [
                '@type'          => 'Question',
                'name'           => $q,
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => $a],
            ];
        }
        if (!$entities) {
            return '';
        }

        return self::ld([
            '@context'   => 'https://schema.org',
            '@type'      => 'FAQPage',
            'mainEntity' => $entities,
        ]);
    }

    protected static function ld(array $data): string
    {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_LINE_TERMINATORS);

        return $json ? '<script type="application/ld+json">' . $json . '</script>' : '';
    }

    /* ================================================================
     * llms.txt / llms-full.txt / robots.txt 生成
     * ================================================================ */

    public static function ensureFiles(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;

        if (self::cfg('enable', '1') !== '1') {
            return;
        }
        $doLlms   = self::cfg('llms', '1') === '1';
        $doRobots = self::cfg('robots', '1') === '1';
        if (!$doLlms && !$doRobots) {
            return;
        }

        $public = public_path();
        if (!is_dir($public) || !is_writable($public)) {
            return;
        }

        // 节流：窗口期内且目标文件齐全则跳过
        $runDir   = runtime_path() . 'geo';
        $metaFile = $runDir . DIRECTORY_SEPARATOR . 'meta.json';
        $meta     = is_file($metaFile) ? json_decode((string)file_get_contents($metaFile), true) : [];
        if (is_array($meta) && (int)($meta['t'] ?? 0) > time() - self::THROTTLE) {
            $ok = true;
            if ($doLlms) {
                $ok = $ok && is_file($public . 'llms.txt') && is_file($public . 'llms-full.txt');
            }
            if ($doRobots) {
                $ok = $ok && is_file($public . 'robots.txt');
            }
            if ($ok) {
                return;
            }
        }

        self::generate($public, $doLlms, $doRobots, $runDir, $metaFile);
    }

    protected static function generate(string $public, bool $doLlms, bool $doRobots, string $runDir, string $metaFile): void
    {
        $site = Settings::all();
        $name = self::cfg('org_name', (string)($site['site_name'] ?? ''));
        $desc = self::cfg('org_desc', (string)($site['site_description'] ?? ''));
        $def  = Lang::defaultCode();

        // 栏目与内容（默认语言）
        $sorts    = Db::name('sort')->where('lang', $def)->where('status', 1)
            ->order('pid asc, sort asc, id asc')->select()->toArray();
        $sortById = [];
        foreach ($sorts as $s) {
            $sortById[(int)$s['id']] = $s;
        }
        $contents = Db::name('content')->where('lang', $def)->where('status', 1)->where('noindex', 0)
            ->order('sort_id asc, sort asc, id asc')->select()->toArray();

        if ($doLlms) {
            self::atomic($public . 'llms.txt', self::llmsTxt($name, $desc, $site, $sorts, $sortById, $contents));
            self::atomic($public . 'llms-full.txt', self::llmsFull($name, $desc, $sorts, $sortById, $contents));
        }
        if ($doRobots) {
            self::atomic($public . 'robots.txt', self::robotsTxt());
        }

        if (!is_dir($runDir)) {
            @mkdir($runDir, 0755, true);
        }
        self::atomic($metaFile, json_encode(['t' => time()]));
    }

    protected static function llmsTxt(string $name, string $desc, array $site, array $sorts, array $sortById, array $contents): string
    {
        $lines   = [];
        $lines[] = '# ' . $name;
        $lines[] = '';
        if ($desc !== '') {
            $lines[] = '> ' . $desc;
            $lines[] = '';
        }

        // 核心服务（用户配置，优先级最高）
        $svcs = self::parseLines(self::cfg('org_services'));
        if ($svcs) {
            $lines[] = '## Core Services';
            foreach ($svcs as $row) {
                $sName = (string)($row[0] ?? '');
                $sDesc = (string)($row[1] ?? '');
                $sUrl  = (string)($row[2] ?? '');
                if ($sName === '') {
                    continue;
                }
                if ($sUrl !== '') {
                    $lines[] = '- [' . $sName . '](' . self::absUrl($sUrl) . ')' . ($sDesc !== '' ? ': ' . $sDesc : '');
                } else {
                    $lines[] = '- ' . $sName . ($sDesc !== '' ? ': ' . $sDesc : '');
                }
            }
            $lines[] = '';
        }

        // 全站页面（栏目 + 内容）
        $lines[] = '## Site Pages';
        foreach ($sorts as $s) {
            if ((string)$s['type'] === 'link' && (string)$s['link'] !== '') {
                $url = (string)$s['link'];
            } else {
                $url = TwUrl::sort($s);
            }
            $label = (string)$s['name'];
            $sd    = (string)($s['seo_description'] ?: $s['description']);
            $sd    = self::oneLine((string)$sd);
            $pad   = (int)$s['pid'] > 0 ? '  ' : '';
            $lines[] = $pad . '- [' . $label . '](' . self::absUrl($url) . ')' . ($sd !== '' ? ': ' . $sd : '');

            // 该栏目下的内容
            foreach ($contents as $c) {
                if ((int)$c['sort_id'] !== (int)$s['id']) {
                    continue;
                }
                $curl = TwUrl::detail($c, $s);
                $cd   = self::oneLine((string)($c['seo_description'] ?: $c['summary']));
                $lines[] = $pad . '  - [' . (string)$c['title'] . '](' . self::absUrl($curl) . ')' . ($cd !== '' ? ': ' . $cd : '');
            }
        }
        $lines[] = '';

        // 联系方式
        $phone   = self::cfg('org_phone', (string)($site['phone'] ?? ''));
        $email   = self::cfg('org_email', (string)($site['email'] ?? ''));
        $address = self::cfg('org_address', (string)($site['address'] ?? ''));
        if ($phone !== '' || $email !== '' || $address !== '') {
            $lines[] = '## Contact';
            if ($phone !== '') {
                $lines[] = '- Phone: ' . $phone;
            }
            if ($email !== '') {
                $lines[] = '- Email: ' . $email;
            }
            if ($address !== '') {
                $lines[] = '- Address: ' . $address;
            }
            $lines[] = '';
        }

        // 语言版本
        $langs = Lang::all();
        if (count($langs) > 1) {
            $lines[] = '## Other Languages';
            foreach ($langs as $lang) {
                if ((string)$lang['code'] === Lang::defaultCode()) {
                    continue;
                }
                $lines[] = '- [' . (string)($lang['native_name'] ?: $lang['name']) . '](' . self::absUrl(TwUrl::home((string)$lang['code'])) . ')';
            }
            $lines[] = '';
        }

        // 机器可读索引
        $lines[] = '## Machine-readable Index';
        $lines[] = '- Sitemap: ' . Seo::abs('/sitemap.xml');
        $lines[] = '- Full content (plain text): ' . Seo::abs('/llms-full.txt');

        return implode("\n", $lines) . "\n";
    }

    protected static function llmsFull(string $name, string $desc, array $sorts, array $sortById, array $contents): string
    {
        $lines   = [];
        $lines[] = '# ' . $name . ' — Full Content for AI';
        $lines[] = '';
        if ($desc !== '') {
            $lines[] = '> ' . $desc;
            $lines[] = '';
        }

        // 单页栏目（page 型，含 About/Quality 等）
        foreach ($sorts as $s) {
            if ((string)$s['type'] !== 'page') {
                continue;
            }
            $url = TwUrl::sort($s);
            $lines[] = '## ' . (string)$s['name'];
            $lines[] = 'URL: ' . self::absUrl($url);
            $sd = self::oneLine((string)($s['seo_description'] ?: $s['description']));
            if ($sd !== '') {
                $lines[] = '';
                $lines[] = $sd;
            }
            $lines[] = '';
            $lines[] = '----';
            $lines[] = '';
        }

        // 内容页（列表型栏目下的内容）
        foreach ($contents as $c) {
            $s     = $sortById[(int)$c['sort_id']] ?? null;
            $curl  = TwUrl::detail($c, $s);
            $lines[] = '## ' . (string)$c['title'];
            $lines[] = 'URL: ' . self::absUrl($curl);
            $cd = self::oneLine((string)($c['seo_description'] ?: $c['summary']));
            if ($cd !== '') {
                $lines[] = '';
                $lines[] = $cd;
            }
            $body = self::text((string)($c['content'] ?? ''));
            if ($body !== '') {
                if (mb_strlen($body) > self::MAX_PAGE_TEXT) {
                    $body = mb_substr($body, 0, self::MAX_PAGE_TEXT) . "\n\n[... truncated ...]";
                }
                $lines[] = '';
                $lines[] = $body;
            }
            $lines[] = '';
            $lines[] = '----';
            $lines[] = '';
        }

        return implode("\n", $lines);
    }

    protected static function robotsTxt(): string
    {
        $lines   = [];
        $lines[] = '# robots.txt generated by ThinkWoCMS geo plugin';
        $lines[] = '# AI / LLM crawlers are explicitly welcome.';
        $lines[] = '';
        $lines[] = '# === AI / LLM crawlers: allowed ===';
        foreach (self::AI_AGENTS as $agent) {
            $lines[] = 'User-agent: ' . $agent;
        }
        $lines[] = 'Allow: /';
        $lines[] = '';
        $lines[] = '# === All crawlers ===';
        $lines[] = 'User-agent: *';
        $lines[] = 'Allow: /';
        $lines[] = 'Disallow: /admin.php';
        $lines[] = 'Disallow: /search';
        $lines[] = 'Disallow: /api/';
        $lines[] = 'Disallow: /runtime/';
        $lines[] = '';
        $lines[] = 'Sitemap: ' . Seo::abs('/sitemap.xml');

        return implode("\n", $lines) . "\n";
    }

    /* ================================================================
     * 后台（GEO 优化 → 概览页）用到的公开接口
     * ================================================================ */

    /**
     * 注入一份配置覆盖（保存后同一请求内重建用）
     */
    public static function useConfig(array $config): void
    {
        self::$override = $config;
    }

    /**
     * AI / LLM 爬虫清单
     */
    public static function agents(): array
    {
        return self::AI_AGENTS;
    }

    /**
     * 三个生成文件的状态（只读，不触发任何生成）
     *
     * @return array<string,mixed>
     */
    public static function status(): array
    {
        $public = public_path();
        $out    = [];
        foreach (['llms.txt', 'llms-full.txt', 'robots.txt'] as $name) {
            $file = $public . $name;
            $out[$name] = [
                'name'   => $name,
                'exists' => is_file($file),
                'size'   => is_file($file) ? (int)filesize($file) : 0,
                'time'   => is_file($file) ? (int)filemtime($file) : 0,
                'url'    => '/' . $name,
            ];
        }

        $meta = runtime_path() . 'geo' . DIRECTORY_SEPARATOR . 'meta.json';
        $last = 0;
        if (is_file($meta)) {
            $json = json_decode((string)file_get_contents($meta), true);
            $last = is_array($json) ? (int)($json['t'] ?? 0) : 0;
        }
        $out['last_run'] = $last;

        return $out;
    }

    /**
     * 强制重建三文件（后台按钮）
     *
     * 顺带清前台静态缓存：静态页里已固化了旧的 <head>，
     * 不清掉的话新配置 / 新 JSON-LD 不会出现在缓存页上。
     *
     * @return array<string,mixed>
     */
    public static function rebuild(): array
    {
        $public = public_path();
        if (!is_dir($public)) {
            throw new \RuntimeException('找不到 public 目录：' . $public);
        }
        if (!is_writable($public)) {
            throw new \RuntimeException('public 目录不可写，请检查目录权限：' . $public);
        }

        if (self::cfg('enable', '1') !== '1') {
            throw new \RuntimeException('GEO 优化已关闭，先打开总开关再重建');
        }

        $doLlms   = self::cfg('llms', '1') === '1';
        $doRobots = self::cfg('robots', '1') === '1';
        if (!$doLlms && !$doRobots) {
            throw new \RuntimeException('llms.txt 与 robots.txt 都关着，没有需要生成的文件');
        }

        $runDir   = runtime_path() . 'geo';
        $metaFile = $runDir . DIRECTORY_SEPARATOR . 'meta.json';
        @unlink($metaFile);

        self::generate($public, $doLlms, $doRobots, $runDir, $metaFile);

        $cleared = 0;
        try {
            $cleared = HtmlCache::clear();
        } catch (\Throwable $e) {
            $cleared = 0;
        }

        $status                  = self::status();
        $status['cache_cleared'] = $cleared;

        return $status;
    }

    /**
     * 有效配置项数量统计（概览页展示用）
     *
     * @return array{services:int,faq:int,links:int}
     */
    public static function cfgStats(): array
    {
        $services = 0;
        foreach (self::parseLines(self::cfg('org_services')) as $row) {
            if (trim((string)($row[0] ?? '')) !== '') {
                $services++;
            }
        }
        $faq = 0;
        foreach (self::parseLines(self::cfg('org_faq')) as $row) {
            if (trim((string)($row[0] ?? '')) !== '' && trim((string)($row[1] ?? '')) !== '') {
                $faq++;
            }
        }
        $links = 0;
        foreach (self::parseLines(self::cfg('org_links')) as $row) {
            if (preg_match('#^https?://#i', (string)($row[0] ?? ''))) {
                $links++;
            }
        }

        return ['services' => $services, 'faq' => $faq, 'links' => $links];
    }

    /* ================================================================
     * 工具
     * ================================================================ */

    protected static function cfg(string $key, string $default = ''): string
    {
        if (self::$override !== null) {
            $v = self::$override[$key] ?? null;

            return ($v === null || trim((string)$v) === '') ? $default : (string)$v;
        }

        $v = PluginManager::config('geo', $key, null);
        if ($v === null || trim((string)$v) === '') {
            return $default;
        }

        return (string)$v;
    }

    /**
     * 多行文本解析：每行一条，竖线分段
     */
    protected static function parseLines(string $raw): array
    {
        $out = [];
        foreach (preg_split('/\r\n|\r|\n/', $raw) as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $out[] = array_map('trim', explode('|', $line));
        }

        return $out;
    }

    /**
     * 相对路径转绝对 URL（已是绝对则原样返回）
     */
    protected static function absUrl(string $url): string
    {
        if ($url === '') {
            return Seo::abs('/');
        }

        return Seo::abs($url);
    }

    /**
     * HTML 转纯文本（llms-full 正文）
     */
    protected static function text(string $html): string
    {
        if ($html === '') {
            return '';
        }
        $html = preg_replace('#<(script|style)\b[^>]*>.*?</\1>#is', '', $html) ?? '';
        $text = html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8');
        $text = str_replace("\r\n", "\n", $text);
        $text = preg_replace('/[ \t]+/', ' ', $text) ?? '';
        $text = preg_replace('/\n{3,}/', "\n\n", $text) ?? '';

        return trim($text);
    }

    /**
     * 单行摘要（描述用）：去标签压空白
     */
    protected static function oneLine(string $raw): string
    {
        $t = self::text($raw);

        return preg_replace('/\s+/', ' ', $t) ?? '';
    }

    /**
     * 原子写文件（临时文件 + rename，防止并发写坏）
     */
    protected static function atomic(string $file, string $content): void
    {
        $tmp = $file . '.tmp.' . getmypid();
        if (@file_put_contents($tmp, $content, LOCK_EX) !== false) {
            if (!@rename($tmp, $file)) {
                @unlink($tmp);
            }
        }
    }
}
