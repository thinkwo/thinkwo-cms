<?php

declare(strict_types=1);

namespace plugins\geo;

use app\common\controller\Backend;
use app\common\library\Plugin as PluginManager;
use app\common\library\Settings;
use think\facade\View;

/**
 * GEO 生成引擎优化 —— 后台控制器实现
 *
 * 路由入口由自动生成的 app\admin\controller\Geo 桥接过来，
 * 页面模板放在插件目录 view/ 下（渲染时用绝对路径，无需往 app/admin/view 塞文件）。
 */
class Controller extends Backend
{
    /**
     * 只校验登录，具体动作不再逐条配权限
     */
    protected array $noNeedRight = ['*'];

    /** 与 config.php 对齐的配置字段 */
    protected const FIELDS = [
        'enable', 'llms', 'robots', 'jsonld',
        'org_name', 'org_desc', 'org_services', 'org_faq',
        'org_phone', 'org_email', 'org_address', 'org_links',
    ];

    /** 开关型字段 */
    protected const SWITCHES = ['enable', 'llms', 'robots', 'jsonld'];

    /**
     * 概览页：生成状态 + AI 爬虫 + 配置表单 + 自检
     */
    public function index()
    {
        $cfg = self::currentConfig();
        foreach (self::SWITCHES as $k) {
            $cfg[$k] = ($cfg[$k] ?? '1') === '1' ? 1 : 0;
        }

        $site  = Settings::all();
        $stats = Builder::cfgStats();

        $files = [];
        $st    = Builder::status();
        foreach (['llms.txt', 'llms-full.txt', 'robots.txt'] as $name) {
            $item = $st[$name];
            $files[] = [
                'name'   => $name,
                'exists' => $item['exists'] ? 1 : 0,
                'size'   => self::sizeText($item['size']),
                'time'   => $item['time'] ? date('Y-m-d H:i', $item['time']) : '-',
                'url'    => $item['url'],
            ];
        }

        return $this->tpl('index', [
            'meta_title'   => 'GEO 优化',
            'cfg'          => $cfg,
            'site'         => $site,
            'stats'        => $stats,
            'files'        => $files,
            'lastRun'      => $st['last_run'] ? date('Y-m-d H:i', $st['last_run']) : '尚未生成',
            'agents'       => Builder::agents(),
            'enabled'      => $cfg['enable'] === 1,
            'siteName'     => (string)($site['site_name'] ?? ''),
            'siteDesc'     => (string)($site['site_description'] ?? ''),
            'sitePhone'    => (string)($site['phone'] ?? ''),
            'siteEmail'    => (string)($site['email'] ?? ''),
            'siteAddress'  => (string)($site['address'] ?? ''),
        ]);
    }

    /**
     * 保存配置并立即重建（不用跳去「插件管理」）
     */
    public function save()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $post = $this->request->post();
        $cfg  = [];
        foreach (self::FIELDS as $key) {
            if (in_array($key, self::SWITCHES, true)) {
                $cfg[$key] = ((int)($post[$key] ?? 0)) === 1 ? '1' : '0';
            } else {
                $cfg[$key] = trim((string)($post[$key] ?? ''));
            }
        }

        // 保留插件可能存在的其他键（例如以后新增的配置项）
        $old = PluginManager::config('geo');
        if (is_array($old) && $old) {
            $cfg = array_merge($old, $cfg);
        }

        try {
            PluginManager::saveConfig('geo', $cfg);
            // 本次请求内 Plugin::config 有静态缓存，必须显式覆盖，否则重建用的是旧配置
            Builder::useConfig($cfg);

            if ($cfg['enable'] === '1') {
                $status = Builder::rebuild();
                $msg    = '已保存并重建三文件';
            } else {
                // 总开关关闭时不生成文件（已有的保留不动）
                $status = Builder::status();
                $msg    = '已保存（GEO 优化已关闭，不生成新文件）';
            }
        } catch (\Throwable $e) {
            return $this->fail('保存失败：' . $e->getMessage());
        }

        return $this->ok($msg, self::payload($status));
    }

    /**
     * 立即重建三文件（不改配置）
     */
    public function rebuild()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        try {
            $status = Builder::rebuild();
        } catch (\Throwable $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok('三文件已重建', self::payload($status));
    }

    /**
     * 自检：抓取本站首页与两个文件，看结构化数据是否真的输出
     */
    public function selfcheck()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $base = rtrim((string)$this->request->domain(), '/');
        if ($base === '') {
            return $this->fail('无法识别站点域名');
        }

        $html = $this->httpGet($base . '/');
        if ($html === null) {
            return $this->fail('抓取首页失败：服务器可能禁止回环请求，请直接在浏览器打开首页查看源码 search「application/ld+json」');
        }

        $want  = ['Organization', 'WebSite', 'BreadcrumbList', 'FAQPage', 'Product', 'Article'];
        $types = [];
        foreach ($want as $t) {
            $types[$t] = (bool)preg_match('/"@type"\s*:\s*"' . preg_quote($t, '/') . '"/i', $html);
        }

        $llms   = $this->httpGet($base . '/llms.txt');
        $robots = $this->httpGet($base . '/robots.txt');

        return $this->ok('自检完成', [
            'types'        => $types,
            'llms_ok'      => $llms !== null,
            'robots_ok'    => $robots !== null,
            'robots_ai'    => $robots !== null && stripos($robots, 'GPTBot') !== false,
            'llms_size'    => $llms !== null ? mb_strlen($llms) : 0,
            'faq_expected' => Builder::cfgStats()['faq'],
        ]);
    }

    /* ================================================================
     * 内部工具
     * ================================================================ */

    /**
     * 当前配置（补齐默认值）
     */
    protected static function currentConfig(): array
    {
        $raw = PluginManager::config('geo');
        $raw = is_array($raw) ? $raw : [];

        return array_merge([
            'enable'       => '1',
            'llms'         => '1',
            'robots'       => '1',
            'jsonld'       => '1',
            'org_name'     => '',
            'org_desc'     => '',
            'org_services' => '',
            'org_faq'      => '',
            'org_phone'    => '',
            'org_email'    => '',
            'org_address'  => '',
            'org_links'    => '',
        ], $raw);
    }

    /**
     * 重建结果转前端可用的结构
     */
    protected static function payload(array $status): array
    {
        $files = [];
        foreach (['llms.txt', 'llms-full.txt', 'robots.txt'] as $name) {
            $item = $status[$name];
            $files[] = [
                'name'   => $name,
                'exists' => $item['exists'] ? 1 : 0,
                'size'   => self::sizeText($item['size']),
                'time'   => $item['time'] ? date('Y-m-d H:i', $item['time']) : '-',
            ];
        }

        return [
            'files'         => $files,
            'cache_cleared' => (int)($status['cache_cleared'] ?? 0),
            'last_run'      => !empty($status['last_run']) ? date('Y-m-d H:i', (int)$status['last_run']) : '-',
        ];
    }

    protected static function sizeText(int $bytes): string
    {
        if ($bytes <= 0) {
            return '-';
        }
        if ($bytes < 1024) {
            return $bytes . ' B';
        }
        if ($bytes < 1048576) {
            return round($bytes / 1024, 1) . ' KB';
        }

        return round($bytes / 1048576, 2) . ' MB';
    }

    /**
     * 简单 GET（curl 优先，退回 stream）
     */
    protected function httpGet(string $url): ?string
    {
        try {
            if (function_exists('curl_init')) {
                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT        => 6,
                    CURLOPT_CONNECTTIMEOUT => 3,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS      => 3,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_USERAGENT      => 'ThinkWoCMS-GEO-SelfCheck/1.0',
                ]);
                $body = curl_exec($ch);
                $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);

                return is_string($body) && $code >= 200 && $code < 400 ? $body : null;
            }

            $ctx  = stream_context_create(['http' => ['timeout' => 6, 'user_agent' => 'ThinkWoCMS-GEO-SelfCheck/1.0']]);
            $body = @file_get_contents($url, false, $ctx);

            return is_string($body) ? $body : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * 渲染插件目录下的模板（绝对路径，同时保留后台布局继承）
     */
    protected function tpl(string $template, array $vars = []): string
    {
        View::assign($vars);

        return View::fetch(PluginManager::path('geo') . 'view' . DIRECTORY_SEPARATOR . $template . '.html');
    }
}
