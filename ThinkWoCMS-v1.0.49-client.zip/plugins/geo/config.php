<?php

declare(strict_types=1);

return [
    [
        'key'     => 'enable',
        'title'   => '启用 GEO 优化（总开关）',
        'type'    => 'switch',
        'default' => '1',
        'tip'     => '关闭后不再生成 llms.txt / robots.txt，也不再注入 JSON-LD',
    ],
    [
        'key'     => 'llms',
        'title'   => '生成 llms.txt 与 llms-full.txt',
        'type'    => 'switch',
        'default' => '1',
        'tip'     => '内容或配置变化后，前台任意页面被访问时自动重新生成 public/llms.txt',
    ],
    [
        'key'     => 'robots',
        'title'   => '生成 AI 友好 robots.txt',
        'type'    => 'switch',
        'default' => '1',
        'tip'     => '显式允许 GPTBot / ClaudeBot / PerplexityBot 等 AI 爬虫，并声明 Sitemap。生成静态文件 public/robots.txt',
    ],
    [
        'key'     => 'jsonld',
        'title'   => '注入 JSON-LD 结构化数据',
        'type'    => 'switch',
        'default' => '1',
        'tip'     => 'Organization / WebSite / Article / FAQPage，对所有主题生效',
    ],
    [
        'key'     => 'org_name',
        'title'   => '公司 / 组织名称',
        'type'    => 'text',
        'default' => '',
        'tip'     => '留空则使用站点设置里的网站名称',
    ],
    [
        'key'     => 'org_desc',
        'title'   => '组织简介（AI 引用本站的依据）',
        'type'    => 'textarea',
        'default' => '',
        'tip'     => '120~300 字，写清「是谁、做什么、凭什么信任（认证/年限/产能）」。留空则用站点描述',
    ],
    [
        'key'     => 'org_services',
        'title'   => '核心服务 / 产品',
        'type'    => 'textarea',
        'default' => '',
        'tip'     => '每行一个，格式：名称 | 一句话描述 | 链接（链接可省略）',
    ],
    [
        'key'     => 'org_faq',
        'title'   => '常见问答（输出 FAQPage 结构化数据）',
        'type'    => 'textarea',
        'default' => '',
        'tip'     => '每行一个，格式：问题 | 答案。配置后注入首页 FAQPage 结构化数据，推荐 4~8 条',
    ],
    [
        'key'     => 'org_phone',
        'title'   => '联系电话',
        'type'    => 'text',
        'default' => '',
        'tip'     => '留空则使用站点设置里的电话',
    ],
    [
        'key'     => 'org_email',
        'title'   => '邮箱',
        'type'    => 'text',
        'default' => '',
        'tip'     => '留空则使用站点设置里的邮箱',
    ],
    [
        'key'     => 'org_address',
        'title'   => '公司地址',
        'type'    => 'text',
        'default' => '',
        'tip'     => '留空则使用站点设置里的地址',
    ],
    [
        'key'     => 'org_links',
        'title'   => '权威链接（sameAs）',
        'type'    => 'textarea',
        'default' => '',
        'tip'     => '每行一个 URL：领英 / YouTube / 行业协会 / 认证机构页面等',
    ],
];
