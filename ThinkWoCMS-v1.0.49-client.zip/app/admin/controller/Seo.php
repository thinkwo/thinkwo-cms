<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\HtmlCache;
use app\common\library\ImageTool;
use app\common\library\IndexNow;
use app\common\library\Lang;
use app\common\library\Settings;
use think\facade\Db;

/**
 * SEO 工具
 */
class Seo extends Backend
{
    public function index()
    {
        $cache = HtmlCache::stats();

        $stat = [
            'content'   => 0,
            'noindex'   => 0,
            'no_seo'    => 0,
            'sort'      => 0,
            'redirect'  => 0,
            'no_title'  => 0,
        ];

        try {
            $stat['content']  = (int)Db::name('content')->where('status', 1)->count();
            $stat['noindex']  = (int)Db::name('content')->where('noindex', 1)->count();
            $stat['no_seo']   = (int)Db::name('content')->where('status', 1)->where('seo_description', '')->count();
            $stat['no_title'] = (int)Db::name('content')->where('status', 1)->where('seo_title', '')->count();
            $stat['sort']     = (int)Db::name('sort')->where('status', 1)->count();
            $stat['redirect'] = (int)Db::name('redirect')->where('status', 1)->count();
        } catch (\Throwable $e) {
            // 忽略
        }

        // 最近缺少 SEO 描述的内容，方便批量补
        $missing = [];
        try {
            $missing = Db::name('content')
                ->where('status', 1)
                ->where('seo_description', '')
                ->order('id desc')
                ->limit(10)
                ->field('id,title,lang,slug,sort_id')
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            $missing = [];
        }

        return $this->view('seo/index', [
            'meta_title'    => 'SEO 工具',
            'cache'         => $cache,
            'stat'          => $stat,
            'missing'       => $missing,
            'langs'         => Lang::all(),
            'domain'        => (string)Settings::get('site_domain', $this->request->domain()),
            'htmlCacheOn'   => HtmlCache::enabled(),
            'sitemapEnable' => Settings::get('sitemap_enable', '1') === '1',
            'indexnowOn'    => IndexNow::enabled(),
            'indexnowKey'   => IndexNow::enabled() ? IndexNow::key() : '',
            'noTdk'         => $stat['no_title'] + $stat['no_seo'],
        ]);
    }

    /**
     * 清空静态化缓存
     */
    public function clearCache()
    {
        $count = HtmlCache::clear();
        // 版权审计缓存一并清掉，改完页脚/主题后提示立即刷新
        \app\common\library\Brand::forget();

        return $this->ok('已清理 ' . $count . ' 个缓存文件');
    }

    /**
     * 开关静态化
     */
    public function toggleCache()
    {
        $on = (int)$this->request->param('enable', 0) === 1;
        Settings::set('html_cache', $on ? '1' : '0', 'seo');
        HtmlCache::clear();

        return $this->ok($on ? '静态化已开启' : '静态化已关闭');
    }

    /**
     * 预热静态化：把所有栏目页与详情页生成一遍
     */
    public function warmup()
    {
        $count = 0;
        $base  = rtrim((string)Settings::get('site_domain', ''), '/');
        if ($base === '') {
            return $this->fail('请先到「站点设置」填写站点域名，预热需要用它拼接完整地址');
        }

        // 预热只做本机请求，不阻塞太久
        $urls = ['/'];
        try {
            $sorts = Db::name('sort')->where('status', 1)->where('type', '<>', 'link')->select()->toArray();
            foreach ($sorts as $sort) {
                $urls[] = '/' . $sort['slug'] . ($sort['type'] === 'page' ? '.html' : '/');
            }
        } catch (\Throwable $e) {
            // 忽略
        }

        foreach (array_slice($urls, 0, 50) as $url) {
            $ch = curl_init($base . $url);
            if ($ch === false) {
                continue;
            }
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 5,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => false,
            ]);
            curl_exec($ch);
            curl_close($ch);
            $count++;
        }

        return $this->ok('已预热 ' . $count . ' 个页面');
    }

    /**
     * TDK 一键补全：批量给缺 SEO 标题/描述的内容自动生成
     * 每次最多 100 条，前端循环调用直到补完，避免超时
     */
    public function fillTdk()
    {
        $rows = Db::name('content')
            ->where('status', 1)
            ->where(function ($q) {
                $q->whereOr('seo_title', '')->whereOr('seo_description', '');
            })
            ->field('id,title,summary,content,seo_title,seo_description')
            ->order('id asc')
            ->limit(100)
            ->select()
            ->toArray();

        $done = 0;
        foreach ($rows as $row) {
            $data = [];
            if ((string)$row['seo_title'] === '') {
                $data['seo_title'] = tw_cut((string)$row['title'], 60);
            }
            if ((string)$row['seo_description'] === '') {
                $src = (string)$row['summary'] !== '' ? (string)$row['summary'] : (string)$row['content'];
                $data['seo_description'] = tw_cut($src, 160, '...');
            }
            if ($data) {
                $data['updatetime'] = time();
                Db::name('content')->where('id', (int)$row['id'])->update($data);
                $done++;
            }
        }

        if ($done > 0) {
            HtmlCache::clear();
        }

        // 剩余待补条数
        $remaining = (int)Db::name('content')
            ->where('status', 1)
            ->where(function ($q) {
                $q->whereOr('seo_title', '')->whereOr('seo_description', '');
            })
            ->count();

        return $this->ok('本轮补全 ' . $done . ' 条' . ($remaining > 0 ? '，还剩 ' . $remaining . ' 条' : ''), ['remaining' => $remaining]);
    }

    /**
     * 存量图片批量转 WebP：扫描 uploads 下的 jpg/jpeg/png
     * 每批 20 张，前端循环调用直到 remaining=0
     */
    public function webpScan()
    {
        if (!(bool)config('tw.image.webp', true) || !function_exists('imagewebp')) {
            return $this->fail('服务器 GD 不支持 WebP，请在 PHP 里启用 webp 扩展');
        }

        $dir = public_path() . 'uploads';
        if (!is_dir($dir)) {
            return $this->ok('没有 uploads 目录', ['remaining' => 0, 'done' => 0]);
        }

        // 找出还没有同名 .webp 的位图
        $it   = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
        $todo = [];
        foreach ($it as $f) {
            /** @var \SplFileInfo $f */
            if (!$f->isFile()) {
                continue;
            }
            $ext = strtolower($f->getExtension());
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'bmp'], true)) {
                continue;
            }
            $webp = preg_replace('/\.[a-zA-Z0-9]+$/', '.webp', $f->getPathname());
            if (!is_file($webp)) {
                $todo[] = $f->getPathname();
            }
        }

        $batch = array_slice($todo, 0, 20);
        $done  = 0;
        foreach ($batch as $abs) {
            $rel = 'uploads/' . str_replace('\\', '/', ltrim(substr($abs, strlen($dir)), '/\\'));
            $webp = ImageTool::toWebp($abs, $rel);
            if ($webp !== null) {
                ImageTool::makeSizes($abs, $rel);
                $done++;
            }
        }

        $remaining = max(0, count($todo) - count($batch));

        if ($done > 0) {
            HtmlCache::clear();
        }

        return $this->ok($done > 0 ? '本轮转换 ' . $done . ' 张' : '没有需要转换的图片', [
            'remaining' => $remaining,
            'done'      => $done,
        ]);
    }

    /**
     * IndexNow 开关
     */
    public function toggleIndexNow()
    {
        $on = (int)$this->request->param('enable', 0) === 1;
        Settings::set('indexnow_enable', $on ? '1' : '0', 'seo');
        if ($on) {
            IndexNow::key();          // 生成密钥
            IndexNow::writeKeyFile(); // 立即落 key 文件
        }

        return $this->ok($on ? 'IndexNow 已开启，密钥文件已写入站点根目录' : 'IndexNow 已关闭');
    }

    /**
     * IndexNow 手动全量推送
     */
    public function pushAll()
    {
        if (!IndexNow::enabled()) {
            return $this->fail('请先开启 IndexNow 推送');
        }

        $count = IndexNow::pushAll();
        if ($count <= 0) {
            return $this->fail('推送失败，请检查站点域名设置与网络（已写入 runtime 日志）');
        }

        return $this->ok('已推送 ' . $count . ' 个 URL 到 IndexNow（Bing/Yandex 等）');
    }
}
