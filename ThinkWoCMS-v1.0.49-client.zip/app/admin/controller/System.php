<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\License;
use app\common\library\Settings;
use app\common\library\Updater;

/**
 * 授权与在线更新
 *
 * 自用版（edition=self）同样显示本页，方便换机器时看到版本与升级状态。
 */
class System extends Backend
{
    /**
     * 授权状态
     */
    public function license()
    {
        $st = License::state(true);

        $pub = (string)config('license.public_key', '');
        $fp  = $pub !== '' ? strtoupper(substr(md5($pub), 0, 16)) : '';

        // 拍平授权体，模板只取确定存在的键，避免缺键报错
        $d    = (array)($st['data'] ?? []);
        $info = [
            'license_id' => (string)($d['license_id'] ?? '-'),
            'customer'   => (string)($d['customer'] ?? '-'),
            'issued_txt' => !empty($d['issued_at']) ? date('Y-m-d', (int)$d['issued_at']) : '-',
            'expire_txt' => (string)$st['expire_txt'],
            'update_txt' => (string)$st['update_txt'],
            'note'       => (string)($d['note'] ?? ''),
        ];

        return $this->view('system/license', [
            'meta_title' => '授权',
            'st'         => $st,
            'info'       => $info,
            'api'        => License::api(),
            'is_client'  => License::isClient(),
            'version'    => (string)config('tw.version', ''),
            'fp'         => trim(chunk_split($fp, 4, ' ')),
            'grace'      => (int)config('license.grace_days', 30),
            'build'      => $this->buildInfo(),
        ]);
    }

    /**
     * 构建信息（水印）
     *
     * 每份客户包在构建时写入 CUSTOMER / FINGERPRINT，
     * 外泄时按这两个值即可定位到具体是哪一份。
     */
    protected function buildInfo(): array
    {
        $cls  = 'app\\common\\library\\Build';
        $sign = 'app\\common\\library\\Signature';

        $serial = class_exists($sign) ? (string)constant($sign . '::SERIAL') : '';

        if (!class_exists($cls)) {
            return ['ok' => false, 'serial' => $serial];
        }

        $fp = (string)constant($cls . '::FINGERPRINT');

        return [
            'ok'       => true,
            'customer' => (string)constant($cls . '::CUSTOMER'),
            'build_id' => (string)constant($cls . '::BUILD_ID'),
            'built_at' => (string)constant($cls . '::BUILT_AT'),
            'fp'       => $fp !== '' ? trim(chunk_split($fp, 4, ' ')) : '',
            'php'      => (string)constant($cls . '::TARGET_PHP'),
            'encoded'  => (bool)constant($cls . '::ENCODED'),
            'serial'   => $serial,
        ];
    }

    /**
     * 用授权码激活
     */
    public function activate()
    {
        if (!$this->request->isPost()) {
            return json(['code' => 0, 'msg' => '请求方式错误']);
        }

        $code = (string)$this->request->post('code', '');
        $res  = License::activate($code);

        if (($res['code'] ?? 0) === 1) {
            Settings::flush();
        }

        return json($res);
    }

    /**
     * 刷新授权（续期后同步到期时间）
     */
    public function refresh()
    {
        if (!$this->request->isPost()) {
            return json(['code' => 0, 'msg' => '请求方式错误']);
        }
        return json(License::refresh());
    }

    /**
     * 解绑本机授权文件
     */
    public function unbind()
    {
        if (!$this->request->isPost()) {
            return json(['code' => 0, 'msg' => '请求方式错误']);
        }
        License::clear();
        Settings::flush();
        return json(['code' => 1, 'msg' => '已清除本机授权文件']);
    }

    /**
     * 保存授权站地址
     */
    public function saveApi()
    {
        if (!$this->request->isPost()) {
            return json(['code' => 0, 'msg' => '请求方式错误']);
        }

        $api = trim((string)$this->request->post('api', ''));
        if ($api !== '' && !preg_match('#^https?://[^\s]+$#i', $api)) {
            return json(['code' => 0, 'msg' => '请填写完整地址，含 http:// 或 https://']);
        }

        Settings::set('license_api', rtrim($api, '/'), 'system');
        Settings::flush();

        return json(['code' => 1, 'msg' => '已保存']);
    }

    /**
     * 在线更新页
     */
    public function update()
    {
        $st = License::state(true);
        $at = (int)Settings::get('last_update_at', 0);

        return $this->view('system/update', [
            'meta_title'  => '在线更新',
            'st'          => $st,
            'version'     => (string)config('tw.version', ''),
            'last_ver'    => (string)Settings::get('last_update_ver', ''),
            'last_at_txt' => $at > 0 ? date('Y-m-d H:i', $at) : '',
            'api'         => License::api(),
            'zip'         => class_exists('PharData') || class_exists('ZipArchive'),
        ]);
    }

    /**
     * 检查更新（AJAX）
     */
    public function check()
    {
        if (!$this->request->isPost()) {
            return json(['code' => 0, 'msg' => '请求方式错误']);
        }
        try {
            return json(Updater::check());
        } catch (\Throwable $e) {
            return json(['code' => 0, 'msg' => '检查更新异常：' . $e->getMessage() . ' @ ' . basename((string)$e->getFile()) . ':' . $e->getLine()]);
        }
    }

    /**
     * 执行更新（AJAX）
     */
    public function install()
    {
        if (!$this->request->isPost()) {
            return json(['code' => 0, 'msg' => '请求方式错误']);
        }

        $version = (string)$this->request->post('version', '');
        try {
            $res = Updater::install($version);
        } catch (\Throwable $e) {
            // 任何意外异常都转成可读 JSON，前端不会再显示「网络中断」
            $res = ['code' => 0,
                'msg' => '更新过程出现异常：' . $e->getMessage()
                    . '（' . basename((string)$e->getFile()) . ':' . $e->getLine() . '）'];
        }

        return json($res);
    }
}
