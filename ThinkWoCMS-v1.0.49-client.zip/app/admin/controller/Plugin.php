<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\Plugin as PluginManager;
use app\common\library\PluginLicense;
use app\common\library\PluginUpgrade;
use think\facade\Db;

/**
 * 插件管理
 *
 * 插件分两类，规则完全不同：
 *  - 云端插件（授权站下发的，目录里有 .cloud 标记）：只能从云端安装/升级，不能卸载，
 *    受授权端「启用开关 + 开通 + 到期时间」约束
 *  - 本地插件（自己上传或手工放进去的）：只能后台手动上传新包升级，可卸载
 *
 * 除了启停、配置、上传、卸载，还负责「在线升级」：进页面即比对授权站版本，
 * 有更新的插件行上直接出「升级」按钮，按版本顺序逐级升级（不跳版）。
 */
class Plugin extends Backend
{
    /**
     * 检查更新 / 升级 / 卸载 / 上传 / 云端安装只校验登录，不单独配权限规则
     */
    protected array $noNeedRight = ['check', 'upgrade', 'uninstall', 'upload', 'install'];

    public function index()
    {
        $scanned = PluginManager::scan();

        $rows = [];
        try {
            $db = Db::name('plugin')->select()->toArray();
        } catch (\Throwable $e) {
            $db = [];
        }

        $dbMap = [];
        foreach ($db as $row) {
            $dbMap[(string)$row['name']] = $row;
        }

        $isSelf = PluginLicense::isSelf();

        foreach ($scanned as $name => $manifest) {
            $row     = $dbMap[$name] ?? [];
            $source  = PluginManager::source($name);
            $cloud   = $source === 'cloud' ? PluginLicense::of($name) : null;
            $locked  = $source === 'cloud' && PluginManager::isLocked($name);
            $expired = $cloud ? (bool)$cloud['expired'] : false;
            $blocked = $cloud ? (!$cloud['active'] || !$cloud['authorized']) : false;

            // 启用按钮为什么点不了（空字符串=可以启用）
            $lockReason = '';
            if ($source === 'cloud') {
                if ($expired) {
                    $lockReason = '授权已于 ' . $cloud['expire_txt'] . ' 到期，到期后不能启用，请续费';
                } elseif ($locked) {
                    $lockReason = '到期后已停用并锁定，续费（授权到期时间往后延）后才能启用';
                } elseif (!$cloud['active']) {
                    $lockReason = '授权端已停用该插件，客户站不能启用';
                } elseif (!$cloud['authorized']) {
                    $lockReason = '本站未开通该插件，请先联系服务商开通';
                }
            }

            $rows[] = [
                'name'        => $name,
                'title'       => (string)($manifest['title'] ?? $name),
                'version'     => (string)($manifest['version'] ?? '1.0.0'),
                'author'      => (string)($manifest['author'] ?? ''),
                'description' => (string)($manifest['description'] ?? ''),
                'homepage'    => (string)($manifest['homepage'] ?? ''),
                'status'      => (int)($row['status'] ?? 0),
                'has_config'  => is_file(PluginManager::path($name) . 'config.php') ? 1 : 0,
                'installed'   => $row ? 1 : 0,
                'source'      => $source,                                  // cloud | local
                'price'       => $cloud ? (string)$cloud['price_text'] : '',  // 云端价格（空=本地）
                'expire'      => $cloud ? (string)$cloud['expire_txt'] : '',
                'expired'     => $expired ? 1 : 0,
                'locked'      => $locked ? 1 : 0,
                'active'      => $cloud ? ($cloud['active'] ? 1 : 0) : 1,        // 授权端是否启用
                'authorized'  => $cloud ? ($cloud['authorized'] ? 1 : 0) : 1,
                'cloud_blocked' => $blocked ? 1 : 0,                       // 云端不允许使用（未启用/未开通）
                'lock_reason' => $lockReason,
                'can_uninstall' => $source === 'local' ? 1 : 0,
                'note'        => $cloud ? PluginLicense::note($name) : '',
            ];
        }

        // 云端插件排前面（客户日常基本只碰云端），同类按名称排
        usort($rows, static function (array $a, array $b): int {
            if ($a['source'] !== $b['source']) {
                return $a['source'] === 'cloud' ? -1 : 1;
            }

            return strcmp($a['name'], $b['name']);
        });

        // 上次检查结果还在有效期内就直接渲染出来，进页面不用等
        $updates   = [];
        $checkedAt = '';
        $cacheFile = PluginUpgrade::workDir() . 'remote.json';
        if (is_file($cacheFile)) {
            $c = json_decode((string)@file_get_contents($cacheFile), true);
            if (is_array($c) && time() - (int)($c['at'] ?? 0) < PluginUpgrade::CACHE_TTL) {
                $updates   = PluginUpgrade::compare((array)($c['packages'] ?? []));
                $checkedAt = date('Y-m-d H:i', (int)$c['at']);
            }
        }

        $status = PluginUpgrade::status();

        return $this->view('plugin/index', [
            'meta_title'    => '插件管理',
            'rows'          => $rows,
            'pluginDir'     => PluginManager::path(),
            'updates_json'  => (string)json_encode(array_values($updates), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP),
            'updates_count' => count($updates),
            'checked_at'    => $checkedAt,
            'api'           => (string)$status['api'],
            'unzip'         => (string)$status['unzip'],
            'writable'      => (bool)$status['writable'],
            'licensed'      => (bool)$status['licensed'],
            'license_note'  => (string)$status['reason'],
            'is_self'       => $isSelf,
        ]);
    }

    /**
     * 启用 / 停用
     */
    public function toggle()
    {
        $name   = (string)$this->request->param('name', '');
        $enable = (int)$this->request->param('enable', 0) === 1;

        if ($name === '') {
            return $this->fail('参数错误');
        }

        $res = PluginManager::toggle($name, $enable);

        return $res['ok'] ? $this->ok($res['msg']) : $this->fail($res['msg']);
    }

    /**
     * 检查插件更新：向授权站拉签名清单，比对本机版本
     *
     * force=1 强制联网刷新（点按钮时用），force=0 走 10 分钟缓存（进页面自动检查用）
     * name 指定时只返回这一个插件的结果（行内「更新」按钮用）
     */
    public function check()
    {
        if (!$this->request->isPost()) {
            return $this->fail('请求方式错误');
        }

        $force = (int)$this->request->post('force', 1) === 1;
        $name  = (string)$this->request->post('name', '');

        try {
            $r = PluginUpgrade::remote($force);
        } catch (\Throwable $e) {
            return $this->fail('检查失败：' . $e->getMessage());
        }

        if (($r['code'] ?? 0) !== 1) {
            return $this->fail((string)($r['msg'] ?? '检查失败'));
        }

        $updates = PluginUpgrade::compare((array)($r['packages'] ?? []));
        $checked = date('Y-m-d H:i', (int)($r['at'] ?? time()));

        if ($name !== '') {
            $locals = PluginUpgrade::locals();
            if (!isset($locals[$name])) {
                return $this->fail('本机没有安装插件 ' . $name);
            }
            $one = $updates[$name] ?? null;

            return $this->ok($one ? '发现新版本' : '已是最新版本', [
                'name'       => $name,
                'update'     => $one,
                'updates'    => $one ? [$one] : [],
                'local'      => (string)$locals[$name]['version'],
                'count'      => $one ? 1 : 0,
                'checked_at' => $checked,
            ]);
        }

        return $this->ok('检查完成', [
            'updates'    => array_values($updates),
            'count'      => count($updates),
            'checked_at' => $checked,
        ]);
    }

    /**
     * 升级单个插件（按授权站下发的版本链逐级安装）
     */
    public function upgrade()
    {
        if (!$this->request->isPost()) {
            return $this->fail('请求方式错误');
        }

        $name = (string)$this->request->post('name', '');
        if ($name === '') {
            return $this->fail('缺少插件名');
        }

        // 两类插件升级通道严格分开
        if (PluginManager::source($name) === 'local') {
            return $this->fail('本地插件不走云端升级，请点该行的「上传升级包」手动升级');
        }
        if (!PluginLicense::canUpgrade($name)) {
            $st = PluginLicense::of($name);
            if ($st['expired']) {
                return $this->fail('插件授权已于 ' . $st['expire_txt'] . ' 到期，可继续使用但不能升级，续费后恢复');
            }
            return $this->fail('该插件当前不可升级（授权端停用或本站未开通）');
        }

        try {
            // 包信息只信授权站签名清单，不信前端传的版本
            $r = PluginUpgrade::remote(false);
            if (($r['code'] ?? 0) !== 1) {
                return $this->fail((string)($r['msg'] ?? '获取清单失败'));
            }

            $pkg = null;
            foreach ((array)($r['packages'] ?? []) as $p) {
                if ((string)($p['name'] ?? '') === $name) {
                    $pkg = $p;
                    break;
                }
            }
            if ($pkg === null) {
                return $this->fail('没有找到该插件的更新，可能已是最新版本；可点「检查更新」重新核对一次');
            }

            // 先把链条按本机当前版本过滤一遍，缺包/已最新都在这里拦掉
            $locals  = PluginUpgrade::locals();
            $current = (string)($locals[$name]['version'] ?? '');
            $steps   = PluginUpgrade::chainOf($pkg, $current);
            if (!$steps) {
                $need = (string)($pkg['blocked']['need'] ?? '');
                if ($need !== '') {
                    return $this->fail('缺少 v' . $need . ' 的安装包，无法从 v' . $current . ' 按顺序升级，请联系服务商补齐');
                }
                return $this->fail('当前已是 v' . $current . '，无需升级');
            }

            $res = PluginUpgrade::install($pkg);
        } catch (\Throwable $e) {
            return $this->fail('升级失败：' . $e->getMessage());
        }

        if (($res['code'] ?? 0) !== 1) {
            return $this->fail((string)($res['msg'] ?? '升级失败'), [
                'name' => $name,
                'from' => (string)($res['from'] ?? ''),
                'to'   => (string)($res['to'] ?? ''),
            ]);
        }

        return $this->ok((string)$res['msg'], [
            'name'  => $name,
            'from'  => (string)($res['from'] ?? ''),
            'to'    => (string)($res['to'] ?? ''),
            'steps' => (int)($res['steps'] ?? 1),
            'done'  => (array)($res['done'] ?? []),
        ]);
    }

    /**
     * 卸载插件
     *
     * 备份插件目录 → 删文件 → 删菜单与插件记录 → 删桥接控制器 → 清缓存。
     * 插件自建的数据表保留，避免误删客户内容。
     */
    public function uninstall()
    {
        if (!$this->request->isPost()) {
            return $this->fail('请求方式错误');
        }

        $name = (string)$this->request->post('name', '');
        if ($name === '') {
            return $this->fail('缺少插件名');
        }

        try {
            $res = PluginManager::uninstall($name);
        } catch (\Throwable $e) {
            return $this->fail('卸载失败：' . $e->getMessage());
        }

        return $res['ok'] ? $this->ok($res['msg'], ['backup' => (string)($res['backup'] ?? '')])
            : $this->fail($res['msg']);
    }

    /**
     * 上传本地插件包（安装或升级本地插件）
     *
     * 只给本地插件用；包内结构必须 plugins/{插件名}/plugin.json。
     * 云端插件不允许被本地包覆盖（会绕过云端授权），由 installLocal 拦掉。
     */
    public function upload()
    {
        if (!$this->request->isPost()) {
            return $this->fail('请求方式错误');
        }

        $file = $this->request->file('file');
        if (!$file) {
            return $this->fail('请选择插件包（.zip）');
        }

        $ext = strtolower((string)pathinfo((string)$file->getOriginalName(), PATHINFO_EXTENSION));
        if ($ext !== 'zip') {
            return $this->fail('插件包必须是 .zip');
        }
        if ((int)$file->getSize() > PluginUpgrade::MAX_MB * 1048576) {
            return $this->fail('插件包超过 ' . PluginUpgrade::MAX_MB . 'MB');
        }

        try {
            $res = PluginUpgrade::installLocal((string)$file->getPathname());
        } catch (\Throwable $e) {
            return $this->fail('安装失败：' . $e->getMessage());
        }

        if (($res['code'] ?? 0) !== 1) {
            return $this->fail((string)($res['msg'] ?? '安装失败'));
        }

        return $this->ok((string)$res['msg'], [
            'name' => (string)($res['name'] ?? ''),
            'from' => (string)($res['from'] ?? ''),
            'to'   => (string)($res['to'] ?? ''),
        ]);
    }

    /**
     * 从云端首次安装插件（只认授权站下发、且标了可安装的包）
     */
    public function install()
    {
        if (!$this->request->isPost()) {
            return $this->fail('请求方式错误');
        }

        $name = (string)$this->request->post('name', '');
        if ($name === '') {
            return $this->fail('缺少插件名');
        }

        try {
            $r = PluginUpgrade::remote(false);
            if (($r['code'] ?? 0) !== 1) {
                return $this->fail((string)($r['msg'] ?? '获取清单失败'));
            }

            $pkg = null;
            foreach ((array)($r['packages'] ?? []) as $p) {
                if ((string)($p['name'] ?? '') === $name) {
                    $pkg = $p;
                    break;
                }
            }
            if ($pkg === null) {
                return $this->fail('授权站没有下发该插件的安装包，可能未开通、已停用或已下架');
            }

            $res = PluginUpgrade::install($pkg);
        } catch (\Throwable $e) {
            return $this->fail('安装失败：' . $e->getMessage());
        }

        if (($res['code'] ?? 0) !== 1) {
            return $this->fail((string)($res['msg'] ?? '安装失败'), ['name' => $name]);
        }

        return $this->ok((string)$res['msg'], [
            'name' => $name,
            'to'   => (string)($res['to'] ?? ''),
        ]);
    }

    /**
     * 读取配置项定义
     */
    public function config()
    {
        $name = (string)$this->request->param('name', '');
        if ($name === '') {
            return $this->fail('参数错误');
        }

        $file = PluginManager::path($name) . 'config.php';
        if (!is_file($file)) {
            return $this->fail('该插件没有可配置项');
        }

        $fields = include $file;
        if (!is_array($fields)) {
            return $this->fail('插件配置定义格式错误');
        }

        return $this->ok('ok', [
            'fields' => $fields,
            'values' => PluginManager::config($name),
        ]);
    }

    /**
     * 保存插件配置
     */
    public function saveConfig()
    {
        $name = (string)$this->request->param('name', '');
        if ($name === '') {
            return $this->fail('参数错误');
        }

        $file = PluginManager::path($name) . 'config.php';
        if (!is_file($file)) {
            return $this->fail('该插件没有可配置项');
        }

        $fields = include $file;
        $post   = $this->request->post();
        $values = [];

        foreach ((array)$fields as $field) {
            $key = (string)($field['key'] ?? '');
            if ($key === '') {
                continue;
            }
            $values[$key] = $post[$key] ?? ($field['default'] ?? '');
        }

        PluginManager::saveConfig($name, $values);

        return $this->ok('配置已保存');
    }
}
