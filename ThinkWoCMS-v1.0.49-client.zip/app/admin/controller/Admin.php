<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\Auth;
use app\common\library\Menu;
use think\facade\Db;

/**
 * 管理员与角色组
 */
class Admin extends Backend
{
    /**
     * 管理员列表
     */
    public function index()
    {
        $rows = [];
        try {
            $rows = Db::name('admin')->order('id asc')->select()->toArray();
        } catch (\Throwable $e) {
            $rows = [];
        }

        $groups = [];
        foreach (Db::name('admin_group')->select()->toArray() as $group) {
            $groups[(int)$group['id']] = (string)$group['name'];
        }

        foreach ($rows as &$row) {
            $row['group_name'] = $groups[(int)$row['group_id']] ?? '-';
            $row['last']       = $row['login_time'] ? date('Y-m-d H:i', (int)$row['login_time']) : '从未登录';
        }
        unset($row);

        return $this->view('admin/index', [
            'meta_title' => '管理员',
            'rows'       => $rows,
            'groups'     => $groups,
        ]);
    }

    /**
     * 表单
     */
    public function form()
    {
        $id  = (int)$this->request->param('id', 0);
        $row = [];

        if ($id > 0) {
            $row = Db::name('admin')->where('id', $id)->find();
            if (!$row) {
                return $this->fail('管理员不存在');
            }
            unset($row['password']);
        }

        $groups = Db::name('admin_group')->where('status', 1)->select()->toArray();

        return $this->view('admin/form', [
            'meta_title' => $id > 0 ? '编辑管理员' : '添加管理员',
            'row'        => $row,
            'id'         => $id,
            'groups'     => $groups,
        ]);
    }

    /**
     * 保存管理员
     */
    public function save()
    {
        $post = $this->request->post();
        $id   = (int)($post['id'] ?? 0);

        $username = trim((string)($post['username'] ?? ''));
        $password = (string)($post['password'] ?? '');

        if ($username === '') {
            return $this->fail('账号不能为空');
        }
        if (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $username)) {
            return $this->fail('账号只能包含字母数字下划线，长度 3~30');
        }

        $exists = Db::name('admin')->where('username', $username)->where('id', '<>', $id)->find();
        if ($exists) {
            return $this->fail('该账号已存在');
        }

        $data = [
            'username'   => $username,
            'group_id'   => (int)($post['group_id'] ?? 1),
            'nickname'   => (string)($post['nickname'] ?? $username),
            'email'      => (string)($post['email'] ?? ''),
            'status'     => (int)($post['status'] ?? 1) === 1 ? 1 : 0,
            'updatetime' => time(),
        ];

        if ($password !== '') {
            if (strlen($password) < 6) {
                return $this->fail('密码至少 6 位');
            }
            $data['password'] = Auth::hashPassword($password);
            $data['salt']     = '';
        } elseif ($id <= 0) {
            return $this->fail('新增管理员必须设置密码');
        }

        if ($id > 0) {
            if ($id === Auth::id() && (int)$data['status'] === 0) {
                return $this->fail('不能禁用自己');
            }
            Db::name('admin')->where('id', $id)->update($data);
        } else {
            $data['createtime'] = time();
            Db::name('admin')->insert($data);
        }

        return $this->okJump('保存成功', '/admin.php/admin/index');
    }

    /**
     * 删除管理员
     */
    public function delete()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }
        if ($id === Auth::id()) {
            return $this->fail('不能删除自己');
        }
        if (Db::name('admin')->count() <= 1) {
            return $this->fail('至少要保留一个管理员');
        }

        Db::name('admin')->where('id', $id)->delete();

        return $this->ok('已删除');
    }

    /**
     * 角色组
     */
    public function group()
    {
        $rows = [];
        try {
            $rows = Db::name('admin_group')->order('id asc')->select()->toArray();
        } catch (\Throwable $e) {
            $rows = [];
        }

        foreach ($rows as &$row) {
            $row['is_super'] = (string)$row['rules'] === '*' ? 1 : 0;
            $row['count']    = (int)Db::name('admin')->where('group_id', $row['id'])->count();
            $row['rule_count'] = $row['is_super'] ? 0 : count(array_filter(explode(',', (string)$row['rules'])));
        }
        unset($row);

        $tree = Menu::flatOptions();

        return $this->view('admin/group', [
            'meta_title' => '角色组',
            'rows'       => $rows,
            'rules'      => $tree,
        ]);
    }

    /**
     * 保存角色组
     */
    public function saveGroup()
    {
        $post = $this->request->post();
        $id   = (int)($post['id'] ?? 0);

        $name = trim((string)($post['name'] ?? ''));
        if ($name === '') {
            return $this->fail('角色名称不能为空');
        }

        $rules = $post['rules'] ?? [];
        if (is_array($rules) && in_array('*', $rules, true)) {
            $rulesStr = '*';
        } else {
            $ids      = array_filter(array_map('intval', (array)$rules));
            $rulesStr = implode(',', array_unique($ids));
        }

        $data = [
            'name'   => $name,
            'rules'  => $rulesStr,
            'remark' => (string)($post['remark'] ?? ''),
            'status' => (int)($post['status'] ?? 1) === 1 ? 1 : 0,
        ];

        if ($id === 1 && $rulesStr !== '*') {
            return $this->fail('超级管理员角色的权限不能被修改');
        }

        if ($id > 0) {
            Db::name('admin_group')->where('id', $id)->update($data);
        } else {
            $data['createtime'] = time();
            Db::name('admin_group')->insert($data);
        }

        return $this->okJump('保存成功', '/admin.php/admin/group');
    }

    /**
     * 删除角色组
     */
    public function deleteGroup()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 1) {
            return $this->fail('内置角色不能删除');
        }
        if (Db::name('admin')->where('group_id', $id)->count() > 0) {
            return $this->fail('该角色下还有管理员，请先调整');
        }

        Db::name('admin_group')->where('id', $id)->delete();

        return $this->ok('已删除');
    }
}
