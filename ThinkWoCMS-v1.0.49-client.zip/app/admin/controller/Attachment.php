<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\ImageTool;
use think\facade\Db;

/**
 * 附件管理
 */
class Attachment extends Backend
{
    /**
     * 上传 / 媒体库列表：所有能进后台的人都要能用（下拉菜单里没有独立权限项）
     */
    protected array $noNeedRight = ['upload', 'picker'];

    public function index()
    {
        [$page, $limit] = $this->pageParam(24, 120);

        $ext     = (string)$this->request->param('ext', '');
        $keyword = trim((string)$this->request->param('keyword', ''));

        $build = function () use ($ext, $keyword) {
            $q = Db::name('attachment');
            if ($ext !== '') {
                $q->where('ext', $ext);
            }
            if ($keyword !== '') {
                $q->whereLike('name', '%' . $keyword . '%');
            }

            return $q;
        };

        $total = 0;
        $rows  = [];
        try {
            $total = (int)$build()->count();
            $rows  = $build()->order('id desc')->page($page, $limit)->select()->toArray();
        } catch (\Throwable $e) {
            $total = 0;
            $rows  = [];
        }

        foreach ($rows as &$row) {
            $row['size_text'] = $this->sizeText((int)$row['size']);
            $row['is_image'] = in_array($row['ext'], ImageTool::IMAGE_EXTS, true) ? 1 : 0;
            $row['thumb']    = $this->thumbOf($row);
        }
        unset($row);

        return $this->view('attachment/index', [
            'meta_title' => '附件管理',
            'rows'       => $rows,
            'total'      => $total,
            'page'       => $page,
            'limit'      => $limit,
            'ext'        => $ext,
            'keyword'    => $keyword,
        ]);
    }

    /**
     * 媒体库列表（AJAX，供后台各处的「选择已上传文件」使用）
     *
     * 参数：page / limit / keyword / ext（image=只看图片，空或 all=全部）
     */
    public function picker()
    {
        [$page, $limit] = $this->pageParam(30, 60);

        $ext     = strtolower(trim((string)$this->request->param('ext', 'image')));
        $keyword = trim((string)$this->request->param('keyword', ''));

        $build = function () use ($ext, $keyword) {
            $q = Db::name('attachment');
            if ($ext === 'image') {
                $q->whereIn('ext', ImageTool::IMAGE_EXTS);
            } elseif ($ext !== '' && $ext !== 'all') {
                $q->where('ext', $ext);
            }
            if ($keyword !== '') {
                $q->whereLike('name', '%' . $keyword . '%');
            }

            return $q;
        };

        $total = 0;
        $rows  = [];
        try {
            $total = (int)$build()->count();
            $rows  = $build()->order('id desc')->page($page, $limit)->select()->toArray();
        } catch (\Throwable $e) {
            $total = 0;
            $rows  = [];
        }

        foreach ($rows as &$row) {
            $row['is_image']  = in_array(strtolower((string)$row['ext']), ImageTool::IMAGE_EXTS, true) ? 1 : 0;
            $row['size_text'] = $this->sizeText((int)$row['size']);
            $row['thumb']     = $this->thumbOf($row);
            $row['date']      = $row['createtime'] ? date('Y-m-d', (int)$row['createtime']) : '';
            unset($row['hash'], $row['mime'], $row['admin_id'], $row['path']);
        }
        unset($row);

        return $this->ok('ok', [
            'rows'     => $rows,
            'total'    => $total,
            'page'     => $page,
            'limit'    => $limit,
            'has_more' => $page * $limit < $total,
        ]);
    }

    /**
     * 文件大小文案
     */
    protected function sizeText(int $size): string
    {
        if ($size >= 1048576) {
            return round($size / 1048576, 2) . ' MB';
        }
        if ($size >= 1024) {
            return round($size / 1024, 1) . ' KB';
        }

        return $size . ' B';
    }

    /**
     * 取可用于列表展示的缩略图地址（400 宽 WebP → WebP → 原图）
     */
    protected function thumbOf(array $row): string
    {
        $url = (string)($row['url'] ?? '');
        if (!in_array(strtolower((string)($row['ext'] ?? '')), ImageTool::IMAGE_EXTS, true)) {
            return '';
        }

        $width = (int)config('tw.image.sizes.thumb', 400);
        if ($width > 0) {
            $thumbUrl = preg_replace('/\.[a-zA-Z0-9]+$/', '-' . $width . '.webp', $url);
            $thumbAbs = public_path() . ltrim((string)$thumbUrl, '/');
            if ($thumbUrl !== null && is_file($thumbAbs)) {
                return (string)$thumbUrl;
            }
        }

        $webp = (string)($row['webp'] ?? '');
        if ($webp !== '' && is_file(public_path() . ltrim($webp, '/'))) {
            return '/' . ltrim($webp, '/');
        }

        return $url;
    }

    /**
     * 上传（支持多文件）
     */
    public function upload()
    {
        $files = $this->request->file();
        if (empty($files)) {
            return $this->fail('没有收到文件');
        }

        $subdir = (string)$this->request->param('dir', '');
        $result = [];

        foreach ($files as $file) {
            $items = is_array($file) && isset($file[0]) ? $file : [$file];
            foreach ($items as $one) {
                if (!$one instanceof \think\file\UploadedFile) {
                    continue;
                }

                // TP8 的 UploadedFile 没有 getInfo()，这里手工还原 $_FILES 结构
                $info = [
                    'name'     => $one->getOriginalName(),
                    'tmp_name' => $one->getPathname(),
                    'size'     => (int)$one->getSize(),
                    'error'    => $one->isValid() ? 0 : 4,
                ];

                $res = ImageTool::upload($info, $subdir);
                if (!$res['ok']) {
                    return $this->fail($res['msg']);
                }

                $data = $res['data'];
                $data['admin_id']   = (int)session('tw_admin_id');
                $data['createtime'] = time();

                $id = (int)Db::name('attachment')->insertGetId($data);
                $data['id']       = $id;
                $data['thumb']    = $this->thumbOf($data);
                $data['is_image'] = in_array(strtolower((string)$data['ext']), ImageTool::IMAGE_EXTS, true) ? 1 : 0;
                $data['size_text'] = $this->sizeText((int)$data['size']);
                $data['date']     = date('Y-m-d');
                $result[]   = $data;
            }
        }

        \think\facade\Event::trigger('upload_after', $result);

        return $this->ok('上传成功', ['files' => $result, 'url' => $result[0]['url'] ?? '']);
    }

    /**
     * 删除
     */
    public function delete()
    {
        $ids = $this->request->post('ids/a', []);
        if (!$ids) {
            $ids = [(int)$this->request->param('id', 0)];
        }
        $ids = array_filter(array_map('intval', (array)$ids));
        if (!$ids) {
            return $this->fail('请选择文件');
        }

        foreach ($ids as $id) {
            $row = Db::name('attachment')->where('id', $id)->find();
            if (!$row) {
                continue;
            }

            $abs = public_path() . ltrim((string)$row['path'], '/');
            if (is_file($abs)) {
                @unlink($abs);
            }
            if (!empty($row['webp'])) {
                $webp = public_path() . ltrim((string)$row['webp'], '/');
                if (is_file($webp)) {
                    @unlink($webp);
                }
            }
            // 清理缩略图
            foreach ((array)config('tw.image.sizes', []) as $width) {
                $thumb = preg_replace('/\.[a-zA-Z0-9]+$/', '-' . (int)$width . '.webp', $abs);
                if ($thumb && is_file($thumb)) {
                    @unlink($thumb);
                }
            }

            Db::name('attachment')->where('id', $id)->delete();
        }

        return $this->ok('已删除 ' . count($ids) . ' 个文件');
    }
}
