<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\Mailer;
use app\common\library\Settings;
use think\facade\Db;

/**
 * 客户询盘
 */
class Inquiry extends Backend
{
    /**
     * 列表
     */
    public function index()
    {
        [$page, $limit] = $this->pageParam();

        $status  = (string)$this->request->param('status', '');
        $keyword = trim((string)$this->request->param('keyword', ''));
        $start   = (string)$this->request->param('start', '');
        $end     = (string)$this->request->param('end', '');

        $build = function () use ($status, $keyword, $start, $end) {
            $q = Db::name('inquiry');
            if ($status !== '') {
                $q->where('status', $status);
            }
            if ($keyword !== '') {
                $q->where(function ($sub) use ($keyword) {
                    $sub->whereLike('name', '%' . $keyword . '%')
                        ->whereOr('email', 'like', '%' . $keyword . '%')
                        ->whereOr('company', 'like', '%' . $keyword . '%')
                        ->whereOr('subject', 'like', '%' . $keyword . '%')
                        ->whereOr('no', 'like', '%' . $keyword . '%');
                });
            }
            if ($start !== '') {
                $q->where('createtime', '>=', (int)strtotime($start . ' 00:00:00'));
            }
            if ($end !== '') {
                $q->where('createtime', '<=', (int)strtotime($end . ' 23:59:59'));
            }

            return $q;
        };

        $total = 0;
        $rows  = [];
        try {
            $total = (int)$build()->count();
            $rows  = $build()->order('id desc')->page($page, $limit)->select()->toArray();
        } catch (\Throwable $e) {
            $total = 0;
            $rows  = [];
        }

        foreach ($rows as &$row) {
            $row['date']  = date('Y-m-d H:i', (int)$row['createtime']);
            $row['items'] = $row['items'] !== '' ? (array)json_decode((string)$row['items'], true) : [];
        }
        unset($row);

        $stat = ['new' => 0, 'total' => 0, 'today' => 0];
        try {
            $stat['new']   = (int)Db::name('inquiry')->where('status', 'new')->count();
            $stat['total'] = (int)Db::name('inquiry')->count();
            $stat['today'] = (int)Db::name('inquiry')->where('createtime', '>=', strtotime('today'))->count();
        } catch (\Throwable $e) {
            // 忽略
        }

        return $this->view('inquiry/index', [
            'meta_title' => '询盘列表',
            'rows'       => $rows,
            'total'      => $total,
            'page'       => $page,
            'limit'      => $limit,
            'status'     => $status,
            'keyword'    => $keyword,
            'start'      => $start,
            'end'        => $end,
            'stat'       => $stat,
        ]);
    }

    /**
     * 详情（返回 HTML 供弹层使用）
     */
    public function detail()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }

        $row = Db::name('inquiry')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('询盘不存在');
        }

        if ($row['status'] === 'new') {
            Db::name('inquiry')->where('id', $id)->update(['status' => 'read', 'updatetime' => time()]);
            $row['status'] = 'read';
        }

        $items = $row['items'] !== '' ? (array)json_decode((string)$row['items'], true) : [];

        $statusMap = [
            'new' => '新询盘', 'read' => '已读', 'quoted' => '已报价',
            'replied' => '已回复', 'won' => '已成交', 'closed' => '已关闭',
        ];

        $html = '<div class="tw-inq-detail">';
        $html .= '<table class="layui-table" lay-size="sm"><tbody>';
        foreach ([
            '编号' => $row['no'], '姓名' => $row['name'], '邮箱' => $row['email'],
            '电话' => $row['phone'], 'WhatsApp' => $row['whatsapp'], '公司' => $row['company'],
            '国家' => $row['country'], '语言' => $row['lang'], '来源' => $row['source_url'],
            '时间' => date('Y-m-d H:i:s', (int)$row['createtime']), 'IP' => $row['ip'],
        ] as $label => $value) {
            if ((string)$value === '') {
                continue;
            }
            $html .= '<tr><td style="width:90px;color:#999">' . tw_e($label) . '</td><td>'
                . tw_e((string)$value) . '</td></tr>';
        }
        $html .= '<tr><td style="color:#999">状态</td><td>' . tw_e($statusMap[$row['status']] ?? $row['status']) . '</td></tr>';
        $html .= '</tbody></table>';

        if ($row['product_name'] !== '') {
            $html .= '<p style="margin:10px 0"><b>产品：</b>' . tw_e((string)$row['product_name']) . '</p>';
        }

        if ($items) {
            $html .= '<table class="layui-table" lay-size="sm"><thead><tr><th>产品</th><th style="width:70px">数量</th><th style="width:90px">单价</th></tr></thead><tbody>';
            foreach ($items as $item) {
                $html .= '<tr><td>' . tw_e((string)($item['name'] ?? '')) . '</td><td>'
                    . (int)($item['qty'] ?? 1) . '</td><td>' . tw_e((string)($item['price'] ?? '')) . '</td></tr>';
            }
            $html .= '</tbody></table>';
        }

        $msgHtml = tw_e((string)$row['message']);
        // 附件路径转可点链接（询盘正文里的 --- Attachments --- 段）
        $msgHtml = preg_replace('~(https?://[^\s<]+|/uploads/[^\s<]+)~', '<a href="$1" target="_blank" rel="noopener">$1</a>', $msgHtml);

        $html .= '<div style="margin-top:12px"><b>内容：</b><div style="background:#f7f8fa;padding:12px;border-radius:6px;white-space:pre-wrap;margin-top:6px">'
            . $msgHtml . '</div></div>';

        $html .= '<div style="margin-top:16px"><label style="display:block;margin-bottom:6px;color:#666">跟进备注</label>'
            . '<textarea id="twRemark" class="layui-textarea" rows="3">' . tw_e((string)$row['remark']) . '</textarea></div>';

        $html .= '<div style="margin-top:12px;text-align:right">'
            . '<button class="layui-btn layui-btn-sm" onclick="twInqSave(' . $id . ')">保存备注</button>'
            . '<button class="layui-btn layui-btn-sm layui-btn-normal" onclick="twInqQuote(' . $id . ')">发送报价邮件</button>'
            . '</div></div>';

        return $this->ok('ok', ['html' => $html, 'data' => $row]);
    }

    /**
     * 保存状态 / 备注 / 优先级
     */
    public function save()
    {
        $post = $this->request->post();
        $id   = (int)($post['id'] ?? 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }

        $row = Db::name('inquiry')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('询盘不存在');
        }

        $data = ['updatetime' => time()];
        if (isset($post['status'])) {
            $allow = ['new', 'read', 'quoted', 'replied', 'won', 'closed'];
            if (in_array((string)$post['status'], $allow, true)) {
                $data['status'] = (string)$post['status'];
            }
        }
        if (isset($post['remark'])) {
            $data['remark'] = (string)$post['remark'];
        }
        if (isset($post['priority'])) {
            $data['priority'] = max(1, min(3, (int)$post['priority']));
        }
        $data['admin_id'] = (int)session('tw_admin_id');

        Db::name('inquiry')->where('id', $id)->update($data);

        return $this->ok('已保存');
    }

    /**
     * 发送报价邮件
     */
    public function quote()
    {
        $id     = (int)$this->request->param('id', 0);
        $content = (string)$this->request->post('content', '');

        $row = Db::name('inquiry')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('询盘不存在');
        }

        $body = $content !== '' ? nl2br(tw_e($content)) : '<p>Please find our quotation below.</p>';

        $res = Mailer::send(
            (string)$row['email'],
            'Quotation for your inquiry ' . $row['no'],
            Mailer::wrap('Quotation', $body),
            (string)$row['name']
        );

        if (!$res['ok']) {
            return $this->fail($res['msg']);
        }

        Db::name('inquiry')->where('id', $id)->update([
            'status'     => 'quoted',
            'updatetime' => time(),
            'admin_id'   => (int)session('tw_admin_id'),
        ]);

        return $this->ok('报价邮件已发送');
    }

    /**
     * 删除
     */
    public function delete()
    {
        $ids = $this->request->post('ids/a', []);
        if (!$ids) {
            $ids = [(int)$this->request->param('id', 0)];
        }
        $ids = array_filter(array_map('intval', (array)$ids));
        if (!$ids) {
            return $this->fail('请选择记录');
        }

        Db::name('inquiry')->whereIn('id', $ids)->delete();

        return $this->ok('已删除 ' . count($ids) . ' 条');
    }

    /**
     * 询价车记录
     */
    public function cart()
    {
        [$page, $limit] = $this->pageParam();

        $total = 0;
        $rows  = [];
        try {
            $total = (int)Db::name('cart')->count();
            $rows  = Db::name('cart')->order('id desc')->page($page, $limit)->select()->toArray();
        } catch (\Throwable $e) {
            $total = 0;
            $rows  = [];
        }

        foreach ($rows as &$row) {
            $row['date'] = date('Y-m-d H:i', (int)$row['createtime']);
        }
        unset($row);

        return $this->view('inquiry/cart', [
            'meta_title' => '询价车',
            'rows'       => $rows,
            'total'      => $total,
            'page'       => $page,
            'limit'      => $limit,
        ]);
    }
}
