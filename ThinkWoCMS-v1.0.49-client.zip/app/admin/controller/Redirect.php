<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\HtmlCache;
use think\facade\Db;

/**
 * 301 跳转管理
 */
class Redirect extends Backend
{
    public function index()
    {
        [$page, $limit] = $this->pageParam();

        $keyword = trim((string)$this->request->param('keyword', ''));

        $build = function () use ($keyword) {
            $q = Db::name('redirect');
            if ($keyword !== '') {
                $q->where(function ($sub) use ($keyword) {
                    $sub->whereLike('from_path', '%' . $keyword . '%')
                        ->whereOr('to_path', 'like', '%' . $keyword . '%');
                });
            }

            return $q;
        };

        $total = 0;
        $rows  = [];
        try {
            $total = (int)$build()->count();
            $rows  = $build()->order('id desc')->page($page, $limit)->select()->toArray();
        } catch (\Throwable $e) {
            $total = 0;
            $rows  = [];
        }

        foreach ($rows as &$row) {
            $row['date'] = date('Y-m-d H:i', (int)$row['createtime']);
        }
        unset($row);

        return $this->view('redirect/index', [
            'meta_title' => '301 跳转',
            'rows'       => $rows,
            'total'      => $total,
            'page'       => $page,
            'limit'      => $limit,
            'keyword'    => $keyword,
        ]);
    }

    /**
     * 保存
     */
    public function save()
    {
        $post = $this->request->post();
        $id   = (int)($post['id'] ?? 0);

        $from = trim((string)($post['from_path'] ?? ''));
        $to   = trim((string)($post['to_path'] ?? ''));

        if ($from === '' || $to === '') {
            return $this->fail('旧地址和新地址都要填');
        }
        if (!str_starts_with($from, '/')) {
            $from = '/' . $from;
        }
        if (!str_starts_with($to, '/') && !preg_match('#^https?://#i', $to)) {
            $to = '/' . $to;
        }
        if ($from === $to) {
            return $this->fail('新旧地址不能相同');
        }

        $exists = Db::name('redirect')->where('from_path', $from)->where('id', '<>', $id)->find();
        if ($exists) {
            return $this->fail('该旧地址已存在跳转规则');
        }

        $data = [
            'from_path' => $from,
            'to_path'   => $to,
            'code'      => (int)($post['code'] ?? 301) === 302 ? 302 : 301,
            'status'    => (int)($post['status'] ?? 1) === 1 ? 1 : 0,
        ];

        if ($id > 0) {
            Db::name('redirect')->where('id', $id)->update($data);
        } else {
            $data['createtime'] = time();
            Db::name('redirect')->insert($data);
        }

        HtmlCache::clear();

        return $this->okJump('保存成功', '/admin.php/redirect/index');
    }

    /**
     * 删除
     */
    public function delete()
    {
        $ids = $this->request->post('ids/a', []);
        if (!$ids) {
            $ids = [(int)$this->request->param('id', 0)];
        }
        $ids = array_filter(array_map('intval', (array)$ids));
        if (!$ids) {
            return $this->fail('请选择记录');
        }

        Db::name('redirect')->whereIn('id', $ids)->delete();

        return $this->ok('已删除');
    }
}
