<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\Currency as CurrencyLib;
use app\common\library\HtmlCache;
use think\facade\Db;

/**
 * 多货币管理
 */
class Currency extends Backend
{
    public function index()
    {
        $rows = [];
        try {
            $rows = Db::name('currency')->order('sort asc, id asc')->select()->toArray();
        } catch (\Throwable $e) {
            $rows = [];
        }

        return $this->view('currency/index', [
            'meta_title' => '多货币',
            'rows'       => $rows,
        ]);
    }

    /**
     * 保存（新增或编辑）
     */
    public function save()
    {
        $post = $this->request->post();
        $id   = (int)($post['id'] ?? 0);

        $code = strtoupper(trim((string)($post['code'] ?? '')));
        if (!preg_match('/^[A-Z]{3}$/', $code)) {
            return $this->fail('货币代码格式不对，请填三位大写，例如 USD、EUR');
        }

        $exists = Db::name('currency')->where('code', $code)->where('id', '<>', $id)->find();
        if ($exists) {
            return $this->fail('该货币代码已存在');
        }

        $rate = (float)($post['rate'] ?? 1);
        if ($rate <= 0) {
            return $this->fail('汇率必须大于 0');
        }

        $data = [
            'code'      => $code,
            'name'      => trim((string)($post['name'] ?? '')),
            'symbol'    => (string)($post['symbol'] ?? $code),
            'rate'      => $rate,
            'decimals'  => max(0, min(4, (int)($post['decimals'] ?? 2))),
            'is_default' => (int)($post['is_default'] ?? 0) === 1 ? 1 : 0,
            'sort'      => (int)($post['sort'] ?? 0),
            'status'    => (int)($post['status'] ?? 1) === 1 ? 1 : 0,
        ];

        if ($data['is_default'] === 1) {
            $data['rate'] = 1; // 基准货币汇率恒为 1
            Db::name('currency')->where('id', '<>', $id)->update(['is_default' => 0]);
        }

        if ($id > 0) {
            Db::name('currency')->where('id', $id)->update($data);
        } else {
            $data['createtime'] = time();
            Db::name('currency')->insert($data);
        }

        CurrencyLib::flush();
        HtmlCache::clear();

        return $this->ok('保存成功');
    }

    /**
     * 删除
     */
    public function delete()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }

        $row = Db::name('currency')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('货币不存在');
        }
        if ((int)$row['is_default'] === 1) {
            return $this->fail('基准货币不能删除，请先把其他货币设为基准');
        }

        Db::name('currency')->where('id', $id)->delete();
        CurrencyLib::flush();
        HtmlCache::clear();

        return $this->ok('已删除');
    }
}
