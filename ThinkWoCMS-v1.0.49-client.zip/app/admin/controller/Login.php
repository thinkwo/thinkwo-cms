<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\Auth;
use app\common\library\Captcha;
use think\facade\Db;
use think\Response;

/**
 * 后台登录
 */
class Login extends Backend
{
    // 整个 login 控制器都免登录（Backend 里按「控制器名」或「控制器/方法」匹配）
    protected array $noNeedLogin = ['login'];

    /**
     * 登录页
     */
    public function index()
    {
        if (Auth::check()) {
            return redirect('/admin.php/index/index');
        }

        return $this->view('login/index', [
            'meta_title' => '登录 - 跨境圈子CMS',
        ]);
    }

    /**
     * 验证码
     */
    public function captcha(): Response
    {
        return Captcha::image();
    }

    /**
     * 登录提交
     */
    public function check(): Response
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $username = trim((string)$this->request->post('username', ''));
        $password = (string)$this->request->post('password', '');
        $code     = (string)$this->request->post('captcha', '');

        if ($username === '' || $password === '') {
            return $this->fail('请输入账号和密码');
        }

        if (!captcha_check($code)) {
            return $this->fail('验证码不正确');
        }

        $admin = Db::name('admin')->where('username', $username)->find();
        if (!$admin) {
            return $this->fail('账号或密码错误');
        }
        if ((int)$admin['status'] !== 1) {
            return $this->fail('该账号已被禁用');
        }

        $now = time();
        if ((int)$admin['lock_until'] > $now) {
            return $this->fail('登录失败次数过多，请 ' . ceil(((int)$admin['lock_until'] - $now) / 60) . ' 分钟后再试');
        }

        if (!Auth::verifyPassword($admin, $password)) {
            $fail = (int)$admin['login_fail'] + 1;
            $upd  = ['login_fail' => $fail];
            $max  = (int)config('tw.admin.login_fail', 5);
            if ($fail >= $max) {
                $upd['lock_until'] = $now + (int)config('tw.admin.login_lock', 900);
                $upd['login_fail'] = 0;
            }
            Db::name('admin')->where('id', $admin['id'])->update($upd);

            return $this->fail('账号或密码错误');
        }

        Auth::login($admin);

        \think\facade\Event::trigger('admin_login', $admin);

        return $this->okJump('登录成功', '/admin.php/index/index');
    }

    /**
     * 退出
     */
    public function logout()
    {
        Auth::logout();

        return redirect('/admin.php/login/index');
    }
}
