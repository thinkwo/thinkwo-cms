<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\HtmlCache;
use app\common\library\Lang;
use app\common\library\Pinyin;
use app\common\library\Settings;
use app\common\library\Translate;
use app\common\library\TransSync;
use app\common\library\Tree;
use app\common\library\Theme;
use app\common\library\TwUrl;
use think\facade\Db;

/**
 * 栏目管理
 */
class Sort extends Backend
{
    /**
     * 列表（树形表格）
     */
    public function index()
    {
        $lang = (string)$this->request->param('lang', '');

        $build = function () use ($lang) {
            $q = Db::name('sort');
            if ($lang !== '') {
                $q->where('lang', $lang);
            }

            return $q->order('sort asc, id asc');
        };

        $all = [];
        try {
            $all = $build()->select()->toArray();
        } catch (\Throwable $e) {
            $all = [];
        }

        $tree = Tree::build($all, 0);
        $rows = Tree::flatten($tree);

        foreach ($rows as &$row) {
            $row['url']       = TwUrl::sort($row);
            $row['count']     = (int)Db::name('content')->where('sort_id', $row['id'])->count();
            $row['type_text'] = ['list' => '列表', 'page' => '单页', 'link' => '外链'][$row['type']] ?? $row['type'];
            $row['indent']    = str_repeat('&nbsp;&nbsp;&nbsp;', (int)$row['depth']) . (($row['depth'] ?? 0) > 0 ? '└ ' : '');
        }
        unset($row);

        return $this->view('sort/index', [
            'meta_title'  => '栏目管理',
            'rows'        => $rows,
            'lang'        => $lang,
            'langOptions' => Lang::all(),
        ]);
    }

    /**
     * 新增 / 编辑表单
     */
    public function form()
    {
        $id  = (int)$this->request->param('id', 0);
        $row = [];

        if ($id > 0) {
            $row = Db::name('sort')->where('id', $id)->find();
            if (!$row) {
                return $this->fail('栏目不存在');
            }
        }

        $all  = Db::name('sort')->order('sort asc, id asc')->select()->toArray();
        $tree = Tree::flatten(Tree::build($all, 0));

        $row += ['template_list' => 'lists', 'template_detail' => 'detail', 'template_page' => 'page'];

        return $this->view('sort/form', [
            'meta_title'  => $id > 0 ? '编辑栏目' : '添加栏目',
            'row'         => $row,
            'id'          => $id,
            'parents'     => $tree,
            'langOptions' => Lang::all(),
            'tplList'     => $this->templateOptions((string)$row['template_list'], 'lists'),
            'tplDetail'   => $this->templateOptions((string)$row['template_detail'], 'detail'),
            'tplPage'     => $this->templateOptions((string)$row['template_page'], 'page'),
            'slideGroups' => $this->slideGroups(),
        ]);
    }

    /**
     * 幻灯片分组下拉（栏目可绑定一个分组，内页模板 {tw:slide} 自动取）
     */
    private function slideGroups(): array
    {
        try {
            return Db::name('slide_group')
                ->where('status', 1)
                ->order('sort asc, id asc')
                ->field('code,name')
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            return []; // 没建表的老站不显示这个下拉
        }
    }

    /**
     * 模板名清洗：只允许字母数字下划线中划线；文件不存在时回退默认
     */
    private function cleanTpl(string $v, string $default): string
    {
        $v = preg_replace('/[^a-zA-Z0-9_\-]/', '', $v);
        if ($v === '' || $v === $default) {
            return $default;
        }
        return is_file(Theme::path() . $v . '.html') ? $v : $default;
    }

    /**
     * 模板下拉选项：扫描当前主题目录下的顶层 .html 文件
     *
     * 主题目录里每个顶层 .html 都是一个可用版式，除了 404/搜索/留言这类
     * 由系统固定调用的页面。文件名前加一句中文说明，方便运营认出版式用途。
     */
    private function templateOptions(string $current, string $default): array
    {
        // 404/搜索/留言页永远不会被栏目引用，不进下拉
        $exclude = ['404', 'search', 'message'];
        $files   = [];
        $dir     = Theme::path();
        if (is_dir($dir)) {
            foreach ((array)scandir($dir) as $f) {
                if (is_file($dir . $f) && str_ends_with($f, '.html')) {
                    $name = substr($f, 0, -5);
                    if (!in_array($name, $exclude, true)) {
                        $files[] = $name;
                    }
                }
            }
        }
        sort($files);

        $label = static function (string $name): string {
            $map = [
                'index'   => '首页版式',
                'lists'   => '栏目列表页',
                'detail'  => '内容详情页',
                'page'    => '通用单页（正文）',
                'custom'  => '定制服务页（工艺流程 + FAQ）',
                'contact' => '联系我们 / 询价表单页',
                'about'   => '关于我们页',
                'quality' => '质量与认证页',
                'case'    => '案例页',
            ];

            return isset($map[$name]) ? $name . ' — ' . $map[$name] : $name;
        };

        $opts = [];
        // 当前值不在文件列表里（如换过主题）：保留显示，避免静默改值
        if ($current !== '' && !in_array($current, $files, true)) {
            $opts[] = ['v' => $current, 'label' => $current . '（文件不存在）', 'sel' => true];
        }
        // 默认项排第一
        if (in_array($default, $files, true)) {
            $opts[] = ['v' => $default, 'label' => $label($default) . '（默认）', 'sel' => $default === $current];
            $files  = array_values(array_diff($files, [$default]));
        }
        foreach ($files as $f) {
            $opts[] = ['v' => $f, 'label' => $label($f), 'sel' => $f === $current];
        }

        return $opts;
    }

    /**
     * 保存
     */
    public function save()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $post = $this->request->post();
        $id   = (int)($post['id'] ?? 0);

        $name = trim((string)($post['name'] ?? ''));
        if ($name === '') {
            return $this->fail('栏目名称不能为空');
        }

        $lang = (string)($post['lang'] ?? Lang::defaultCode());
        $pid  = (int)($post['pid'] ?? 0);

        if ($id > 0 && $pid === $id) {
            return $this->fail('上级栏目不能是自己');
        }

        $slug = Pinyin::sanitize((string)($post['slug'] ?? ''));
        if ($slug === '') {
            $slug = Pinyin::smartSlug($name);
        }
        $slug = Pinyin::unique('sort', $slug, $lang, $id);

        $data = [
            'lang'             => $lang,
            'pid'              => $pid,
            'type'             => (string)($post['type'] ?? 'list'),
            'name'             => $name,
            'subname'          => (string)($post['subname'] ?? ''),
            'slug'             => $slug,
            'ico'              => (string)($post['ico'] ?? ''),
            'pic'              => (string)($post['pic'] ?? ''),
            'slide_group'      => preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)($post['slide_group'] ?? '')),
            'description'      => (string)($post['description'] ?? ''),
            'seo_title'        => (string)($post['seo_title'] ?? ''),
            'seo_keywords'     => (string)($post['seo_keywords'] ?? ''),
            'seo_description'  => (string)($post['seo_description'] ?? ''),
            'canonical'        => (string)($post['canonical'] ?? ''),
            'trans_key'        => (string)($post['trans_key'] ?? ''),
            'template_list'    => $this->cleanTpl((string)($post['template_list'] ?? ''), 'lists'),
            'template_detail'  => $this->cleanTpl((string)($post['template_detail'] ?? ''), 'detail'),
            'template_page'    => $this->cleanTpl((string)($post['template_page'] ?? ''), 'page'),
            'link'             => (string)($post['link'] ?? ''),
            'status'           => (int)($post['status'] ?? 1) === 1 ? 1 : 0,
            'sort'             => (int)($post['sort'] ?? 0),
            'updatetime'       => time(),
        ];

        if ($id > 0) {
            Db::name('sort')->where('id', $id)->update($data);
            $sortId = $id;
        } else {
            $data['createtime'] = time();
            $sortId = (int)Db::name('sort')->insertGetId($data);
        }

        HtmlCache::clear();

        // 译文人工修改保护：编辑的是某语言的译文栏目时，标记为人工
        $isTranslationCopy = $lang !== Lang::defaultCode()
            && trim((string)($data['trans_key'] ?? '')) !== '';
        if ($isTranslationCopy) {
            TransSync::markManual('sort', $sortId);
        } elseif (Settings::get('translate_auto', '1') === '1' && Translate::available()) {
            // 自动同步：默认语言栏目保存后，自动翻译到其他已启用语言
            try {
                TransSync::sort($sortId, [], false, 40);
            } catch (\Throwable $e) {
                // 翻译失败不影响保存
            }
        }

        return $this->okJump('保存成功', '/admin.php/sort/index');
    }

    /**
     * 删除
     */
    public function delete()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }

        // 连带该配对键下的其他语言栏目一起删除，避免各语言残留孤立栏目
        $row = Db::name('sort')->where('id', $id)->find();
        $key = $row ? trim((string)$row['trans_key']) : '';
        $ids = $key !== ''
            ? array_map('intval', Db::name('sort')->where('trans_key', $key)->column('id'))
            : [$id];
        if (!$ids) {
            $ids = [$id];
        }

        if (Db::name('sort')->whereIn('pid', $ids)->whereNotIn('id', $ids)->count() > 0) {
            return $this->fail('该栏目下还有子栏目，请先删除子栏目');
        }
        if (Db::name('content')->whereIn('sort_id', $ids)->count() > 0) {
            return $this->fail('该栏目下还有内容（含其他语言译文），请先移走或删除内容');
        }

        Db::name('sort')->whereIn('id', $ids)->delete();
        HtmlCache::clear();

        return $this->ok('已删除');
    }

    /**
     * 同步翻译：把本栏目同步/翻译到其他语言（含名称与 SEO 字段）
     */
    public function translate()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }

        $row = Db::name('sort')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('栏目不存在');
        }

        $langsParam = trim((string)$this->request->param('langs', ''));
        $langs      = $langsParam !== ''
            ? array_values(array_filter(array_map('trim', explode(',', $langsParam))))
            : [];
        $force      = (string)$this->request->param('force', '0') === '1';

        $detail = TransSync::sort($id, $langs, $force, 90);
        if (isset($detail['_error'])) {
            return $this->fail($detail['_error']);
        }

        return $this->ok('同步完成', ['detail' => $detail]);
    }

    /**
     * 栏目自定义字段（v1.0.44）
     *
     * 给某个栏目定义附加字段（文本/多行/下拉/开关），录内容时自动出现输入框，
     * 值以 JSON 存进内容的 meta 扩展字段，模板里可直接取（$list.字段键 / $list.cf.字段键）。
     * 典型用途：价格文案、交付周期、参数表等模板专属信息，不用改程序。
     */
    public function fields()
    {
        $sortId = (int)$this->request->param('sort_id', 0);

        // 栏目下拉（全部语言平铺，选谁就管谁）
        $sorts = Db::name('sort')->field('id,name,lang,pid,type')->order('lang asc, sort asc, id asc')->select()->toArray();

        $sort = null;
        $rows = [];
        if ($sortId > 0) {
            $sort = Db::name('sort')->where('id', $sortId)->find();
        }
        if ($sort) {
            try {
                $rows = Db::name('sort_field')->where('sort_id', $sortId)
                    ->order('sort asc, id asc')->select()->toArray();
            } catch (\Throwable $e) {
                $rows = [];
            }
        }

        // 编辑某条字段
        $fid   = (int)$this->request->param('fid', 0);
        $field = [
            'id' => 0, 'sort_id' => $sortId, 'name' => '', 'fkey' => '',
            'type' => 'text', 'options' => '', 'defval' => '', 'sort' => 0, 'status' => 1,
        ];
        if ($fid > 0) {
            $f = Db::name('sort_field')->where('id', $fid)->find();
            if ($f) {
                $field = $f;
                $sortId = (int)$f['sort_id'];
                if (!$sort) {
                    $sort = Db::name('sort')->where('id', $sortId)->find();
                }
            }
        }

        $typeText = ['text' => '单行文本', 'textarea' => '多行文本', 'select' => '下拉选择', 'switch' => '开关'];

        return $this->view('sort/fields', [
            'meta_title' => '栏目自定义字段',
            'sorts'      => $sorts,
            'sort'       => $sort,
            'sortId'     => $sortId,
            'rows'       => $rows,
            'field'      => $field,
            'typeText'   => $typeText,
        ]);
    }

    /**
     * 保存自定义字段
     */
    public function fieldSave()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $post   = $this->request->post();
        $id     = (int)($post['id'] ?? 0);
        $sortId = (int)($post['sort_id'] ?? 0);

        if (!Db::name('sort')->where('id', $sortId)->find()) {
            return $this->fail('请先选择栏目');
        }

        $name = trim((string)($post['name'] ?? ''));
        if ($name === '') {
            return $this->fail('字段名称不能为空');
        }

        $fkey = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '', (string)($post['fkey'] ?? '')));
        if ($fkey === '') {
            $fkey = 'cf_' . Pinyin::sanitize($name);
            $fkey = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '', $fkey));
        }
        if ($fkey === '') {
            return $this->fail('字段键不能为空（只允许字母数字下划线）');
        }

        // 字段键在本栏目内唯一（内置列名也不允许占用，避免模板取值被覆盖）
        $reserved = ['id', 'lang', 'sort_id', 'title', 'slug', 'subtitle', 'ico', 'images', 'summary',
            'content', 'tags', 'seo_title', 'seo_keywords', 'seo_description', 'canonical', 'noindex',
            'attr', 'author', 'source', 'views', 'price', 'unit', 'model_no', 'moq', 'meta', 'trans_key',
            'status', 'sort', 'publish_time', 'createtime', 'updatetime', 'url', 'date', 'datetime',
            'lines', 'cf', 'tag_list', 'sort_url', 'sort_name', 'sort_slug'];
        if (in_array($fkey, $reserved, true)) {
            return $this->fail('字段键「' . $fkey . '」是系统保留名，请换一个');
        }
        $dup = Db::name('sort_field')
            ->where('sort_id', $sortId)->where('fkey', $fkey)
            ->where('id', '<>', $id)->find();
        if ($dup) {
            return $this->fail('该栏目下已有同名字段键「' . $fkey . '」');
        }

        $type = (string)($post['type'] ?? 'text');
        if (!in_array($type, ['text', 'textarea', 'select', 'switch'], true)) {
            $type = 'text';
        }

        $data = [
            'sort_id'    => $sortId,
            'name'       => mb_substr($name, 0, 50),
            'fkey'       => mb_substr($fkey, 0, 50),
            'type'       => $type,
            'options'    => $type === 'select' ? mb_substr((string)($post['options'] ?? ''), 0, 500) : '',
            'defval'     => mb_substr(trim((string)($post['defval'] ?? '')), 0, 200),
            'sort'       => (int)($post['sort'] ?? 0),
            'status'     => (int)($post['status'] ?? 1) === 1 ? 1 : 0,
            'updatetime' => time(),
        ];

        if ($id > 0) {
            Db::name('sort_field')->where('id', $id)->update($data);
        } else {
            $data['createtime'] = time();
            Db::name('sort_field')->insert($data);
        }

        HtmlCache::clear();

        return $this->okJump('保存成功', '/admin.php/sort/fields?sort_id=' . $sortId);
    }

    /**
     * 删除自定义字段
     */
    public function fieldDelete()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }

        $row = Db::name('sort_field')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('字段不存在');
        }

        Db::name('sort_field')->where('id', $id)->delete();
        HtmlCache::clear();

        return $this->ok('已删除（已录的值还保留在内容里，重新定义同名字段可恢复显示）');
    }
}
