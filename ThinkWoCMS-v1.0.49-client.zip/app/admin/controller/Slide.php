<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\HtmlCache;
use app\common\library\Lang;
use think\facade\Db;

/**
 * 幻灯片管理
 *
 * 两级结构：
 *   分组（slide_group）—— 一个分组对应模板里一处轮播，如首页首屏 home、产品页横幅 product
 *   条目（slide）      —— 分组下的每一张图，可设标题、副文案、按钮、链接、定时上架
 *
 * 模板调用：{tw:slide group="home" limit="5"}...{/tw:slide}
 *   不写 group 时，取当前栏目绑定的分组（栏目管理 → 幻灯片分组）
 */
class Slide extends Backend
{
    /**
     * 分组列表
     */
    public function index()
    {
        $rows = [];
        try {
            $rows = Db::name('slide_group')->order('sort asc, id asc')->select()->toArray();
            foreach ($rows as &$row) {
                $row['count']  = (int)Db::name('slide')->where('group_id', (int)$row['id'])->count();
                $row['online'] = (int)Db::name('slide')
                    ->where('group_id', (int)$row['id'])
                    ->where('status', 1)
                    ->whereRaw('(start_time = 0 OR start_time <= ' . time() . ')')
                    ->whereRaw('(end_time = 0 OR end_time >= ' . time() . ')')
                    ->count();
                $row['size_text'] = ((int)$row['width'] > 0 && (int)$row['height'] > 0)
                    ? $row['width'] . ' × ' . $row['height']
                    : '未设置';
                // 直接给一段能粘到模板里的示例
                $row['snippet'] = '{tw:slide group="' . $row['code'] . '"}';
            }
            unset($row);
        } catch (\Throwable $e) {
            $rows = [];
        }

        return $this->view('slide/index', [
            'meta_title' => '幻灯片',
            'rows'       => $rows,
            'langOptions' => Lang::all(),
        ]);
    }

    /**
     * 分组表单
     */
    public function groupForm()
    {
        $id  = (int)$this->request->param('id', 0);
        $row = [
            'id'         => 0,
            'name'       => '',
            'code'       => '',
            'remark'     => '',
            'width'      => 1920,
            'height'     => 900,
            'status'     => 1,
            'sort'       => 0,
            'createtime' => 0,
            'updatetime' => 0,
        ];

        if ($id > 0) {
            $found = Db::name('slide_group')->where('id', $id)->find();
            if (!$found) {
                return $this->fail('分组不存在');
            }
            $row = array_merge($row, $found);
        }

        return $this->view('slide/group', [
            'meta_title' => $id > 0 ? '编辑分组' : '新建分组',
            'row'        => $row,
            'id'         => $id,
        ]);
    }

    /**
     * 保存分组
     */
    public function groupSave()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $post = $this->request->post();
        $id   = (int)($post['id'] ?? 0);

        $name = trim((string)($post['name'] ?? ''));
        if ($name === '') {
            return $this->fail('分组名称不能为空');
        }

        // code 是模板里写的调用标识：只允许小写字母数字中划线下划线
        $code = strtolower(trim((string)($post['code'] ?? '')));
        $code = preg_replace('/[^a-z0-9_\-]/', '', $code) ?? '';
        if ($code === '') {
            return $this->fail('调用标识不能为空，只能用字母、数字、中划线、下划线');
        }

        // 同 code 只能有一个（模板里靠它取数据）
        $dup = Db::name('slide_group')->where('code', $code)->where('id', '<>', $id)->find();
        if ($dup) {
            return $this->fail('调用标识「' . $code . '」已被分组「' . $dup['name'] . '」占用');
        }

        $data = [
            'name'       => $name,
            'code'       => $code,
            'remark'     => (string)($post['remark'] ?? ''),
            'width'      => max(0, (int)($post['width'] ?? 0)),
            'height'     => max(0, (int)($post['height'] ?? 0)),
            'status'     => (int)($post['status'] ?? 1) === 1 ? 1 : 0,
            'sort'       => (int)($post['sort'] ?? 0),
            'updatetime' => time(),
        ];

        if ($id > 0) {
            Db::name('slide_group')->where('id', $id)->update($data);
        } else {
            $data['createtime'] = time();
            $id = (int)Db::name('slide_group')->insertGetId($data);
        }

        HtmlCache::clear();

        return $this->okJump('分组已保存', '/admin.php/slide/index');
    }

    /**
     * 删除分组（连条目一起删）
     */
    public function groupDelete()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $id = (int)$this->request->post('id', 0);
        $g  = Db::name('slide_group')->where('id', $id)->find();
        if (!$g) {
            return $this->fail('分组不存在');
        }

        Db::name('slide')->where('group_id', $id)->delete();
        Db::name('slide_group')->where('id', $id)->delete();

        HtmlCache::clear();

        return $this->ok('已删除分组和它下面的所有幻灯片');
    }

    /**
     * 某个分组下的幻灯片列表
     */
    public function items()
    {
        $gid = (int)$this->request->param('gid', 0);
        $g   = Db::name('slide_group')->where('id', $gid)->find();
        if (!$g) {
            return $this->fail('分组不存在');
        }

        $rows = [];
        try {
            $rows = Db::name('slide')
                ->where('group_id', $gid)
                ->order('sort asc, id asc')
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            $rows = [];
        }

        $now = time();
        foreach ($rows as &$row) {
            $row['online'] = (int)$row['status'] === 1
                && ((int)$row['start_time'] === 0 || (int)$row['start_time'] <= $now)
                && ((int)$row['end_time'] === 0 || (int)$row['end_time'] >= $now);
            $row['time_text'] = $this->timeText($row);
            $row['target_text'] = ((string)$row['target'] === '_blank') ? '新窗口' : '本窗口';
        }
        unset($row);

        return $this->view('slide/items', [
            'meta_title' => $g['name'] . ' · 幻灯片',
            'group'      => $g,
            'rows'       => $rows,
            'langOptions' => Lang::all(),
        ]);
    }

    /**
     * 条目表单
     */
    public function form()
    {
        $id  = (int)$this->request->param('id', 0);
        $gid = (int)$this->request->param('gid', 0);

        $row = [
            'id'           => 0,
            'group_id'     => $gid,
            'lang'         => Lang::defaultCode(),
            'title'        => '',
            'subtitle'     => '',
            'summary'      => '',
            'image'        => '',
            'image_mobile' => '',
            'video'        => '',
            'url'          => '',
            'target'       => '_self',
            'btn_text'     => '',
            'sort'         => 0,
            'status'       => 1,
            'start_time'   => 0,
            'end_time'     => 0,
        ];

        if ($id > 0) {
            $found = Db::name('slide')->where('id', $id)->find();
            if (!$found) {
                return $this->fail('幻灯片不存在');
            }
            $row = array_merge($row, $found);
            $gid = (int)$row['group_id'];
        }

        $g = Db::name('slide_group')->where('id', $gid)->find();
        if (!$g) {
            return $this->fail('请先选择分组');
        }

        return $this->view('slide/form', [
            'meta_title' => $id > 0 ? '编辑幻灯片' : '添加幻灯片',
            'row'        => $row,
            'id'         => $id,
            'group'      => $g,
            'langOptions' => Lang::all(),
        ]);
    }

    /**
     * 保存条目
     */
    public function save()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $post = $this->request->post();
        $id   = (int)($post['id'] ?? 0);

        $gid = (int)($post['group_id'] ?? 0);
        $g   = Db::name('slide_group')->where('id', $gid)->find();
        if (!$g) {
            return $this->fail('分组不存在，请先选择分组');
        }

        $image = trim((string)($post['image'] ?? ''));
        $video = trim((string)($post['video'] ?? ''));
        $title = trim((string)($post['title'] ?? ''));

        // 至少要有图或视频，否则模板里渲染出来是空白
        if ($image === '' && $video === '' && $title === '') {
            return $this->fail('请至少上传一张图片，或填写标题做成纯文字横幅');
        }

        $start = trim((string)($post['start_time'] ?? ''));
        $end   = trim((string)($post['end_time'] ?? ''));
        $startTs = $start !== '' ? (int)strtotime($start) : 0;
        $endTs   = $end !== '' ? (int)strtotime($end) : 0;
        if ($startTs > 0 && $endTs > 0 && $endTs < $startTs) {
            return $this->fail('结束时间不能早于开始时间');
        }

        $data = [
            'group_id'     => $gid,
            'lang'         => (string)($post['lang'] ?? Lang::defaultCode()),
            'title'        => $title,
            'subtitle'     => (string)($post['subtitle'] ?? ''),
            'summary'      => (string)($post['summary'] ?? ''),
            'image'        => $image,
            'image_mobile' => (string)($post['image_mobile'] ?? ''),
            'video'        => $video,
            'url'          => (string)($post['url'] ?? ''),
            'target'       => ((string)($post['target'] ?? '_self') === '_blank') ? '_blank' : '_self',
            'btn_text'     => (string)($post['btn_text'] ?? ''),
            'sort'         => (int)($post['sort'] ?? 0),
            'status'       => (int)($post['status'] ?? 1) === 1 ? 1 : 0,
            'start_time'   => $startTs,
            'end_time'     => $endTs,
            'updatetime'   => time(),
        ];

        if ($id > 0) {
            if (!Db::name('slide')->where('id', $id)->find()) {
                return $this->fail('幻灯片不存在');
            }
            Db::name('slide')->where('id', $id)->update($data);
        } else {
            $data['createtime'] = time();
            $id = (int)Db::name('slide')->insertGetId($data);
        }

        HtmlCache::clear();

        return $this->okJump('已保存', '/admin.php/slide/items?gid=' . $gid);
    }

    /**
     * 删除条目
     */
    public function delete()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $id = (int)$this->request->post('id', 0);
        if (!Db::name('slide')->where('id', $id)->find()) {
            return $this->fail('幻灯片不存在');
        }

        Db::name('slide')->where('id', $id)->delete();
        HtmlCache::clear();

        return $this->ok('已删除');
    }

    /**
     * 启用 / 停用（不删图，临时下线用这个）
     */
    public function toggle()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $id = (int)$this->request->post('id', 0);
        $row = Db::name('slide')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('幻灯片不存在');
        }

        $status = (int)$row['status'] === 1 ? 0 : 1;
        Db::name('slide')->where('id', $id)->update(['status' => $status, 'updatetime' => time()]);
        HtmlCache::clear();

        return $this->ok($status === 1 ? '已显示' : '已隐藏', ['status' => $status]);
    }

    /**
     * 上移 / 下移（和相邻的一条交换 sort）
     */
    public function move()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $id  = (int)$this->request->post('id', 0);
        $dir = (string)$this->request->post('dir', 'up');
        $row = Db::name('slide')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('幻灯片不存在');
        }

        $q = Db::name('slide')->where('group_id', (int)$row['group_id'])->where('lang', (string)$row['lang']);
        if ($dir === 'up') {
            $q->where(function ($w) use ($row) {
                $w->where('sort', '<', (int)$row['sort'])
                    ->whereOr(function ($w2) use ($row) {
                        $w2->where('sort', (int)$row['sort'])->where('id', '<', (int)$row['id']);
                    });
            })->order('sort desc, id desc');
        } else {
            $q->where(function ($w) use ($row) {
                $w->where('sort', '>', (int)$row['sort'])
                    ->whereOr(function ($w2) use ($row) {
                        $w2->where('sort', (int)$row['sort'])->where('id', '>', (int)$row['id']);
                    });
            })->order('sort asc, id asc');
        }

        $other = $q->find();
        if (!$other) {
            return $this->ok('已经在最' . ($dir === 'up' ? '前' : '后'));
        }

        Db::name('slide')->where('id', (int)$row['id'])->update(['sort' => (int)$other['sort'], 'updatetime' => time()]);
        Db::name('slide')->where('id', (int)$other['id'])->update(['sort' => (int)$row['sort'], 'updatetime' => time()]);

        HtmlCache::clear();

        return $this->ok('顺序已调整');
    }

    /**
     * 定时状态文案
     */
    private function timeText(array $row): string
    {
        $start = (int)($row['start_time'] ?? 0);
        $end   = (int)($row['end_time'] ?? 0);

        if ($start === 0 && $end === 0) {
            return '长期';
        }

        $now = time();
        if ($start > 0 && $now < $start) {
            return date('m-d H:i', $start) . ' 开始';
        }
        if ($end > 0 && $now > $end) {
            return date('m-d H:i', $end) . ' 已结束';
        }

        return ($start > 0 ? date('m-d H:i', $start) : '现在') . ' 至 ' . ($end > 0 ? date('m-d H:i', $end) : '长期');
    }
}
