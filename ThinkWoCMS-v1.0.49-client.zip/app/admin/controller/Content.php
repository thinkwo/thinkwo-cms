<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\HtmlCache;
use app\common\library\Lang;
use app\common\library\Pinyin;
use app\common\library\Settings;
use app\common\library\Tags;
use app\common\library\Translate;
use app\common\library\TransSync;
use app\common\library\Tree;
use app\common\library\TwUrl;
use think\facade\Db;

/**
 * 内容管理
 */
class Content extends Backend
{
    /**
     * 列表
     */
    public function index()
    {
        [$page, $limit] = $this->pageParam();

        $keyword = trim((string)$this->request->param('keyword', ''));
        $sortId  = (int)$this->request->param('sort_id', 0);
        $lang    = (string)$this->request->param('lang', '');
        $status  = $this->request->param('status', '');

        $build = function () use ($keyword, $sortId, $lang, $status) {
            $q = Db::name('content');
            if ($keyword !== '') {
                $q->whereLike('title', '%' . $keyword . '%');
            }
            if ($sortId > 0) {
                $q->where('sort_id', $sortId);
            }
            if ($lang !== '') {
                $q->where('lang', $lang);
            }
            if ($status !== '' && $status !== null) {
                $q->where('status', (int)$status);
            }

            return $q;
        };

        $total = 0;
        $rows  = [];
        try {
            $total = (int)$build()->count();
            $rows  = $build()->order('id desc')->page($page, $limit)->select()->toArray();
        } catch (\Throwable $e) {
            $total = 0;
            $rows  = [];
        }

        $sortMap = [];
        foreach (Tags::allSorts() as $sort) {
            $sortMap[(int)$sort['id']] = $sort;
        }
        foreach ($rows as &$row) {
            $row['sort_name'] = (string)($sortMap[(int)$row['sort_id']]['name'] ?? '-');
            $row['url']       = TwUrl::detail($row, $sortMap[(int)$row['sort_id']] ?? null);
            $row['date']      = $row['publish_time'] ? date('Y-m-d', (int)$row['publish_time']) : '-';

            // 翻译状态：原文 / 机器翻译 / 人工修改
            $st = (int)($row['trans_status'] ?? TransSync::ST_ORIGIN);
            if ((string)$row['lang'] === Lang::defaultCode()) {
                $row['trans_label'] = '原文';
                $row['trans_class'] = 'tw-badge-closed';
            } else {
                $row['trans_label'] = TransSync::statusLabel($st);
                $row['trans_class'] = $st === TransSync::ST_MANUAL ? 'tw-badge-quoted' : 'tw-badge-replied';
            }
        }
        unset($row);

        return $this->view('content/index', [
            'meta_title' => '内容列表',
            'rows'       => $rows,
            'total'      => $total,
            'page'       => $page,
            'limit'      => $limit,
            'keyword'    => $keyword,
            'sortId'     => $sortId,
            'lang'       => $lang,
            'status'     => $status === null ? '' : (string)$status,
            'sortOptions' => $this->sortOptions(),
            'langOptions' => Lang::all(),
        ]);
    }

    /**
     * 新增 / 编辑
     */
    public function form()
    {
        $id = (int)$this->request->param('id', 0);

        // 新增时也要有完整字段，否则模板访问 $row.xxx 会报 Undefined array key
        $row = [
            'id'              => 0,
            'lang'            => Lang::code(),
            'sort_id'         => 0,
            'title'           => '',
            'slug'            => '',
            'subtitle'        => '',
            'ico'             => '',
            'images'          => [],
            'summary'         => '',
            'content'         => '',
            'tags'            => '',
            'seo_title'       => '',
            'seo_keywords'    => '',
            'seo_description' => '',
            'canonical'       => '',
            'noindex'         => 0,
            'attr'            => '',
            'author'          => '',
            'source'          => '',
            'views'           => 0,
            'price'           => '',
            'unit'            => '',
            'model_no'        => '',
            'moq'             => '',
            'meta'            => '',
            'trans_key'       => '',
            'trans_status'    => 0,
            'trans_at'        => 0,
            'status'          => 1,
            'sort'            => 0,
            'publish_time'    => 0,
        ];

        if ($id > 0) {
            $found = Db::name('content')->where('id', $id)->find();
            if (!$found) {
                return $this->fail('内容不存在');
            }
            $found['images'] = (isset($found['images']) && $found['images'] !== '')
                ? (array)json_decode((string)$found['images'], true)
                : [];
            $row = array_merge($row, $found);
        }

        // 自定义字段定义（按栏目分组，前端按选中栏目渲染输入框）与已录值
        $cfDefs = [];
        try {
            $cfDefs = Db::name('sort_field')->where('status', 1)
                ->order('sort asc, id asc')->select()->toArray();
        } catch (\Throwable $e) {
            $cfDefs = [];
        }
        $cfValues = [];
        $rawMeta  = (string)($row['meta'] ?? '');
        if ($rawMeta !== '' && $rawMeta[0] === '{') {
            $decoded = json_decode($rawMeta, true);
            if (is_array($decoded)) {
                $cfValues = $decoded;
            }
        }

        return $this->view('content/form', [
            'meta_title'  => $id > 0 ? '编辑内容' : '添加内容',
            'row'         => $row,
            'id'          => $id,
            'sortOptions' => $this->sortOptions(),
            'langOptions' => Lang::all(),
            'cfDefsJson'  => json_encode(array_map(static function ($d) {
                return [
                    'sort_id' => (int)$d['sort_id'],
                    'name'    => (string)$d['name'],
                    'fkey'    => (string)$d['fkey'],
                    'type'    => (string)$d['type'],
                    'options' => array_values(array_filter(array_map('trim', explode("\n", (string)$d['options'])))),
                    'defval'  => (string)$d['defval'],
                ];
            }, $cfDefs), JSON_UNESCAPED_UNICODE),
            'cfValuesJson' => json_encode($cfValues, JSON_UNESCAPED_UNICODE),
            'hasCfDefs'    => !empty($cfDefs),
        ]);
    }

    /**
     * 保存
     */
    public function save()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $post = $this->request->post();
        $id   = (int)($post['id'] ?? 0);

        $title = trim((string)($post['title'] ?? ''));
        if ($title === '') {
            return $this->fail('标题不能为空');
        }

        $lang   = (string)($post['lang'] ?? Lang::defaultCode());
        $sortId = (int)($post['sort_id'] ?? 0);
        if ($sortId <= 0) {
            return $this->fail('请选择栏目');
        }

        $slug = Pinyin::sanitize((string)($post['slug'] ?? ''));
        if ($slug === '') {
            $slug = Pinyin::smartSlug($title);
        }
        $slug = Pinyin::unique('content', $slug, $lang, $id);

        $images = [];
        if (!empty($post['images']) && is_array($post['images'])) {
            $images = array_values(array_filter(array_map('trim', $post['images'])));
        }

        $publish = (string)($post['publish_time'] ?? '');
        $publishTs = $publish !== '' ? (int)strtotime($publish) : time();

        // meta：当前栏目定义了自定义字段 → 值收成 JSON；否则用表单里的「扩展」原文
        $metaValue = '';
        try {
            $cfDefs = Db::name('sort_field')->where('sort_id', $sortId)
                ->where('status', 1)->order('sort asc, id asc')->select()->toArray();
        } catch (\Throwable $e) {
            $cfDefs = [];
        }
        if ($cfDefs) {
            $cfIn  = is_array($post['cf'] ?? null) ? $post['cf'] : [];
            $vals  = [];
            foreach ($cfDefs as $d) {
                $k = (string)$d['fkey'];
                $v = (string)($cfIn[$k] ?? '');
                if ($d['type'] === 'switch') {
                    $v = ($v === '1' || $v === 'on') ? '1' : '0';
                } elseif ($d['type'] === 'select') {
                    $opts = array_values(array_filter(array_map('trim', explode("\n", (string)$d['options']))));
                    if (!in_array($v, $opts, true)) {
                        $v = $v === '' ? '' : (string)$d['defval'];
                    }
                } else {
                    $v = mb_substr(trim($v), 0, 500);
                }
                $vals[$k] = $v;
            }
            $metaValue = json_encode($vals, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } else {
            $metaValue = mb_substr((string)($post['meta'] ?? ''), 0, 1000);
        }

        $data = [
            'lang'            => $lang,
            'sort_id'         => $sortId,
            'title'           => $title,
            'slug'            => $slug,
            'subtitle'        => (string)($post['subtitle'] ?? ''),
            'ico'             => (string)($post['ico'] ?? ''),
            'images'          => $images ? json_encode($images, JSON_UNESCAPED_UNICODE) : '',
            'summary'         => (string)($post['summary'] ?? ''),
            'content'         => (string)($post['content'] ?? ''),
            'tags'            => (string)($post['tags'] ?? ''),
            'seo_title'       => (string)($post['seo_title'] ?? ''),
            'seo_keywords'    => (string)($post['seo_keywords'] ?? ''),
            'seo_description' => (string)($post['seo_description'] ?? ''),
            'canonical'       => (string)($post['canonical'] ?? ''),
            'noindex'         => (int)($post['noindex'] ?? 0) === 1 ? 1 : 0,
            'attr'            => is_array($post['attr'] ?? null) ? implode(',', (array)$post['attr']) : (string)($post['attr'] ?? ''),
            'author'          => (string)($post['author'] ?? ''),
            'source'          => (string)($post['source'] ?? ''),
            'price'           => (float)($post['price'] ?? 0),
            'unit'            => (string)($post['unit'] ?? ''),
            'model_no'        => (string)($post['model_no'] ?? ''),
            'moq'             => (string)($post['moq'] ?? ''),
            'meta'            => $metaValue,
            'trans_key'       => (string)($post['trans_key'] ?? ''),
            'status'          => (int)($post['status'] ?? 1) === 1 ? 1 : 0,
            'sort'            => (int)($post['sort'] ?? 0),
            'publish_time'    => $publishTs,
            'updatetime'      => time(),
        ];

        if ($id > 0) {
            $old = Db::name('content')->where('id', $id)->find();
            if (!$old) {
                return $this->fail('内容不存在');
            }

            Db::name('content')->where('id', $id)->update($data);

            // slug 变更时自动写 301，保住旧外链权重
            if ((string)$old['slug'] !== $slug) {
                $this->addRedirect(
                    TwUrl::detail($old, $this->sortById((int)$old['sort_id'])),
                    TwUrl::detail(array_merge($old, ['slug' => $slug, 'lang' => $lang]), $this->sortById($sortId))
                );
            }
        } else {
            $data['views']      = 0;
            $data['createtime'] = time();
            $id = (int)Db::name('content')->insertGetId($data);
        }

        HtmlCache::clear();
        \think\facade\Event::trigger('content_saved', ['id' => $id, 'data' => $data]);

        // 译文人工修改保护：编辑的是某语言的译文副本时，标记为人工，后续自动同步不再覆盖
        $isTranslationCopy = $lang !== Lang::defaultCode()
            && trim((string)($data['trans_key'] ?? '')) !== '';
        if ($isTranslationCopy) {
            TransSync::markManual('content', $id);
        }

        // 自动同步：默认语言的原文保存后，自动翻译到其他已启用语言
        if (!$isTranslationCopy
            && Settings::get('translate_auto', '1') === '1'
            && Translate::available()) {
            try {
                TransSync::content($id, [], false, 30, Settings::get('translate_auto_body', '1') === '1');
            } catch (\Throwable $e) {
                // 翻译失败不影响保存
            }
        }

        // IndexNow 即时收录推送（开启且已发布才推）
        if (class_exists(\app\common\library\IndexNow::class)
            && \app\common\library\IndexNow::enabled() && (int)$data['status'] === 1) {
            try {
                $url = \app\common\library\TwUrl::detail(
                    array_merge($data, ['id' => $id, 'lang' => $lang, 'slug' => $slug, 'sort_id' => $sortId]),
                    $this->sortById($sortId) ?: []
                );
                \app\common\library\IndexNow::push($url, $id > 0 && isset($old) ? 'Updated' : 'Added');
            } catch (\Throwable $e) {
                // 推送失败不影响保存
            }
        }

        return $this->okJump('保存成功', '/admin.php/content/index');
    }

    /**
     * 删除
     */
    public function delete()
    {
        $ids = $this->request->post('ids/a', []);
        if (!$ids) {
            $ids = [(int)$this->request->param('id', 0)];
        }
        $ids = array_filter(array_map('intval', (array)$ids));
        if (!$ids) {
            return $this->fail('请选择要删除的内容');
        }

        $removedUrls = [];
        foreach ($ids as $id) {
            $row = Db::name('content')->where('id', $id)->find();
            if ($row) {
                // 连带删除同一配对键下的其他语言译文，避免各语言残留孤立内容
                $transKey = trim((string)($row['trans_key'] ?? ''));
                if ($transKey !== '') {
                    Db::name('content')->where('trans_key', $transKey)->delete();
                } else {
                    Db::name('content')->where('id', $id)->delete();
                }

                $sort = $this->sortById((int)$row['sort_id']) ?: ['slug' => ''];
                try {
                    $removedUrls[] = \app\common\library\TwUrl::detail($row, $sort);
                } catch (\Throwable $e) {
                    // URL 拼接失败不影响删除
                }
                $this->addRedirect(
                    TwUrl::detail($row, $this->sortById((int)$row['sort_id'])),
                    TwUrl::sort($sort)
                );
            }
        }

        HtmlCache::clear();

        // IndexNow：告知搜索引擎这些 URL 已删除
        if (class_exists(\app\common\library\IndexNow::class)
            && \app\common\library\IndexNow::enabled() && isset($removedUrls)) {
            try {
                \app\common\library\IndexNow::pushBatch(array_map(
                    static fn ($u) => ['path' => $u, 'type' => 'Removed'],
                    $removedUrls
                ));
            } catch (\Throwable $e) {
                // 推送失败不影响删除
            }
        }

        return $this->ok('已删除 ' . count($ids) . ' 条');
    }

    /**
     * 切换状态
     */
    public function status()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }

        $row = Db::name('content')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('内容不存在');
        }

        $status = (int)$row['status'] === 1 ? 0 : 1;
        Db::name('content')->where('id', $id)->update(['status' => $status, 'updatetime' => time()]);
        HtmlCache::clear();

        return $this->ok($status === 1 ? '已发布' : '已下线', ['status' => $status]);
    }

    /**
     * 同步翻译：把本条内容同步/翻译到其他语言
     * POST id, langs（可选，逗号分隔目标语言，缺省为除自身外全部启用语言）, force（1=强制覆盖人工译文）
     */
    public function translate()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }

        $row = Db::name('content')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('内容不存在');
        }

        $langsParam = trim((string)$this->request->param('langs', ''));
        $langs      = $langsParam !== ''
            ? array_values(array_filter(array_map('trim', explode(',', $langsParam))))
            : [];
        $force      = (string)$this->request->param('force', '0') === '1';

        $detail = TransSync::content($id, $langs, $force, 120, true);
        if (isset($detail['_error'])) {
            return $this->fail($detail['_error']);
        }
        if (!$detail) {
            return $this->fail('没有可同步的目标语言，请先在「多语言」添加并启用语言');
        }

        $failed = array_filter($detail, static fn ($m) => str_starts_with((string)$m, '失败'));

        return $this->ok($failed ? '部分语言同步失败' : '同步完成', [
            'driver' => Translate::label(),
            'detail' => $detail,
        ]);
    }

    /**
     * 批量同步翻译（选中多条）
     */
    public function translateBatch()
    {
        $ids = $this->request->post('ids/a', []);
        $ids = array_values(array_filter(array_map('intval', (array)$ids)));
        if (!$ids) {
            return $this->fail('请选择要翻译的内容');
        }

        $force  = (string)$this->request->post('force', '0') === '1';
        $done   = 0;
        $errors = [];

        foreach (array_slice($ids, 0, 30) as $id) {
            $detail = TransSync::content($id, [], $force, 40, true);
            $bad    = [];
            foreach ((array)$detail as $lang => $msg) {
                if (str_starts_with((string)$msg, '失败')) {
                    $bad[] = $lang . ' ' . $msg;
                }
            }
            if ($bad) {
                $errors[] = '#' . $id . ' ' . implode('，', $bad);
            } else {
                $done++;
            }
        }

        HtmlCache::clear();

        return $this->ok('完成 ' . $done . ' 条' . ($errors ? '，失败：' . implode('；', array_slice($errors, 0, 3)) : ''), [
            'done' => $done,
        ]);
    }

    /**
     * 写 301 记录
     */
    protected function addRedirect(string $from, string $to): void
    {
        if ($from === '' || $to === '' || $from === $to) {
            return;
        }

        try {
            $exists = Db::name('redirect')->where('from_path', $from)->find();
            if ($exists) {
                Db::name('redirect')->where('id', $exists['id'])->update(['to_path' => $to, 'status' => 1]);
            } else {
                Db::name('redirect')->insert([
                    'from_path'  => $from,
                    'to_path'    => $to,
                    'code'       => 301,
                    'status'     => 1,
                    'createtime' => time(),
                ]);
            }
        } catch (\Throwable $e) {
            // 忽略
        }
    }

    /**
     * 栏目
     */
    protected function sortById(int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }
        $row = Db::name('sort')->where('id', $id)->find();

        return $row ?: null;
    }

    /**
     * 栏目下拉（带层级）
     */
    protected function sortOptions(): array
    {
        $all = Db::name('sort')->order('sort asc, id asc')->select()->toArray();
        $tree = Tree::build($all, 0);

        return Tree::flatten($tree);
    }
}
