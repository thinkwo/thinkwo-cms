<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\HtmlCache;
use app\common\library\Lang;
use app\common\library\Translate;
use app\common\library\TransSync;
use think\facade\Db;

/**
 * 多语言管理
 *
 * 新增/启用语言后，这里负责把默认语言下的栏目与内容同步翻译过去，
 * 并自动生成前台界面文案 lang/{code}.php。
 */
class Language extends Backend
{
    public function index()
    {
        $rows = [];
        try {
            $rows = Db::name('language')->order('sort asc, id asc')->select()->toArray();
        } catch (\Throwable $e) {
            $rows = [];
        }

        $default = Lang::defaultCode();
        foreach ($rows as &$row) {
            $code = (string)$row['code'];

            $row['count'] = (int)Db::name('content')->where('lang', $code)->count();
            $row['dict']  = is_file(root_path() . 'lang' . DIRECTORY_SEPARATOR . $code . '.php') ? 1 : 0;
            $row['is_default_lang'] = $code === $default ? 1 : 0;

            $progress = TransSync::progress($code);
            $row['sort_total'] = $progress['sort']['total'];
            $row['sort_done']  = $progress['sort']['done'];
            $row['cont_total'] = $progress['content']['total'];
            $row['cont_done']  = $progress['content']['done'];
            $row['manual']     = $progress['content']['manual'];

            if ($code === $default) {
                $row['percent'] = 100;
            } elseif ((int)$row['cont_total'] > 0) {
                $row['percent'] = (int)floor($row['cont_done'] / $row['cont_total'] * 100);
            } else {
                $row['percent'] = 0;
            }
        }
        unset($row);

        return $this->view('language/index', [
            'meta_title' => '多语言',
            'rows'       => $rows,
            'syncLang'   => strtolower(trim((string)$this->request->param('sync', ''))),
            'driverName' => Translate::label(),
            'engineOk'   => Translate::available(),
            'defaultLang' => $default,
        ]);
    }

    /**
     * 保存（新增或编辑）
     */
    public function save()
    {
        $post = $this->request->post();
        $id   = (int)($post['id'] ?? 0);

        $code = strtolower(trim((string)($post['code'] ?? '')));
        if (!preg_match('/^[a-z]{2}(-[a-z]{2,4})?$/', $code)) {
            return $this->fail('语言代码格式不对，例如 en、en-us、zh-cn');
        }

        $name = trim((string)($post['name'] ?? ''));
        if ($name === '') {
            return $this->fail('请填写语言名称');
        }

        $exists = Db::name('language')->where('code', $code)->where('id', '<>', $id)->find();
        if ($exists) {
            return $this->fail('该语言代码已存在');
        }

        $data = [
            'code'        => $code,
            'name'        => $name,
            'native_name' => (string)($post['native_name'] ?? $name),
            'region'      => (string)($post['region'] ?? $code),
            'dir'         => (string)($post['dir'] ?? 'ltr') === 'rtl' ? 'rtl' : 'ltr',
            'is_default'  => (int)($post['is_default'] ?? 0) === 1 ? 1 : 0,
            'sort'        => (int)($post['sort'] ?? 0),
            'status'      => (int)($post['status'] ?? 1) === 1 ? 1 : 0,
        ];

        if ($data['is_default'] === 1) {
            Db::name('language')->where('id', '<>', $id)->update(['is_default' => 0]);
        }

        if ($id > 0) {
            Db::name('language')->where('id', $id)->update($data);
        } else {
            $data['createtime'] = time();
            Db::name('language')->insert($data);
        }

        Lang::flush();
        HtmlCache::clear();

        // 新增/启用语言 → 直接进入自动同步流程
        $needSync = $data['status'] === 1 && $code !== Lang::defaultCode() && Translate::available();

        return $this->okJump(
            $needSync ? '保存成功，开始同步内容…' : '保存成功',
            '/admin.php/language/index' . ($needSync ? '?sync=' . urlencode($code) : '')
        );
    }

    /**
     * 删除
     */
    public function delete()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }

        $row = Db::name('language')->where('id', $id)->find();
        if (!$row) {
            return $this->fail('语言不存在');
        }
        if ((int)$row['is_default'] === 1) {
            return $this->fail('默认语言不能删除，请先把其他语言设为默认');
        }
        if (Db::name('content')->where('lang', $row['code'])->count() > 0) {
            return $this->fail('该语言下还有内容，请先清理');
        }

        Db::name('language')->where('id', $id)->delete();
        // 连带清理该语言的栏目译文，避免残留孤立栏目
        try {
            Db::name('sort')->where('lang', $row['code'])->delete();
        } catch (\Throwable $e) {
            // 忽略
        }
        Lang::flush();
        HtmlCache::clear();

        return $this->ok('已删除');
    }

    /**
     * 分批同步（前端进度条循环调用）
     * GET lang, type=sort|content, offset, limit
     */
    public function chunk()
    {
        $lang   = strtolower(trim((string)$this->request->param('lang', '')));
        $type   = (string)$this->request->param('type', 'content') === 'sort' ? 'sort' : 'content';
        $offset = max(0, (int)$this->request->param('offset', 0));
        $limit  = (int)$this->request->param('limit', $type === 'sort' ? 20 : 5);

        if ($lang === '') {
            return $this->fail('缺少语言参数');
        }
        if (!Translate::available()) {
            return $this->fail('未配置翻译引擎，请到「站点设置 → 翻译设置」选择引擎（Google / MyMemory 免费无需密钥）');
        }

        $res = TransSync::chunk($lang, $type, $offset, $limit);
        $res['msg'] = '已完成 ' . $res['offset'] . ' / ' . $res['total'];

        return $this->ok($res['msg'], $res);
    }

    /**
     * 生成前台界面文案 lang/{code}.php（分批，前端循环调用）
     */
    public function dict()
    {
        $lang   = strtolower(trim((string)$this->request->param('lang', '')));
        $offset = max(0, (int)$this->request->param('offset', 0));
        $limit  = (int)$this->request->param('limit', 12);
        $force  = (string)$this->request->param('force', '0') === '1';

        if ($lang === '') {
            return $this->fail('缺少语言参数');
        }

        try {
            $res = TransSync::dictChunk($lang, $offset, $limit, $force);
        } catch (\Throwable $e) {
            return $this->fail('生成失败：' . mb_substr($e->getMessage(), 0, 120));
        }

        return $res['ok'] ? $this->ok($res['msg'], $res) : $this->fail($res['msg'], $res);
    }

    /**
     * 测试翻译引擎连通性
     */
    public function test()
    {
        try {
            return $this->ok(Translate::test());
        } catch (\Throwable $e) {
            return $this->fail('测试失败：' . mb_substr($e->getMessage(), 0, 160));
        }
    }
}
