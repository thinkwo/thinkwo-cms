<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\Visit as VisitLog;
use think\facade\Db;

/**
 * 访问统计
 *
 * 访客列表（一次访问一行）→ 点开看单次访问的逐页时间线
 */
class Visit extends Backend
{
    public function index()
    {
        [$page, $limit] = $this->pageParam(20);

        $days   = (int)$this->request->param('days', 7);
        $online = (int)$this->request->param('online', 0);
        $device = (string)$this->request->param('device', '');
        $kw     = trim((string)$this->request->param('keyword', ''));

        $build = function () use ($days, $online, $device, $kw) {
            $q = Db::name('visit');

            if ($days > 0) {
                $q->where('first_time', '>=', strtotime('-' . $days . ' days 00:00:00'));
            }
            if ($online === 1) {
                $q->where('last_time', '>=', time() - VisitLog::ONLINE_GAP);
            }
            if (in_array($device, ['desktop', 'mobile', 'tablet'], true)) {
                $q->where('device', $device);
            }
            if ($kw !== '') {
                $like = '%' . $kw . '%';
                $q->where(function ($sub) use ($like) {
                    $sub->whereLike('ip', $like)
                        ->whereOr('landing', 'like', $like)
                        ->whereOr('ref_host', 'like', $like)
                        ->whereOr('last_url', 'like', $like);
                });
            }

            return $q;
        };

        $total = 0;
        $rows  = [];
        $overview = VisitLog::overview();

        try {
            $total = (int)$build()->count();
            $list  = $build()->order('last_time desc, id desc')->page($page, $limit)->select()->toArray();
        } catch (\Throwable $e) {
            $list = [];
        }

        $now = time();
        foreach ($list as $row) {
            $row['online']       = ((int)$row['last_time'] >= $now - VisitLog::ONLINE_GAP) ? 1 : 0;
            $row['duration_txt'] = VisitLog::humanDuration((int)$row['duration']);
            $row['first_txt']    = date('m-d H:i', (int)$row['first_time']);
            $row['last_txt']     = VisitLog::humanTime((int)$row['last_time']);
            $row['ref_txt']      = (string)$row['ref_host'] !== '' ? (string)$row['ref_host'] : '直接访问';
            $row['device_txt']   = ['mobile' => '手机', 'tablet' => '平板', 'desktop' => '电脑'][$row['device']] ?? (string)$row['device'];
            $row['ip_txt']       = (string)$row['ip'];
            $row['landing_txt']  = (string)$row['landing'];
            $rows[] = $row;
        }

        return $this->view('visit/index', [
            'meta_title' => '访客记录',
            'rows'       => $rows,
            'total'      => $total,
            'page'       => $page,
            'limit'      => $limit,
            'days'       => $days,
            'online'     => $online,
            'device'     => $device,
            'keyword'    => $kw,
            'overview'   => $overview,
        ]);
    }

    /**
     * 单个访客的访问详情（逐页时间线）
     */
    public function detail()
    {
        $id = (int)$this->request->param('id', 0);
        if ($id <= 0) {
            return $this->deny('参数错误', '/admin.php/visit/index');
        }

        try {
            $row = Db::name('visit')->where('id', $id)->find();
        } catch (\Throwable $e) {
            $row = null;
        }

        if (!$row) {
            return $this->deny('访客记录不存在或已清理', '/admin.php/visit/index');
        }

        $pages = [];
        try {
            $pages = Db::name('visit_page')
                ->where('visit_id', $id)
                ->order('enter_time asc, id asc')
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            $pages = [];
        }

        // 同一访客的历史访问（visitor 维度回访情况）
        $history = [];
        try {
            $history = Db::name('visit')
                ->where('vid', (string)$row['vid'])
                ->where('id', '<>', $id)
                ->order('last_time desc')
                ->limit(8)
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            $history = [];
        }

        $now = time();
        $row['online']       = ((int)$row['last_time'] >= $now - VisitLog::ONLINE_GAP) ? 1 : 0;
        $row['duration_txt'] = VisitLog::humanDuration((int)$row['duration']);
        $row['first_full']   = date('Y-m-d H:i:s', (int)$row['first_time']);
        $row['last_full']    = date('Y-m-d H:i:s', (int)$row['last_time']);
        $row['device_txt']   = ['mobile' => '手机', 'tablet' => '平板', 'desktop' => '电脑'][$row['device']] ?? (string)$row['device'];
        $row['ref_txt']      = (string)$row['ref_host'] !== '' ? (string)$row['ref_host'] : '直接访问';

        foreach ($pages as &$p) {
            $p['time_txt'] = date('H:i:s', (int)$p['enter_time']);
            $p['dur_txt']  = VisitLog::humanDuration((int)$p['duration']);
            $p['is_entry'] = (string)$p['url'] === (string)$row['landing'];
        }
        unset($p);

        foreach ($history as &$h) {
            $h['start_txt']    = date('m-d H:i', (int)$h['first_time']);
            $h['duration_txt'] = VisitLog::humanDuration((int)$h['duration']);
            $h['ref_txt']      = (string)$h['ref_host'] !== '' ? (string)$h['ref_host'] : '直接访问';
        }
        unset($h);

        return $this->view('visit/detail', [
            'meta_title' => '访问详情',
            'row'        => $row,
            'pages'      => $pages,
            'history'    => $history,
        ]);
    }

    /**
     * 页面热度排行
     */
    public function pages()
    {
        $days = (int)$this->request->param('days', 7);

        $since = $days > 0 ? strtotime('-' . $days . ' days 00:00:00') : 0;

        $rows = [];
        try {
            $q = Db::name('visit_page')->field(
                'url, COUNT(*) AS pv, COUNT(DISTINCT vid) AS uv, AVG(duration) AS avg_dur, MAX(enter_time) AS last_time, MAX(title) AS title'
            );
            if ($since > 0) {
                $q->where('enter_time', '>=', $since);
            }
            $rows = $q->group('url')->order('pv desc')->limit(100)->select()->toArray();
        } catch (\Throwable $e) {
            $rows = [];
        }

        // 把栏目页/详情页补上可读名称：能对上 slug 就显示标题
        $sortNames = [];
        try {
            foreach (Db::name('sort')->field('slug,name')->select()->toArray() as $s) {
                $sortNames[(string)$s['slug']] = (string)$s['name'];
            }
        } catch (\Throwable $e) {
            $sortNames = [];
        }

        foreach ($rows as &$r) {
            $r['pv']        = (int)$r['pv'];
            $r['uv']        = (int)$r['uv'];
            $r['avg_txt']   = VisitLog::humanDuration((int)round((float)$r['avg_dur']));
            $r['last_txt']  = VisitLog::humanTime((int)$r['last_time']);
            $r['name']      = (string)($r['title'] ?: '');
            $slug = trim((string)$r['url'], '/');
            $slug = explode('?', $slug)[0];
            $r['sort_name'] = $sortNames[$slug] ?? '';
        }
        unset($r);

        return $this->view('visit/pages', [
            'meta_title' => '页面热度',
            'rows'       => $rows,
            'days'       => $days,
        ]);
    }

    /**
     * 删除一条访客记录
     */
    public function delete()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $id = (int)$this->request->post('id', 0);
        if ($id <= 0) {
            return $this->fail('参数错误');
        }

        try {
            Db::name('visit')->where('id', $id)->delete();
            Db::name('visit_page')->where('visit_id', $id)->delete();
        } catch (\Throwable $e) {
            return $this->fail('删除失败：' . $e->getMessage());
        }

        return $this->ok('已删除');
    }

    /**
     * 清理历史数据（days=0 表示清空全部）
     */
    public function clean()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $days = (int)$this->request->post('days', 0);

        try {
            if ($days <= 0) {
                Db::name('visit_page')->where('id', '>', 0)->delete();
                Db::name('visit')->where('id', '>', 0)->delete();

                return $this->ok('已清空全部访客记录');
            }

            $before = strtotime('-' . $days . ' days');
            $ids    = Db::name('visit')->where('last_time', '<', $before)->column('id');
            if (!$ids) {
                return $this->ok('没有需要清理的记录');
            }
            Db::name('visit')->whereIn('id', $ids)->delete();
            Db::name('visit_page')->whereIn('visit_id', $ids)->delete();

            return $this->ok('已清理 ' . count($ids) . ' 条');
        } catch (\Throwable $e) {
            return $this->fail('清理失败：' . $e->getMessage());
        }
    }
}
