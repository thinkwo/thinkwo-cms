<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\HtmlCache;
use app\common\library\Settings;
use app\common\library\Theme;
use app\common\library\Translate;
use think\facade\Db;

/**
 * 站点设置
 */
class Setting extends Backend
{
    public function index()
    {
        $groups = self::fields();
        $values = Settings::all();
        $themes = Theme::available();

        // 把当前值塞回字段定义，模板里直接用 $field.value
        foreach ($groups as &$group) {
            $group['icon']  = (string)($group['icon'] ?? 'layui-icon-set');
            $group['desc']  = (string)($group['desc'] ?? '');
            $group['count'] = count($group['fields']);
            $group['need']  = 0;
            foreach ($group['fields'] as &$field) {
                $key = (string)$field['key'];
                $raw = (string)($values[$key] ?? '');
                // 密码类保留原样（可能含空格），其余去掉首尾空格便于判断「待填」
                $field['value'] = ($field['type'] ?? '') === 'password' ? $raw : trim($raw);
                // 没写 tip / placeholder 的字段补空串，避免模板取不到键
                $field['tip']         = (string)($field['tip'] ?? '');
                $field['placeholder'] = (string)($field['placeholder'] ?? '');
                // 主题字段：把可用主题转成统一的下拉选项（value=目录名）
                if (($field['type'] ?? '') === 'theme') {
                    $themeOpts = [];
                    foreach ($themes as $dir => $t) {
                        $themeOpts[(string)$dir] = (string)$t['name'] . '（v' . (string)$t['version'] . '）';
                    }
                    $field['options'] = self::optionList($themeOpts, $field['value']);
                } else {
                    $field['options'] = self::optionList((array)($field['options'] ?? []), $field['value']);
                }
                $field['need']        = in_array($key, self::REQUIRED_KEYS, true) && $field['value'] === '';
                if ($field['need']) {
                    $group['need']++;
                }
            }
            unset($field);
        }
        unset($group);

        // 当前分类（?tab=base），非法值回退到第一个分组
        $keys = array_column($groups, 'key');
        $tab  = (string)$this->request->get('tab', '');
        if (!in_array($tab, $keys, true)) {
            $tab = (string)($keys[0] ?? 'base');
        }

        $themes = Theme::available();

        return $this->view('setting/index', [
            'meta_title' => '站点设置',
            'groups'     => $groups,
            'values'     => $values,
            'themes'     => $themes,
            'tab'        => $tab,
            'langs'      => Db::name('language')->where('status', 1)->select()->toArray(),
        ]);
    }

    /**
     * 保存
     */
    public function save()
    {
        if (!$this->request->isPost()) {
            return $this->fail('Method Not Allowed');
        }

        $post = $this->request->post();

        $allow      = [];
        $switchKeys = [];
        foreach (self::fields() as $group) {
            foreach ($group['fields'] as $field) {
                $allow[(string)$field['key']] = (string)$group['name'];
                if (($field['type'] ?? '') === 'switch') {
                    $switchKeys[] = (string)$field['key'];
                }
            }
        }

        $data = [];
        foreach ($allow as $key => $groupName) {
            if (!array_key_exists($key, $post)) {
                // switch 未勾选时传空
                if (in_array($key, $switchKeys, true)) {
                    $data[$key] = '0';
                }
                continue;
            }
            $value = $post[$key];
            $data[$key] = is_array($value) ? implode(',', array_map('strval', $value)) : (string)$value;
        }

        // 下拉框值校验：不在选项内的一律丢弃（保留库里原值），防止脏值写进设置表
        $themeDirs = array_keys(Theme::available());
        foreach (self::fields() as $group) {
            foreach ($group['fields'] as $field) {
                $key  = (string)$field['key'];
                $type = (string)($field['type'] ?? '');
                if (!array_key_exists($key, $data)) {
                    continue;
                }
                if ($type === 'theme') {
                    if (!in_array($data[$key], $themeDirs, true)) {
                        unset($data[$key]);
                    }
                } elseif ($type === 'select') {
                    $opts = (array)($field['options'] ?? []);
                    if ($opts && !array_key_exists($data[$key], $opts)) {
                        unset($data[$key]);
                    }
                }
            }
        }

        Settings::saveMany($data);
        HtmlCache::clear();
        Theme::reset();
        // 换了主题或改了站点信息，版权审计结果要重算（页脚位置随主题变）
        \app\common\library\Brand::forget();

        // 保存后回到原来所在的分类，避免每次都跳回第一个
        $tab  = (string)($post['__tab'] ?? '');
        $back = '/admin.php/setting/index' . ($tab !== '' ? '?tab=' . urlencode($tab) : '');

        return $this->okJump('设置已保存', $back);
    }

    /**
     * 外贸站必须配置的关键项（为空时提示「待填」）
     */
    public const REQUIRED_KEYS = [
        'site_name', 'site_domain', 'logo',
        'company', 'phone', 'email', 'whatsapp',
        'site_description', 'og_image',
        'smtp_host', 'smtp_user', 'notify_email',
    ];

    /**
     * 还没填写的关键设置项（控制台用来做配置提醒）
     */
    public static function missingKeys(): array
    {
        $miss = [];
        foreach (self::ofRequired() as $key => $label) {
            if (trim((string)Settings::get($key, '')) === '') {
                $miss[$key] = $label;
            }
        }

        return $miss;
    }

    /**
     * 关键项 => 中文名（跨分组取）
     */
    protected static function ofRequired(): array
    {
        $map = [];
        foreach (self::fields() as $group) {
            foreach ($group['fields'] as $field) {
                if (in_array((string)$field['key'], self::REQUIRED_KEYS, true)) {
                    $map[(string)$field['key']] = (string)$field['label'];
                }
            }
        }

        return $map;
    }

    /**
     * 下拉选项统一成列表：[['value'=>..., 'label'=>..., 'selected'=>bool], ...]
     *
     * 注意：ThinkPHP 的 volist 标签 key 属性是「循环序号」，不是数组键，
     * 所以下拉框一律在控制器里转成带 value 的列表，模板只读 $opt.value，
     * 避免出现 value="1" value="2" 这种把真实键名丢掉的问题。
     */
    public static function optionList(array $options, string $current = ''): array
    {
        $list = [];
        foreach ($options as $value => $label) {
            $value = (string)$value;
            $list[] = [
                'value'    => $value,
                'label'    => (string)$label,
                'selected' => $value === $current,
            ];
        }

        return $list;
    }

    /**
     * 设置项定义
     *
     * type 支持：text textarea number select switch image color code theme
     */
    public static function fields(): array
    {
        $groups = [
            ['name' => '基础信息', 'key' => 'base', 'icon' => 'layui-icon-website',
                'desc' => '站点身份、Logo 与前台主题，决定买家第一眼看到的样子', 'fields' => [
                ['key' => 'site_name', 'label' => '网站名称', 'type' => 'text', 'tip' => '用于标题后缀与邮件署名'],
                ['key' => 'logo', 'label' => '网站 Logo', 'type' => 'image', 'tip' => '留空则显示站名文字；建议透明 PNG，高 60px 以内'],
                ['key' => 'logo_text', 'label' => 'Logo 文字', 'type' => 'text', 'tip' => '没有 Logo 图时显示的文字'],
                ['key' => 'favicon', 'label' => 'Favicon', 'type' => 'image', 'tip' => '浏览器标签页小图标，建议 32×32 或 64×64'],
                ['key' => 'theme', 'label' => '前台主题', 'type' => 'theme'],
                ['key' => 'site_domain', 'label' => '站点域名', 'type' => 'text', 'tip' => '例如 https://www.example.com，用于 canonical 与 sitemap'],
                ['key' => 'site_icp', 'label' => 'ICP 备案号', 'type' => 'text', 'placeholder' => '粤ICP备12345678号-1', 'tip' => '国内主机建站必须备案，填了就显示在页脚并自动链接工信部；用海外主机或未备案可留空，页脚不显示这一项'],
                ['key' => 'currency', 'label' => '默认货币', 'type' => 'text', 'tip' => '例如 USD、EUR，产品价格按此货币录入'],
            ]],
            ['name' => '联系方式', 'key' => 'contact', 'icon' => 'layui-icon-dialogue',
                'desc' => '展示给海外买家的公司名片，也用于结构化数据与邮件落款', 'fields' => [
                ['key' => 'company', 'label' => '公司名称', 'type' => 'text'],
                ['key' => 'phone', 'label' => '电话', 'type' => 'text', 'tip' => '建议带国际区号，例如 +86 138 0000 0000'],
                ['key' => 'email', 'label' => '邮箱', 'type' => 'text'],
                ['key' => 'whatsapp', 'label' => 'WhatsApp', 'type' => 'text', 'tip' => '填号码即可，前台会生成 wa.me 直达链接'],
                ['key' => 'wechat_qr', 'label' => '微信二维码', 'type' => 'image', 'tip' => '上传后页脚「联系」栏整栏显示这张二维码（国内站常用）；不上传则维持邮箱/电话等联系信息'],
                ['key' => 'address', 'label' => '地址', 'type' => 'textarea', 'tip' => '英文地址更利于 Google 识别与买家判断'],
                ['key' => 'country', 'label' => '国家代码', 'type' => 'text', 'tip' => '例如 CN、US，用于结构化数据'],
                ['key' => 'copyright', 'label' => '版权信息', 'type' => 'text'],
                ['key' => 'social_facebook', 'label' => 'Facebook', 'type' => 'text', 'tip' => '完整主页地址'],
                ['key' => 'social_linkedin', 'label' => 'LinkedIn', 'type' => 'text'],
                ['key' => 'social_youtube', 'label' => 'YouTube', 'type' => 'text'],
            ]],
            ['name' => 'SEO 设置', 'key' => 'seo', 'icon' => 'layui-icon-chart-screen',
                'desc' => '决定 Google 搜索结果里的标题、描述与社交分享卡片', 'fields' => [
                ['key' => 'seo_index_title', 'label' => '首页标题', 'type' => 'text', 'tip' => '留空则用网站名称；建议 30~60 字符'],
                ['key' => 'seo_title_format', 'label' => '标题格式', 'type' => 'text', 'tip' => '可用 {title} 与 {site_name}'],
                ['key' => 'site_keywords', 'label' => '默认关键词', 'type' => 'text', 'tip' => '英文逗号分隔，Google 已不看重但仍建议填写'],
                ['key' => 'site_description', 'label' => '默认描述', 'type' => 'textarea', 'tip' => '建议 120~160 字符，直接影响点击率'],
                ['key' => 'og_image', 'label' => '默认分享图', 'type' => 'image', 'tip' => '1200×630 最佳，用于 WhatsApp / Facebook 分享预览'],
                ['key' => 'sitemap_enable', 'label' => '开启 sitemap', 'type' => 'switch', 'tip' => '开启后可提交给 Google Search Console'],
                ['key' => 'html_cache', 'label' => '开启静态化', 'type' => 'switch', 'tip' => '生成 HTML 缓存，首字节更快；改模板后记得清缓存'],
            ]],
            ['name' => '代码与统计', 'key' => 'code', 'icon' => 'layui-icon-code-circle',
                'desc' => '统计代码与自定义脚本，原样输出到前台，填错会影响网站显示', 'fields' => [
                ['key' => 'analytics_code', 'label' => '统计代码', 'type' => 'code', 'tip' => 'GA4 / 百度统计脚本，原样输出到 head'],
                ['key' => 'head_code', 'label' => 'head 附加代码', 'type' => 'code', 'tip' => '例如 Google Search Console 验证 meta 标签'],
                ['key' => 'footer_code', 'label' => '底部附加代码', 'type' => 'code', 'tip' => '例如在线客服挂件、再营销像素'],
                ['key' => 'visit_enable', 'label' => '访客统计', 'type' => 'switch', 'tip' => '记录访客来源、浏览页面与停留时长；开启后前台自动加载约 2KB 统计脚本，不影响打开速度'],
                ['key' => 'visit_keep_days', 'label' => '记录保留天数', 'type' => 'text', 'tip' => '默认 90 天，超过自动清理；填 0 表示永久保留（数据量大时建议限制）'],
            ]],
            ['name' => '邮件与询盘', 'key' => 'smtp', 'icon' => 'layui-icon-email',
                'desc' => '询盘通知邮件与客户自动回复，填好才能第一时间接到询价', 'fields' => [
                ['key' => 'smtp_host', 'label' => 'SMTP 服务器', 'type' => 'text', 'tip' => '例如 smtp.qq.com、smtp.exmail.qq.com'],
                ['key' => 'smtp_port', 'label' => 'SMTP 端口', 'type' => 'text', 'tip' => 'SSL 用 465，TLS 用 587'],
                ['key' => 'smtp_user', 'label' => 'SMTP 账号', 'type' => 'text'],
                ['key' => 'smtp_pass', 'label' => 'SMTP 密码', 'type' => 'password', 'tip' => 'QQ 邮箱需使用「授权码」而非登录密码'],
                ['key' => 'smtp_secure', 'label' => '加密方式', 'type' => 'select', 'options' => ['ssl' => 'SSL', 'tls' => 'TLS', 'none' => '不加密']],
                ['key' => 'smtp_from', 'label' => '发件邮箱', 'type' => 'text', 'tip' => '留空则用 SMTP 账号'],
                ['key' => 'smtp_from_name', 'label' => '发件人名称', 'type' => 'text'],
                ['key' => 'notify_email', 'label' => '询盘通知邮箱', 'type' => 'text', 'tip' => '收到询盘时通知这个邮箱，可填多个用英文逗号分隔'],
                ['key' => 'inquiry_autoreply', 'label' => '客户自动回复', 'type' => 'switch', 'tip' => '开启后买家提交询盘会立刻收到一封确认邮件'],
            ]],
            ['name' => '翻译设置', 'key' => 'translate', 'icon' => 'layui-icon-transfer',
                'desc' => '多语言自动同步使用的引擎，免费引擎可直接用，付费引擎质量更稳', 'fields' => [
                ['key' => 'translate_driver', 'label' => '翻译引擎', 'type' => 'select',
                    'options' => Translate::engineOptions(),
                    'tip' => '免费无需密钥：Google、MyMemory（开箱可用）；百度 5 万字符/月、有道体验额度、DeepL 50 万字符/月为免费额度，超出按量付费。改完到「多语言」页点「测试连通」验证'],
                ['key' => 'translate_auto', 'label' => '保存后自动同步', 'type' => 'switch',
                    'tip' => '默认语言新增/编辑内容、栏目后自动翻译到其他已启用语言；关闭则只能手动点「翻译」'],
                ['key' => 'translate_auto_body', 'label' => '自动同步正文', 'type' => 'switch',
                    'tip' => '关闭则自动同步只翻标题/摘要/SEO，正文沿用原文；正文很长、接口较慢时可关掉加快保存'],
                ['key' => 'translate_appid', 'label' => 'APPID / Key', 'type' => 'text',
                    'tip' => '百度 APPID、有道应用 Key 或 DeepL auth_key；Google / MyMemory 留空'],
                ['key' => 'translate_secret', 'label' => '翻译密钥', 'type' => 'password', 'tip' => '百度/有道的密钥，DeepL 留空'],
                ['key' => 'translate_deepl_pro', 'label' => 'DeepL Pro 套餐', 'type' => 'switch', 'tip' => 'Pro 用 api.deepl.com，免费版用 api-free.deepl.com'],
            ]],
        ];

        return $groups;
    }
}
