<?php

declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\HtmlCache;
use app\common\library\IndexNow;
use app\common\library\Lang;
use app\common\library\License;
use app\common\library\Settings;
use app\common\library\TransSync;
use app\common\library\Visit as VisitLog;
use think\facade\Db;
use think\Response;

/**
 * 控制台
 */
class Index extends Backend
{
    /**
     * 实时访客面板靠轮询刷新，只要登录就允许拉取（不受角色权限限制，
     * 否则运营账号在首页只会看到一块空白）
     */
    protected array $noNeedRight = ['live'];
    /**
     * 后台框架（左侧菜单 + iframe）
     */
    public function index()
    {
        // 匿名心跳：分发版后台打开时向授权站报一次到（6h 节流，失败静默）
        try {
            \app\common\library\License::ping();
        } catch (\Throwable $e) {
            // 忽略
        }

        // 版权标识审计：客户删掉页脚版权时给出提醒（不阻断任何功能）
        $brand = ['ok' => true, 'missing' => []];
        try {
            $brand = \app\common\library\Brand::audit();
        } catch (\Throwable $e) {
            // 忽略
        }

        return $this->view('index/index', [
            'meta_title' => 'ThinkWo CMS 管理后台',
            'homeUrl'    => '/',
            'siteName'   => (string)Settings::get('site_name', '跨境圈子CMS'),
            'twVersion'  => (string)config('tw.version', '1.0'),
            'brandOk'    => !empty($brand['ok']),
            'brandMiss'  => implode('、', (array)($brand['missing'] ?? [])),
        ]);
    }

    /**
     * 仪表盘（iframe 内页）
     */
    public function dashboard()
    {
        $stat = ['content' => 0, 'sort' => 0, 'inquiry' => 0, 'new' => 0, 'today' => 0, 'lang' => 0];

        try {
            $stat['content'] = (int)Db::name('content')->where('status', 1)->count();
            $stat['sort']    = (int)Db::name('sort')->where('status', 1)->count();
            $stat['inquiry'] = (int)Db::name('inquiry')->count();
            $stat['new']     = (int)Db::name('inquiry')->where('status', 'new')->count();
            $stat['today']   = (int)Db::name('inquiry')->where('createtime', '>=', strtotime('today'))->count();
            $stat['lang']    = (int)Db::name('language')->where('status', 1)->count();
        } catch (\Throwable $e) {
            // 忽略
        }

        $cache  = HtmlCache::stats();
        $recent = [];
        try {
            $recent = Db::name('inquiry')->order('id desc')->limit(6)->select()->toArray();
        } catch (\Throwable $e) {
            $recent = [];
        }

        // 实时访客（首屏服务端渲染，之后前端每 10 秒局部刷新）
        $live = VisitLog::live(12);

        // 运行环境：转成 [label, value] 列表——volist 的 key 是循环序号，不是数组键
        $env = [];
        $lic = License::state();
        $licTxt = $lic['licensed']
            ? ($lic['edition'] === 'self' ? '自用完整版（无需授权）' : '已激活 · ' . $lic['reason'])
            : '未激活';
        $envPairs = [
            'ThinkWo 版本' => (string)config('tw.version'),
            '授权状态'    => $licTxt,
            '授权到期'    => (string)($lic['expire_txt'] ?? '-'),
            '升级服务到期' => (string)($lic['update_txt'] ?? '-'),
            'PHP 版本'    => PHP_VERSION,
            '服务器'      => (string)$this->request->server('SERVER_SOFTWARE', ''),
            '数据库'      => $this->dbVersion(),
            '静态化缓存'  => $cache['enable']
                ? '已开启（' . $cache['files'] . ' 个 / ' . round($cache['size'] / 1024, 1) . ' KB）'
                : '已关闭',
            '语言数量'    => count(Lang::all()) . ' 种',
            '站点域名'    => (string)Settings::get('site_domain', ''),
        ];
        foreach ($envPairs as $label => $value) {
            $env[] = ['label' => $label, 'value' => $value];
        }
        // 授权状态一行可点击，直达授权管理页
        foreach ($env as $i => $item) {
            if ($item['label'] === '授权状态') {
                $env[$i]['href'] = '/admin.php/system/license';
            }
        }

        // 各语言翻译完成度（外贸核心：一眼看出哪种语言还没翻完）
        $langStat = [];
        try {
            $langs = Db::name('language')->where('status', 1)->order('sort asc,id asc')->select()->toArray();
            foreach ($langs as $lg) {
                $item = [
                    'code'       => (string)$lg['code'],
                    'name'       => (string)$lg['name'],
                    'is_default' => (int)$lg['is_default'],
                    'percent'    => 100,
                    'desc'       => '原文语言',
                ];
                if (!$item['is_default']) {
                    try {
                        $p     = TransSync::progress($item['code']);
                        $total = (int)($p['content']['total'] ?? 0);
                        $done  = (int)($p['content']['done'] ?? 0);
                        $item['percent'] = $total > 0 ? (int)round($done / $total * 100) : 100;
                        $item['desc']    = $total > 0 ? $done . ' / ' . $total . ' 条已翻译' : '暂无内容';
                    } catch (\Throwable $e) {
                        $item['percent'] = 0;
                        $item['desc']    = '未同步';
                    }
                }
                $langStat[] = $item;
            }
        } catch (\Throwable $e) {
            $langStat = [];
        }

        // SEO 健康度
        $tdkMissing = 0;
        try {
            $tdkMissing = (int)Db::name('content')->where('status', 1)
                ->whereRaw("(seo_description IS NULL OR seo_description = '')")->count();
        } catch (\Throwable $e) {
        }

        $health = [
            'sitemap'     => Settings::get('sitemap_enable', '0') === '1',
            'indexnow'    => IndexNow::enabled(),
            'webp'        => (bool)config('tw.image.webp', true),
            'tdk_missing' => $tdkMissing,
        ];

        // 关键设置里还没填的项（提醒用户补齐公司名片、SMTP 等）
        $missing = [];
        try {
            $missing = Setting::missingKeys();
        } catch (\Throwable $e) {
        }

        return $this->view('index/dashboard', [
            'meta_title' => '控制台',
            'stat'       => $stat,
            'recent'     => $recent,
            'env'        => $env,
            'langStat'   => $langStat,
            'health'     => $health,
            'missing'    => $missing,
            'live'       => $live,
            'liveItems'  => $live['items'],
            'siteName'   => (string)Settings::get('site_name', 'ThinkWo'),
        ]);
    }

    /**
     * 实时访客数据（控制台首页每 10 秒轮询一次）
     *
     * 只读接口，返回在线人数、今日数字与最近浏览流水，前端局部刷新不闪屏。
     */
    public function live(): Response
    {
        return json([
            'code' => 1,
            'time' => date('H:i:s'),
            'data' => VisitLog::live(12),
        ]);
    }

    /**
     * 数据库版本
     */
    protected function dbVersion(): string
    {
        try {
            $row = Db::query('SELECT VERSION() AS v');

            return (string)($row[0]['v'] ?? '');
        } catch (\Throwable $e) {
            return '';
        }
    }
}
