<?php

// +----------------------------------------------------------------------
// | 后台菜单定义
// | 同步后写入 tw_admin_rule 表，name 为权限标识，path 为「控制器/方法」
// +----------------------------------------------------------------------

return [
    [
        'title' => '控制台',
        'name'  => 'dashboard',
        'path'  => 'index/dashboard',
        'icon'  => 'layui-icon-home',
    ],
    [
        'title'    => '内容管理',
        'name'     => 'content_group',
        'path'     => '',
        'icon'     => 'layui-icon-template-1',
        'children' => [
            ['title' => '内容列表', 'name' => 'content/index', 'path' => 'content/index'],
            ['title' => '添加内容', 'name' => 'content/add', 'path' => 'content/add', 'type' => 'button'],
            ['title' => '同步翻译', 'name' => 'content/translate', 'path' => 'content/translate', 'type' => 'button'],
            ['title' => '批量翻译', 'name' => 'content/translateBatch', 'path' => 'content/translateBatch', 'type' => 'button'],
            ['title' => '栏目管理', 'name' => 'sort/index', 'path' => 'sort/index'],
            ['title' => '栏目翻译', 'name' => 'sort/translate', 'path' => 'sort/translate', 'type' => 'button'],
            ['title' => '栏目字段', 'name' => 'sort/fields', 'path' => 'sort/fields', 'type' => 'button'],
            ['title' => '保存栏目字段', 'name' => 'sort/fieldSave', 'path' => 'sort/fieldSave', 'type' => 'button'],
            ['title' => '删除栏目字段', 'name' => 'sort/fieldDelete', 'path' => 'sort/fieldDelete', 'type' => 'button'],
            ['title' => '幻灯片', 'name' => 'slide/index', 'path' => 'slide/index'],
            ['title' => '幻灯片分组表单', 'name' => 'slide/groupForm', 'path' => 'slide/groupForm', 'type' => 'button'],
            ['title' => '保存分组', 'name' => 'slide/groupSave', 'path' => 'slide/groupSave', 'type' => 'button'],
            ['title' => '删除分组', 'name' => 'slide/groupDelete', 'path' => 'slide/groupDelete', 'type' => 'button'],
            ['title' => '幻灯片图片', 'name' => 'slide/items', 'path' => 'slide/items', 'type' => 'button'],
            ['title' => '幻灯片表单', 'name' => 'slide/form', 'path' => 'slide/form', 'type' => 'button'],
            ['title' => '保存幻灯片', 'name' => 'slide/save', 'path' => 'slide/save', 'type' => 'button'],
            ['title' => '删除幻灯片', 'name' => 'slide/delete', 'path' => 'slide/delete', 'type' => 'button'],
            ['title' => '幻灯片排序', 'name' => 'slide/move', 'path' => 'slide/move', 'type' => 'button'],
            ['title' => '幻灯片启停', 'name' => 'slide/toggle', 'path' => 'slide/toggle', 'type' => 'button'],
            ['title' => '附件管理', 'name' => 'attachment/index', 'path' => 'attachment/index'],
        ],
    ],
    [
        'title'    => '多语言',
        'name'     => 'lang_group',
        'path'     => '',
        'icon'     => 'layui-icon-location',
        'children' => [
            ['title' => '语言列表', 'name' => 'language/index', 'path' => 'language/index'],
            ['title' => '多货币', 'name' => 'currency/index', 'path' => 'currency/index'],
        ],
    ],
    [
        'title'    => '客户询盘',
        'name'     => 'inquiry_group',
        'path'     => '',
        'icon'     => 'layui-icon-dialogue',
        'children' => [
            ['title' => '询盘列表', 'name' => 'inquiry/index', 'path' => 'inquiry/index'],
            ['title' => '询价车', 'name' => 'inquiry/cart', 'path' => 'inquiry/cart'],
        ],
    ],
    [
        'title'    => 'SEO 工具',
        'name'     => 'seo_group',
        'path'     => '',
        'icon'     => 'layui-icon-chart-screen',
        'children' => [
            ['title' => 'SEO 概览', 'name' => 'seo/index', 'path' => 'seo/index'],
            ['title' => '301 跳转', 'name' => 'redirect/index', 'path' => 'redirect/index'],
        ],
    ],
    [
        'title'    => '访问统计',
        'name'     => 'visit_group',
        'path'     => '',
        'icon'     => 'layui-icon-chart',
        'children' => [
            ['title' => '访客记录', 'name' => 'visit/index', 'path' => 'visit/index'],
            ['title' => '页面热度', 'name' => 'visit/pages', 'path' => 'visit/pages'],
            ['title' => '访问详情', 'name' => 'visit/detail', 'path' => 'visit/detail', 'type' => 'button'],
            ['title' => '删除记录', 'name' => 'visit/delete', 'path' => 'visit/delete', 'type' => 'button'],
            ['title' => '清理记录', 'name' => 'visit/clean', 'path' => 'visit/clean', 'type' => 'button'],
        ],
    ],
    [
        'title'    => '插件',
        'name'     => 'plugin_group',
        'path'     => '',
        'icon'     => 'layui-icon-app',
        'children' => [
            ['title' => '插件管理', 'name' => 'plugin/index', 'path' => 'plugin/index'],
        ],
    ],
    [
        'title'    => '系统',
        'name'     => 'system_group',
        'path'     => '',
        'icon'     => 'layui-icon-set',
        'children' => [
            ['title' => '站点设置', 'name' => 'setting/index', 'path' => 'setting/index'],
            ['title' => '授权', 'name' => 'system/license', 'path' => 'system/license'],
            ['title' => '在线更新', 'name' => 'system/update', 'path' => 'system/update'],
            ['title' => '激活授权', 'name' => 'system/activate', 'path' => 'system/activate', 'type' => 'button'],
            ['title' => '刷新授权', 'name' => 'system/refresh', 'path' => 'system/refresh', 'type' => 'button'],
            ['title' => '清除授权', 'name' => 'system/unbind', 'path' => 'system/unbind', 'type' => 'button'],
            ['title' => '保存授权站', 'name' => 'system/saveApi', 'path' => 'system/saveApi', 'type' => 'button'],
            ['title' => '检查更新', 'name' => 'system/check', 'path' => 'system/check', 'type' => 'button'],
            ['title' => '执行更新', 'name' => 'system/install', 'path' => 'system/install', 'type' => 'button'],
            ['title' => '管理员', 'name' => 'admin/index', 'path' => 'admin/index'],
            ['title' => '角色组', 'name' => 'admin/group', 'path' => 'admin/group'],
        ],
    ],
];
