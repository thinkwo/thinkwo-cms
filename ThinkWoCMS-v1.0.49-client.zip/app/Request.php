<?php

declare(strict_types=1);

namespace app;

/**
 * 应用请求对象
 */
class Request extends \think\Request
{
    /**
     * 当前语言 code，例如 en
     */
    protected string $twLang = '';

    /**
     * 当前语言 URL 前缀，例如 en/（默认语言为空串）
     */
    protected string $twLangPrefix = '';

    public function setTwLang(string $code, string $prefix = ''): void
    {
        $this->twLang       = $code;
        $this->twLangPrefix = $prefix;
    }

    public function twLang(): string
    {
        return $this->twLang;
    }

    public function twLangPrefix(): string
    {
        return $this->twLangPrefix;
    }
}
