<?php

declare(strict_types=1);

namespace app;

use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\exception\Handle;
use think\exception\HttpException;
use think\exception\HttpResponseException;
use think\exception\ValidateException;
use think\Response;
use Throwable;

/**
 * 应用异常处理类
 */
class ExceptionHandle extends Handle
{
    /**
     * 不需要记录日志的异常
     */
    protected $ignoreReport = [
        HttpException::class,
        HttpResponseException::class,
        ModelNotFoundException::class,
        DataNotFoundException::class,
        ValidateException::class,
    ];

    /**
     * 记录日志
     */
    public function report(Throwable $exception): void
    {
        parent::report($exception);
    }

    /**
     * 渲染异常
     */
    public function render($request, Throwable $e): Response
    {
        if ($e instanceof HttpException) {
            $status = $e->getStatusCode();
            if ($status === 404 && !$request->isAjax()) {
                return Response::create($this->render404(), 'html', 404);
            }
            if ($status === 404) {
                return json(['code' => 0, 'msg' => 'Not Found'], 404);
            }
        }

        return parent::render($request, $e);
    }

    /**
     * 404 页面
     *
     * 优先用当前主题的 404.html 渲染（保持站点风格、SEO 标签正常）；
     * 渲染失败时回落到内置的纯静态页面，保证一定能出内容。
     */
    protected function render404(): string
    {
        try {
            $theme = \app\common\library\Theme::current();
            $file  = root_path() . 'template' . DIRECTORY_SEPARATOR . $theme . DIRECTORY_SEPARATOR . '404.html';

            if (is_file($file)) {
                $engine = \think\facade\View::engine();
                if (is_object($engine) && method_exists($engine, 'config')) {
                    $engine->config([
                        'view_path' => root_path() . 'template' . DIRECTORY_SEPARATOR . $theme . DIRECTORY_SEPARATOR,
                    ]);
                }

                \think\facade\View::assign(array_merge(
                    \app\common\controller\Frontend::siteVars(),
                    ['is_404' => 1]
                ));

                return \think\facade\View::fetch('/404');
            }
        } catch (Throwable $e) {
            // 交给下面的静态兜底
        }

        return '<!doctype html><html lang="en"><head><meta charset="utf-8">'
            . '<meta name="robots" content="noindex"><title>404 Not Found</title></head>'
            . '<body style="font-family:system-ui;padding:80px;text-align:center">'
            . '<h1 style="font-size:48px;margin:0">404</h1><p>Page not found.</p>'
            . '<p><a href="/">Back to home</a></p></body></html>';
    }
}
