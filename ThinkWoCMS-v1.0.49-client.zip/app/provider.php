<?php

// +----------------------------------------------------------------------
// | 容器绑定定义文件
// +----------------------------------------------------------------------

use app\ExceptionHandle;
use app\Request;

return [
    'think\Request'          => Request::class,
    'think\exception\Handle' => ExceptionHandle::class,
];
