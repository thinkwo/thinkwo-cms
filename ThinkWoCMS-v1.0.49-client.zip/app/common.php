<?php

// [TW-CMS-ZW-2026-8F3A1C] ThinkWoCMS 原创代码 · 未经授权不得二次分发
// +----------------------------------------------------------------------
// | 应用公共函数文件
// +----------------------------------------------------------------------

use app\common\library\Seo;
use app\common\library\Settings;
use app\common\library\TwUrl;

if (!function_exists('tw_setting')) {
    /**
     * 读取站点设置项
     *
     * @param string $key     设置键名
     * @param mixed  $default 默认值
     * @return mixed
     */
    function tw_setting(string $key, $default = null)
    {
        return Settings::get($key, $default);
    }
}

if (!function_exists('tw_url')) {
    /**
     * 生成站内 URL（自动带语言前缀）
     *
     * 用法：
     *   tw_url('')                      -> /
     *   tw_url('products')              -> /products/
     *   tw_url('products', ['page'=>2]) -> /products/page/2
     *   tw_url('detail', ['sort'=>'products','slug'=>'abc.html'])
     */
    function tw_url(string $name = '', array $params = []): string
    {
        return TwUrl::build($name, $params);
    }
}

if (!function_exists('tw_asset')) {
    /**
     * 主题静态资源 URL
     */
    function tw_asset(string $path): string
    {
        $theme = \app\common\library\Theme::current();
        return '/template/' . $theme . '/' . ltrim($path, '/');
    }
}

if (!function_exists('tw_seo')) {
    /**
     * 输出 SEO 头部标签（title / description / canonical / hreflang / og / jsonld）
     */
    function tw_seo(): string
    {
        return Seo::render();
    }
}

if (!function_exists('tw_lang')) {
    /**
     * 当前语言 code
     */
    function tw_lang(): string
    {
        return \app\common\library\Lang::code();
    }
}

if (!function_exists('__tw')) {
    /**
     * 界面文案翻译
     *
     * @param string $key 语言键名
     */
    function __tw(string $key, array $replace = []): string
    {
        $text = \app\common\library\Lang::dict($key);
        foreach ($replace as $k => $v) {
            $text = str_replace('{' . $k . '}', (string)$v, $text);
        }

        return $text;
    }
}

if (!function_exists('tw_e')) {
    /**
     * HTML 转义输出
     */
    function tw_e(?string $value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('tw_slug')) {
    /**
     * 生成 URL 别名（中文转拼音）
     */
    function tw_slug(string $text): string
    {
        return \app\common\library\Pinyin::slug($text);
    }
}

if (!function_exists('tw_date')) {
    /**
     * 时间格式化（按语言习惯）
     */
    function tw_date($time, string $format = 'M d, Y'): string
    {
        $ts = is_numeric($time) ? (int)$time : strtotime((string)$time);
        if (!$ts) {
            return '';
        }

        return date($format, $ts);
    }
}

if (!function_exists('tw_cut')) {
    /**
     * 截取纯文本
     */
    function tw_cut(?string $html, int $length = 160, string $suffix = ''): string
    {
        $text = trim(preg_replace('/\s+/u', ' ', strip_tags((string)$html)));
        if (mb_strlen($text, 'UTF-8') <= $length) {
            return $text;
        }

        return mb_substr($text, 0, $length, 'UTF-8') . $suffix;
    }
}

if (!function_exists('tw_price')) {
    /**
     * 价格输出：基准货币金额按当前浏览货币换算并格式化
     */
    function tw_price(float $amount, string $unit = ''): string
    {
        return \app\common\library\Currency::format($amount, null, $unit);
    }
}

if (!function_exists('tw_currency')) {
    /**
     * 当前浏览货币代码
     */
    function tw_currency(): string
    {
        return \app\common\library\Currency::code();
    }
}

if (!function_exists('tw_dict_json')) {
    /**
     * 当前语言的界面词条 JSON（基础 lang/{语言}.php + 主题词条合并）
     * 模板里用 {:tw_dict_json()} 注入给前端脚本，避免模板表达式解析命名空间反斜杠
     */
    function tw_dict_json(array $keys = []): string
    {
        $all = \app\common\library\Lang::dictAll();
        if ($keys) {
            $all = array_intersect_key($all, array_flip($keys));
        }

        return (string)json_encode(
            $all,
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
        );
    }
}

if (!function_exists('tw_brand_url')) {
    /**
     * 品牌官网地址（唯一来源：config/tw.php 的 brand.url）
     */
    function tw_brand_url(): string
    {
        return rtrim((string)config('tw.brand.url', 'https://www.thinkwocms.com'), '/');
    }
}

if (!function_exists('tw_brand_name')) {
    /**
     * 品牌名称
     */
    function tw_brand_name(): string
    {
        return (string)config('tw.brand.name', 'ThinkWo CMS');
    }
}

if (!function_exists('tw_brand_link')) {
    /**
     * 品牌版权链接（带 class 便于各主题自行排版）
     *
     * 模板里统一写 {:tw_brand_link()}，不要手写 a 标签，
     * 这样换官网域名只改 config/tw.php 一处。
     */
    function tw_brand_link(string $class = 'tw-brand', string $prefix = 'Powered by '): string
    {
        return $prefix
            . '<a class="' . htmlspecialchars($class, ENT_QUOTES) . '"'
            . ' href="' . htmlspecialchars(tw_brand_url(), ENT_QUOTES) . '"'
            . ' target="_blank" rel="noopener">'
            . htmlspecialchars(tw_brand_name(), ENT_QUOTES)
            . '</a>';
    }
}
