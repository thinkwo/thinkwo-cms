<?php

// +----------------------------------------------------------------------
// | 前台路由
// | 固定接口写在前面，其余全部交给 Dispatch 分发器（见 Dispatch.php）
// +----------------------------------------------------------------------

use think\facade\Route;

Route::rule('captcha', 'api/captcha');

Route::post('api/inquiry', 'api/inquiry');

Route::post('api/visit', 'api/visit');

Route::post('api/cart/add', 'api/cartAdd');
Route::post('api/cart/list', 'api/cartList');
Route::post('api/cart/update', 'api/cartUpdate');
Route::post('api/cart/remove', 'api/cartRemove');
Route::post('api/cart/clear', 'api/cartClear');

Route::miss('dispatch/index');
