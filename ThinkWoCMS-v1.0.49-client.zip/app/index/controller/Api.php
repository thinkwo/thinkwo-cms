<?php

declare(strict_types=1);

namespace app\index\controller;

use app\common\controller\Frontend;
use app\common\library\Captcha;
use app\common\library\Lang;
use app\common\library\Mailer;
use app\common\library\Settings;
use app\common\library\Tags;
use app\common\library\TwUrl;
use app\common\library\Visit;
use think\facade\Cache;
use think\facade\Db;
use think\Response;

/**
 * 前台接口：询盘提交、询价车、验证码
 */
class Api extends Frontend
{
    /**
     * 验证码图片
     */
    public function captcha(): Response
    {
        return Captcha::image();
    }

    /**
     * 访客打点（页面浏览 / 心跳 / 离开）
     *
     * 前端用 sendBeacon 或 fetch(keepalive) 上报，必须始终返回 200 且体积最小，
     * 统计失败绝不能影响用户浏览。
     */
    public function visit(): Response
    {
        if ($this->request->isPost()) {
            $in = $this->request->post();
            if (!is_array($in) || !$in) {
                // 部分环境 JSON body 需要手动解析
                $raw = (string)$this->request->getContent();
                $in  = $raw !== '' ? (array)json_decode($raw, true) : [];
            }

            try {
                Visit::record($in, (string)$this->request->ip(), (string)$this->request->header('user-agent', ''));
            } catch (\Throwable $e) {
                // 统计失败静默
            }
        }

        return Response::create('', 'html', 204, [
            'Cache-Control' => 'no-store, no-cache, must-revalidate',
        ]);
    }

    /**
     * 提交询盘
     */
    public function inquiry(): Response
    {
        if (!$this->request->isPost()) {
            return json(['code' => 0, 'msg' => 'Method Not Allowed'], 405);
        }

        $post = $this->request->post();

        // 蜜罐：机器人会填这个隐藏字段
        if (!empty($post['hp'])) {
            return json(['code' => 1, 'msg' => __tw('inquiry_success')]);
        }

        $cfg      = (array)config('tw.inquiry', []);
        $ip       = (string)$this->request->ip();
        $interval = (int)($cfg['interval'] ?? 20);

        if ($interval > 0) {
            $key = 'tw_inq_gap_' . md5($ip);
            if (Cache::get($key)) {
                return json(['code' => 0, 'msg' => __tw('too_frequent')]);
            }
            Cache::set($key, 1, $interval);
        }

        // 验证码
        if (!empty($cfg['captcha'])) {
            $code = (string)($post['captcha'] ?? '');
            if ($code === '') {
                return json(['code' => 0, 'msg' => __tw('captcha_required')]);
            }
            if (!captcha_check($code)) {
                return json(['code' => 0, 'msg' => __tw('captcha_error')]);
            }
        }

        $name    = trim((string)($post['name'] ?? ''));
        $email   = trim((string)($post['email'] ?? ''));
        $message = trim((string)($post['message'] ?? ''));

        if ($name === '') {
            return json(['code' => 0, 'msg' => __tw('name_required')]);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return json(['code' => 0, 'msg' => __tw('email_invalid')]);
        }
        if ($message === '') {
            return json(['code' => 0, 'msg' => __tw('message_required')]);
        }

        if (mb_strlen($message) > 5000) {
            return json(['code' => 0, 'msg' => 'Message is too long']);
        }

        // 图纸附件（可选，最多 5 个，单个 50MB 内）
        [$files, $fileErr] = $this->saveDrawings();
        if ($fileErr !== '') {
            return json(['code' => 0, 'msg' => $fileErr]);
        }
        if ($files) {
            $lines = [];
            foreach ($files as $f) {
                $lines[] = $f['name'] . ' (' . $f['size_txt'] . ') ' . $f['url'];
            }
            $message = trim($message) . "\n\n--- Attachments ---\n" . implode("\n", $lines);
        }

        // 产品带入：以服务端数据为准，前端传什么不算数
        $productId   = (int)($post['product_id'] ?? 0);
        $productName = '';
        $amount      = 0.0;
        if ($productId > 0) {
            try {
                $product = Db::name('content')->where('id', $productId)->where('status', 1)->find();
                if ($product) {
                    $productName = (string)$product['title'];
                    $amount      = (float)$product['price'];
                }
            } catch (\Throwable $e) {
                $productName = '';
            }
        }

        // 询价车明细
        $items = [];
        $rawItems = (string)($post['items'] ?? '');
        if ($rawItems !== '') {
            $decoded = json_decode($rawItems, true);
            if (is_array($decoded)) {
                foreach (array_slice($decoded, 0, 50) as $item) {
                    $pid   = (int)($item['id'] ?? 0);
                    $qty   = max(1, (int)($item['qty'] ?? 1));
                    $row   = null;
                    try {
                        $row = Db::name('content')->where('id', $pid)->where('status', 1)->find();
                    } catch (\Throwable $e) {
                        $row = null;
                    }
                    if (!$row) {
                        continue;
                    }
                    $price  = (float)$row['price'];
                    $items[] = [
                        'id'    => $pid,
                        'name'  => (string)$row['title'],
                        'qty'   => $qty,
                        'price' => $price,
                        'url'   => TwUrl::detail($row),
                    ];
                    $amount += $price * $qty;
                }
            }
        }

        $no = 'INQ' . date('YmdHis') . strtoupper(substr(md5(uniqid('', true)), 0, 4));

        $data = [
            'no'           => $no,
            'lang'         => Lang::code(),
            'name'         => mb_substr($name, 0, 100),
            'email'        => mb_substr($email, 0, 120),
            'phone'        => mb_substr(trim((string)($post['phone'] ?? '')), 0, 50),
            'whatsapp'     => mb_substr(trim((string)($post['whatsapp'] ?? '')), 0, 50),
            'company'      => mb_substr(trim((string)($post['company'] ?? '')), 0, 150),
            'country'      => mb_substr(trim((string)($post['country'] ?? '')), 0, 80),
            'subject'      => mb_substr(trim((string)($post['subject'] ?? $productName)), 0, 200),
            'message'      => $message,
            'product_id'   => $productId,
            'product_name' => $productName,
            'items'        => $items ? json_encode($items, JSON_UNESCAPED_UNICODE) : '',
            'amount'       => $amount,
            'currency'     => (string)Settings::get('currency', 'USD'),
            'source_url'   => mb_substr((string)($post['source_url'] ?? $this->request->header('referer', '')), 0, 500),
            'ip'           => $ip,
            'ua'           => mb_substr((string)$this->request->header('user-agent', ''), 0, 255),
            'status'       => 'new',
            'priority'     => 2,
            'createtime'   => time(),
            'updatetime'   => time(),
        ];

        try {
            Db::name('inquiry')->insert($data);
        } catch (\Throwable $e) {
            return json(['code' => 0, 'msg' => 'Save failed, please try again later']);
        }

        // 清空该 sid 的询价车
        $sid = (string)($post['sid'] ?? '');
        if ($sid !== '') {
            try {
                Db::name('cart')->where('sid', $sid)->delete();
            } catch (\Throwable $e) {
                // 忽略
            }
        }

        $this->notify($data, $items);

        \think\facade\Event::trigger('inquiry_saved', $data);

        return json(['code' => 1, 'msg' => __tw('inquiry_success'), 'no' => $no]);
    }

    /**
     * 保存询盘图纸附件（STEP / DWG / PDF …，最多 5 个，单个 50MB）
     *
     * 不转 WebP、不写附件库：这类文件站长只作报价参考，按年月存放在
     * public/uploads/rfq/ 下即可，路径写进询盘正文与通知邮件。
     *
     * @return array{0:array<int,array{name:string,url:string,size_txt:string}>,1:string}
     */
    protected function saveDrawings(): array
    {
        $raw = $this->request->file('drawings');
        if (empty($raw)) {
            return [[], ''];
        }

        $items = is_array($raw) ? array_values(array_filter($raw)) : [$raw];
        if (!$items) {
            return [[], ''];
        }

        $cfg     = (array)config('tw.inquiry', []);
        $maxNum  = max(1, (int)($cfg['file_max_num'] ?? 5));
        $maxSize = max(1, (int)($cfg['file_max_mb'] ?? 50)) * 1024 * 1024;

        if (count($items) > $maxNum) {
            return [[], 'Up to ' . $maxNum . ' files per request.'];
        }

        $allow = ['step', 'stp', 'igs', 'iges', 'x_t', 'x_b', 'sldprt', 'sldasm', 'dwg', 'dxf',
                  'pdf', 'zip', 'rar', '7z', 'jpg', 'jpeg', 'png', 'webp'];

        $relDir = 'uploads/rfq/' . date('Ym') . '/';
        $absDir = public_path() . $relDir;
        if (!is_dir($absDir)) {
            @mkdir($absDir, 0755, true);
        }
        if (!is_dir($absDir) || !is_writable($absDir)) {
            return [[], 'Upload directory is not writable, please send files by email.'];
        }

        $saved = [];
        foreach ($items as $file) {
            if (!$file || !$file->isValid()) {
                return [[], 'Upload failed, please try again or send files by email.'];
            }

            $origin = (string)$file->getOriginalName();
            $osize  = (int)$file->getSize();
            $ext    = strtolower((string)($file->getOriginalExtension() ?: pathinfo($origin, PATHINFO_EXTENSION)));

            if (!in_array($ext, $allow, true)) {
                return [[], '.' . $ext . ' files are not accepted.'];
            }
            if ($osize > $maxSize) {
                return [[], 'Each file must be under ' . (int)($cfg['file_max_mb'] ?? 50) . ' MB.'];
            }

            $name = date('His') . '-' . substr(md5(uniqid('', true)), 0, 8) . '.' . $ext;
            try {
                $file->move($absDir, $name);
            } catch (\Throwable $e) {
                return [[], 'Failed to save file, please try again.'];
            }

            $saved[] = [
                'name'     => mb_substr(preg_replace('/[\/\\\\:*?"<>|]/u', '', $origin) ?: ('file.' . $ext), 0, 80),
                'url'      => '/' . $relDir . $name,
                'size_txt' => $osize >= 1048576
                    ? round($osize / 1048576, 1) . ' MB'
                    : max(1, (int)round($osize / 1024)) . ' KB',
            ];
        }

        return [$saved, ''];
    }

    /**
     * 通知：给站长发提醒 + 给客户发自动回复
     */
    protected function notify(array $data, array $items): void
    {
        $to = (string)Settings::get('notify_email', Settings::get('email', ''));
        if ($to === '') {
            return;
        }

        $rows = '';
        foreach ([
            'Name'    => $data['name'],
            'Email'   => $data['email'],
            'Phone'   => $data['phone'],
            'Company' => $data['company'],
            'Country' => $data['country'],
            'No.'     => $data['no'],
        ] as $label => $value) {
            if ((string)$value === '') {
                continue;
            }
            $rows .= '<tr><td style="padding:6px 12px 6px 0;color:#888;white-space:nowrap">' . tw_e($label)
                . '</td><td style="padding:6px 0">' . tw_e((string)$value) . '</td></tr>';
        }

        $product = '';
        if ($items) {
            $product .= '<table style="width:100%;border-collapse:collapse;margin:12px 0">'
                . '<tr style="background:#f5f6f8"><th style="padding:8px;text-align:left">Product</th>'
                . '<th style="padding:8px">Qty</th></tr>';
            foreach ($items as $item) {
                $product .= '<tr><td style="padding:8px;border-top:1px solid #eee">' . tw_e($item['name'])
                    . '</td><td style="padding:8px;border-top:1px solid #eee;text-align:center">' . (int)$item['qty'] . '</td></tr>';
            }
            $product .= '</table>';
        } elseif ($data['product_name'] !== '') {
            $product = '<p style="margin:12px 0"><b>Product:</b> ' . tw_e($data['product_name']) . '</p>';
        }

        $body = '<table>' . $rows . '</table>' . $product
            . '<p style="margin:16px 0 6px;color:#888">Message</p>'
            . '<div style="background:#f7f8fa;padding:14px;border-radius:6px;white-space:pre-wrap">'
            . preg_replace('~(https?://[^\s<]+|/uploads/[^\s<]+)~', '<a href="$1">$1</a>', tw_e($data['message'])) . '</div>'
            . '<p style="margin-top:16px;color:#aaa;font-size:12px">Source: ' . tw_e($data['source_url']) . '</p>';

        Mailer::send($to, '[' . Settings::get('site_name', 'Website') . '] New inquiry ' . $data['no'], Mailer::wrap('New inquiry from website', $body));

        if (Settings::get('inquiry_autoreply', '1') === '1') {
            $reply = '<p>Dear ' . tw_e($data['name']) . ',</p>'
                . '<p>Thank you for contacting us. We have received your inquiry (No. ' . tw_e($data['no'])
                . ') and will reply within 24 hours.</p>'
                . '<p style="color:#888">' . nl2br(tw_e(tw_cut($data['message'], 300))) . '</p>'
                . '<p>Best regards,<br>' . tw_e((string)Settings::get('company', Settings::get('site_name', ''))) . '</p>';

            Mailer::send($data['email'], 'Re: Your inquiry ' . $data['no'], Mailer::wrap('We received your inquiry', $reply), $data['name']);
        }
    }

    /**
     * 询价车：加入
     */
    public function cartAdd(): Response
    {
        $sid = $this->sid();
        $id  = (int)$this->request->post('id', 0);
        $qty = max(1, (int)$this->request->post('qty', 1));

        if ($id <= 0) {
            return json(['code' => 0, 'msg' => 'Invalid product']);
        }

        try {
            $product = Db::name('content')->where('id', $id)->where('status', 1)->find();
        } catch (\Throwable $e) {
            $product = null;
        }
        if (!$product) {
            return json(['code' => 0, 'msg' => 'Product not found']);
        }

        $exists = Db::name('cart')->where('sid', $sid)->where('product_id', $id)->find();
        if ($exists) {
            Db::name('cart')->where('id', $exists['id'])->update(['qty' => (int)$exists['qty'] + $qty]);
        } else {
            Db::name('cart')->insert([
                'sid'          => $sid,
                'lang'         => Lang::code(),
                'product_id'   => $id,
                'product_name' => (string)$product['title'],
                'product_url'  => TwUrl::detail($product),
                'price'        => (float)$product['price'],
                'qty'          => $qty,
                'currency'     => (string)Settings::get('currency', 'USD'),
                'createtime'   => time(),
            ]);
        }

        return json(['code' => 1, 'msg' => __tw('added_to_cart'), 'count' => $this->cartCount($sid)]);
    }

    /**
     * 询价车：列表
     */
    public function cartList(): Response
    {
        return json(['code' => 1, 'data' => $this->cartItems($this->sid())]);
    }

    /**
     * 询价车：改数量
     */
    public function cartUpdate(): Response
    {
        $sid = $this->sid();
        $id  = (int)$this->request->post('id', 0);
        $qty = (int)$this->request->post('qty', 1);

        if ($qty <= 0) {
            Db::name('cart')->where('sid', $sid)->where('id', $id)->delete();
        } else {
            Db::name('cart')->where('sid', $sid)->where('id', $id)->update(['qty' => $qty]);
        }

        return json(['code' => 1, 'data' => $this->cartItems($sid)]);
    }

    /**
     * 询价车：删除
     */
    public function cartRemove(): Response
    {
        $sid = $this->sid();
        $id  = (int)$this->request->post('id', 0);
        Db::name('cart')->where('sid', $sid)->where('id', $id)->delete();

        return json(['code' => 1, 'data' => $this->cartItems($sid)]);
    }

    /**
     * 询价车：清空
     */
    public function cartClear(): Response
    {
        Db::name('cart')->where('sid', $this->sid())->delete();

        return json(['code' => 1, 'data' => []]);
    }

    /**
     * 当前会话ID（存 cookie，无需登录）
     */
    protected function sid(): string
    {
        $sid = (string)$this->request->cookie('tw_sid', '');
        if ($sid === '' || !preg_match('/^[a-f0-9]{32}$/', $sid)) {
            $sid = bin2hex(random_bytes(16));
            cookie('tw_sid', $sid, 86400 * 30);
        }

        return $sid;
    }

    /**
     * 询价车明细
     */
    protected function cartItems(string $sid): array
    {
        try {
            $rows = Db::name('cart')->where('sid', $sid)->order('id asc')->select()->toArray();
        } catch (\Throwable $e) {
            return [];
        }

        $total = 0.0;
        foreach ($rows as &$row) {
            $row['subtotal'] = (float)$row['price'] * (int)$row['qty'];
            $total += $row['subtotal'];
        }
        unset($row);

        return ['items' => $rows, 'total' => $total, 'count' => count($rows)];
    }

    /**
     * 询价车数量
     */
    protected function cartCount(string $sid): int
    {
        try {
            return (int)Db::name('cart')->where('sid', $sid)->count();
        } catch (\Throwable $e) {
            return 0;
        }
    }
}
