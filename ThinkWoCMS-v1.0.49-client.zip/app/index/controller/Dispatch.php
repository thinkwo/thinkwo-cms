<?php

declare(strict_types=1);

namespace app\index\controller;

use app\common\controller\Frontend;
use app\common\library\HtmlCache;
use app\common\library\ImageTool;
use app\common\library\Lang;
use app\common\library\Seo;
use app\common\library\Settings;
use app\common\library\Tags;
use app\common\library\TwUrl;
use think\facade\Db;
use think\Response;

/**
 * 前台路由分发器
 *
 * 所有前台地址都由这里解析，好处是：
 * 1. URL 规则集中在一处，改规则不用动路由文件
 * 2. 可以在解析阶段插入 301 跳转、静态化缓存、语言识别
 */
class Dispatch extends Frontend
{
    /**
     * 入口
     */
    public function index()
    {
        $path = trim((string)$this->request->pathinfo(), '/');

        // 1. 语言前缀识别
        [$code, $rest] = $this->resolveLang($path);
        Lang::set($code);
        $this->setupView();

        // 2. 301 跳转表
        $redirect = $this->checkRedirect('/' . $path);
        if ($redirect !== null) {
            return redirect($redirect['url'], $redirect['code']);
        }

        // 3. 静态化缓存
        $cacheKey = '/' . $path . ($code !== Lang::defaultCode() ? '' : '');
        if (HtmlCache::cacheable($cacheKey)) {
            $cached = HtmlCache::get($cacheKey);
            if ($cached !== null) {
                return Response::create($cached, 'html', 200);
            }
        }

        // 4. 解析
        $response = $this->route($rest);

        // 5. 写缓存
        if ($response instanceof Response && $response->getCode() === 200) {
            HtmlCache::put($cacheKey, (string)$response->getContent());
        }

        return $response;
    }

    /**
     * 识别语言前缀
     *
     * @return array{0:string,1:string} [语言code, 去掉前缀后的路径]
     */
    protected function resolveLang(string $path): array
    {
        $default = Lang::defaultCode();
        $langs   = Lang::all();

        $segments = $path === '' ? [] : explode('/', $path);
        $first    = $segments[0] ?? '';

        if ($first !== '' && isset($langs[$first]) && $first !== $default) {
            array_shift($segments);

            return [$first, implode('/', $segments)];
        }

        return [$default, $path];
    }

    /**
     * 301 跳转
     */
    protected function checkRedirect(string $path): ?array
    {
        try {
            $row = Db::name('redirect')->where('from_path', $path)->where('status', 1)->find();
        } catch (\Throwable $e) {
            return null;
        }

        if (!$row) {
            return null;
        }

        try {
            Db::name('redirect')->where('id', $row['id'])->inc('hits')->update();
        } catch (\Throwable $e) {
            // 忽略
        }

        return [
            'url'  => (string)$row['to_path'],
            'code' => (int)$row['code'] === 302 ? 302 : 301,
        ];
    }

    /**
     * 路径分发
     */
    protected function route(string $rest): Response
    {
        $rest = trim($rest, '/');

        // sitemap
        if ($rest === 'sitemap.xml') {
            return $this->sitemapIndex();
        }
        if (preg_match('#^sitemap-([a-zA-Z0-9\-]+)\.xml$#', $rest, $m)) {
            return $this->sitemapLang($m[1]);
        }
        if ($rest === 'robots.txt') {
            return $this->robots();
        }

        // 站内搜索
        if ($rest === 'search') {
            return $this->search();
        }

        // 询盘页
        if ($rest === 'message' || $rest === 'contact.html') {
            return $this->message();
        }

        // 列表分页
        if (preg_match('#^([a-zA-Z0-9\-]+)/page/(\d+)$#', $rest, $m)) {
            return $this->lists($m[1], max(1, (int)$m[2]));
        }

        // 内容详情
        if (preg_match('#^([a-zA-Z0-9\-]+)/([a-zA-Z0-9\-_]+)\.html$#', $rest, $m)) {
            return $this->detail($m[1], $m[2]);
        }

        // 单页
        if (preg_match('#^([a-zA-Z0-9\-]+)\.html$#', $rest, $m)) {
            return $this->single($m[1]);
        }

        // 栏目列表
        if (preg_match('#^([a-zA-Z0-9\-]+)$#', $rest, $m)) {
            return $this->lists($m[1], 1);
        }

        // 首页
        if ($rest === '') {
            return $this->home();
        }

        return $this->render404();
    }

    /**
     * 取栏目
     */
    protected function findSort(string $slug): ?array
    {
        try {
            $row = Db::name('sort')
                ->where('lang', Lang::code())
                ->where('slug', $slug)
                ->where('status', 1)
                ->find();
        } catch (\Throwable $e) {
            return null;
        }

        return $row ?: null;
    }

    /**
     * 首页
     */
    protected function home(): Response
    {
        Seo::set([
            'title'       => Lang::text((string)Settings::get('seo_index_title', '')),
            'description' => Lang::text((string)Settings::get('site_description', '')),
            'keywords'    => Lang::text((string)Settings::get('site_keywords', '')),
            'canonical'   => TwUrl::home(),
        ]);

        // 多语言首页互指
        $alts = [];
        foreach (Lang::all() as $code => $lang) {
            $alts[$code] = TwUrl::home((string)$code);
        }
        Seo::alternates($alts);

        Seo::jsonld(Seo::organization());
        Seo::jsonld(Seo::website());

        return $this->render('index', [
            'is_home' => 1,
        ]);
    }

    /**
     * 栏目列表页
     */
    protected function lists(string $slug, int $page): Response
    {
        $sort = $this->findSort($slug);
        if (!$sort) {
            return $this->render404();
        }

        if ($sort['type'] === 'link' && $sort['link'] !== '') {
            return redirect((string)$sort['link'], 301);
        }

        if ($sort['type'] === 'page') {
            return $this->single($slug);
        }

        $position = [
            ['name' => __tw('home'), 'url' => TwUrl::home()],
            ['name' => (string)$sort['name'], 'url' => TwUrl::sort($sort)],
        ];

        Tags::context([
            'sort'     => $sort,
            'position' => $position,
        ]);

        $canonical = $sort['canonical'] !== '' ? (string)$sort['canonical'] : TwUrl::sort($sort, $page);

        Seo::set([
            'title'       => (string)($sort['seo_title'] ?: $sort['name']),
            'description' => (string)($sort['seo_description'] ?: $sort['description']),
            'keywords'    => (string)$sort['seo_keywords'],
            'canonical'   => $canonical,
            'og_type'     => 'website',
            'og_image'    => (string)$sort['pic'],
        ]);

        if ($sort['trans_key'] !== '') {
            Seo::alternates(Tags::translateSortUrls((string)$sort['trans_key']));
        }

        Seo::jsonld(Seo::breadcrumb($position));

        $template = (string)($sort['template_list'] ?: 'lists');

        return $this->render($template, [
            'sort'    => $this->decorateSort($sort),
            'tw_page' => $page,
            'position' => $position,
            'canonical' => $canonical,
        ]);
    }

    /**
     * 内容详情页
     */
    protected function detail(string $sortSlug, string $slug): Response
    {
        $sort = $this->findSort($sortSlug);
        if (!$sort) {
            return $this->render404();
        }

        try {
            $content = Db::name('content')
                ->where('lang', Lang::code())
                ->where('sort_id', (int)$sort['id'])
                ->where('slug', $slug)
                ->where('status', 1)
                ->find();
        } catch (\Throwable $e) {
            $content = null;
        }

        if (!$content) {
            return $this->render404();
        }

        // 浏览计数
        try {
            Db::name('content')->where('id', $content['id'])->inc('views')->update();
        } catch (\Throwable $e) {
            // 忽略
        }

        $position = [
            ['name' => __tw('home'), 'url' => TwUrl::home()],
            ['name' => (string)$sort['name'], 'url' => TwUrl::sort($sort)],
            ['name' => (string)$content['title'], 'url' => TwUrl::detail($content, $sort)],
        ];

        Tags::context([
            'sort'     => $sort,
            'content'  => $content,
            'position' => $position,
        ]);

        $content   = Tags::decorateContent($content);
        $canonical = (string)$content['canonical'] !== '' ? (string)$content['canonical'] : TwUrl::detail($content, $sort);

        // 装饰后回写上下文，保证 {tw:content /} 拿到的也是完整数据
        Tags::context(['content' => $content]);

        Seo::set([
            'title'       => (string)($content['seo_title'] ?: $content['title']),
            'description' => (string)($content['seo_description'] ?: $content['summary'] ?: tw_cut((string)$content['content'], 160)),
            'keywords'    => (string)$content['seo_keywords'],
            'canonical'   => $canonical,
            'robots'      => (int)$content['noindex'] === 1 ? 'noindex,follow' : 'index,follow',
            'og_type'     => $sort['type'] === 'product' ? 'product' : 'article',
            'og_image'    => (string)$content['ico'],
        ]);

        if ($content['trans_key'] !== '') {
            Seo::alternates(Tags::translateUrls((string)$content['trans_key'], Tags::sortSlugMap()));
        }

        Seo::jsonld(Seo::breadcrumb($position));
        if ((string)$sort['slug'] === 'products' || (string)Settings::get('product_sort', 'products') === (string)$sort['slug']) {
            Seo::jsonld(Seo::product($content));
        } else {
            Seo::jsonld(Seo::article($content));
        }

        $template = (string)($sort['template_detail'] ?: 'detail');

        return $this->render($template, [
            'sort'    => $this->decorateSort($sort),
            'content' => $content,
            'position' => $position,
            'canonical' => $canonical,
            'prev'    => Tags::nearby((int)$sort['id'], (int)($content['publish_time'] ?: $content['createtime']), (int)$content['id'], 'prev'),
            'next'    => Tags::nearby((int)$sort['id'], (int)($content['publish_time'] ?: $content['createtime']), (int)$content['id'], 'next'),
        ]);
    }

    /**
     * 单页（关于我们 / 联系我们这类只有一个内容的栏目）
     */
    protected function single(string $slug): Response
    {
        $sort = $this->findSort($slug);
        if (!$sort) {
            return $this->render404();
        }

        try {
            $content = Db::name('content')
                ->where('lang', Lang::code())
                ->where('sort_id', (int)$sort['id'])
                ->where('status', 1)
                ->order('sort asc, id asc')
                ->find();
        } catch (\Throwable $e) {
            $content = null;
        }

        $position = [
            ['name' => __tw('home'), 'url' => TwUrl::home()],
            ['name' => (string)$sort['name'], 'url' => TwUrl::sort($sort)],
        ];

        Tags::context([
            'sort'     => $sort,
            'content'  => $content,
            'position' => $position,
        ]);

        Seo::set([
            'title'       => (string)($sort['seo_title'] ?: $sort['name']),
            'description' => (string)($sort['seo_description'] ?: $sort['description']),
            'keywords'    => (string)$sort['seo_keywords'],
            'canonical'   => $sort['canonical'] !== '' ? (string)$sort['canonical'] : TwUrl::sort($sort),
        ]);

        if ($sort['trans_key'] !== '') {
            Seo::alternates(Tags::translateSortUrls((string)$sort['trans_key']));
        }

        Seo::jsonld(Seo::breadcrumb($position));

        $template = (string)($sort['template_page'] ?: 'page');

        $content = $content ? Tags::decorateContent($content) : [];
        Tags::context(['content' => $content]);

        return $this->render($template, [
            'sort'    => $this->decorateSort($sort),
            'content' => $content,
            'position' => $position,
        ]);
    }

    /**
     * 站内搜索
     */
    protected function search(): Response
    {
        $keyword = trim((string)$this->request->get('kw', ''));
        $page    = max(1, (int)$this->request->get('page', 1));

        Tags::context(['sort' => null, 'keyword' => $keyword]);

        Seo::set([
            'title'       => $keyword !== '' ? $keyword : __tw('search'),
            'description' => '',
            'canonical'   => TwUrl::search($keyword),
            'robots'      => 'noindex,follow',
        ]);

        return $this->render('search', [
            'keyword' => $keyword,
            'tw_page' => $page,
            'position' => [
                ['name' => __tw('home'), 'url' => TwUrl::home()],
                ['name' => __tw('search'), 'url' => TwUrl::search()],
            ],
        ]);
    }

    /**
     * 询盘页
     */
    protected function message(): Response
    {
        Tags::context(['sort' => null]);

        Seo::set([
            'title'       => __tw('contact_us'),
            'description' => (string)Settings::get('site_description', ''),
            'canonical'   => TwUrl::message(),
        ]);

        Seo::jsonld(Seo::breadcrumb([
            ['name' => __tw('home'), 'url' => TwUrl::home()],
            ['name' => __tw('contact_us'), 'url' => TwUrl::message()],
        ]));

        return $this->render('message', [
            'position' => [
                ['name' => __tw('home'), 'url' => TwUrl::home()],
                ['name' => __tw('contact_us'), 'url' => TwUrl::message()],
            ],
        ]);
    }

    /**
     * sitemap 索引
     */
    protected function sitemapIndex(): Response
    {
        $items = '';
        foreach (Lang::all() as $code => $lang) {
            $lastmod = date('c');
            try {
                $max = Db::name('content')->where('lang', $code)->max('updatetime');
                if ($max) {
                    $lastmod = date('c', (int)$max);
                }
            } catch (\Throwable $e) {
                // 忽略
            }

            $items .= '<sitemap><loc>' . tw_e(Seo::abs(TwUrl::sitemapLang((string)$code)))
                . '</loc><lastmod>' . $lastmod . '</lastmod></sitemap>';
        }

        $xml = '<?xml version="1.0" encoding="UTF-8"?>'
            . '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . $items . '</sitemapindex>';

        return Response::create($xml, 'html', 200, ['Content-Type' => 'application/xml; charset=utf-8']);
    }

    /**
     * 单语言 sitemap
     */
    protected function sitemapLang(string $code): Response
    {
        $langs = Lang::all();
        if (!isset($langs[$code])) {
            return $this->render404();
        }

        $urls = [];
        $urls[] = ['loc' => Seo::abs(TwUrl::home($code)), 'lastmod' => date('c'), 'priority' => '1.0'];

        // 栏目
        try {
            $sorts = Db::name('sort')->where('lang', $code)->where('status', 1)->where('type', '<>', 'link')->select()->toArray();
        } catch (\Throwable $e) {
            $sorts = [];
        }
        $sortMap = [];
        foreach ($sorts as $sort) {
            $sortMap[(int)$sort['id']] = $sort;
            $urls[] = [
                'loc'      => Seo::abs(TwUrl::sort($sort, 1, $code)),
                'lastmod'  => date('c', (int)($sort['updatetime'] ?: $sort['createtime'])),
                'priority' => '0.8',
            ];
        }

        // 内容
        try {
            $contents = Db::name('content')
                ->where('lang', $code)
                ->where('status', 1)
                ->where('noindex', 0)
                ->field('id,slug,sort_id,updatetime,createtime')
                ->order('updatetime desc')
                ->limit(20000)
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            $contents = [];
        }

        foreach ($contents as $row) {
            $sort = $sortMap[(int)$row['sort_id']] ?? null;
            if (!$sort) {
                continue;
            }
            $urls[] = [
                'loc'      => Seo::abs(TwUrl::detail($row, $sort, $code)),
                'lastmod'  => date('c', (int)($row['updatetime'] ?: $row['createtime'])),
                'priority' => '0.6',
            ];
        }

        $xml = '<?xml version="1.0" encoding="UTF-8"?>'
            . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" '
            . 'xmlns:xhtml="http://www.w3.org/1999/xhtml">';

        foreach ($urls as $url) {
            $xml .= '<url><loc>' . tw_e($url['loc']) . '</loc>'
                . '<lastmod>' . $url['lastmod'] . '</lastmod>'
                . '<priority>' . $url['priority'] . '</priority></url>';
        }

        $xml .= '</urlset>';

        return Response::create($xml, 'html', 200, ['Content-Type' => 'application/xml; charset=utf-8']);
    }

    /**
     * robots.txt
     */
    protected function robots(): Response
    {
        $lines = [
            'User-agent: *',
            'Allow: /',
            'Disallow: /admin.php',
            'Disallow: /search',
            'Disallow: /api/',
            'Disallow: /runtime/',
            '',
            'Sitemap: ' . Seo::abs('/sitemap.xml'),
        ];

        return Response::create(implode("\n", $lines), 'html', 200, ['Content-Type' => 'text/plain; charset=utf-8']);
    }

    /**
     * 补全栏目派生字段
     */
    protected function decorateSort(array $sort): array
    {
        $sort['url']    = TwUrl::sort($sort);
        $sort['pic']    = ImageTool::webpUrl((string)($sort['pic'] ?? ''));
        $sort['ico']    = ImageTool::webpUrl((string)($sort['ico'] ?? ''));
        $sort['children'] = [];
        try {
            $sort['children'] = Db::name('sort')
                ->where('lang', Lang::code())
                ->where('pid', (int)$sort['id'])
                ->where('status', 1)
                ->order('sort asc, id asc')
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            $sort['children'] = [];
        }
        foreach ($sort['children'] as &$child) {
            $child['url'] = TwUrl::sort($child);
        }
        unset($child);

        return $sort;
    }
}
