<?php

declare(strict_types=1);

namespace app;

use think\Service;

/**
 * 应用服务类
 */
class AppService extends Service
{
    public function register(): void
    {
        // 注册应用服务绑定
    }

    public function boot(): void
    {
        // 插件加载（后台与前台共用）
        if (is_file(root_path() . 'install.lock')) {
            try {
                \app\common\library\Plugin::boot();
            } catch (\Throwable $e) {
                // 插件异常不阻断整站
            }
        }
    }
}
