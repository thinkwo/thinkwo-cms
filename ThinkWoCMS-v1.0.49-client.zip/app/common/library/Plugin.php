<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Db;

/**
 * 插件管理器
 *
 * 目录规范：
 *   plugins/{name}/plugin.json     插件信息
 *   plugins/{name}/Plugin.php      入口类，命名空间 plugins\{name}
 *   plugins/{name}/config.php      后台配置项定义（可选）
 *   plugins/{name}/README.md       说明（可选）
 *
 * 入口类必须提供静态方法 register()，在 register() 里用
 * Plugin::listen('钩子名', 回调) 注册行为。
 */
class Plugin
{
    /**
     * 已加载的插件清单
     */
    protected static array $manifests = [];

    /**
     * 钩子表
     */
    protected static array $hooks = [];

    /**
     * 是否已 boot
     */
    protected static bool $booted = false;

    /**
     * 插件根目录
     */
    public static function path(string $name = ''): string
    {
        return root_path() . 'plugins' . DIRECTORY_SEPARATOR . ($name !== '' ? $name . DIRECTORY_SEPARATOR : '');
    }

    /**
     * 云端标记文件
     *
     * 有 plugins/{name}/.cloud = 从授权站装的云端插件；
     * 没有 = 本地插件（后台本地上传或手工放进来的）。
     * 不用 plugin.json 里的字段做判定，客户自己打包、改文件都会失真。
     */
    public static function cloudFlag(string $name): string
    {
        return self::path($name) . '.cloud';
    }

    /**
     * 插件来源：cloud / local
     */
    public static function source(string $name): string
    {
        return is_file(self::cloudFlag($name)) ? 'cloud' : 'local';
    }

    /**
     * 写入云端标记（由云端安装/升级流程调用）
     */
    public static function markCloud(string $name, array $info = []): void
    {
        $data = array_merge([
            'name' => $name,
            'from' => License::api(),
            'at'   => time(),
        ], $info);

        @file_put_contents(self::cloudFlag($name), (string)json_encode($data, JSON_UNESCAPED_UNICODE));
    }

    /**
     * 云端标记里的信息
     */
    public static function cloudInfo(string $name): array
    {
        $file = self::cloudFlag($name);
        if (!is_file($file)) {
            return [];
        }
        $data = json_decode((string)@file_get_contents($file), true);

        return is_array($data) ? $data : [];
    }

    /**
     * 到期停用锁文件
     *
     * 云端插件授权到期后，一旦客户手动停用就写一个锁：之后没续费不能再启用。
     * 续费后授权站下发的 expire_at 往后推（或改为永久），启用时自动解锁。
     */
    public static function lockFile(string $name): string
    {
        return self::path($name) . '.lock';
    }

    /**
     * 锁文件内容
     */
    public static function lockInfo(string $name): array
    {
        $file = self::lockFile($name);
        if (!is_file($file)) {
            return [];
        }
        $data = json_decode((string)@file_get_contents($file), true);

        return is_array($data) ? $data : [];
    }

    /**
     * 是否已上锁（到期后停用过）
     */
    public static function isLocked(string $name): bool
    {
        return is_file(self::lockFile($name));
    }

    /**
     * 上锁
     */
    public static function setLock(string $name, int $expireAt): void
    {
        @file_put_contents(self::lockFile($name), (string)json_encode([
            'name'      => $name,
            'expire_at' => $expireAt,
            'at'        => time(),
        ], JSON_UNESCAPED_UNICODE));
    }

    /**
     * 解锁（续费后启用时调用）
     */
    public static function clearLock(string $name): void
    {
        @unlink(self::lockFile($name));
    }

    /**
     * 扫描磁盘上的全部插件
     *
     * @return array name => manifest
     */
    public static function scan(): array
    {
        $dir = self::path();
        if (!is_dir($dir)) {
            return [];
        }

        $list = [];
        foreach ((array)scandir($dir) as $item) {
            if ($item === '.' || $item === '..' || $item === 'index.html') {
                continue;
            }
            $pluginDir = $dir . $item . DIRECTORY_SEPARATOR;
            $jsonFile  = $pluginDir . 'plugin.json';
            if (!is_dir($pluginDir) || !is_file($jsonFile)) {
                continue;
            }
            $json = json_decode((string)file_get_contents($jsonFile), true);
            if (!is_array($json)) {
                continue;
            }
            $json['name'] = $json['name'] ?? $item;
            $json['dir']  = $item;
            $list[$item]  = $json;
        }

        return $list;
    }

    /**
     * 已启用的插件
     */
    public static function enabled(): array
    {
        $all = self::scan();
        if (!$all) {
            return [];
        }

        $status = [];
        try {
            $rows = Db::name('plugin')->select()->toArray();
            foreach ($rows as $row) {
                $status[(string)$row['name']] = (int)$row['status'];
            }
        } catch (\Throwable $e) {
            $status = [];
        }

        $result = [];
        foreach ($all as $name => $manifest) {
            if (($status[$name] ?? 0) !== 1) {
                continue;
            }
            // 云端插件受授权站约束：插件被停用或本站未开通时不加载（自用版放行）
            if (self::source($name) === 'cloud' && !PluginLicense::usable($name)) {
                continue;
            }
            $result[$name] = $manifest;
        }

        return $result;
    }

    /**
     * 启动所有已启用插件
     */
    public static function boot(): void
    {
        if (self::$booted) {
            return;
        }
        self::$booted = true;

        // 注册插件命名空间自动加载
        spl_autoload_register(static function (string $class): void {
            if (!str_starts_with($class, 'plugins\\')) {
                return;
            }
            $parts = explode('\\', $class);
            if (count($parts) < 3) {
                return;
            }
            $file = self::path($parts[1]) . $parts[2] . '.php';
            if (is_file($file)) {
                require_once $file;
            }
        });

        foreach (self::enabled() as $name => $manifest) {
            self::$manifests[$name] = $manifest;
            $class = 'plugins\\' . $name . '\\Plugin';
            if (class_exists($class) && method_exists($class, 'register')) {
                try {
                    $class::register();
                } catch (\Throwable $e) {
                    // 插件异常不阻断整站
                }
            }
        }
    }

    /**
     * 注册钩子
     */
    public static function listen(string $hook, callable $callback, int $priority = 10): void
    {
        self::$hooks[$hook][$priority][] = $callback;
    }

    /**
     * 触发钩子
     *
     * @return array 所有回调的返回值
     */
    public static function run(string $hook, ...$args): array
    {
        if (empty(self::$hooks[$hook])) {
            return [];
        }

        $results = [];
        ksort(self::$hooks[$hook]);
        foreach (self::$hooks[$hook] as $callbacks) {
            foreach ($callbacks as $cb) {
                try {
                    $results[] = $cb(...$args);
                } catch (\Throwable $e) {
                    $results[] = null;
                }
            }
        }

        return $results;
    }

    /**
     * 读取插件配置
     *
     * @param string $name  插件名
     * @param string $key   配置键
     * @param mixed  $default
     */
    public static function config(string $name, string $key = '', $default = null)
    {
        static $cache = [];
        if (!isset($cache[$name])) {
            $json = '';
            try {
                $row = Db::name('plugin')->where('name', $name)->find();
                $json = $row ? (string)$row['config'] : '';
            } catch (\Throwable $e) {
                $json = '';
            }
            $data = $json !== '' ? json_decode($json, true) : [];
            $cache[$name] = is_array($data) ? $data : [];
        }

        if ($key === '') {
            return $cache[$name];
        }

        return $cache[$name][$key] ?? $default;
    }

    /**
     * 保存插件配置
     */
    public static function saveConfig(string $name, array $config): void
    {
        $json = json_encode($config, JSON_UNESCAPED_UNICODE);
        $row  = Db::name('plugin')->where('name', $name)->find();
        if ($row) {
            Db::name('plugin')->where('name', $name)->update([
                'config'     => $json,
                'updatetime' => time(),
            ]);
        } else {
            Db::name('plugin')->insert([
                'name'       => $name,
                'config'     => $json,
                'createtime' => time(),
                'updatetime' => time(),
            ]);
        }
    }

    /**
     * 启用 / 停用
     *
     * 云端插件的三条硬规则（自用版全部放行）：
     *  1. 授权端停用 / 本站未开通 => 不能启用（启用也不会被加载）
     *  2. 授权已到期 => 不能启用
     *  3. 到期后手动停用过 => 上锁，没续费不能启用（续费后 expire_at 变化自动解锁）
     *
     * @return array{ok:bool,msg:string}
     */
    public static function toggle(string $name, bool $enable): array
    {
        $all = self::scan();
        if (!isset($all[$name])) {
            return ['ok' => false, 'msg' => '插件不存在：' . $name];
        }

        $manifest = $all[$name];

        if (self::source($name) === 'cloud' && !PluginLicense::isSelf()) {
            $st = PluginLicense::of($name);

            if ($enable) {
                if (!$st['active']) {
                    return ['ok' => false, 'msg' => '授权端已停用该插件，客户站不能启用；如需继续使用请联系服务商'];
                }
                if (!$st['authorized']) {
                    return ['ok' => false, 'msg' => '本站未开通该插件' . ($st['price_text'] !== '' ? '（' . $st['price_text'] . '）' : '') . '，请先联系服务商开通'];
                }
                if ($st['expired']) {
                    return ['ok' => false, 'msg' => '插件授权已于 ' . $st['expire_txt'] . ' 到期，到期后不能启用，请续费后再启用'];
                }
                if (self::isLocked($name)) {
                    $lock     = self::lockInfo($name);
                    $lockExp  = (int)($lock['expire_at'] ?? 0);
                    $renewed  = $st['expire_at'] === 0 || $st['expire_at'] > $lockExp;

                    if (!$renewed) {
                        return ['ok' => false, 'msg' => '该插件授权到期后被手动停用，已锁定；续费（授权到期时间往后延）后才能重新启用'];
                    }
                    self::clearLock($name);
                }
            } elseif ($st['expired']) {
                // 到期状态下手动停用 => 上锁，续费前不能再启用
                self::setLock($name, (int)$st['expire_at']);
            }
        }

        $row = Db::name('plugin')->where('name', $name)->find();

        $data = [
            'name'        => $name,
            'title'       => (string)($manifest['title'] ?? $name),
            'version'     => (string)($manifest['version'] ?? '1.0.0'),
            'author'      => (string)($manifest['author'] ?? ''),
            'description' => (string)($manifest['description'] ?? ''),
            'status'      => $enable ? 1 : 0,
            'updatetime'  => time(),
        ];

        if ($row) {
            Db::name('plugin')->where('name', $name)->update($data);
        } else {
            $data['createtime'] = time();
            Db::name('plugin')->insert($data);
        }

        return ['ok' => true, 'msg' => $enable ? '已启用' : '已停用'];
    }

    /**
     * 卸载插件：备份目录 → 删文件 → 删菜单与插件记录 → 删桥接控制器 → 清缓存
     *
     * 只删插件自己带来的东西，不动主程序已有文件：
     *   - plugins/{name}/ 整个目录（先复制一份到 runtime/pluginupgrade/backup/uninstall/）
     *   - tw_admin_rule 里 plugin={name} 的菜单/权限规则
     *   - tw_plugin 里的记录（含配置）
     *   - app/admin/controller/ 下内容引用了 plugins\{name}\ 的桥接控制器
     * 插件自己建的数据表（如 tw_aiwriter_article）保留，避免误删客户数据。
     *
     * @return array{ok:bool,msg:string,backup?:string}
     */
    public static function uninstall(string $name): array
    {
        if (!preg_match('/^[a-z0-9_]{2,40}$/', $name)) {
            return ['ok' => false, 'msg' => '插件名不合法'];
        }

        $dir = rtrim(self::path($name), '/\\');
        // 只允许删 plugins/ 下面的直接子目录，防路径穿越
        if (!is_dir($dir) || str_contains($name, '..') || basename($dir) !== $name) {
            return ['ok' => false, 'msg' => '插件目录不存在：' . $name];
        }

        // 云端插件不允许卸载：文件由授权站下发，卸掉后客户端就再也装不回来。
        // 需要停止使用时点「停用」即可，插件仍可随云端升级。
        if (self::source($name) === 'cloud') {
            return ['ok' => false, 'msg' => '云端插件不能卸载，只能停用；如需彻底移除请联系服务商'];
        }

        $ver = '0.0.0';
        $mf  = @json_decode((string)@file_get_contents($dir . DIRECTORY_SEPARATOR . 'plugin.json'), true);
        if (is_array($mf) && (string)($mf['version'] ?? '') !== '') {
            $ver = (string)$mf['version'];
        }

        // 1. 先停用，避免卸载过程中还有请求按「已启用」去加载它
        try {
            $row = Db::name('plugin')->where('name', $name)->find();
            if ($row) {
                Db::name('plugin')->where('name', $name)->update(['status' => 0, 'updatetime' => time()]);
            }
        } catch (\Throwable $e) {
            // 停用失败不阻断，后面整行会被删掉
        }

        // 2. 备份整个插件目录（复制不动原位，复制失败就不往下走）
        $backup = PluginUpgrade::workDir() . 'backup' . DIRECTORY_SEPARATOR . 'uninstall'
            . DIRECTORY_SEPARATOR . $name . '-' . $ver . '-' . date('YmdHis');
        if (!self::copyTree($dir, $backup)) {
            return ['ok' => false, 'msg' => '备份插件目录失败（请检查 runtime 目录权限），已中止卸载'];
        }

        // 3. 删插件目录
        PluginUpgrade::rrmdir($dir);
        if (is_dir($dir)) {
            return ['ok' => false, 'msg' => '插件目录删除失败，可能被占用；备份在 ' . $backup . '，请手工删除 plugins/' . $name];
        }

        // 4. 删菜单与权限规则（不调 Menu::sync()，否则本请求已注册的钩子会把它重新写回来）
        try {
            Db::name('admin_rule')->where('plugin', $name)->delete();
        } catch (\Throwable $e) {
            // 忽略
        }

        // 5. 删插件记录（含配置）
        try {
            Db::name('plugin')->where('name', $name)->delete();
        } catch (\Throwable $e) {
            // 忽略
        }

        // 6. 删桥接控制器（只删内容里引用了 plugins\{name}\ 的那一个）
        $ctrlDir = app()->getBasePath() . 'admin' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR;
        foreach ((array)glob($ctrlDir . '*.php') as $file) {
            if (!is_file($file) || @filesize($file) > 262144) {
                continue;
            }
            $src = (string)@file_get_contents($file);
            if ($src !== '' && str_contains($src, 'plugins\\' . $name . '\\')) {
                @unlink($file);
            }
        }

        // 7. 清缓存，让前台/后台立即看不到它
        PluginUpgrade::flushCache();
        @unlink(PluginUpgrade::workDir() . 'remote.json');

        return [
            'ok'     => true,
            'msg'    => '已卸载插件 ' . $name . '（插件目录已备份到 runtime/pluginupgrade/backup/uninstall/）',
            'backup' => $backup,
        ];
    }

    /**
     * 递归复制目录
     */
    protected static function copyTree(string $src, string $dst): bool
    {
        $src = rtrim($src, '/\\');
        if (!is_dir($src)) {
            return false;
        }
        if (!is_dir($dst) && !@mkdir($dst, 0755, true) && !is_dir($dst)) {
            return false;
        }

        $ok = true;
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($src, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($it as $item) {
            $rel = substr($item->getPathname(), strlen($src) + 1);
            $to  = rtrim($dst, '/\\') . DIRECTORY_SEPARATOR . $rel;
            if ($item->isDir()) {
                if (!is_dir($to) && !@mkdir($to, 0755, true) && !is_dir($to)) {
                    $ok = false;
                }
            } else {
                if (!is_dir(dirname($to))) {
                    @mkdir(dirname($to), 0755, true);
                }
                if (!@copy($item->getPathname(), $to)) {
                    $ok = false;
                }
            }
        }

        return $ok;
    }

    /**
     * 已加载清单
     */
    public static function manifests(): array
    {
        return self::$manifests;
    }
}
