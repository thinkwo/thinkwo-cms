<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Session;
use think\Response;

/**
 * 自绘清晰验证码
 *
 * think-captcha 的杂点实为 50 个淡色字母、字符定位公式会画出图片边界，
 * 实际显示效果难以辨认，故改为自绘：
 *   - 4 位纯数字（剔除 0/1 等易混字符），等距排布，永不越界
 *   - 统一深色大字 + 轻微随机旋转，抗锯齿渲染
 *   - 仅两条浅色干扰弧线，人眼清晰、机器难认
 *
 * 会话格式与 think-captcha 完全一致（session 'captcha' => ['key' => bcrypt 哈希]），
 * 因此业务端的 captcha_check() 无需任何改动。
 */
class Captcha
{
    /** 验证码位数 */
    private const LENGTH = 4;

    /** 数字字符集（剔除 0/1，避免与 O/I 混淆） */
    private const CHARS = '23456789';

    /**
     * 输出验证码图片
     */
    public static function image(int $width = 132, int $height = 44): Response
    {
        // 生成验证码并按 think-captcha 的会话格式存储
        $code = '';
        $max  = strlen(self::CHARS) - 1;
        for ($i = 0; $i < self::LENGTH; $i++) {
            $code .= self::CHARS[random_int(0, $max)];
        }
        Session::set('captcha', [
            'key' => password_hash(mb_strtolower($code, 'UTF-8'), PASSWORD_BCRYPT, ['cost' => 10]),
        ]);

        // 画布（真彩色，imagettftext 自动抗锯齿）
        $im = imagecreatetruecolor($width, $height);
        $bg = imagecolorallocate($im, 248, 250, 253);
        imagefill($im, 0, 0, $bg);

        // 干扰弧线：浅蓝灰，两段
        $line = imagecolorallocate($im, 205, 216, 233);
        self::arc($im, $width, $height, $line);
        self::arc($im, $width, $height, $line);

        // 字体
        $font = root_path() . 'vendor/topthink/think-captcha/assets/ttfs/2.ttf';

        // 字色：深藏青，带轻微随机
        $color = imagecolorallocate($im, mt_rand(16, 40), mt_rand(38, 58), mt_rand(85, 115));

        $fontSize = 22;
        $slot     = $width / self::LENGTH;

        for ($i = 0; $i < self::LENGTH; $i++) {
            $char = $code[$i];
            $angle = mt_rand(-10, 10);

            if (is_file($font)) {
                // 按字形实际宽度在格内水平居中
                $box  = imagettfbbox($fontSize, 0, $font, $char);
                $cw   = abs($box[4] - $box[0]);
                $x    = (int) round($slot * $i + ($slot - $cw) / 2);
                $y    = (int) round($height * 0.74);
                imagettftext($im, $fontSize, $angle, $x, $y, $color, $font, $char);
            } else {
                // 字体缺失时退回内置字体（保证可用）
                $x = (int) round($slot * $i + ($slot - imagefontwidth(5)) / 2);
                $y = (int) round(($height - imagefontheight(5)) / 2);
                imagestring($im, 5, $x, $y, $char, $color);
            }
        }

        ob_start();
        imagepng($im);
        $content = ob_get_clean();
        imagedestroy($im);

        return response($content, 200, ['Content-Length' => (string) strlen($content)])
            ->contentType('image/png');
    }

    /**
     * 画一条贯穿画布的浅色正弦干扰线
     */
    private static function arc($im, int $w, int $h, int $color): void
    {
        $A = $h / mt_rand(4, 6);              // 振幅
        $T = mt_rand((int) ($w * 0.8), $w * 2); // 周期
        $wq = (2 * M_PI) / $T;
        $f  = mt_rand(0, 100) / 10;
        $b  = $h / 2;

        for ($x = 0; $x <= $w; $x++) {
            $y = (int) round($A * sin($wq * $x + $f) + $b);
            if ($y >= 0 && $y < $h) {
                imagesetpixel($im, $x, $y, $color);
            }
        }
    }
}
