<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * 前台主题
 */
class Theme
{
    protected static ?string $current = null;

    /**
     * 当前主题目录名
     */
    public static function current(): string
    {
        if (self::$current !== null) {
            return self::$current;
        }

        $theme = (string)Settings::get('theme', (string)config('tw.theme', 'default'));
        $theme = preg_replace('/[^a-zA-Z0-9_\-]/', '', $theme);

        if ($theme === '' || !is_dir(root_path() . 'template' . DIRECTORY_SEPARATOR . $theme)) {
            $theme = 'default';
        }

        self::$current = $theme;

        return $theme;
    }

    /**
     * 主题模板目录（绝对路径）
     */
    public static function path(): string
    {
        return root_path() . 'template' . DIRECTORY_SEPARATOR . self::current() . DIRECTORY_SEPARATOR;
    }

    /**
     * 可用主题列表
     */
    public static function available(): array
    {
        $dir  = root_path() . 'template';
        $list = [];
        if (!is_dir($dir)) {
            return $list;
        }

        foreach ((array)scandir($dir) as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path) && is_file($path . DIRECTORY_SEPARATOR . 'theme.json')) {
                $json = json_decode((string)file_get_contents($path . DIRECTORY_SEPARATOR . 'theme.json'), true);
                $list[$item] = [
                    'name'    => (string)($json['name'] ?? $item),
                    'version' => (string)($json['version'] ?? '1.0.0'),
                    'author'  => (string)($json['author'] ?? ''),
                    'thumb'   => (string)($json['thumb'] ?? ''),
                ];
            }
        }

        return $list;
    }

    /**
     * 重置（测试用）
     */
    public static function reset(): void
    {
        self::$current = null;
    }
}
