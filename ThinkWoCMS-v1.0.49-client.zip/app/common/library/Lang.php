<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Cache;
use think\facade\Db;

/**
 * 多语言上下文
 *
 * 约定：
 * - 默认语言不带 URL 前缀，例如 /products/
 * - 其他语言带前缀，例如 /en/products/
 */
class Lang
{
    /**
     * 启用的语言列表
     */
    protected static ?array $langs = null;

    /**
     * 当前语言
     */
    protected static ?array $current = null;

    /**
     * 界面文案字典
     */
    protected static array $dict = [];

    /**
     * 全部启用语言
     */
    public static function all(): array
    {
        if (self::$langs !== null) {
            return self::$langs;
        }

        $langs = [];
        try {
            $rows = Db::name('language')
                ->where('status', 1)
                ->order('sort asc, id asc')
                ->select()
                ->toArray();
            foreach ($rows as $row) {
                $langs[(string)$row['code']] = $row;
            }
        } catch (\Throwable $e) {
            $langs = [];
        }

        if (!$langs) {
            $langs = [
                'en' => [
                    'id' => 0, 'code' => 'en', 'name' => 'English', 'native_name' => 'English',
                    'region' => 'en-US', 'dir' => 'ltr', 'is_default' => 1, 'sort' => 0, 'status' => 1,
                ],
            ];
        }

        self::$langs = $langs;

        return $langs;
    }

    /**
     * 默认语言
     */
    public static function default(): array
    {
        foreach (self::all() as $lang) {
            if ((int)$lang['is_default'] === 1) {
                return $lang;
            }
        }

        return current(self::all()) ?: [
            'code' => 'en', 'name' => 'English', 'native_name' => 'English',
            'region' => 'en-US', 'dir' => 'ltr', 'is_default' => 1,
        ];
    }

    /**
     * 默认语言 code
     */
    public static function defaultCode(): string
    {
        return (string)self::default()['code'];
    }

    /**
     * 设置当前语言
     */
    public static function set(?string $code = null): void
    {
        $all = self::all();
        if ($code !== null && isset($all[$code])) {
            self::$current = $all[$code];
        } else {
            self::$current = self::default();
        }

        self::$dict = [];
    }

    /**
     * 当前语言
     */
    public static function current(): array
    {
        if (self::$current === null) {
            self::set();
        }

        return self::$current ?? self::default();
    }

    /**
     * 当前语言 code
     */
    public static function code(): string
    {
        return (string)self::current()['code'];
    }

    /**
     * 当前语言 hreflang 区域码
     */
    public static function region(): string
    {
        $region = (string)(self::current()['region'] ?? '');
        return $region !== '' ? $region : self::code();
    }

    /**
     * 指定语言的 URL 前缀（含结尾斜杠），默认语言返回空串
     */
    public static function prefix(?string $code = null): string
    {
        $code = $code ?? self::code();
        if ($code === self::defaultCode()) {
            return '';
        }

        return $code . '/';
    }

    /**
     * 是否从右到左书写
     */
    public static function isRtl(): bool
    {
        return strtolower((string)(self::current()['dir'] ?? 'ltr')) === 'rtl';
    }

    /**
     * 除当前语言外的其他语言
     */
    public static function others(): array
    {
        $code = self::code();
        $result = [];
        foreach (self::all() as $k => $lang) {
            if ($k !== $code) {
                $result[$k] = $lang;
            }
        }

        return $result;
    }

    /**
     * 站点文案按当前语言输出
     *
     * 后台「站点设置」里的文案是全局的；非默认语言访问时，这里把
     * SEO 标题 / 描述 / 关键词翻译一次并缓存 30 天。
     * 品牌名、公司名、地址等专有名词照原样输出（不翻译）。
     */
    public static function text(string $text): string
    {
        $text = (string)$text;
        $code = self::code();

        if (trim($text) === '' || $code === self::defaultCode() || !Translate::available()) {
            return $text;
        }

        $key = 'tw_text_' . $code . '_' . md5($text);

        try {
            $cached = Cache::get($key);
            if (is_string($cached) && $cached !== '') {
                return $cached;
            }
        } catch (\Throwable $e) {
            // 缓存不可用则继续
        }

        try {
            $out = (string)(Translate::strings([$text], self::defaultCode(), $code)[0] ?? $text);
        } catch (\Throwable $e) {
            return $text;
        }

        try {
            Cache::set($key, $out, 2592000);
        } catch (\Throwable $e) {
            // 忽略
        }

        return $out;
    }

    /**
     * 当前语言的全部界面文案（含主题词条）
     */
    public static function dictAll(): array
    {
        $code = self::code();
        if (!isset(self::$dict[$code])) {
            self::$dict[$code] = self::loadDict($code);
        }

        return self::$dict[$code];
    }

    /**
     * 界面文案翻译
     */
    public static function dict(string $key, ?string $default = null): string
    {
        $d = self::dictAll();

        return (string)($d[$key] ?? $default ?? $key);
    }

    /**
     * 载入语言文件（lang/{code}.php + lang/theme/{主题}.{code}.php 合并）
     *
     * 主题词条随主题包分发，键名带主题前缀（如 s001_）避免与基础词条冲突；
     * 当前语言的主题词条缺失时回退英文版。
     */
    public static function loadDict(string $code): array
    {
        $code = strtolower($code);
        $file = root_path() . 'lang' . DIRECTORY_SEPARATOR . $code . '.php';
        if (!is_file($file)) {
            $file = root_path() . 'lang' . DIRECTORY_SEPARATOR . 'en.php';
        }

        $data = [];
        if (is_file($file)) {
            $inc  = include $file;
            $data = is_array($inc) ? $inc : [];
        }

        $theme = Theme::current();
        if ($theme !== '') {
            $tdir  = root_path() . 'lang' . DIRECTORY_SEPARATOR . 'theme' . DIRECTORY_SEPARATOR;
            $tfile = $tdir . strtolower($theme) . '.' . $code . '.php';
            if (!is_file($tfile)) {
                $tfile = $tdir . strtolower($theme) . '.en.php';
            }
            if (is_file($tfile)) {
                $inc = include $tfile;
                if (is_array($inc)) {
                    $data += $inc;
                }
            }
        }

        return $data;
    }

    /**
     * 清理缓存（语言表变动后调用）
     */
    public static function flush(): void
    {
        self::$langs   = null;
        self::$current = null;
        self::$dict    = [];
    }
}
