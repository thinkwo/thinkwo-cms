<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Db;

/**
 * 后台鉴权（基于 Session）
 */
class Auth
{
    protected const SESSION_KEY = 'tw_admin_id';

    protected static ?array $user = null;

    protected static ?array $group = null;

    /**
     * 登录
     */
    public static function login(array $admin): void
    {
        session(self::SESSION_KEY, (int)$admin['id']);
        session('tw_admin_time', time());

        Db::name('admin')->where('id', $admin['id'])->update([
            'login_time' => time(),
            'login_ip'   => (string)request()->ip(),
            'login_fail' => 0,
            'lock_until' => 0,
        ]);

        self::$user  = null;
        self::$group = null;
    }

    /**
     * 退出
     */
    public static function logout(): void
    {
        session(self::SESSION_KEY, null);
        session('tw_admin_time', null);
        self::$user  = null;
        self::$group = null;
    }

    /**
     * 当前管理员ID
     */
    public static function id(): int
    {
        return (int)session(self::SESSION_KEY);
    }

    /**
     * 是否已登录
     */
    public static function check(): bool
    {
        $id = self::id();
        if ($id <= 0) {
            return false;
        }

        $ttl = (int)config('tw.admin.session_ttl', 7200);
        $at  = (int)session('tw_admin_time');
        if ($ttl > 0 && $at > 0 && (time() - $at) > $ttl) {
            self::logout();
            return false;
        }

        session('tw_admin_time', time());

        return self::user() !== null;
    }

    /**
     * 当前管理员信息
     */
    public static function user(): ?array
    {
        if (self::$user !== null) {
            return self::$user;
        }

        $id = self::id();
        if ($id <= 0) {
            return null;
        }

        $user = Db::name('admin')->where('id', $id)->where('status', 1)->find();
        self::$user = $user ?: null;

        return self::$user;
    }

    /**
     * 当前角色组
     */
    public static function group(): array
    {
        if (self::$group !== null) {
            return self::$group;
        }

        $user = self::user();
        if (!$user) {
            return [];
        }

        $group = Db::name('admin_group')->where('id', (int)$user['group_id'])->find();
        self::$group = $group ?: [];

        return self::$group;
    }

    /**
     * 是否超级管理员
     */
    public static function isSuper(): bool
    {
        $group = self::group();

        return ($group['rules'] ?? '') === '*';
    }

    /**
     * 权限判断
     *
     * @param string $name 权限标识，一般是 控制器/方法，例如 content/index
     */
    public static function can(string $name): bool
    {
        if (self::isSuper()) {
            return true;
        }

        $group = self::group();
        $rules = (string)($group['rules'] ?? '');
        if ($rules === '') {
            return false;
        }

        $ids = array_filter(array_map('intval', explode(',', $rules)));
        if (!$ids) {
            return false;
        }

        $rule = Db::name('admin_rule')->where('name', $name)->find();
        if (!$rule) {
            return false;
        }

        return in_array((int)$rule['id'], $ids, true);
    }

    /**
     * 校验密码
     */
    public static function verifyPassword(array $admin, string $password): bool
    {
        $hash = (string)($admin['password'] ?? '');
        if ($hash === '') {
            return false;
        }

        if (password_verify($password, $hash)) {
            return true;
        }

        // 兼容旧数据：md5(md5(pass) . salt)
        $legacy = md5(md5($password) . (string)($admin['salt'] ?? ''));
        if (hash_equals($hash, $legacy)) {
            return true;
        }

        return false;
    }

    /**
     * 生成密码哈希
     */
    public static function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_DEFAULT);
    }
}
