<?php

// [TW-CMS-ZW-2026-8F3A1C] ThinkWoCMS 原创代码 · 未经授权不得二次分发
// +----------------------------------------------------------------------
// | 品牌版权：链接地址统一出口 + 版权标识防篡改审计
// +----------------------------------------------------------------------

declare(strict_types=1);

namespace app\common\library;

use think\facade\Cache;

/**
 * 品牌版权
 *
 * 设计原则：
 *   1. 官网地址只在 config/tw.php 的 brand.url 里写一次，所有页面都从
 *      这里取，避免散落硬编码（改域名只改一处）。
 *   2. 版权标识属于授权条款的一部分，客户可以改样式、换位置，但不该删。
 *      删了后台会报警并上报授权站留痕，同时前台由中间件补一个右下角
 *      小徽标（不做任何破坏性处理，绝不影响站点正常经营）。
 */
class Brand
{
    /** 官网域名（判断页面是否带版权链接用，不带协议与 www） */
    public const HOST = 'thinkwocms.com';

    /** 审计结果的缓存键 */
    protected const CACHE_KEY = 'tw_brand_audit';

    public static function url(): string
    {
        return rtrim((string)config('tw.brand.url', 'https://' . self::HOST), '/');
    }

    public static function name(): string
    {
        return (string)config('tw.brand.name', 'ThinkWo CMS');
    }

    public static function owner(): string
    {
        return (string)config('tw.brand.owner', '');
    }

    /** 前台是否要补徽标（防篡改兜底，可在 config 里关） */
    public static function guardEnabled(): bool
    {
        // 主题页脚不要求带版权时，也就没有「缺版权」这回事，不必补徽标
        return (bool)config('tw.brand.guard', true) && self::themeCreditRequired();
    }

    /**
     * 前台主题页脚是否必须带品牌版权
     *
     * 程序内页面（后台框架页、登录页、安装向导）不受此项影响，始终必需。
     */
    public static function themeCreditRequired(): bool
    {
        return (bool)config('tw.brand.theme_credit', false);
    }

    /**
     * 一段 HTML / 模板里是否已经有版权标识
     *
     * 两种写法都算数：
     *   1. 渲染后的页面 —— 出现官网域名
     *   2. 模板源文件 —— 用 tw_brand_link() / tw_brand_url() 函数输出（域名在配置里）
     * 否则模板改用函数输出后，文件级审计会误报「被移除」。
     */
    public static function hasCredit(string $html): bool
    {
        if ($html === '') {
            return false;
        }
        return stripos($html, self::HOST) !== false
            || stripos($html, 'tw_brand_link') !== false
            || stripos($html, 'tw_brand_url') !== false;
    }

    /**
     * 版权标识落点审计
     *
     * 文件级检查，只看「该出现的地方在不在」，不修改任何文件。
     * 结果缓存 10 分钟，后台每次进首页不必反复扫盘。
     *
     * @return array{ok:bool,missing:array<int,string>,at:int}
     */
    public static function audit(bool $fresh = false): array
    {
        if (!$fresh) {
            try {
                $hit = Cache::get(self::CACHE_KEY);
                if (is_array($hit) && isset($hit['ok'])) {
                    return $hit;
                }
            } catch (\Throwable $e) {
                // 缓存不可用就直接算
            }
        }

        $root    = rtrim((string)app()->getRootPath(), '/\\') . DIRECTORY_SEPARATOR;
        $missing = [];

        // 程序内固定页面（改动这些等于改程序，属于明确违约）
        $fixed = [
            '后台框架页' => 'app/admin/view/index/index.html',
            '后台登录页' => 'app/admin/view/login/index.html',
            '安装向导'   => 'public/install.php',
        ];
        foreach ($fixed as $label => $rel) {
            $file = $root . str_replace('/', DIRECTORY_SEPARATOR, $rel);
            if (!is_file($file) || !self::hasCredit((string)@file_get_contents($file))) {
                $missing[] = $label;
            }
        }

        // 当前启用主题的页脚（视图目录优先，其次 public/template）
        // 仅在 brand.theme_credit = true 时检查；否则前台页脚带不带版权都不算缺失
        if (self::themeCreditRequired()) {
            $theme  = (string)Settings::get('theme', config('tw.theme', 'default'));
            $theme  = $theme !== '' ? $theme : 'default';
            $footer = '';
            foreach ([
                $root . 'template' . DIRECTORY_SEPARATOR . $theme . DIRECTORY_SEPARATOR . 'comm' . DIRECTORY_SEPARATOR . 'footer.html',
                $root . 'public' . DIRECTORY_SEPARATOR . 'template' . DIRECTORY_SEPARATOR . $theme . DIRECTORY_SEPARATOR . 'comm' . DIRECTORY_SEPARATOR . 'footer.html',
            ] as $f) {
                if (is_file($f)) {
                    $footer = $f;
                    break;
                }
            }
            if ($footer === '' || !self::hasCredit((string)@file_get_contents($footer))) {
                $missing[] = '前台主题页脚（' . $theme . '）';
            }
        }

        $res = ['ok' => $missing === [], 'missing' => $missing, 'at' => time()];

        try {
            Cache::set(self::CACHE_KEY, $res, 600);
        } catch (\Throwable $e) {
            // 忽略
        }

        return $res;
    }

    /**
     * 报给授权站的状态字：ok / missing
     */
    public static function status(): string
    {
        return self::audit()['ok'] ? 'ok' : 'missing';
    }

    /**
     * 版权被改动后清一下审计缓存（后台「清除缓存」时调用）
     */
    public static function forget(): void
    {
        try {
            Cache::delete(self::CACHE_KEY);
        } catch (\Throwable $e) {
            // 忽略
        }
    }
}
