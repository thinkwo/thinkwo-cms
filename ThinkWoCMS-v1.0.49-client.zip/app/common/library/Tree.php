<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * 无限级分类工具
 */
class Tree
{
    /**
     * 列表转树
     *
     * @param array  $items    二维数组
     * @param int    $pid      根节点父ID
     * @param string $idKey    主键字段
     * @param string $pidKey   父键字段
     * @param string $childKey 子节点字段名
     */
    public static function build(array $items, int $pid = 0, string $idKey = 'id', string $pidKey = 'pid', string $childKey = 'children'): array
    {
        $tree = [];
        foreach ($items as $item) {
            if ((int)$item[$pidKey] === $pid) {
                $children = self::build($items, (int)$item[$idKey], $idKey, $pidKey, $childKey);
                if ($children) {
                    $item[$childKey] = $children;
                }
                $tree[] = $item;
            }
        }

        return $tree;
    }

    /**
     * 树转扁平列表（带层级 depth 与缩进 name）
     */
    public static function flatten(array $tree, int $depth = 0, string $childKey = 'children'): array
    {
        $result = [];
        foreach ($tree as $node) {
            $children = $node[$childKey] ?? [];
            unset($node[$childKey]);
            $node['depth'] = $depth;
            $result[]      = $node;
            if ($children) {
                foreach (self::flatten($children, $depth + 1, $childKey) as $child) {
                    $result[] = $child;
                }
            }
        }

        return $result;
    }

    /**
     * 取某节点的全部子孙ID
     */
    public static function childrenIds(array $items, int $id, string $idKey = 'id', string $pidKey = 'pid'): array
    {
        $ids = [];
        foreach ($items as $item) {
            if ((int)$item[$pidKey] === $id) {
                $ids[] = (int)$item[$idKey];
                foreach (self::childrenIds($items, (int)$item[$idKey], $idKey, $pidKey) as $sub) {
                    $ids[] = $sub;
                }
            }
        }

        return $ids;
    }

    /**
     * 取从根到指定节点的路径（含自身）
     */
    public static function path(array $items, int $id, string $idKey = 'id', string $pidKey = 'pid'): array
    {
        $map  = [];
        foreach ($items as $item) {
            $map[(int)$item[$idKey]] = $item;
        }

        $path = [];
        $cur  = $map[$id] ?? null;
        $guard = 0;
        while ($cur && $guard++ < 20) {
            array_unshift($path, $cur);
            $cur = $map[(int)$cur[$pidKey]] ?? null;
        }

        return $path;
    }
}
