<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Db;

/**
 * 跨语言同步调度
 *
 * 一条内容（或一个栏目）在每种语言下都有一条独立记录，用 trans_key 配对；
 * 前台按语言读取，后台可按语言分别编辑。本类负责：
 *
 *  - content()  把内容同步到指定语言（新建 / 更新译文）
 *  - sort()     把栏目同步到指定语言（含父栏目递归补齐）
 *  - chunk()    分批同步（后台进度条用，避免一次请求跑太久）
 *  - progress() 统计某语言的同步进度
 *  - dict()     自动生成前台界面文案 lang/{code}.php
 *
 * 译文状态（trans_status）：
 *  - 0 原文（默认语言，或直接新建的某语言内容）
 *  - 1 机器翻译（自动同步产生，下次同步会更新）
 *  - 2 人工修改（后台手工编辑过，自动同步会跳过，除非强制覆盖）
 */
class TransSync
{
    public const ST_ORIGIN = 0;
    public const ST_AUTO   = 1;
    public const ST_MANUAL = 2;

    /**
     * 数据库是否已升级（有 trans_status 字段）
     */
    protected static ?bool $hasCol = null;

    public static function ready(): bool
    {
        if (self::$hasCol !== null) {
            return self::$hasCol;
        }

        try {
            $table = Db::name('content')->getTable();
            Db::query('SELECT trans_status FROM ' . $table . ' LIMIT 1');
            self::$hasCol = true;
        } catch (\Throwable $e) {
            self::$hasCol = false;
        }

        return self::$hasCol;
    }

    /**
     * 译文状态文案
     */
    public static function statusLabel(int $status): string
    {
        return match ($status) {
            self::ST_AUTO   => '机器翻译',
            self::ST_MANUAL => '人工修改',
            default         => '原文',
        };
    }

    // ------------------------------------------------------------------
    // 内容
    // ------------------------------------------------------------------

    /**
     * 把一条内容同步/翻译到其他语言
     *
     * @param  array    $langs    目标语言，空则全部启用语言
     * @param  bool     $force    强制覆盖人工修改过的译文
     * @param  float    $budget   本请求最多耗时（秒），超时剩余语言跳过
     * @param  bool     $withBody 是否翻译正文
     * @return array<string,string> 语言 => 结果说明
     */
    public static function content(int $id, array $langs = [], bool $force = false, float $budget = 90.0, bool $withBody = true): array
    {
        $row = Db::name('content')->where('id', $id)->find();
        if (!$row) {
            return ['_error' => '内容不存在'];
        }

        $all     = Lang::all();
        $targets = self::targets((string)$row['lang'], $langs, $all);
        if (!$targets) {
            return ['_error' => '没有可同步的目标语言，请先在「多语言」添加并启用语言'];
        }

        $transKey = self::ensureKey('content', $row, $id);
        $deadline = microtime(true) + max(5.0, $budget);
        $out      = [];

        foreach ($targets as $lang) {
            if (!isset($all[$lang])) {
                $out[$lang] = '语言未启用';
                continue;
            }
            if (microtime(true) >= $deadline) {
                $out[$lang] = '超时跳过（可在「多语言」页继续同步）';
                continue;
            }
            try {
                $out[$lang] = self::copyContent($row, $transKey, $lang, $force, $withBody);
            } catch (\Throwable $e) {
                $out[$lang] = '失败: ' . mb_substr($e->getMessage(), 0, 110);
            }
        }

        HtmlCache::clear();

        return $out;
    }

    /**
     * 生成某语言的译文记录
     */
    protected static function copyContent(array $row, string $transKey, string $lang, bool $force, bool $withBody): string
    {
        $from   = (string)$row['lang'];
        $exists = Db::name('content')->where('trans_key', $transKey)->where('lang', $lang)->find();

        if ($exists && !$force && (int)($exists['trans_status'] ?? 0) === self::ST_MANUAL) {
            return '已人工修改，已跳过';
        }

        // 短字段合并成一次请求（tags 也翻，否则英文页会露出中文标签）
        $fields = ['title', 'subtitle', 'summary', 'tags', 'seo_title', 'seo_keywords', 'seo_description'];
        $src    = [];
        $keys   = [];
        $list   = [];
        foreach ($fields as $f) {
            $v = (string)($row[$f] ?? '');
            $src[$f] = $v;
            if (trim($v) !== '') {
                $keys[] = $f;
                $list[] = $v;
            }
        }
        $translated = $list ? Translate::strings($list, $from, $lang) : [];
        $map        = [];
        foreach ($fields as $f) {
            $map[$f] = '';
        }
        $same = 0;
        foreach ($keys as $k => $f) {
            $map[$f] = (string)($translated[$k] ?? $src[$f]);
            // 源文有字母却原样返回 = 引擎没翻（限流/断网/离线复制）
            if ($map[$f] === $src[$f] && preg_match('/\p{L}/u', $src[$f])) {
                $same++;
            }
        }
        if ($keys && $same === count($keys)) {
            return '失败：翻译引擎未返回译文（' . (Translate::lastError() ?: '接口无响应') . '），请先在「站点设置 → 翻译设置」点测试连通';
        }
        // 引擎常把逗号翻成中文逗号，标签按半角逗号切分会整段变成一个标签
        if (isset($map['tags']) && $map['tags'] !== '') {
            $map['tags'] = str_replace(['，', '、', ' ,'], ',', $map['tags']);
            $map['tags'] = trim(preg_replace('/\s*,\s*/', ',', $map['tags']), ',');
        }

        // 正文
        $body = (string)($row['content'] ?? '');
        $bodyWarn = '';
        if ($withBody) {
            $bodyDst = $body !== '' ? Translate::html($body, $from, $lang) : '';
            if ($body !== '' && $bodyDst === $body && preg_match('/\p{L}/u', (string)strip_tags($body))) {
                $bodyWarn = '；正文未翻译（' . (Translate::lastError() ?: '引擎无返回') . '）';
            }
        } else {
            $bodyDst = (string)($exists['content'] ?? $body);
        }

        // 栏目映射
        $sortId = self::mapSort((int)$row['sort_id'], $lang);

        $now  = time();
        $data = [
            'sort_id'         => $sortId,
            'title'           => $map['title'],
            'subtitle'        => $map['subtitle'],
            'summary'         => $map['summary'],
            'tags'            => $map['tags'],
            'seo_title'       => $map['seo_title'],
            'seo_keywords'    => $map['seo_keywords'],
            'seo_description' => $map['seo_description'],
            'content'         => $bodyDst,
            'updatetime'      => $now,
        ];
        if (self::ready()) {
            $data['trans_status'] = self::ST_AUTO;
            $data['trans_at']     = $now;
        }

        if ($exists) {
            Db::name('content')->where('id', (int)$exists['id'])->update($data);

            return '已更新译文' . $bodyWarn;
        }

        // 新建译文：整行复制，保留图集/价格/型号/属性等
        $copy = $row;
        unset($copy['id']);
        $copy = array_merge($copy, $data);
        $copy['lang']       = $lang;
        $copy['slug']       = self::uniqueSlug('content', (string)$row['slug'], $lang);
        $copy['trans_key']  = $transKey;
        $copy['views']      = 0;
        $copy['createtime'] = $now;
        $copy['updatetime'] = $now;
        if (!self::ready()) {
            unset($copy['trans_status'], $copy['trans_at']);
        }

        Db::name('content')->insert($copy);

        return '已新建译文' . $bodyWarn;
    }

    // ------------------------------------------------------------------
    // 栏目
    // ------------------------------------------------------------------

    /**
     * 把一个栏目同步/翻译到其他语言
     *
     * @return array<string,string>
     */
    public static function sort(int $id, array $langs = [], bool $force = false, float $budget = 60.0): array
    {
        $row = Db::name('sort')->where('id', $id)->find();
        if (!$row) {
            return ['_error' => '栏目不存在'];
        }

        $all     = Lang::all();
        $targets = self::targets((string)$row['lang'], $langs, $all);
        if (!$targets) {
            return [];
        }

        $transKey = self::ensureKey('sort', $row, $id);
        $deadline = microtime(true) + max(5.0, $budget);
        $out      = [];

        foreach ($targets as $lang) {
            if (!isset($all[$lang])) {
                $out[$lang] = '语言未启用';
                continue;
            }
            if (microtime(true) >= $deadline) {
                $out[$lang] = '超时跳过';
                continue;
            }
            try {
                $out[$lang] = self::copySort($row, $transKey, $lang, $force);
            } catch (\Throwable $e) {
                $out[$lang] = '失败: ' . mb_substr($e->getMessage(), 0, 110);
            }
        }

        HtmlCache::clear();
        Lang::flush();

        return $out;
    }

    protected static function copySort(array $row, string $transKey, string $lang, bool $force): string
    {
        $from   = (string)$row['lang'];
        $exists = Db::name('sort')->where('trans_key', $transKey)->where('lang', $lang)->find();

        if ($exists && !$force && (int)($exists['trans_status'] ?? 0) === self::ST_MANUAL) {
            return '已人工修改，已跳过';
        }

        $fields = ['name', 'subname', 'description', 'seo_title', 'seo_keywords', 'seo_description'];
        $src    = [];
        $keys   = [];
        $list   = [];
        foreach ($fields as $f) {
            $v = (string)($row[$f] ?? '');
            $src[$f] = $v;
            if (trim($v) !== '') {
                $keys[] = $f;
                $list[] = $v;
            }
        }
        $translated = $list ? Translate::strings($list, $from, $lang) : [];
        $map        = [];
        foreach ($fields as $f) {
            $map[$f] = '';
        }
        $same = 0;
        foreach ($keys as $k => $f) {
            $map[$f] = (string)($translated[$k] ?? $src[$f]);
            if ($map[$f] === $src[$f] && preg_match('/\p{L}/u', $src[$f])) {
                $same++;
            }
        }
        if ($keys && $same === count($keys)) {
            return '失败：翻译引擎未返回译文（' . (Translate::lastError() ?: '接口无响应') . '），请先点「翻译设置 → 测试连通」';
        }

        $pid = self::mapSort((int)$row['pid'], $lang);
        $now = time();

        $data = [
            'pid'             => $pid,
            'name'            => $map['name'],
            'subname'         => $map['subname'],
            'description'     => $map['description'],
            'seo_title'       => $map['seo_title'],
            'seo_keywords'    => $map['seo_keywords'],
            'seo_description' => $map['seo_description'],
            'updatetime'      => $now,
        ];
        if (self::ready()) {
            $data['trans_status'] = self::ST_AUTO;
            $data['trans_at']     = $now;
        }

        if ($exists) {
            Db::name('sort')->where('id', (int)$exists['id'])->update($data);

            return '已更新译文';
        }

        $copy = $row;
        unset($copy['id']);
        $copy = array_merge($copy, $data);
        $copy['lang']       = $lang;
        $copy['slug']       = self::uniqueSlug('sort', (string)$row['slug'], $lang);
        $copy['trans_key']  = $transKey;
        $copy['createtime'] = $now;
        $copy['updatetime'] = $now;
        if (!self::ready()) {
            unset($copy['trans_status'], $copy['trans_at']);
        }

        Db::name('sort')->insert($copy);

        return '已新建译文';
    }

    /**
     * 栏目映射：源栏目 → 目标语言栏目 ID（缺失时递归补齐父栏目并翻译）
     */
    protected static function mapSort(int $sortId, string $lang, int $depth = 0): int
    {
        if ($sortId <= 0 || $depth > 6) {
            return 0;
        }

        $src = Db::name('sort')->where('id', $sortId)->find();
        if (!$src) {
            return 0;
        }
        if ((string)$src['lang'] === $lang) {
            return $sortId;
        }

        $key = trim((string)$src['trans_key']);
        if ($key === '') {
            $key = 's' . $sortId;
            Db::name('sort')->where('id', $sortId)->update(['trans_key' => $key]);
        }

        $hit = Db::name('sort')->where('trans_key', $key)->where('lang', $lang)->find();
        if ($hit) {
            return (int)$hit['id'];
        }

        // 目标语言还没有这个栏目 → 先翻译栏目本身（父栏目会被递归补齐）
        try {
            self::sort($sortId, [$lang], false, 30);
        } catch (\Throwable $e) {
            return 0;
        }

        $hit = Db::name('sort')->where('trans_key', $key)->where('lang', $lang)->find();

        return $hit ? (int)$hit['id'] : 0;
    }

    // ------------------------------------------------------------------
    // 分批同步 / 进度
    // ------------------------------------------------------------------

    /**
     * 分批把默认语言的数据同步到某语言
     *
     * @return array{total:int,offset:int,done:int,ok:int,skip:int,fail:int,errors:array,finished:bool}
     */
    public static function chunk(string $lang, string $type = 'content', int $offset = 0, int $limit = 10, bool $force = false): array
    {
        $table = $type === 'sort' ? 'sort' : 'content';
        $all   = Lang::all();

        if (!isset($all[$lang])) {
            return ['total' => 0, 'offset' => $offset, 'done' => 0, 'ok' => 0, 'skip' => 0, 'fail' => 1,
                    'errors' => ['语言未启用'], 'finished' => true];
        }

        $default = Lang::defaultCode();
        $limit   = max(1, min(30, $limit));
        $total   = (int)Db::name($table)->where('lang', $default)->count();
        $rows    = Db::name($table)->where('lang', $default)->order('id asc')->limit($offset, $limit)->select()->toArray();

        $ok = 0;
        $skip = 0;
        $fail = 0;
        $errors = [];

        foreach ($rows as $r) {
            $res = $type === 'sort'
                ? self::sort((int)$r['id'], [$lang], $force, 30)
                : self::content((int)$r['id'], [$lang], $force, 30);
            $msg = (string)($res[$lang] ?? '');

            if (str_starts_with($msg, '失败')) {
                $fail++;
                $errors[] = '#' . $r['id'] . ' ' . $msg;
            } elseif (str_contains($msg, '跳过') || $msg === '') {
                $skip++;
            } else {
                $ok++;
            }
        }

        $next = $offset + count($rows);

        return [
            'total'    => $total,
            'offset'   => $next,
            'done'     => count($rows),
            'ok'       => $ok,
            'skip'     => $skip,
            'fail'     => $fail,
            'errors'   => array_slice($errors, 0, 3),
            'finished' => $next >= $total,
        ];
    }

    /**
     * 同步进度（默认语言为源）
     */
    public static function progress(string $lang): array
    {
        $default = Lang::defaultCode();
        $out     = [];

        foreach (['sort' => '栏目', 'content' => '内容'] as $table => $label) {
            try {
                $total = (int)Db::name($table)->where('lang', $default)->count();
                $done  = (int)Db::name($table)->where('lang', $lang)->count();
                $manual = self::ready()
                    ? (int)Db::name($table)->where('lang', $lang)->where('trans_status', self::ST_MANUAL)->count()
                    : 0;
            } catch (\Throwable $e) {
                $total = $done = $manual = 0;
            }

            $out[$table] = [
                'label'  => $label,
                'total'  => $total,
                'done'   => min($done, $total),
                'actual' => $done,
                'manual' => $manual,
            ];
        }

        return $out;
    }

    // ------------------------------------------------------------------
    // 界面文案字典
    // ------------------------------------------------------------------

    /**
     * 生成前台界面文案 lang/{code}.php（一次跑完，供 CLI / 测试使用）
     *
     * @return array{ok:bool,msg:string}
     */
    public static function dict(string $code, bool $force = false): array
    {
        $file = root_path() . 'lang' . DIRECTORY_SEPARATOR . strtolower($code) . '.php';
        if (!$force && is_file($file)) {
            return ['ok' => true, 'msg' => 'lang/' . $code . '.php 已存在，跳过'];
        }

        $offset = 0;
        $last   = ['ok' => true, 'msg' => ''];
        for ($i = 0; $i < 200; $i++) {
            $last = self::dictChunk($code, $offset, 15, $force);
            if (($last['finished'] ?? false) || !($last['ok'] ?? false)) {
                break;
            }
            $offset = (int)$last['offset'];
        }

        return ['ok' => (bool)($last['ok'] ?? false), 'msg' => (string)($last['msg'] ?? '')];
    }

    /**
     * 分批生成界面文案（后台进度条用，避免接口慢时一次请求超时）
     *
     * @return array{ok:bool,msg:string,total:int,offset:int,finished:bool}
     */
    public static function dictChunk(string $code, int $offset = 0, int $limit = 12, bool $force = false): array
    {
        $code = strtolower($code);
        $file = root_path() . 'lang' . DIRECTORY_SEPARATOR . $code . '.php';

        // 主题词条：lang/theme/{主题}.en.php 为源，目标 lang/theme/{主题}.{code}.php
        $tdir     = root_path() . 'lang' . DIRECTORY_SEPARATOR . 'theme';
        $themeSrc = [];
        $themeKey = []; // 键 => 主题名
        foreach ((array)(is_dir($tdir) ? glob($tdir . DIRECTORY_SEPARATOR . '*.en.php') : []) as $tf) {
            $theme = substr(basename((string)$tf), 0, -7);
            $inc   = include $tf;
            if (is_array($inc) && $inc) {
                $themeSrc[$theme] = $inc;
                foreach ($inc as $k => $v) {
                    $themeKey[(string)$k] = $theme;
                }
            }
        }

        // 基础 + 全部主题目标文件都已存在 → 跳过
        $allDone = is_file($file);
        foreach (array_keys($themeSrc) as $theme) {
            if (!is_file($tdir . DIRECTORY_SEPARATOR . $theme . '.' . $code . '.php')) {
                $allDone = false;
                break;
            }
        }
        if (!$force && $allDone) {
            return ['ok' => true, 'msg' => 'lang/' . $code . '.php 已存在，跳过', 'total' => 0, 'offset' => 0, 'finished' => true];
        }
        if (!Translate::available()) {
            return ['ok' => false, 'msg' => '未配置翻译引擎，无法自动生成界面文案', 'total' => 0, 'offset' => 0, 'finished' => true];
        }

        // 基础词条源文件（直接读文件，不走 loadDict——那会混入主题词条）
        $sourceCode = Lang::defaultCode();
        $src        = self::readLangFile($sourceCode);
        if (!$src) {
            $sourceCode = 'en';
            $src        = self::readLangFile('en');
        }
        if (!$src && !$themeSrc) {
            return ['ok' => false, 'msg' => '缺少源语言文案文件 lang/' . $sourceCode . '.php', 'total' => 0, 'offset' => 0, 'finished' => true];
        }

        // 基础文件已存在时只补主题词条，避免重翻已有文案
        $baseKeys = [];
        if (!is_file($file) || $force) {
            $baseKeys = array_keys($src);
        } else {
            $src = [];
        }
        foreach ($themeSrc as $theme => $dict) {
            if (is_file($tdir . DIRECTORY_SEPARATOR . $theme . '.' . $code . '.php') && !$force) {
                continue; // 该主题词条文件已生成，跳过
            }
            $src += $dict;
        }
        if (!$src) {
            return ['ok' => true, 'msg' => '界面文案已全部存在，跳过', 'total' => 0, 'offset' => 0, 'finished' => true];
        }

        $keys  = array_keys($src);
        $vals  = array_values($src);
        $total = count($keys);

        // 断点续传：已翻译的键值存在临时文件
        $tmpFile = root_path() . 'lang' . DIRECTORY_SEPARATOR . '.' . $code . '.dict.json';
        $done    = [];
        if (!$force && is_file($tmpFile)) {
            $done = (array)json_decode((string)file_get_contents($tmpFile), true);
        }

        $sliceKeys = array_slice($keys, $offset, max(1, $limit));
        $sliceVals = array_slice($vals, $offset, max(1, $limit));

        if ($sliceVals) {
            try {
                // 基础词条以站点默认语言为源；主题词条固定以英文为源（其源文件就是英文）
                $bVals = [];
                $bPos  = [];
                $tVals = [];
                $tPos  = [];
                foreach ($sliceKeys as $i => $k) {
                    if (isset($themeKey[$k])) {
                        $tVals[] = $sliceVals[$i];
                        $tPos[]  = $i;
                    } else {
                        $bVals[] = $sliceVals[$i];
                        $bPos[]  = $i;
                    }
                }
                $map = [];
                if ($bVals) {
                    foreach (Translate::strings($bVals, $sourceCode, $code) as $i => $v) {
                        $map[$bPos[$i]] = $v;
                    }
                }
                if ($tVals && $code !== 'en') {
                    foreach (Translate::strings($tVals, 'en', $code) as $i => $v) {
                        $map[$tPos[$i]] = $v;
                    }
                }
                foreach ($sliceKeys as $i => $k) {
                    $done[$k] = (string)($map[$i] ?? $sliceVals[$i]);
                }
            } catch (\Throwable $e) {
                return [
                    'ok' => false,
                    'msg' => '翻译失败：' . mb_substr($e->getMessage(), 0, 100),
                    'total' => $total,
                    'offset' => $offset,
                    'finished' => true,
                ];
            }
            @file_put_contents($tmpFile, json_encode($done, JSON_UNESCAPED_UNICODE));
        }

        $next = $offset + count($sliceKeys);
        if ($next < $total) {
            return [
                'ok'       => true,
                'msg'      => '界面文案 ' . $next . ' / ' . $total,
                'total'    => $total,
                'offset'   => $next,
                'finished' => false,
            ];
        }

        // 全部完成 → 写正式文件（基础 + 各主题）
        $write = function (string $path, array $list) use ($done, $src): bool {
            $php = "<?php\n\n// 前台界面文案\n// 由「多语言 → 同步」自动生成于 " . date('Y-m-d H:i') . "，可手工调整\n\nreturn [\n";
            foreach ($list as $k) {
                $v = (string)($done[$k] ?? $src[$k]);
                $v = str_replace(['\\', "'"], ['\\\\', "\\'"], $v);
                $php .= "    '" . $k . "' => '" . $v . "',\n";
            }
            $php .= "];\n";

            return @file_put_contents($path, $php) !== false;
        };

        $written = [];
        if ($baseKeys) {
            if (!$write($file, $baseKeys)) {
                return ['ok' => false, 'msg' => '写入 lang/' . $code . '.php 失败，请检查目录权限', 'total' => $total, 'offset' => $next, 'finished' => true];
            }
            $written[] = 'lang/' . $code . '.php（' . count($baseKeys) . ' 条）';
        }
        foreach ($themeSrc as $theme => $dict) {
            $tfile = $tdir . DIRECTORY_SEPARATOR . $theme . '.' . $code . '.php';
            $list  = array_keys(array_filter($themeKey, fn ($t) => $t === $theme));
            if (!$write($tfile, $list)) {
                return ['ok' => false, 'msg' => '写入 lang/theme/' . $theme . '.' . $code . '.php 失败，请检查目录权限', 'total' => $total, 'offset' => $next, 'finished' => true];
            }
            $written[] = 'lang/theme/' . $theme . '.' . $code . '.php（' . count($list) . ' 条）';
        }
        @unlink($tmpFile);

        return [
            'ok'       => true,
            'msg'      => '已生成 ' . implode('、', $written),
            'total'    => $total,
            'offset'   => $next,
            'finished' => true,
        ];
    }

    /**
     * 直接读取某个语言文件（不含主题词条）
     */
    protected static function readLangFile(string $code): array
    {
        $file = root_path() . 'lang' . DIRECTORY_SEPARATOR . strtolower($code) . '.php';
        if (!is_file($file)) {
            return [];
        }
        $inc = include $file;

        return is_array($inc) ? $inc : [];
    }

    // ------------------------------------------------------------------
    // 工具
    // ------------------------------------------------------------------

    /**
     * 标记为人工修改（自动同步会跳过）
     */
    public static function markManual(string $table, int $id): void
    {
        if ($id <= 0 || !self::ready()) {
            return;
        }
        try {
            Db::name($table)->where('id', $id)->update([
                'trans_status' => self::ST_MANUAL,
                'trans_at'     => time(),
            ]);
        } catch (\Throwable $e) {
            // 忽略
        }
    }

    /**
     * 目标语言列表
     */
    protected static function targets(string $sourceLang, array $langs, array $all): array
    {
        $targets = $langs ?: array_keys($all);
        $targets = array_map('strval', $targets);

        return array_values(array_unique(array_diff($targets, [$sourceLang])));
    }

    /**
     * 确保配对键存在
     */
    protected static function ensureKey(string $table, array &$row, int $id): string
    {
        $key = trim((string)($row['trans_key'] ?? ''));
        if ($key !== '') {
            return $key;
        }

        $key = ($table === 'sort' ? 's' : 'c') . $id;
        Db::name($table)->where('id', $id)->update(['trans_key' => $key]);
        $row['trans_key'] = $key;

        return $key;
    }

    /**
     * 同语言内 slug 唯一
     */
    protected static function uniqueSlug(string $table, string $slug, string $lang, int $excludeId = 0): string
    {
        $base = $slug !== '' ? $slug : 'item';
        $try  = $base;
        $i    = 2;

        while ($i < 200) {
            $q = Db::name($table)->where('lang', $lang)->where('slug', $try);
            if ($excludeId > 0) {
                $q->where('id', '<>', $excludeId);
            }
            if (!$q->find()) {
                return $try;
            }
            $try = $base . '-' . $i;
            $i++;
        }

        return $base . '-' . substr((string)mt_rand(100000, 999999), 0, 6);
    }
}
