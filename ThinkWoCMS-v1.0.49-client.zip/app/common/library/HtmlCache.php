<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * 伪静态 HTML 缓存（三期性能优化）
 *
 * 命中时直接输出静态 HTML，连框架模板渲染都省掉，
 * 首字节时间可压到 5~20ms。
 */
class HtmlCache
{
    /**
     * 缓存目录
     */
    protected static function dir(): string
    {
        return runtime_path() . 'html' . DIRECTORY_SEPARATOR;
    }

    /**
     * 是否启用
     */
    public static function enabled(): bool
    {
        $cfg = (array)config('tw.html_cache', []);
        if (empty($cfg['enable'])) {
            return false;
        }
        if (Settings::get('html_cache', '1') === '0') {
            return false;
        }

        return true;
    }

    /**
     * 当前请求是否可缓存
     */
    public static function cacheable(string $path): bool
    {
        if (!self::enabled()) {
            return false;
        }
        if (!request()->isGet()) {
            return false;
        }
        if (session('admin_id')) {
            return false;
        }

        $cfg = (array)config('tw.html_cache', []);
        if (empty($cfg['query']) && !empty(request()->get())) {
            return false;
        }

        foreach ((array)($cfg['exclude'] ?? []) as $prefix) {
            if ($prefix !== '' && str_starts_with($path, (string)$prefix)) {
                return false;
            }
        }

        return true;
    }

    /**
     * 缓存文件路径
     */
    protected static function file(string $path, ?string $lang = null): string
    {
        $lang = $lang ?? Lang::code();
        $dir  = self::dir() . preg_replace('/[^a-z0-9\-]/i', '', $lang) . DIRECTORY_SEPARATOR;
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        return $dir . md5($path) . '.html';
    }

    /**
     * 读取缓存
     */
    public static function get(string $path): ?string
    {
        $file = self::file($path);
        if (!is_file($file)) {
            return null;
        }

        $ttl = (int)(config('tw.html_cache.ttl') ?? 3600);
        if ($ttl > 0 && (time() - (int)filemtime($file)) > $ttl) {
            @unlink($file);
            return null;
        }

        $html = @file_get_contents($file);

        return ($html === false || $html === '') ? null : $html;
    }

    /**
     * 写入缓存
     */
    public static function put(string $path, string $html): void
    {
        if (!self::cacheable($path) || $html === '' || str_contains($html, '<!--nocache-->')) {
            return;
        }

        @file_put_contents(self::file($path), $html, LOCK_EX);
    }

    /**
     * 清空全部缓存
     */
    public static function clear(): int
    {
        return self::removeDir(self::dir());
    }

    /**
     * 清空指定语言缓存
     */
    public static function clearLang(string $lang): int
    {
        return self::removeDir(self::dir() . preg_replace('/[^a-z0-9\-]/i', '', $lang) . DIRECTORY_SEPARATOR);
    }

    /**
     * 统计
     */
    public static function stats(): array
    {
        $files = 0;
        $size  = 0;
        $dir   = self::dir();
        if (is_dir($dir)) {
            $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
            foreach ($it as $f) {
                if ($f->isFile() && $f->getExtension() === 'html') {
                    $files++;
                    $size += $f->getSize();
                }
            }
        }

        return ['files' => $files, 'size' => $size, 'enable' => self::enabled()];
    }

    /**
     * 递归删除
     */
    protected static function removeDir(string $dir): int
    {
        if (!is_dir($dir)) {
            return 0;
        }

        $count = 0;
        foreach ((array)scandir($dir) as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir . $item;
            if (is_dir($path)) {
                $count += self::removeDir($path . DIRECTORY_SEPARATOR);
            } elseif (@unlink($path)) {
                $count++;
            }
        }
        @rmdir($dir);

        return $count;
    }
}
