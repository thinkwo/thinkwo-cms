<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Log;

/**
 * 在线更新
 *
 * 完整链路：清单验签 → 下载 → SHA256 → 备份 → 冲突检测 → 覆盖 → 更新清单 → 清理
 *
 * 两条安全底线：
 * 1. 升级清单必须带授权站私钥签名，验不过一律不装（防伪造更新源投毒）
 * 2. 客户改过的文件不覆盖，只记录到冲突列表（防一键升级把定制改没了）
 */
class Updater
{
    /** 出包清单，记录发布时每个文件的 SHA256 */
    public const MANIFEST = 'config/manifest.sha256';

    /**
     * 请求更新清单
     *
     * @return array{code:int,msg:string,data?:array}
     */
    public static function check(): array
    {
        $st = License::state(true);

        if (!$st['licensed']) {
            return ['code' => 0, 'msg' => $st['reason']];
        }
        if (!$st['can_update']) {
            return ['code' => 0, 'msg' => '升级服务已到期，请联系服务商续期'];
        }

        $api = License::api();
        if ($api === '') {
            return ['code' => 0, 'msg' => '未配置授权站地址'];
        }

        $res = self::post($api . '/api/update/check', [
            'license' => (string)($st['data']['license_id'] ?? ''),
            'version' => (string)config('tw.version', ''),
            'edition' => $st['edition'],
            'domain'  => self::host(),
            'php'     => PHP_VERSION,
        ]);

        if ($res === null) {
            return ['code' => 0, 'msg' => '无法连接授权服务器，请稍后重试'];
        }
        if (($res['code'] ?? 0) !== 1) {
            return ['code' => 0, 'msg' => (string)($res['msg'] ?? '获取更新失败')];
        }

        $payload = (string)($res['payload'] ?? '');
        $sig     = (string)($res['sig'] ?? '');
        if ($payload === '' || $sig === '') {
            return ['code' => 0, 'msg' => '更新清单不完整'];
        }

        $data = License::verify($payload, $sig);
        if ($data === null) {
            return ['code' => 0, 'msg' => '更新清单签名校验失败，已阻止本次更新'];
        }

        $current = (string)config('tw.version', '');
        $latest  = (string)($data['latest'] ?? $current);

        return [
            'code' => 1,
            'msg'  => 'ok',
            'data' => [
                'current'  => $current,
                'latest'   => $latest,
                'has_new'  => version_compare($latest, $current, '>'),
                'packages' => array_values((array)($data['packages'] ?? [])),
                'notice'   => (string)($data['notice'] ?? ''),
            ],
        ];
    }

    /**
     * 执行更新
     *
     * @return array{code:int,msg:string,detail?:array}
     */
    public static function install(string $version): array
    {
        $version = trim($version);
        if (!preg_match('/^\d+\.\d+\.\d+$/', $version)) {
            return ['code' => 0, 'msg' => '版本号不合法'];
        }

        // 重新拉一次清单：包信息只信授权站签名过的，不信前端传参
        $chk = self::check();
        if (($chk['code'] ?? 0) !== 1) {
            return $chk;
        }

        $pkg = null;
        foreach ($chk['data']['packages'] as $p) {
            if ((string)($p['version'] ?? '') === $version) {
                $pkg = $p;
                break;
            }
        }
        if ($pkg === null) {
            return ['code' => 0, 'msg' => '授权站没有该版本的升级包'];
        }

        $url    = (string)($pkg['url'] ?? '');
        $sha    = strtolower((string)($pkg['sha256'] ?? ''));
        $size   = (int)($pkg['size'] ?? 0);
        $maxMb  = max(1, (int)config('license.max_package_mb', 200));

        if ($url === '' || $sha === '') {
            return ['code' => 0, 'msg' => '升级包信息不完整'];
        }
        if ($size > 0 && $size > $maxMb * 1048576) {
            return ['code' => 0, 'msg' => '升级包超过允许大小（' . $maxMb . 'MB）'];
        }
        $format = strtolower((string)($pkg['format'] ?? 'tar.gz'));
        if ($format === 'zip' && !class_exists('ZipArchive')) {
            return ['code' => 0, 'msg' => '该升级包为 zip 格式，服务器未安装 zip 扩展'];
        }
        if ($format !== 'zip' && !class_exists('PharData')) {
            return ['code' => 0, 'msg' => '服务器缺少 Phar 扩展，无法解压升级包'];
        }

        $work = self::workDir();
        self::rrmdir($work . 'extract');
        self::mkdir($work);

        $zip = $work . 'update-' . $version . ($format === 'zip' ? '.zip' : '.tar.gz');

        // 1. 下载
        if (!self::download($url, $zip, $maxMb * 1048576)) {
            $why = self::$lastDlError !== '' ? '（' . self::$lastDlError . '）' : '';
            return ['code' => 0, 'msg' => '下载升级包失败，请检查服务器是否能访问授权站' . $why];
        }

        // 2. 校验哈希
        $real = hash_file('sha256', $zip);
        if (!is_string($real) || strtolower($real) !== $sha) {
            @unlink($zip);
            return ['code' => 0, 'msg' => '升级包校验失败（哈希不符），已丢弃'];
        }

        // 3. 解压到临时目录
        $extract = $work . 'extract';
        self::mkdir($extract);
        $unzip = self::unzip($zip, $extract);
        if (($unzip['code'] ?? 0) !== 1) {
            self::rrmdir($extract);
            @unlink($zip);
            return $unzip;
        }

        // 4. 覆盖
        //    升级包是差异包：只含变更文件，站点上没有变更的文件一律不动。
        //    写入遇到归 root 所有的文件时，逐文件自愈（删了重建）或目录级自愈
        //    （把目录改名重建、内容原样挪回），不需要整目录重铺，也不碰模板。
        $res = self::apply($extract);

        self::rrmdir($extract);
        @unlink($zip);

        if (($res['code'] ?? 0) !== 1) {
            return $res;
        }

        // 5. 版本号可能与 config/tw.php 冲突被跳过，这里强制同步，避免反复提示有更新
        self::syncVersion($version);

        // 6. 记一笔，清缓存
        try {
            Settings::set('last_update_at', (string)time(), 'system');
            Settings::set('last_update_ver', $version, 'system');
            Settings::flush();
        } catch (\Throwable $e) {
            Log::error('更新后写设置失败：' . $e->getMessage());
        }

        self::clearCache();

        $rep  = $res['detail'] ?? [];
        $heal = (int)($rep['healed'] ?? 0);
        $tail = $heal > 0 ? '（已自动修复 ' . $heal . ' 个目录的写入权限，以后升级不再受限制）' : '';

        return [
            'code'   => 1,
            'msg'    => '已更新到 v' . $version . $tail,
            'detail' => $rep,
        ];
    }

    /**
     * 预检：返回「连自愈也救不了」的目标文件列表（零副作用，不写任何东西）
     *
     * 能救的都不算 blocked：
     *   目标文件本身可写                        → 直接覆盖
     *   目标所在目录可写                        → 删了重建（新文件属主=运行用户）
     *   目录不可写，但上级目录可写              → 目录级自愈后即可写
     * 救不了才会 blocked：站点根目录本身不可写，整条路径上找不到任何可写层。
     *
     * @return string[]
     */
    protected static function precheck(string $extract, string $root): array
    {
        $blocked = [];
        $it0 = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($extract, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($it0 as $item) {
            if (!$item->isFile()) {
                continue;
            }
            $rel = str_replace('\\', '/', substr($item->getPathname(), strlen($extract) + 1));
            if ($rel === self::MANIFEST) {
                continue;
            }
            $target = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
            if (self::canWrite($target, $root)) {
                continue;
            }
            $blocked[] = $rel;
        }
        return $blocked;
    }

    /**
     * 这个路径是否属于「程序文件」（升级可以覆盖）
     *
     * 模板、上传、运行时、配置文件属于客户数据/站点专属，升级永远不覆盖，
     * 基线也永远不重写（保住客户定制）。
     */
    protected static function isProgramPath(string $rel): bool
    {
        $rel = ltrim(str_replace('\\', '/', $rel), '/');
        foreach (['template/', 'public/template/', 'public/uploads/', 'runtime/', 'config/'] as $p) {
            if (str_starts_with($rel, $p)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 这个路径允不允许被升级流程删除
     *
     * 只允许删程序目录里的文件。配置文件、客户数据（上传/模板/扩展）、
     * 运行目录一律不碰 —— 哪怕删除清单里写了也不执行。
     */
    protected static function isRemovable(string $rel): bool
    {
        $rel = ltrim(str_replace('\\', '/', $rel), '/');
        if ($rel === '' || $rel === '.env' || $rel === '.htaccess' || str_starts_with($rel, 'config/')) {
            return false;
        }
        foreach (['public/uploads/', 'public/template/', 'template/', 'runtime/', 'extend/'] as $p) {
            if (str_starts_with($rel, $p)) {
                return false;
            }
        }
        foreach (['app/', 'public/', 'vendor/', 'lang/', 'plugins/'] as $p) {
            if (str_starts_with($rel, $p)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 这个目标能不能写成（含自愈）
     */
    protected static function canWrite(string $target, string $root): bool
    {
        if (is_file($target)) {
            if (is_writable($target)) {
                return true;
            }
            return self::canHealDir(dirname($target), $root);
        }
        // 目标不存在：最近的已存在祖先目录可写（或可自愈）即可
        $d = dirname($target);
        while (!is_dir($d) && $d !== dirname($d)) {
            $d = dirname($d);
        }
        return self::canHealDir($d, $root);
    }

    /**
     * 目录能否通过「改名 → 重建 → 内容原样挪回」变得可写
     *
     * 只改目录本身，不动里面任何一个文件的 inode 与内容，因此对模板、图片、
     * 客户定制文件完全无副作用。自愈范围严格限制在站点根目录之内。
     */
    protected static function canHealDir(string $dir, string $root): bool
    {
        $root = rtrim($root, '/\\');
        $dir  = rtrim($dir, '/\\');

        if (is_dir($dir) && is_writable($dir)) {
            return true;
        }
        // 站点根自身不可写 → 不允许动它（动它等于整个站点消失），视为不可修
        if ($dir === $root) {
            return false;
        }
        $parent = dirname($dir);
        if ($parent === $dir || !str_starts_with(str_replace('\\', '/', $parent), str_replace('\\', '/', $root))) {
            return false;
        }
        if (is_writable($parent)) {
            return true;
        }
        return self::canHealDir($parent, $root);
    }

    /**
     * 覆盖文件（核心：冲突检测）
     *
     * @return array{code:int,msg:string,detail?:array}
     */
    protected static function apply(string $extract, ?array $blocked = null): array
    {
        $root = rtrim(app()->getRootPath(), '/\\');

        $old = self::readManifest($root . DIRECTORY_SEPARATOR . self::MANIFEST);

        // ---- 预检：只拦「连自愈都救不了」的情况（站点根不可写），避免写一半回滚 ----
        $blocked = $blocked ?? self::precheck($extract, $root);
        if ($blocked) {
            $show = implode('、', array_slice($blocked, 0, 4))
                . (count($blocked) > 4 ? ' 等 ' . count($blocked) . ' 个' : '');
            return ['code' => 0,
                'msg' => '升级被拦住：站点根目录对程序运行用户（' . self::runUser() . '）不可写，'
                    . '无法自动修复（' . $show . '）。'
                    . '这属于服务器层面的目录归属异常，请在宝塔 → 网站 → 设置 → 网站目录 点一次保存，'
                    . '或让运维确认站点根目录属主为 ' . self::runUser() . ' 后重试。',
                'detail' => ['blocked' => $blocked, 'offline' => true, 'root' => $root]];
        }

        $newMan   = $root . DIRECTORY_SEPARATOR . self::MANIFEST;
        $backup   = self::workDir() . 'backup-' . date('YmdHis');
        self::mkdir($backup);

        $files    = [];
        $conflict = [];
        $added    = [];
        $healed   = 0;

        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($extract, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($it as $item) {
            if ($item->isDir()) {
                continue;
            }
            $abs = $item->getPathname();
            $rel = str_replace('\\', '/', substr($abs, strlen($extract) + 1));

            // 清单文件最后单独写，不当普通文件覆盖
            if ($rel === self::MANIFEST) {
                continue;
            }
            // 删除清单是指令，不是文件：执行完即丢弃，不落到站点上
            if ($rel === 'config/update-remove.txt') {
                continue;
            }
            // 更新日志是随包说明文件（授权站自动提取展示用），不落到站点上
            if ($rel === 'changelog.txt') {
                continue;
            }

            $target = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
            $oldHash = $old[$rel] ?? null;
            $curHash = is_file($target) ? hash_file('sha256', $target) : null;

            // 客户改过这个文件 → 跳过，保留客户版本
            //
            // 只对「客户数据」生效（模板、配置）。程序文件（app/、public/、vendor/…）
            // 一律以官方版本覆盖 —— 否则历史上任何一次「文件写了、清单没写成」
            // 都会让它被永久误判成客户改过，站点从此再也升不动（实踩事故：
            // demo 站卡在 1.0.31，每次升级全部文件被跳过）。
            // 被覆盖的旧文件已备份在 runtime/update/backup-*/，需要可随时找回。
            if (!self::isProgramPath($rel)
                && $oldHash !== null && $curHash !== null && $curHash !== $oldHash) {
                $conflict[] = $rel;
                continue;
            }

            // 备份将被覆盖的原文件
            if (is_file($target)) {
                $bak = $backup . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
                self::mkdir(dirname($bak));
                @copy($target, $bak);
            } else {
                $added[] = $rel;
            }

            self::mkdir(dirname($target));
            $dir = dirname($target);

            // 目录不可写（宝塔解压装机遗留：目录+文件都归 root）→ 目录级自愈。
            // 只把「目录本身」改名重建、再把原有子项原样 rename 回来，
            // 里面每个文件的 inode、属主、内容全都不变；因此模板、图片、
            // 客户定制文件零影响。仅目录属主变为运行用户，从此可写。
            if (!self::ensureWritableDir($dir, $root, $healed)) {
                self::restore($backup, $root);
                return ['code' => 0,
                    'msg' => '无法写入 ' . $rel . '：目录 ' . $dir . ' 及其上级均不可写，已回滚。'
                        . '请在宝塔 → 网站 → 设置 → 网站目录 点一次保存后重试。',
                    'detail' => ['file' => $rel]];
            }

            // 目标已存在但不可写（属主不是运行用户 / 只读）→
            // 先试 chmod；不行就删掉旧文件重建（Linux 删文件只看目录写权限，
            // 目录可写时即使旧文件属主 root 也能删，新文件即归运行用户所有）
            if (is_file($target) && !is_writable($target)) {
                @chmod($target, 0644);
                if (!is_writable($target)) {
                    @unlink($target);
                }
            }
            $err = '';
            $data = file_get_contents($abs);
            $ok = $data !== false && @file_put_contents($target, $data) !== false;
            if (!$ok && !is_file($target)) {
                $ok = @copy($abs, $target);   // file_put_contents 失败时兜底
            }
            if (!$ok) {
                $le = error_get_last();
                $err = isset($le['message']) ? preg_replace('/^(copy|file_put_contents)\(\)?[:\s]*/i', '', $le['message']) : '';
                self::restore($backup, $root);
                return ['code' => 0,
                    'msg' => '写入失败：' . $rel . '，已回滚' . ($err !== '' ? '（' . $err . '）' : '')
                        . '。可磁盘已满或文件被安全软件锁定，请检查后重试。',
                    'detail' => ['file' => $rel]];
            }
            $files[] = $rel;
        }

        // 删除清单：包内 config/update-remove.txt 列出「官方已废弃 / 必须清除」的文件
        // （如历史上误发的 public/deploy.php）。差异包不含被删文件，不显式通知
        // 就会永远留在站点上。删除范围严格限制在程序目录，配置文件与用户数据不碰。
        $removedFiles = [];
        $rmList = $extract . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'update-remove.txt';
        if (is_file($rmList)) {
            foreach (file($rmList, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
                $rel = trim(str_replace('\\', '/', $line));
                if ($rel === '' || str_contains($rel, '..') || str_starts_with($rel, '/')) {
                    continue;
                }
                if (!self::isRemovable($rel)) {
                    continue;
                }
                $abs = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
                if (!is_file($abs)) {
                    continue;
                }
                @chmod($abs, 0644);
                if (@unlink($abs)) {
                    $removedFiles[] = $rel;
                }
            }
        }

        // 写入新清单：本次升级包没带上的文件，保留旧清单里的记录，
        // 这样它们的"原始哈希"不丢，以后客户改没改依然判得准
        if (is_file($extract . DIRECTORY_SEPARATOR . self::MANIFEST)) {
            $newMap = self::readManifest($extract . DIRECTORY_SEPARATOR . self::MANIFEST);
            foreach ($old as $rel => $h) {
                if (isset($newMap[$rel])) {
                    continue;
                }
                // 站点现状与清单记录不一致 → 说明历史上某次升级「文件写了、清单没写成」
                // （清单写入失败的旧 bug）。这种文件会被永久误判成「客户改过」，
                // 从此再也升不动，形成死循环。程序文件一律以站点现状重新对齐基线，
                // 把死循环解开；模板/配置等客户数据仍保留原基线，客户定制照旧受保护。
                if (self::isProgramPath($rel)) {
                    $abs = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
                    $cur = is_file($abs) ? hash_file('sha256', $abs) : null;
                    if (is_string($cur) && $cur !== '') {
                        $newMap[$rel] = $cur;
                        continue;
                    }
                }
                $newMap[$rel] = $h;
            }
            $lines = [];
            foreach ($newMap as $rel => $h) {
                $lines[] = $h . '  ' . $rel;
            }
            sort($lines);
            // 清单文件可能随安装包解压时归 root 所有（宝塔 root 身份解压装机），
            // 与普通文件同样走 chmod/unlink 自愈，否则文件全部更新成功
            // 却在最后一步报 Permission denied，版本号已变、升级被误判失败
            if (!self::writeFileHealed($newMan, implode("\n", $lines) . "\n")) {
                $le = error_get_last();
                $err = isset($le['message']) ? preg_replace('/^file_put_contents\(\)?[:\s]*/i', '', $le['message']) : '';
                Log::error('更新清单写入失败：' . self::MANIFEST . ($err !== '' ? '（' . $err . '）' : ''));
            }
        }

        self::pruneBackup();

        return [
            'code' => 1,
            'msg'  => 'ok',
            'detail' => [
                'updated'  => count($files),
                'added'    => count($added),
                'conflict' => $conflict,
                'backup'   => basename($backup),
                'healed'   => $healed,
                'removed'  => $removedFiles,
            ],
        ];
    }

    /**
     * 保证某个目录可写（写文件前的最后一道保险）
     *
     * 处理顺序：
     *   1. 目录已可写        → 直接通过（绝大多数情况，零操作）
     *   2. 目录不存在        → 递归建它
     *   3. 目录存在但不可写  → 先让上级可写，再对本级做 healDir()
     *
     * healDir() 只重建「目录」本身，原有子项用 rename 原样搬回，
     * 文件 inode / 属主 / 内容全都不变 —— 因此对模板、图片、定制文件零影响。
     *
     * @param int $healed 统计实际做过自愈的目录数（用于提示文案）
     */
    protected static function ensureWritableDir(string $dir, string $root, int &$healed = 0): bool
    {
        $dir  = rtrim($dir, '/\\');
        $root = rtrim($root, '/\\');

        if (is_dir($dir) && is_writable($dir)) {
            return true;
        }

        // 边界：站点根自身不可写时到此为止，绝不动它（动它等于整站消失），
        // 也绝不允许顺着路径往上跑到站点根之外
        if ($dir === $root) {
            return false;
        }
        if (!str_starts_with(str_replace('\\', '/', $dir), str_replace('\\', '/', $root) . '/')) {
            return is_dir($dir) && is_writable($dir);
        }

        // 目录还不存在 → 先把上级弄可写，再建
        if (!is_dir($dir)) {
            if (!self::ensureWritableDir(dirname($dir), $root, $healed)) {
                return false;
            }
            if (@mkdir($dir, 0755) || is_dir($dir)) {
                @chmod($dir, 0755);
                return true;
            }
            return false;
        }

        // 目录存在但不可写 → 上级可写才救得了（rename 只看上级权限）
        if (!self::ensureWritableDir(dirname($dir), $root, $healed)) {
            return false;
        }
        if (self::healDir($dir)) {
            $healed++;
            return true;
        }
        return false;
    }

    /**
     * 目录级自愈：改名 → 新建同名空目录 → 内容原样搬回
     *
     * Linux 上「改目录名」只校验上级目录的写权限，不需要目录内文件的属主配合，
     * 所以网站运行用户可以改名任何「上级可写」的目录（即使里面全是 root 的文件）。
     * 改名后立刻 mkdir 出同名新目录（属主=运行用户，可写），再把旧内容逐个
     * rename 回来。同一分区内 rename 是原子的，文件 inode 不变，
     * 属主、权限、内容原样保留 —— 只是目录这一层换了新的 inode，变得可写。
     *
     * @return bool 自愈后目录是否可写
     */
    protected static function healDir(string $dir): bool
    {
        $dir    = rtrim($dir, '/\\');
        $parent = dirname($dir);
        $base   = basename($dir);
        if ($base === '' || $parent === $dir) {
            return false;
        }

        $tmp = $parent . DIRECTORY_SEPARATOR . '.tw-heal-' . $base . '-' . bin2hex(random_bytes(4));

        if (!@rename($dir, $tmp)) {
            return false;
        }
        if (!@mkdir($dir, 0755)) {
            @rename($tmp, $dir);   // 建不成就退回去，绝不留下半截
            return false;
        }
        @chmod($dir, 0755);

        $names = @scandir($tmp);
        foreach (is_array($names) ? $names : [] as $n) {
            if ($n === '.' || $n === '..') {
                continue;
            }
            $from = $tmp . DIRECTORY_SEPARATOR . $n;
            $to   = $dir . DIRECTORY_SEPARATOR . $n;
            if (!@rename($from, $to)) {
                // rename 失败（跨分区等）→ 复制兜底，保证内容不丢
                self::copyTree($from, $to);
                self::rrmdir($from);
            }
        }
        @rmdir($tmp);

        return is_writable($dir);
    }

    protected static function copyTree(string $src, string $dst): int
    {
        if (is_file($src)) {
            self::mkdir(dirname($dst));
            return @copy($src, $dst) ? 1 : 0;
        }
        if (!is_dir($src)) {
            return 0;
        }
        self::mkdir($dst);
        $n = 0;
        foreach (scandir($src) ?: [] as $it) {
            if ($it === '.' || $it === '..') {
                continue;
            }
            $n += self::copyTree($src . '/' . $it, $dst . '/' . $it);
        }
        return $n;
    }

    /**
     * 递归规范权限：目录 755、文件 644
     */
    protected static function chmodTree(string $path): void
    {
        if (is_file($path)) {
            @chmod($path, 0644);
            return;
        }
        if (!is_dir($path)) {
            return;
        }
        @chmod($path, 0755);
        foreach (scandir($path) ?: [] as $it) {
            if ($it === '.' || $it === '..') {
                continue;
            }
            self::chmodTree($path . '/' . $it);
        }
    }

    /**
     * 从备份还原（只在写入异常时用）
     */
    protected static function restore(string $backup, string $root): void
    {
        if (!is_dir($backup)) {
            return;
        }
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($backup, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($it as $item) {
            if ($item->isDir()) {
                continue;
            }
            $abs = $item->getPathname();
            $rel = substr($abs, strlen($backup) + 1);
            $target = $root . DIRECTORY_SEPARATOR . $rel;
            self::mkdir(dirname($target));
            @copy($abs, $target);
        }
    }

    /**
     * 读取清单元数据：sha256 => 相对路径
     */
    public static function readManifest(string $file): array
    {
        if (!is_file($file)) {
            return [];
        }
        $map = [];
        foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
            $parts = preg_split('/\s+/', trim($line));
            if (count($parts) >= 2 && strlen($parts[0]) === 64) {
                $map[ltrim($parts[1], '*')] = strtolower($parts[0]);
            }
        }
        return $map;
    }

    /**
     * 解压（tar.gz 与 zip 都支持）
     *
     * 优先 tar.gz：PharData 是 PHP 内置，客户服务器没装 zip 扩展也能升级。
     */
    protected static function unzip(string $file, string $to): array
    {
        if (preg_match('/\.(tar\.gz|tgz)$/i', $file)) {
            return self::untar($file, $to);
        }
        return self::unzipZip($file, $to);
    }

    /**
     * 解 tar.gz（PharData，无扩展依赖）
     */
    protected static function untar(string $file, string $to): array
    {
        if (!class_exists('PharData')) {
            return ['code' => 0, 'msg' => 'PHP 缺少 Phar 扩展，无法解压升级包'];
        }

        try {
            $phar = new \PharData($file);
        } catch (\Throwable $e) {
            return ['code' => 0, 'msg' => '升级包无法打开：' . $e->getMessage()];
        }

        // 拒绝路径穿越
        try {
            $it = new \RecursiveIteratorIterator($phar, \RecursiveIteratorIterator::SELF_FIRST);
            foreach ($it as $f) {
                $n = str_replace('\\', '/', $f->getPathname());
                if (str_contains($n, '..')) {
                    return ['code' => 0, 'msg' => '升级包含非法路径，已拒绝'];
                }
            }
        } catch (\Throwable $e) {
            // 迭代失败不阻断，extractTo 自身也会失败并返回错误
        }

        try {
            $phar->extractTo($to, null, true);
        } catch (\Throwable $e) {
            return ['code' => 0, 'msg' => '解压失败：' . $e->getMessage()];
        }

        return ['code' => 1, 'msg' => 'ok'];
    }

    /**
     * 解 zip（需要 zip 扩展）
     */
    protected static function unzipZip(string $zip, string $to): array
    {
        if (!class_exists('ZipArchive')) {
            return ['code' => 0, 'msg' => '服务器未安装 zip 扩展，请改用 tar.gz 升级包'];
        }

        $za = new \ZipArchive();
        if ($za->open($zip) !== true) {
            return ['code' => 0, 'msg' => '升级包无法打开（可能已损坏）'];
        }

        for ($i = 0; $i < $za->numFiles; $i++) {
            $name = (string)$za->getNameIndex($i);
            $norm = str_replace('\\', '/', $name);
            if ($norm === '' || str_contains($norm, '../') || str_starts_with($norm, '/') || preg_match('/^[A-Za-z]:/', $norm)) {
                $za->close();
                return ['code' => 0, 'msg' => '升级包含非法路径，已拒绝：' . $name];
            }
        }

        $ok = $za->extractTo($to);
        $za->close();

        return $ok
            ? ['code' => 1, 'msg' => 'ok']
            : ['code' => 0, 'msg' => '解压失败，请检查目录权限'];
    }

    /** 最近一次 download() 失败的原因（给前端可读提示用） */
    protected static string $lastDlError = '';

    /**
     * 下载到本地文件
     */
    protected static function download(string $url, string $to, int $maxBytes): bool
    {
        self::$lastDlError = '';
        $fp = @fopen($to, 'wb');
        if (!$fp) {
            self::$lastDlError = '无法在 runtime/update 下创建临时文件（目录不可写？）';
            return false;
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_FILE           => $fp,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 3,
                CURLOPT_TIMEOUT        => 300,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_NOPROGRESS     => false,
                CURLOPT_PROGRESSFUNCTION => function ($r, $dl, $total) use ($maxBytes) {
                    return ($total > 0 && $total > $maxBytes) || $dl > $maxBytes ? 1 : 0;
                },
                CURLOPT_USERAGENT      => 'ThinkWoCMS/' . config('tw.version', ''),
            ]);
            $ok    = curl_exec($ch);
            $code  = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $cerr  = curl_error($ch);
            curl_close($ch);
            fclose($fp);

            if ($ok === false) {
                self::$lastDlError = $cerr !== '' ? 'curl: ' . $cerr : 'curl 请求失败';
                if (str_contains($cerr, 'certificate') || str_contains($cerr, 'CA')) {
                    self::$lastDlError .= '（服务器 PHP 缺少 CA 证书包，可让运维安装 ca-certificates）';
                }
                return false;
            }
            if ($code < 200 || $code >= 300) {
                self::$lastDlError = '授权站返回 HTTP ' . $code . '（伪静态未配置或包文件缺失时常见）';
                return false;
            }
            if (filesize($to) <= 0) {
                self::$lastDlError = '下载内容为空';
                return false;
            }
            return true;
        }

        $ctx = stream_context_create([
            'http' => ['timeout' => 300, 'follow_location' => 1],
            'ssl'  => ['verify_peer' => true, 'verify_peer_name' => true],
        ]);
        $out = @file_get_contents($url, false, $ctx, 0, $maxBytes);
        fclose($fp);
        if ($out === false) {
            self::$lastDlError = 'file_get_contents 失败（服务器未装 curl 扩展且流式请求被拒）';
            return false;
        }
        return @file_put_contents($to, $out) !== false;
    }

    /**
     * 清理旧备份，只留最近 N 份
     */
    protected static function pruneBackup(): void
    {
        $keep = max(1, (int)config('license.backup_keep', 3));
        $dirs = glob(self::workDir() . 'backup-*', GLOB_ONLYDIR) ?: [];
        rsort($dirs);
        foreach (array_slice($dirs, $keep) as $d) {
            self::rrmdir($d);
        }
    }

    /**
     * 把版本号写进 config/tw.php
     *
     * 客户改过 config/tw.php 时会被冲突检测跳过，升级后版本号还是旧的，
     * 每次进更新页都提示"有新版本"。版本号不属于定制内容，直接同步。
     */
    protected static function syncVersion(string $version): void
    {
        $file = app()->getRootPath() . 'config' . DIRECTORY_SEPARATOR . 'tw.php';
        if (!is_file($file)) {
            return;
        }

        $s = (string)@file_get_contents($file);
        $n = preg_replace("/('version'\s*=>\s*')[^']*(')/", '${1}' . $version . '${2}', $s, 1);

        if (is_string($n) && $n !== $s) {
            self::writeFileHealed($file, $n);
        }
    }

    /**
     * 写文件（含文件级自愈）
     *
     * 目标文件已存在但不可写时（宝塔 root 身份解压装机遗留：文件归 root）：
     *   1. 先试 chmod 0644
     *   2. 不行就 unlink 删掉重建 —— Linux 删文件只看「上级目录」写权限，
     *      目录可写时旧文件属主是 root 也能删，新文件即归运行用户所有
     *
     * @return bool 是否写入成功
     */
    protected static function writeFileHealed(string $file, string $data): bool
    {
        if (is_file($file) && !is_writable($file)) {
            @chmod($file, 0644);
            if (!is_writable($file)) {
                @unlink($file);
            }
        }
        return @file_put_contents($file, $data, LOCK_EX) !== false;
    }

    /**
     * 当前 PHP 进程的运行用户名（用于错误提示，告客户时能一眼对上）
     */
    protected static function runUser(): string
    {
        if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
            $u = posix_getpwuid(posix_geteuid());
            if (is_array($u) && !empty($u['name'])) {
                return (string)$u['name'];
            }
        }
        return 'www';
    }

    protected static function workDir(): string
    {
        return app()->getRootPath() . 'runtime' . DIRECTORY_SEPARATOR . 'update' . DIRECTORY_SEPARATOR;
    }

    /**
     * 当前站点域名（仅用于授权站留痕）
     */
    protected static function host(): string
    {
        try {
            return (string)request()->host(true);
        } catch (\Throwable $e) {
            return '';
        }
    }

    protected static function mkdir(string $dir): void
    {
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
    }

    protected static function rrmdir(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it as $item) {
            $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
        }
        @rmdir($dir);
    }

    /**
     * 更新后清模板与数据缓存
     */
    protected static function clearCache(): void
    {
        foreach (['cache', 'temp'] as $sub) {
            self::rrmdir(app()->getRootPath() . 'runtime' . DIRECTORY_SEPARATOR . $sub);
        }
        // 伪静态 HTML 缓存必须一并清：否则升级后前台吐的还是升级前的旧页面
        //（价格、版式全是旧的），用户会以为「版本升了但没生效」（v1.0.41 实踩）。
        try {
            HtmlCache::clear();
        } catch (\Throwable $e) {
            // 目录不可写时忽略，后台「SEO → 清空静态化缓存」可手动兜底
        }
    }

    protected static function post(string $url, array $data): ?array
    {
        $body = json_encode($data, JSON_UNESCAPED_UNICODE);

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $body,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 20,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            ]);
            $out  = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($out === false || $code >= 400) {
                return null;
            }
            $json = json_decode((string)$out, true);
            return is_array($json) ? $json : null;
        }

        $ctx = stream_context_create([
            'http' => ['method' => 'POST', 'header' => "Content-Type: application/json\r\n", 'content' => $body, 'timeout' => 20],
            'ssl'  => ['verify_peer' => true, 'verify_peer_name' => true],
        ]);
        $out = @file_get_contents($url, false, $ctx);
        if ($out === false) {
            return null;
        }
        $json = json_decode($out, true);
        return is_array($json) ? $json : null;
    }
}
