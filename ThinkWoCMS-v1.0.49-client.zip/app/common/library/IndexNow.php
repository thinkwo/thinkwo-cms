<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Db;
use think\facade\Log;

/**
 * IndexNow 即时收录推送（Bing / Yandex / Seznam / Naver 共享协议）
 *
 * 外贸 SEO 核心：内容发布、修改、删除后把 URL 主动推给搜索引擎，
 * 免去等待蜘蛛抓取的几天到几周时间差。
 *
 * 协议要点：
 *  - 每站一个 32 位十六进制密钥，放在站点根目录 {key}.txt 供验证
 *  - 推送地址用统一入口 https://api.indexnow.org/indexnow，由它分发到各引擎
 *  - 单次最多 10000 条，这里限制 100 条以内分批
 */
class IndexNow
{
    /**
     * 取（或生成）站点密钥
     */
    public static function key(): string
    {
        $key = (string)Settings::get('indexnow_key', '');
        if (preg_match('/^[a-f0-9]{32}$/', $key)) {
            return $key;
        }

        $key = bin2hex(random_bytes(16));
        Settings::set('indexnow_key', $key, 'seo');
        self::writeKeyFile($key);

        return $key;
    }

    /**
     * 把密钥文件写到 public 根（indexnow 验证要求可公网访问）
     */
    public static function writeKeyFile(?string $key = null): bool
    {
        $key = $key ?: self::key();
        $file = public_path() . $key . '.txt';

        return (bool)@file_put_contents($file, $key);
    }

    /**
     * 是否开启推送
     */
    public static function enabled(): bool
    {
        return (string)Settings::get('indexnow_enable', '0') === '1';
    }

    /**
     * 推送单条 URL（内容保存后调用）
     *
     * @param string $path  相对路径，如 /products/abc.html
     * @param string $type  Added / Updated / Removed
     */
    public static function push(string $path, string $type = 'Updated'): bool
    {
        return self::pushBatch([['path' => $path, 'type' => $type]]);
    }

    /**
     * 批量推送
     *
     * @param array $items [['path'=>'/xx.html','type'=>'Updated'], ...]
     */
    public static function pushBatch(array $items): bool
    {
        if (!$items) {
            return false;
        }

        $key = self::key();
        // 密钥文件必须先就位，否则推送无效
        self::writeKeyFile($key);

        $host    = self::host();
        $locList = [];
        foreach (array_slice($items, 0, 100) as $item) {
            $locList[] = Seo::abs('/' . ltrim((string)$item['path'], '/'));
        }

        $payload = json_encode([
            'host'        => $host,
            'key'         => $key,
            'keyLocation' => Seo::abs('/' . $key . '.txt'),
            'urlList'     => $locList,
        ], JSON_UNESCAPED_SLASHES);

        // 异步短超时，不阻塞后台操作
        $ch = curl_init('https://api.indexnow.org/indexnow/');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json; charset=utf-8'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 3,
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $body  = curl_exec($ch);
        $http  = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        try {
            Log::info('[IndexNow] http=' . $http . ' urls=' . count($locList)
                . ($body !== false && $body !== '' ? ' body=' . substr((string)$body, 0, 200) : '')
                . ($error !== '' ? ' error=' . $error : ''));
        } catch (\Throwable $e) {
            // 日志不可用静默
        }

        return $http === 200 || $http === 202;
    }

    /**
     * 推送全站所有已发布内容的 URL（后台手动全量推送）
     *
     * @return int 推送条数
     */
    public static function pushAll(): int
    {
        $items = [];
        try {
            $rows = Db::name('content')
                ->where('status', 1)
                ->field('id,lang,slug,sort_id,updatetime')
                ->limit(500)
                ->select()
                ->toArray();

            $sorts = [];
            foreach (Db::name('sort')->where('status', 1)->select()->toArray() as $s) {
                $sorts[(int)$s['id']] = $s;
            }

            foreach ($rows as $row) {
                $sort    = $sorts[(int)$row['sort_id']] ?? null;
                $url     = TwUrl::detail($row, $sort ?: []);
                $items[] = ['path' => $url, 'type' => 'Updated'];
            }

            // 栏目页与首页
            foreach ($sorts as $s) {
                if ((string)$s['type'] === 'link') {
                    continue;
                }
                $items[] = ['path' => TwUrl::sort($s), 'type' => 'Updated'];
            }
            $items[] = ['path' => '/', 'type' => 'Updated'];
        } catch (\Throwable $e) {
            return 0;
        }

        return self::pushBatch($items) ? count($items) : 0;
    }

    /**
     * 站点主机名
     */
    protected static function host(): string
    {
        $domain = (string)Settings::get('site_domain', '');
        if ($domain !== '') {
            return preg_replace('#^https?://#i', '', rtrim($domain, '/'));
        }

        return (string)request()->host();
    }
}
