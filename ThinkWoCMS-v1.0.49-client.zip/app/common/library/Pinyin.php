<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * URL 别名生成
 *
 * 优先使用 overtrue/pinyin 把中文转成拼音，
 * 未安装则退化为 ASCII 转换，再不行用短哈希。
 */
class Pinyin
{
    /**
     * 生成 slug
     */
    public static function slug(string $text, int $maxLength = 80): string
    {
        $text = trim($text);
        if ($text === '') {
            return 'p' . substr(md5((string)microtime(true)), 0, 8);
        }

        $slug = '';

        // 1. 中文转拼音
        if (preg_match('/[\x{4e00}-\x{9fa5}]/u', $text) && class_exists('\\Overtrue\\Pinyin\\Pinyin')) {
            try {
                $slug = (string)\Overtrue\Pinyin\Pinyin::permalink($text, '-');
            } catch (\Throwable $e) {
                $slug = '';
            }
        }

        // 2. 非中文或拼音库不可用时，尝试 ASCII 转换
        if ($slug === '') {
            $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
            $slug  = is_string($ascii) ? $ascii : '';
        }

        // 3. 兜底
        if ($slug === '') {
            $slug = 'p' . substr(md5($text), 0, 10);
        }

        $slug = strtolower($slug);
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug) ?? '';
        $slug = trim($slug, '-');
        $slug = preg_replace('/-{2,}/', '-', $slug) ?? '';

        if ($slug === '') {
            $slug = 'p' . substr(md5($text), 0, 10);
        }

        if (mb_strlen($slug) > $maxLength) {
            $slug = substr($slug, 0, $maxLength);
            $slug = rtrim($slug, '-');
        }

        return $slug;
    }

    /**
     * 清洗用户手输的 slug（外贸 SEO 规则：小写字母/数字/连字符）
     *
     * 大写转小写、空格与下划线转连字符、剔除中文及其他非法字符。
     * 清洗后为空返回空串，由调用方回退自动生成。
     */
    public static function sanitize(string $slug): string
    {
        $slug = trim($slug);
        if ($slug === '') {
            return '';
        }

        $slug = mb_strtolower($slug);
        $slug = preg_replace('/[^\x20-\x7e]+/', '-', $slug) ?? ''; // 非 ASCII（中文/全角）剔除
        $slug = str_replace(['_', ' '], '-', $slug);
        $slug = preg_replace('/[^a-z0-9-]+/', '', $slug) ?? '';
        $slug = preg_replace('/-{2,}/', '-', $slug) ?? '';

        return trim($slug, '-');
    }

    /**
     * 智能 slug：中文标题优先走翻译引擎译英（外贸 SEO：URL 含英文关键词），失败回退
     */
    public static function smartSlug(string $title): string
    {
        $title = trim($title);
        if ($title === '') {
            return self::slug($title);
        }

        // 标题含中文 → 强制按 中文→英文 翻译（与站点默认语言无关）
        if (preg_match('/[\x{4e00}-\x{9fa5}]/u', $title) && Translate::available()) {
            try {
                $res = Translate::strings(['t' => $title], 'zh-cn', 'en');
                $en  = trim((string)($res['t'] ?? ''));
                if ($en !== '' && $en !== $title && !preg_match('/[\x{4e00}-\x{9fa5}]/u', $en)) {
                    return self::slug($en);
                }
            } catch (\Throwable $e) {
                // 翻译失败回退默认生成
            }
        }

        return self::slug($title);
    }

    /**
     * 保证 slug 唯一
     *
     * @param string $table  表名（不含前缀）
     * @param string $lang   语言
     * @param int    $ignoreId 排除的ID（编辑时传自身）
     */
    public static function unique(string $table, string $slug, string $lang, int $ignoreId = 0): string
    {
        $base  = $slug;
        $index = 1;

        while (true) {
            $query = \think\facade\Db::name($table)->where('lang', $lang)->where('slug', $slug);
            if ($ignoreId > 0) {
                $query->where('id', '<>', $ignoreId);
            }
            if (!$query->find()) {
                return $slug;
            }
            $index++;
            $slug = $base . '-' . $index;
        }
    }
}
