<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Db;
use think\facade\Log;

/**
 * 数据库结构升级（随版本自动执行，无需重装）
 *
 * 已装旧版的站点访问任意页面时自动补：
 *  - currency 货币表 + 种子数据（v1.0.4）
 *  - translate_* 翻译配置项（v1.0.4）
 *  - indexnow_* 即时收录推送配置项（v1.0.5）
 *  - content / sort 表的 trans_status、trans_at 译文状态字段（v1.0.8）
 *  - translate_auto、translate_auto_body 自动同步开关（v1.0.8）
 * 执行一次后写入 db_version 标记，不再重复。
 */
class Upgrade
{
    public const DB_VERSION = '1.0.48';

    protected static bool $done = false;

    public static function run(): void
    {
        if (self::$done) {
            return;
        }
        self::$done = true;

        try {
            // 版本判断与升级前先清缓存，避免读到旧设置（否则升级逻辑会被缓存挡住）
            Settings::flush();

            if ((string)Settings::get('db_version', '') === self::DB_VERSION) {
                return;
            }

            self::ensureCurrency();
            self::ensureTransColumns();
            self::ensureMetaColumn();
            self::ensureVisitTables();
            self::ensureSlideTables();
            self::ensureSortFieldTable();
            self::ensureSettings();
            self::repairSelects();
            self::retirePluginstore();

            Settings::saveMany(['db_version' => self::DB_VERSION]);
        } catch (\Throwable $e) {
            self::$done = false; // 下次请求再试
            try {
                Log::error('[Upgrade] ' . $e->getMessage());
            } catch (\Throwable $ignore) {
                // 日志不可用时静默
            }
        }
    }

    /**
     * 货币表（兼容 MySQL / SQLite）
     */
    protected static function ensureCurrency(): void
    {
        $prefix = (string)config('database.connections.mysql.prefix', 'tw_');
        try {
            $prefix = (string)config('database.default', 'mysql') === 'sqlite'
                ? 'tw_'
                : $prefix;
        } catch (\Throwable $e) {
            // 默认 mysql 前缀
        }

        $table = $prefix . 'currency';

        // 已存在则跳过
        try {
            Db::query("SELECT 1 FROM {$table} LIMIT 1");

            return;
        } catch (\Throwable $e) {
            // 表不存在，继续建表
        }

        $mysql = "CREATE TABLE IF NOT EXISTS {$table} (
            `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
            `code` varchar(10) NOT NULL DEFAULT '' COMMENT '货币代码 USD',
            `name` varchar(50) NOT NULL DEFAULT '' COMMENT '名称 US Dollar',
            `symbol` varchar(10) NOT NULL DEFAULT '$' COMMENT '符号',
            `rate` decimal(12,6) NOT NULL DEFAULT '1.000000' COMMENT '对基准货币汇率',
            `decimals` tinyint(1) NOT NULL DEFAULT '2' COMMENT '小数位',
            `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '基准货币',
            `sort` int(11) NOT NULL DEFAULT '0',
            `status` tinyint(1) NOT NULL DEFAULT '1',
            `createtime` int(11) unsigned NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`),
            UNIQUE KEY `uk_code` (`code`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='多货币'";

        $sqlite = "CREATE TABLE IF NOT EXISTS {$table} (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT NOT NULL DEFAULT '',
            name TEXT NOT NULL DEFAULT '',
            symbol TEXT NOT NULL DEFAULT '$',
            rate REAL NOT NULL DEFAULT 1,
            decimals INTEGER NOT NULL DEFAULT 2,
            is_default INTEGER NOT NULL DEFAULT 0,
            sort INTEGER NOT NULL DEFAULT 0,
            status INTEGER NOT NULL DEFAULT 1,
            createtime INTEGER NOT NULL DEFAULT 0
        )";

        try {
            Db::execute($mysql);
        } catch (\Throwable $e) {
            Db::execute($sqlite);
        }

        // 种子数据
        try {
            if ((int)Db::name('currency')->count() === 0) {
                $now = time();
                $rows = [
                    ['USD', 'US Dollar',   '$', 1.0,     2, 1, 0],
                    ['EUR', 'Euro',        '€', 0.92,    2, 0, 1],
                    ['GBP', 'British Pound','£', 0.79,    2, 0, 2],
                    ['JPY', 'Japanese Yen','¥', 155.0,   0, 0, 3],
                    ['CNY', 'Chinese Yuan','¥', 7.20,    2, 0, 4],
                    ['AUD', 'Australian Dollar', 'A$', 1.52, 2, 0, 5],
                    ['CAD', 'Canadian Dollar',   'C$', 1.36, 2, 0, 6],
                ];
                foreach ($rows as $r) {
                    Db::name('currency')->insert([
                        'code' => $r[0], 'name' => $r[1], 'symbol' => $r[2],
                        'rate' => $r[3], 'decimals' => $r[4],
                        'is_default' => $r[5], 'sort' => $r[6],
                        'status' => 1, 'createtime' => $now,
                    ]);
                }
            }
        } catch (\Throwable $e) {
            // 并发或权限问题忽略，后台可手动添加
        }
    }

    /**
     * 内容表 / 栏目表补译文状态字段
     *
     * trans_status：0 原文、1 机器翻译、2 人工修改（自动同步会跳过）
     * trans_at    ：译文生成时间
     */
    protected static function ensureTransColumns(): void
    {
        foreach (['content', 'sort'] as $name) {
            try {
                $table = Db::name($name)->getTable();
            } catch (\Throwable $e) {
                continue;
            }

            if (!self::hasColumn($table, 'trans_status')) {
                try {
                    Db::execute("ALTER TABLE {$table} ADD COLUMN `trans_status` tinyint(1) NOT NULL DEFAULT 0");
                } catch (\Throwable $e) {
                    try {
                        Db::execute("ALTER TABLE {$table} ADD COLUMN trans_status INTEGER NOT NULL DEFAULT 0");
                    } catch (\Throwable $ignore) {
                        // 已存在或权限不足，下次再试
                    }
                }
            }

            if (!self::hasColumn($table, 'trans_at')) {
                try {
                    Db::execute("ALTER TABLE {$table} ADD COLUMN `trans_at` int(11) unsigned NOT NULL DEFAULT 0");
                } catch (\Throwable $e) {
                    try {
                        Db::execute("ALTER TABLE {$table} ADD COLUMN trans_at INTEGER NOT NULL DEFAULT 0");
                    } catch (\Throwable $ignore) {
                        // 已存在或权限不足
                    }
                }
            }
        }
    }

    /**
     * 内容表 meta 扩展字段（v1.0.43）
     *
     * 内容的通用自定义属性位：模板可以用它承载结构化不了的信息
     * （如价格卡的价格文案「¥4800」「按项目评估」，decimal 的 price 字段装不下）。
     * 程序不解释它的含义，各模板自行约定。
     */
    protected static function ensureMetaColumn(): void
    {
        try {
            $table = Db::name('content')->getTable();
        } catch (\Throwable $e) {
            return;
        }

        if (self::hasColumn($table, 'meta')) {
            return;
        }
        try {
            Db::execute("ALTER TABLE {$table} ADD COLUMN `meta` varchar(500) NOT NULL DEFAULT '' COMMENT '扩展属性（模板自定义）'");
        } catch (\Throwable $e) {
            try {
                Db::execute("ALTER TABLE {$table} ADD COLUMN meta VARCHAR(500) NOT NULL DEFAULT ''");
            } catch (\Throwable $ignore) {
                // 已存在或权限不足，下次再试
            }
        }
    }

    /**
     * 栏目自定义字段表（v1.0.44）+ meta 扩到 1000（JSON 存多个字段值，500 可能不够）
     */
    protected static function ensureSortFieldTable(): void
    {
        $prefix = 'tw_';
        try {
            $prefix = (string)config('database.connections.mysql.prefix', 'tw_');
            if ((string)config('database.default', 'mysql') === 'sqlite') {
                $prefix = 'tw_';
            }
        } catch (\Throwable $e) {
            // 用默认前缀
        }

        $table = $prefix . 'sort_field';

        if (!self::tableExists($table)) {
            $mysql = "CREATE TABLE IF NOT EXISTS {$table} (
                `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                `sort_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属栏目',
                `name` varchar(50) NOT NULL DEFAULT '' COMMENT '字段名称（后台表单标签）',
                `fkey` varchar(50) NOT NULL DEFAULT '' COMMENT '字段键（模板调用）',
                `type` varchar(10) NOT NULL DEFAULT 'text' COMMENT 'text/textarea/select/switch',
                `options` varchar(500) NOT NULL DEFAULT '' COMMENT '下拉选项，每行一个',
                `defval` varchar(200) NOT NULL DEFAULT '' COMMENT '默认值',
                `sort` int(11) NOT NULL DEFAULT '0',
                `status` tinyint(1) NOT NULL DEFAULT '1',
                `createtime` int(11) unsigned NOT NULL DEFAULT '0',
                `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
                PRIMARY KEY (`id`),
                KEY `idx_sort` (`sort_id`,`status`,`sort`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='栏目自定义字段定义'";

            $sqlite = "CREATE TABLE IF NOT EXISTS {$table} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sort_id INTEGER NOT NULL DEFAULT 0,
                name TEXT NOT NULL DEFAULT '',
                fkey TEXT NOT NULL DEFAULT '',
                type TEXT NOT NULL DEFAULT 'text',
                options TEXT NOT NULL DEFAULT '',
                defval TEXT NOT NULL DEFAULT '',
                sort INTEGER NOT NULL DEFAULT 0,
                status INTEGER NOT NULL DEFAULT 1,
                createtime INTEGER NOT NULL DEFAULT 0,
                updatetime INTEGER NOT NULL DEFAULT 0
            )";

            try {
                Db::execute($mysql);
            } catch (\Throwable $e) {
                Db::execute($sqlite);
            }
        }

        // meta 扩到 1000（v1.0.43 建的是 500，自定义字段 JSON 可能超）
        try {
            $contentTable = Db::name('content')->getTable();
            Db::execute("ALTER TABLE {$contentTable} MODIFY `meta` varchar(1000) NOT NULL DEFAULT '' COMMENT '扩展属性（自定义字段JSON或模板自定义文本）'");
        } catch (\Throwable $e) {
            try {
                Db::execute("ALTER TABLE {$contentTable} MODIFY meta VARCHAR(1000) NOT NULL DEFAULT ''");
            } catch (\Throwable $ignore) {
                // sqlite 不支持 MODIFY，忽略
            }
        }
    }

    /**
     * 访客统计表（v1.0.15）
     *
     * tw_visit      一次访问一行（访客、来源、落地页、页数、停留时长）
     * tw_visit_page 一次浏览一行（页面、进入时间、停留时长）
     */
    protected static function ensureVisitTables(): void
    {
        $prefix = 'tw_';
        try {
            $prefix = (string)config('database.connections.mysql.prefix', 'tw_');
            if ((string)config('database.default', 'mysql') === 'sqlite') {
                $prefix = 'tw_';
            }
        } catch (\Throwable $e) {
            // 用默认前缀
        }

        $visit = $prefix . 'visit';
        $page  = $prefix . 'visit_page';

        if (!self::tableExists($visit)) {
            $mysql = "CREATE TABLE IF NOT EXISTS {$visit} (
                `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                `sid` varchar(32) NOT NULL DEFAULT '' COMMENT '会话ID',
                `vid` varchar(32) NOT NULL DEFAULT '' COMMENT '访客ID',
                `ip` varchar(45) NOT NULL DEFAULT '',
                `ua` varchar(500) NOT NULL DEFAULT '',
                `device` varchar(10) NOT NULL DEFAULT 'desktop',
                `browser` varchar(30) NOT NULL DEFAULT '',
                `os` varchar(30) NOT NULL DEFAULT '',
                `lang` varchar(10) NOT NULL DEFAULT '',
                `referer` varchar(500) NOT NULL DEFAULT '',
                `ref_host` varchar(120) NOT NULL DEFAULT '',
                `landing` varchar(500) NOT NULL DEFAULT '',
                `pages` int(11) NOT NULL DEFAULT '0',
                `duration` int(11) NOT NULL DEFAULT '0',
                `last_url` varchar(500) NOT NULL DEFAULT '',
                `first_time` int(11) unsigned NOT NULL DEFAULT '0',
                `last_time` int(11) unsigned NOT NULL DEFAULT '0',
                PRIMARY KEY (`id`),
                UNIQUE KEY `uk_sid` (`sid`),
                KEY `idx_vid` (`vid`),
                KEY `idx_first` (`first_time`),
                KEY `idx_last` (`last_time`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='访客访问会话'";

            $sqlite = "CREATE TABLE IF NOT EXISTS {$visit} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sid TEXT NOT NULL DEFAULT '',
                vid TEXT NOT NULL DEFAULT '',
                ip TEXT NOT NULL DEFAULT '',
                ua TEXT NOT NULL DEFAULT '',
                device TEXT NOT NULL DEFAULT 'desktop',
                browser TEXT NOT NULL DEFAULT '',
                os TEXT NOT NULL DEFAULT '',
                lang TEXT NOT NULL DEFAULT '',
                referer TEXT NOT NULL DEFAULT '',
                ref_host TEXT NOT NULL DEFAULT '',
                landing TEXT NOT NULL DEFAULT '',
                pages INTEGER NOT NULL DEFAULT 0,
                duration INTEGER NOT NULL DEFAULT 0,
                last_url TEXT NOT NULL DEFAULT '',
                first_time INTEGER NOT NULL DEFAULT 0,
                last_time INTEGER NOT NULL DEFAULT 0
            )";

            try {
                Db::execute($mysql);
            } catch (\Throwable $e) {
                Db::execute($sqlite);
            }

            try {
                Db::execute("CREATE UNIQUE INDEX IF NOT EXISTS uk_visit_sid ON {$visit} (sid)");
                Db::execute("CREATE INDEX IF NOT EXISTS idx_visit_last ON {$visit} (last_time)");
            } catch (\Throwable $e) {
                // MySQL 已在建表语句里定义索引
            }
        }

        if (!self::tableExists($page)) {
            $mysql = "CREATE TABLE IF NOT EXISTS {$page} (
                `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                `visit_id` int(11) unsigned NOT NULL DEFAULT '0',
                `sid` varchar(32) NOT NULL DEFAULT '',
                `vid` varchar(32) NOT NULL DEFAULT '',
                `url` varchar(500) NOT NULL DEFAULT '',
                `title` varchar(255) NOT NULL DEFAULT '',
                `sort_id` int(11) NOT NULL DEFAULT '0',
                `content_id` int(11) NOT NULL DEFAULT '0',
                `referer` varchar(500) NOT NULL DEFAULT '',
                `enter_time` int(11) unsigned NOT NULL DEFAULT '0',
                `leave_time` int(11) unsigned NOT NULL DEFAULT '0',
                `duration` int(11) NOT NULL DEFAULT '0',
                PRIMARY KEY (`id`),
                KEY `idx_visit` (`visit_id`),
                KEY `idx_sid` (`sid`),
                KEY `idx_enter` (`enter_time`),
                KEY `idx_url` (`url`(191))
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='访客页面浏览明细'";

            $sqlite = "CREATE TABLE IF NOT EXISTS {$page} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                visit_id INTEGER NOT NULL DEFAULT 0,
                sid TEXT NOT NULL DEFAULT '',
                vid TEXT NOT NULL DEFAULT '',
                url TEXT NOT NULL DEFAULT '',
                title TEXT NOT NULL DEFAULT '',
                sort_id INTEGER NOT NULL DEFAULT 0,
                content_id INTEGER NOT NULL DEFAULT 0,
                referer TEXT NOT NULL DEFAULT '',
                enter_time INTEGER NOT NULL DEFAULT 0,
                leave_time INTEGER NOT NULL DEFAULT 0,
                duration INTEGER NOT NULL DEFAULT 0
            )";

            try {
                Db::execute($mysql);
            } catch (\Throwable $e) {
                Db::execute($sqlite);
            }

            try {
                Db::execute("CREATE INDEX IF NOT EXISTS idx_vp_visit ON {$page} (visit_id)");
                Db::execute("CREATE INDEX IF NOT EXISTS idx_vp_enter ON {$page} (enter_time)");
            } catch (\Throwable $e) {
                // MySQL 建表时已带索引
            }
        }
    }

    /**
     * 幻灯片分组 / 条目表（v1.0.39）
     *
     * 老站升级后自动建表并补两个默认分组（首页轮播 home、内页横幅 inner），
     * 后台「内容管理 → 幻灯片」立刻可用，模板里 {tw:slide group="home"} 直接取图。
     */
    protected static function ensureSlideTables(): void
    {
        $prefix = 'tw_';
        try {
            $prefix = (string)config('database.connections.mysql.prefix', 'tw_');
            if ((string)config('database.default', 'mysql') === 'sqlite') {
                $prefix = 'tw_';
            }
        } catch (\Throwable $e) {
            // 用默认前缀
        }

        $group = $prefix . 'slide_group';
        $slide = $prefix . 'slide';

        if (!self::tableExists($group)) {
            $mysql = "CREATE TABLE IF NOT EXISTS {$group} (
                `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                `name` varchar(80) NOT NULL DEFAULT '' COMMENT '分组名称',
                `code` varchar(60) NOT NULL DEFAULT '' COMMENT '调用标识',
                `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '用途说明/尺寸建议',
                `width` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '建议宽度',
                `height` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '建议高度',
                `status` tinyint(1) NOT NULL DEFAULT '1',
                `sort` int(11) NOT NULL DEFAULT '0',
                `createtime` int(11) unsigned NOT NULL DEFAULT '0',
                `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
                PRIMARY KEY (`id`),
                UNIQUE KEY `uk_code` (`code`),
                KEY `idx_status` (`status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片分组'";

            $sqlite = "CREATE TABLE IF NOT EXISTS {$group} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL DEFAULT '',
                code TEXT NOT NULL DEFAULT '',
                remark TEXT NOT NULL DEFAULT '',
                width INTEGER NOT NULL DEFAULT 0,
                height INTEGER NOT NULL DEFAULT 0,
                status INTEGER NOT NULL DEFAULT 1,
                sort INTEGER NOT NULL DEFAULT 0,
                createtime INTEGER NOT NULL DEFAULT 0,
                updatetime INTEGER NOT NULL DEFAULT 0
            )";

            try {
                Db::execute($mysql);
            } catch (\Throwable $e) {
                Db::execute($sqlite);
            }
        }

        if (!self::tableExists($slide)) {
            $mysql = "CREATE TABLE IF NOT EXISTS {$slide} (
                `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                `group_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属分组',
                `lang` varchar(10) NOT NULL DEFAULT '' COMMENT '语言',
                `title` varchar(200) NOT NULL DEFAULT '' COMMENT '主标题',
                `subtitle` varchar(200) NOT NULL DEFAULT '' COMMENT '副标题',
                `summary` varchar(500) NOT NULL DEFAULT '' COMMENT '描述',
                `image` varchar(500) NOT NULL DEFAULT '' COMMENT '图片（PC）',
                `image_mobile` varchar(500) NOT NULL DEFAULT '' COMMENT '图片（手机）',
                `video` varchar(500) NOT NULL DEFAULT '' COMMENT '视频地址 mp4，可空',
                `url` varchar(500) NOT NULL DEFAULT '' COMMENT '跳转链接',
                `target` varchar(10) NOT NULL DEFAULT '_self' COMMENT '打开方式',
                `btn_text` varchar(60) NOT NULL DEFAULT '' COMMENT '按钮文字',
                `sort` int(11) NOT NULL DEFAULT '0',
                `status` tinyint(1) NOT NULL DEFAULT '1',
                `start_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '定时开始，0 不限',
                `end_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '定时结束，0 不限',
                `createtime` int(11) unsigned NOT NULL DEFAULT '0',
                `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
                PRIMARY KEY (`id`),
                KEY `idx_group` (`group_id`,`lang`,`status`,`sort`),
                KEY `idx_time` (`start_time`,`end_time`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片条目'";

            $sqlite = "CREATE TABLE IF NOT EXISTS {$slide} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER NOT NULL DEFAULT 0,
                lang TEXT NOT NULL DEFAULT '',
                title TEXT NOT NULL DEFAULT '',
                subtitle TEXT NOT NULL DEFAULT '',
                summary TEXT NOT NULL DEFAULT '',
                image TEXT NOT NULL DEFAULT '',
                image_mobile TEXT NOT NULL DEFAULT '',
                video TEXT NOT NULL DEFAULT '',
                url TEXT NOT NULL DEFAULT '',
                target TEXT NOT NULL DEFAULT '_self',
                btn_text TEXT NOT NULL DEFAULT '',
                sort INTEGER NOT NULL DEFAULT 0,
                status INTEGER NOT NULL DEFAULT 1,
                start_time INTEGER NOT NULL DEFAULT 0,
                end_time INTEGER NOT NULL DEFAULT 0,
                createtime INTEGER NOT NULL DEFAULT 0,
                updatetime INTEGER NOT NULL DEFAULT 0
            )";

            try {
                Db::execute($mysql);
            } catch (\Throwable $e) {
                Db::execute($sqlite);
            }
        }

        // 栏目可绑定自己的幻灯片分组：老站补字段
        $sortTable = $prefix . 'sort';
        if (self::tableExists($sortTable) && !self::hasColumn($sortTable, 'slide_group')) {
            try {
                Db::execute("ALTER TABLE {$sortTable} ADD COLUMN `slide_group` varchar(60) NOT NULL DEFAULT '' COMMENT '幻灯片分组 code'");
            } catch (\Throwable $e) {
                // 列已存在或数据库不支持，忽略
            }
        }

        // 默认分组：没有就补，已有（哪怕被改名）一律不动
        try {
            $exists = (int)Db::name('slide_group')->count();
            if ($exists === 0) {
                $now = time();
                Db::name('slide_group')->insertAll([
                    [
                        'name' => '首页轮播', 'code' => 'home',
                        'remark' => '首页首屏大图轮播，建议 1920×900，手机图另传 750×1000',
                        'width' => 1920, 'height' => 900, 'status' => 1, 'sort' => 1,
                        'createtime' => $now, 'updatetime' => $now,
                    ],
                    [
                        'name' => '内页横幅', 'code' => 'inner',
                        'remark' => '栏目页/详情页顶部横幅，建议 1920×520，单张即可',
                        'width' => 1920, 'height' => 520, 'status' => 1, 'sort' => 2,
                        'createtime' => $now, 'updatetime' => $now,
                    ],
                ]);
            }
        } catch (\Throwable $e) {
            // 分组写入失败不影响建表，后台可手动新建
        }
    }

    protected static function tableExists(string $table): bool
    {
        try {
            Db::query("SELECT 1 FROM {$table} LIMIT 1");

            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected static function hasColumn(string $table, string $column): bool
    {
        try {
            Db::query("SELECT {$column} FROM {$table} LIMIT 1");

            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * 补缺失的设置项
     */
    protected static function ensureSettings(): void
    {
        $defaults = [
            'currency'           => ['USD', 'base'],
            'translate_driver'   => ['auto', 'base'],
            'translate_appid'    => ['', 'base'],
            'translate_secret'   => ['', 'base'],
            'translate_deepl_pro' => ['0', 'base'],
            'translate_auto'     => ['1', 'base'],
            'translate_auto_body' => ['1', 'base'],
            'indexnow_enable'    => ['0', 'seo'],
            'indexnow_key'       => ['', 'seo'],
            'visit_enable'       => ['1', 'seo'],
            'visit_keep_days'    => ['90', 'seo'],
        ];

        foreach ($defaults as $key => [$value, $group]) {
            $exists = Db::name('setting')->where('skey', $key)->find();
            if (!$exists) {
                Db::name('setting')->insert(['skey' => $key, 'svalue' => $value, 'sgroup' => $group]);
            }
        }

        // 老站仍是「离线复制」且没配任何密钥 → 换成免费引擎，开箱即可自动翻译
        $driver = (string)Settings::get('translate_driver', '');
        if (($driver === '' || $driver === 'none') && (string)Settings::get('translate_appid', '') === '') {
            Settings::saveMany(['translate_driver' => 'auto']);
        }
    }

    /**
     * 修复 v1.0.9 及更早版本留下的下拉框脏值
     *
     * 旧设置页用 {volist key="xxx"} 取数组键，实际拿到的是循环序号（1、2、3…），
     * 结果把 theme / smtp_secure / translate_driver 存成了数字：
     *   - theme=1  → 后台换模板永远不生效（目录不存在，回退 default）
     *   - smtp_secure=1 → 邮件加密方式错乱
     *   - translate_driver=1 → 引擎识别失败，自动翻译整体失效
     * 这里按「序号 => 原选项」还原成用户当时真正选的那一项。
     */
    protected static function repairSelects(): void
    {
        $fix = [];

        // 序号按设置页下拉框的渲染顺序（也是定义顺序）还原
        $maps = [
            'smtp_secure'      => ['1' => 'ssl', '2' => 'tls', '3' => 'none'],
            'translate_driver' => [
                '1' => 'auto', '2' => 'google', '3' => 'mymemory', '4' => 'baidu',
                '5' => 'youdao', '6' => 'deepl', '7' => 'none',
            ],
        ];
        foreach ($maps as $key => $map) {
            $cur = trim((string)Settings::get($key, ''));
            if ($cur === '') {
                continue;
            }
            if (isset($map[$cur])) {
                $fix[$key] = $map[$cur];
            }
        }

        // 主题：必须落在真实存在的模板目录；数字序号按主题列表顺序还原
        $cur  = trim((string)Settings::get('theme', ''));
        $dirs = array_keys(Theme::available());
        if ($cur !== '' && !in_array($cur, $dirs, true)) {
            if (ctype_digit($cur) && isset($dirs[(int)$cur - 1])) {
                $fix['theme'] = $dirs[(int)$cur - 1];
            } else {
                $fix['theme'] = 'default';
            }
        }

        if ($fix) {
            Settings::saveMany($fix);
            Theme::reset();
        }
    }

    /**
     * v1.0.47：插件在线升级能力已内置到主程序「插件管理」，
     * 自动移除早期独立插件「插件升级中心（pluginstore）」，避免双入口
     */
    protected static function retirePluginstore(): void
    {
        // 1. 清菜单与插件登记记录
        try {
            Db::name('admin_rule')->where('name', 'pluginstore/index')->delete();
            Db::name('plugin')->where('name', 'pluginstore')->delete();
        } catch (\Throwable $e) {
            // 表不存在等异常忽略（未装过插件的站不会有这些记录）
        }

        // 2. 删自动生成的桥接控制器
        try {
            $bridge = app()->getBasePath() . 'admin' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'Pluginstore.php';
            if (is_file($bridge)) {
                @unlink($bridge);
            }
        } catch (\Throwable $e) {
            // 忽略
        }

        // 3. 删插件目录（留 runtime/pluginstore 的历史备份不清理，无害）
        try {
            $dir = Plugin::path('pluginstore');
            if (is_dir($dir)) {
                PluginUpgrade::rrmdir($dir);
            }
        } catch (\Throwable $e) {
            // 目录被占用等情况：插件已无菜单入口，不影响使用，下次再试
        }
    }
}
