<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * 云端插件授权快照
 *
 * 授权站每次下发插件清单时，把「插件是否启用 / 这个授权码是否开通 / 到期时间 / 价格」
 * 落到 runtime/pluginupgrade/entitlements.json。之后前台、后台的每个请求只读本地快照，
 * 绝不在请求里连授权站（否则每次请求都要等一次网络）。
 *
 * 三条原则：
 * 1. 失败开放：没拉过清单、快照为空、插件不在快照里，一律视为可用，
 *    避免新装站点断网时插件全被锁死。
 * 2. 到期只停升级：到期后插件照常运行，只是「更新」按钮不可用，续费自动恢复。
 * 3. 自用版不受限：License::isClient() === false 时所有云端校验直接放行。
 */
class PluginLicense
{
    /** 单次请求内缓存 */
    protected static ?array $cache = null;

    /**
     * 快照文件
     */
    public static function file(): string
    {
        return PluginUpgrade::workDir() . 'entitlements.json';
    }

    /**
     * 是否自用版（自用版不用授权站启用/开通，全部放行）
     */
    public static function isSelf(): bool
    {
        return !License::isClient();
    }

    /**
     * 全部云端插件状态：name => [title, active, authorized, expire_at, price_text]
     */
    public static function all(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $map = [];
        $file = self::file();
        if (is_file($file)) {
            $data = json_decode((string)@file_get_contents($file), true);
            if (is_array($data) && is_array($data['plugins'] ?? null)) {
                $map = (array)$data['plugins'];
            }
        }

        return self::$cache = $map;
    }

    /**
     * 用授权站下发的清单刷新快照
     *
     * 只保留云端校验要用的字段，不存下载地址（地址 5 分钟就过期了）。
     */
    public static function load(array $packages): void
    {
        $map = [];
        foreach ($packages as $p) {
            if (!is_array($p)) {
                continue;
            }
            $name = (string)($p['name'] ?? '');
            if ($name === '') {
                continue;
            }
            $map[$name] = [
                'title'      => (string)($p['title'] ?? $name),
                'active'     => !empty($p['active']),
                'authorized' => !empty($p['authorized']),
                'expire_at'  => (int)($p['expire_at'] ?? 0),
                'price_text' => (string)($p['price_text'] ?? ''),
            ];
        }

        self::$cache = $map;

        PluginUpgrade::ensureDirs();
        @file_put_contents(self::file(), (string)json_encode([
            'at'      => time(),
            'api'     => License::api(),
            'plugins' => $map,
        ], JSON_UNESCAPED_UNICODE));
    }

    /**
     * 单个插件的云端状态（页面展示用）
     *
     * @return array{known:bool,active:bool,authorized:bool,expire_at:int,expire_txt:string,price_text:string,expired:bool,usable:bool,can_upgrade:bool}
     */
    public static function of(string $name): array
    {
        $all  = self::all();
        $one  = isset($all[$name]) && is_array($all[$name]) ? $all[$name] : null;
        $exp  = (int)($one['expire_at'] ?? 0);

        // 快照里没有这个插件 => 未拉过清单或授权站已下架，按可用处理
        $active     = $one === null ? true : !empty($one['active']);
        $authorized = $one === null ? true : !empty($one['authorized']);
        $expired    = $exp > 0 && time() > $exp;

        return [
            'known'      => $one !== null,
            'active'     => $active,
            'authorized' => $authorized,
            'expire_at'  => $exp,
            'expire_txt' => $exp > 0 ? date('Y-m-d', $exp) : '永久',
            'price_text' => (string)($one['price_text'] ?? ''),
            'expired'    => $expired,
            'usable'     => self::isSelf() || ($active && $authorized),
            'can_upgrade' => self::isSelf() || ($active && $authorized && !$expired),
        ];
    }

    /**
     * 这个插件现在能不能用（授权端停用 / 该站未开通 => 不能）
     */
    public static function usable(string $name): bool
    {
        if (self::isSelf()) {
            return true;
        }
        $s = self::of($name);

        return $s['active'] && $s['authorized'];
    }

    /**
     * 这个插件现在能不能升级（到期只停升级，不影响使用）
     */
    public static function canUpgrade(string $name): bool
    {
        if (self::isSelf()) {
            return true;
        }
        $s = self::of($name);

        return $s['active'] && $s['authorized'] && !$s['expired'];
    }

    /**
     * 页面上的状态说明（空字符串 = 一切正常）
     */
    public static function note(string $name): string
    {
        if (self::isSelf()) {
            return '';
        }
        $s = self::of($name);

        if (!$s['active']) {
            return '授权端已停用该插件，当前不加载；如需继续使用请联系服务商';
        }
        if (!$s['authorized']) {
            return '本站未开通该插件，当前不加载；请联系服务商开通';
        }
        if ($s['expired']) {
            return '插件授权已于 ' . $s['expire_txt'] . ' 到期，插件可继续使用但不能升级，续费后恢复';
        }

        return '';
    }
}
