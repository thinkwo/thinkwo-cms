<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Cache;
use think\facade\Log;

/**
 * 授权校验（离线验签）
 *
 * 三条设计原则：
 * 1. 私钥只存在于授权站，客户端只内置公钥 —— 抄走源码也签不出合法授权
 * 2. 授权失效不锁站：前台永远正常，只影响后台更新与提示
 *    （远程锁站涉法律风险，客户服务器断网时还会造成生产事故）
 * 3. 自用版（edition=self）完全跳过校验，源码与功能零差异
 */
class License
{
    public const FILENAME = 'license.dat';

    /** @var array|null 单次请求内缓存 */
    protected static ?array $state = null;

    /**
     * 授权文件绝对路径
     */
    public static function file(): string
    {
        return app()->getRootPath() . 'config' . DIRECTORY_SEPARATOR . self::FILENAME;
    }

    /**
     * 是否为分发版
     *
     * 读取加密区里的构建常量。读不到（文件被删或被替换）时按分发版处理，
     * 即失败关闭 —— 删文件不能换来"免授权"。
     */
    public static function isClient(): bool
    {
        try {
            return Build::EDITION === 'client';
        } catch (\Throwable $e) {
            return true;
        }
    }

    /**
     * 授权站地址（后台可覆盖配置）
     */
    public static function api(): string
    {
        $api = '';
        try {
            $api = (string)Settings::get('license_api', '');
        } catch (\Throwable $e) {
            $api = '';
        }
        if ($api === '') {
            $api = (string)config('license.api', '');
        }
        return rtrim($api, '/');
    }

    /**
     * 当前授权状态
     *
     * @return array{
     *   ok:bool, edition:string, licensed:bool, can_update:bool,
     *   reason:string, data:array, expire_txt:string, update_txt:string
     * }
     */
    public static function state(bool $fresh = false): array
    {
        if (self::$state !== null && !$fresh) {
            return self::$state;
        }

        if (!self::isClient()) {
            return self::$state = [
                'ok'         => true,
                'edition'    => 'self',
                'licensed'   => true,
                'can_update' => true,
                'reason'     => '自用完整版，无需授权',
                'data'       => [],
                'expire_txt' => '永久',
                'update_txt' => '永久',
            ];
        }

        $file = self::file();
        if (!is_file($file)) {
            return self::$state = self::fail('尚未激活，请先输入授权码');
        }

        $raw = json_decode((string)@file_get_contents($file), true);
        if (!is_array($raw) || empty($raw['payload']) || empty($raw['sig'])) {
            return self::$state = self::fail('授权文件已损坏，请重新激活');
        }

        $data = self::verify((string)$raw['payload'], (string)$raw['sig']);
        if ($data === null) {
            return self::$state = self::fail('授权文件校验失败（签名不符或内容被篡改）');
        }

        if ((string)($data['product'] ?? '') !== (string)config('license.product', 'thinkwocms')) {
            return self::$state = self::fail('授权文件与本产品不匹配');
        }

        $now    = time();
        $grace  = max(0, (int)config('license.grace_days', 30)) * 86400;
        $expire = (int)($data['expire_at'] ?? 0);
        $until  = (int)($data['update_until'] ?? 0);

        $expired   = $expire > 0 && $now > $expire + $grace;
        $canUpdate = $until === 0 || $now <= $until + $grace;

        return self::$state = [
            'ok'         => !$expired,
            'edition'    => 'client',
            'licensed'   => true,
            'can_update' => $canUpdate,
            'reason'     => $expired
                ? '授权已过期（含 ' . (int)config('license.grace_days', 30) . ' 天宽限期）'
                : ($canUpdate ? '授权有效' : '站点授权有效，但升级服务已到期'),
            'data'       => $data,
            'expire_txt' => self::dateTxt($expire),
            'update_txt' => self::dateTxt($until),
        ];
    }

    /**
     * 用公钥校验签名，通过后返回授权体，否则 null
     *
     * 签名对象是 payload 的 base64 原文，避免 JSON 重新序列化造成字节差异
     */
    public static function verify(string $payload, string $sig): ?array
    {
        $pub = (string)config('license.public_key', '');
        if ($pub === '' || !function_exists('openssl_verify')) {
            return null;
        }

        $key = @openssl_pkey_get_public($pub);
        if (!$key) {
            Log::error('授权公钥无法解析');
            return null;
        }

        $bin = base64_decode($sig, true);
        if ($bin === false || $bin === '') {
            return null;
        }

        $ok = @openssl_verify($payload, $bin, $key, OPENSSL_ALGO_SHA256);

        $json = base64_decode($payload, true);
        if ($json === false) {
            return null;
        }
        $data = json_decode($json, true);

        return $ok === 1 && is_array($data) ? $data : null;
    }

    /**
     * 保存授权文件
     */
    public static function save(string $payload, string $sig): bool
    {
        $file = self::file();
        $dir  = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
            return false;
        }

        $body = json_encode(
            ['payload' => $payload, 'sig' => $sig, 'saved_at' => time()],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        $ok = @file_put_contents($file, $body, LOCK_EX) !== false;
        if ($ok) {
            @chmod($file, 0644);
        }
        self::$state = null;
        return $ok;
    }

    /**
     * 删除本地授权（换绑 / 重装时用）
     */
    public static function clear(): void
    {
        $file = self::file();
        if (is_file($file)) {
            @unlink($file);
        }
        self::$state = null;
    }

    /**
     * 用授权码向授权站换取授权文件
     *
     * @return array{code:int,msg:string}
     */
    public static function activate(string $code): array
    {
        $code = strtoupper(trim($code));
        $code = str_replace([' ', '_'], '-', $code);

        if ($code === '') {
            return ['code' => 0, 'msg' => '请输入授权码'];
        }
        if (!preg_match('/^TW-[0-9A-Z]{2}(-[0-9A-Z]{4}){3}$/', $code)) {
            return ['code' => 0, 'msg' => '授权码格式应为 TW-26-XXXX-XXXX-XXXX'];
        }

        $api = self::api();
        if ($api === '') {
            return ['code' => 0, 'msg' => '未配置授权站地址，请联系服务商'];
        }

        $res = self::post($api . '/api/activate', [
            'code'    => $code,
            'domain'  => self::host(),
            'version' => (string)config('tw.version', ''),
            'php'     => PHP_VERSION,
        ]);

        if ($res === null) {
            return ['code' => 0, 'msg' => '无法连接授权服务器，请检查服务器网络或稍后重试'];
        }
        if (($res['code'] ?? 0) !== 1) {
            return ['code' => 0, 'msg' => (string)($res['msg'] ?? '激活失败')];
        }

        $payload = (string)($res['payload'] ?? '');
        $sig     = (string)($res['sig'] ?? '');
        if ($payload === '' || $sig === '') {
            return ['code' => 0, 'msg' => '授权服务器返回数据不完整'];
        }

        // 落盘前先本地验签：即便传输过程被劫持，没有私钥也伪造不出合法签名
        if (self::verify($payload, $sig) === null) {
            return ['code' => 0, 'msg' => '授权签名校验失败，请联系服务商'];
        }

        if (!self::save($payload, $sig)) {
            return ['code' => 0, 'msg' => '授权文件写入失败，请检查 config 目录是否可写'];
        }

        self::$state = null;
        return ['code' => 1, 'msg' => '激活成功'];
    }

    /**
     * 拉取最新授权信息（续期后刷新本地文件）
     *
     * @return array{code:int,msg:string}
     */
    public static function refresh(): array
    {
        $st = self::state(true);
        if (!$st['licensed'] || empty($st['data']['license_id'])) {
            return ['code' => 0, 'msg' => '尚未激活'];
        }

        $api = self::api();
        $res = self::post($api . '/api/refresh', [
            'code'    => (string)$st['data']['license_id'],
            'domain'  => self::host(),
            'version' => (string)config('tw.version', ''),
        ]);

        if ($res === null) {
            return ['code' => 0, 'msg' => '无法连接授权服务器'];
        }
        if (($res['code'] ?? 0) !== 1) {
            return ['code' => 0, 'msg' => (string)($res['msg'] ?? '刷新失败')];
        }

        $payload = (string)($res['payload'] ?? '');
        $sig     = (string)($res['sig'] ?? '');
        if (self::verify($payload, $sig) === null) {
            return ['code' => 0, 'msg' => '签名校验失败'];
        }
        if (!self::save($payload, $sig)) {
            return ['code' => 0, 'msg' => '写入失败，请检查 config 目录权限'];
        }

        self::$state = null;
        return ['code' => 1, 'msg' => '已刷新'];
    }

    /**
     * 匿名心跳（仅分发版）
     *
     * 客户版后台打开时向授权站报一次到：域名 / 版本 / PHP / 是否已激活，
     * 让服务商能看到"装了 CMS 但没激活"的站。6 小时节流，失败完全静默，
     * 任何异常都不影响站点正常运行。
     */
    public static function ping(): void
    {
        try {
            if (!self::isClient()) {
                return;
            }

            try {
                if (Cache::get('tw_ping_at')) {
                    return;
                }
            } catch (\Throwable $e) {
                // 缓存不可用时不阻断，授权站侧还会按域名合并
            }

            $api = self::api();
            if ($api === '') {
                return;
            }

            $st = self::state();
            self::post($api . '/api/ping', [
                'domain'   => self::host(),
                'version'  => (string)config('tw.version', ''),
                'php'      => PHP_VERSION,
                'licensed' => $st['licensed'] ? 1 : 0,
                // 版权标识是否完好（ok/missing）：授权站留痕，用于售后核对，
                // 不做任何限制——客户站点永远正常运行
                'brand'    => class_exists(Brand::class) ? Brand::status() : '',
            ]);

            try {
                Cache::set('tw_ping_at', time(), 21600);
            } catch (\Throwable $e) {
                // 忽略
            }
        } catch (\Throwable $e) {
            // 心跳永远不影响正常使用
        }
    }

    // ------------------------------------------------------------------
    // 内部工具
    // ------------------------------------------------------------------

    protected static function fail(string $reason): array
    {
        return [
            'ok'         => false,
            'edition'    => 'client',
            'licensed'   => false,
            'can_update' => false,
            'reason'     => $reason,
            'data'       => [],
            'expire_txt' => '-',
            'update_txt' => '-',
        ];
    }

    protected static function dateTxt(int $ts): string
    {
        return $ts > 0 ? date('Y-m-d', $ts) : '永久';
    }

    /**
     * 当前站点域名（CLI 或异常时返回空串，仅用于授权站留痕）
     */
    protected static function host(): string
    {
        try {
            return (string)request()->host(true);
        } catch (\Throwable $e) {
            return '';
        }
    }

    /**
     * POST JSON，返回解析后的数组；网络失败返回 null
     */
    protected static function post(string $url, array $data): ?array
    {
        $body = json_encode($data, JSON_UNESCAPED_UNICODE);

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $body,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_HTTPHEADER     => [
                    'Content-Type: application/json',
                    'User-Agent: ThinkWoCMS/' . config('tw.version', ''),
                ],
            ]);
            $out  = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err  = curl_error($ch);
            curl_close($ch);

            if ($out === false || $code >= 400) {
                Log::error('授权站请求失败：' . $url . ' HTTP ' . $code . ' ' . $err);
                return null;
            }
            $json = json_decode((string)$out, true);
            return is_array($json) ? $json : null;
        }

        $ctx = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $body,
                'timeout' => 15,
            ],
            'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
        ]);
        $out = @file_get_contents($url, false, $ctx);
        if ($out === false) {
            return null;
        }
        $json = json_decode($out, true);
        return is_array($json) ? $json : null;
    }
}
