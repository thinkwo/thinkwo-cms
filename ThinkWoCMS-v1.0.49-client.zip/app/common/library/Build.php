<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * 构建信息（由 build/build.php 自动生成，请勿手改）
 *
 * 为什么版本标记不放在 config/license.php：
 * config 目录是明文可改的，客户只要把 edition 改成 self 就白嫖了。
 * 放进这个类里，分发版会把 app/ 整体加密，改不动；删掉这个类会导致
 * License::isClient() 失败关闭（按分发版处理），绕过成本反而更高。
 */
final class Build
{
    /** self = 自用完整版；client = 分发版 */
    public const EDITION = 'client';

    /** 构建标识，便于排查线上跑的是哪个包 */
    public const BUILD_ID = '51B485F04182';

    /** 构建时间 */
    public const BUILT_AT = '2026-11-07 22:01:55';

    /** 授权给谁（构建时写入，用于泄露溯源） */
    public const CUSTOMER = '';

    /** 本份副本的唯一指纹（客户名 + 版本 + 构建号 计算得出） */
    public const FINGERPRINT = '868A150A3E6F28B9';

    /** 编码目标 PHP 版本，明文版为空 */
    public const TARGET_PHP = '';

    /** 是否经过 ionCube 编码 */
    public const ENCODED = false;
}
