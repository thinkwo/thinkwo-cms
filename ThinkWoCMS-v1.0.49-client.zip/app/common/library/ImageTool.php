<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * 图片处理（上传即转 WebP + 多尺寸）
 *
 * 依赖 GD 扩展，不引入第三方图像库。
 */
class ImageTool
{
    /**
     * 允许的图片扩展名
     */
    public const IMAGE_EXTS = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];

    /**
     * 处理上传文件
     *
     * @param array  $file  $_FILES 单元
     * @param string $subdir 相对 uploads 的子目录，空则按日期
     * @return array{ok:bool,msg:string,data:array}
     */
    public static function upload(array $file, string $subdir = ''): array
    {
        if (empty($file['tmp_name']) || ($file['error'] ?? 4) !== 0) {
            return ['ok' => false, 'msg' => '上传失败，文件为空或超出服务器限制', 'data' => []];
        }

        $cfg     = (array)config('upload');
        $maxsize = (int)($cfg['maxsize'] ?? 20971520);
        if (($file['size'] ?? 0) > $maxsize) {
            return ['ok' => false, 'msg' => '文件超过大小限制 ' . round($maxsize / 1048576, 1) . 'MB', 'data' => []];
        }

        $original = (string)($file['name'] ?? 'file');
        $ext      = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        $allow    = (array)($cfg['exts'] ?? []);
        if (!in_array($ext, $allow, true)) {
            return ['ok' => false, 'msg' => '不允许的文件类型：' . $ext, 'data' => []];
        }

        if ($subdir === '') {
            $subdir = date('Ym');
        }
        $subdir = trim(str_replace(['..', '\\'], '', $subdir), '/');

        $relDir = 'uploads/' . $subdir . '/';
        $absDir = public_path() . $relDir;
        if (!is_dir($absDir) && !@mkdir($absDir, 0755, true) && !is_dir($absDir)) {
            return ['ok' => false, 'msg' => '上传目录不可写：' . $relDir, 'data' => []];
        }

        $name = date('Ymd') . '-' . bin2hex(random_bytes(8)) . '.' . $ext;
        $abs  = $absDir . $name;
        $rel  = $relDir . $name;

        if (!move_uploaded_file($file['tmp_name'], $abs)) {
            return ['ok' => false, 'msg' => '移动文件失败，请检查目录权限', 'data' => []];
        }

        $data = [
            'name'   => $original,
            'path'   => $rel,
            'url'    => '/' . $rel,
            'ext'    => $ext,
            'size'   => (int)filesize($abs),
            'width'  => 0,
            'height' => 0,
            'webp'   => '',
            'hash'   => (string)md5_file($abs),
        ];

        if (in_array($ext, self::IMAGE_EXTS, true)) {
            $info = @getimagesize($abs);
            if ($info) {
                $data['width']  = (int)$info[0];
                $data['height'] = (int)$info[1];
            }

            // 长截图 / 高清原图（如 1440×7000）在 128M 限制下会撑爆 GD，临时放宽
            self::boostMemory($data['width'], $data['height']);

            $webpCfg = (bool)config('tw.image.webp', true);
            if ($webpCfg && $ext !== 'webp') {
                $webpRel = self::toWebp($abs, $rel);
                if ($webpRel !== null) {
                    $data['webp'] = $webpRel;
                    $data['size'] = (int)filesize($abs);
                }
            }

            self::makeSizes($abs, $rel);
        }

        return ['ok' => true, 'msg' => 'ok', 'data' => $data];
    }

    /**
     * 大图处理前临时放宽内存上限（128M 下 1000 万像素以上必然失败）
     */
    protected static function boostMemory(int $width, int $height): void
    {
        $pixels = max(0, $width) * max(0, $height);
        if ($pixels < 8000000) {
            return;
        }

        $current = self::memoryLimitBytes();
        // 单张图大致需要 源图 + 目标图 ≈ 像素 × 4 × 2 字节，再留 2 倍余量
        $need = (int)ceil($pixels * 4 * 2 * 2);
        if ($need <= $current) {
            return;
        }

        $target = min(1024 * 1024 * 1024, max($need, $current));
        @ini_set('memory_limit', (string)$target);
    }

    /**
     * 当前 memory_limit（字节，-1 视为无限）
     */
    protected static function memoryLimitBytes(): int
    {
        $raw = trim((string)ini_get('memory_limit'));
        if ($raw === '' || $raw === '-1') {
            return PHP_INT_MAX;
        }

        $unit = strtolower(substr($raw, -1));
        $num  = (float)$raw;
        switch ($unit) {
            case 'g':
                $num *= 1024 * 1024 * 1024;
                break;
            case 'm':
                $num *= 1024 * 1024;
                break;
            case 'k':
                $num *= 1024;
                break;
        }

        return (int)$num;
    }

    /**
     * 转 WebP（生成同名 .webp 文件）
     *
     * @return string|null 相对路径
     */
    public static function toWebp(string $absFile, string $relFile): ?string
    {
        if (!function_exists('imagewebp')) {
            return null;
        }

        $img = self::open($absFile);
        if (!$img) {
            return null;
        }

        $target = preg_replace('/\.[a-zA-Z0-9]+$/', '.webp', $absFile);
        $quality = (int)config('tw.image.webp_quality', 78);
        $ok = @imagewebp($img, $target, $quality);
        imagedestroy($img);

        if (!$ok || !is_file($target)) {
            return null;
        }

        return preg_replace('/\.[a-zA-Z0-9]+$/', '.webp', $relFile);
    }

    /**
     * 生成多尺寸（WebP 优先，原图为 GIF 时跳过）
     */
    public static function makeSizes(string $absFile, string $relFile): array
    {
        $sizes = (array)config('tw.image.sizes', []);
        if (!$sizes) {
            return [];
        }

        $info = @getimagesize($absFile);
        if (!$info) {
            return [];
        }
        $srcW = (int)$info[0];
        self::boostMemory($srcW, (int)$info[1]);
        $results = [];
        $dir = dirname($absFile);

        foreach ($sizes as $key => $width) {
            $width = (int)$width;
            if ($width <= 0 || $srcW <= $width) {
                continue;
            }

            $base   = pathinfo($absFile, PATHINFO_FILENAME);
            $target = $dir . DIRECTORY_SEPARATOR . $base . '-' . $width . '.webp';
            if (is_file($target) && (int)filesize($target) < (int)filesize($absFile)) {
                $results[$key] = $target;
                continue;
            }

            $src = self::open($absFile);
            if (!$src) {
                continue;
            }
            $height = max(1, (int)round($info[1] * $width / max(1, $srcW)));
            $dst    = imagecreatetruecolor($width, $height);
            if (!$dst) {
                imagedestroy($src);
                continue;
            }
            imagealphablending($dst, false);
            imagesavealpha($dst, true);
            imagecopyresampled($dst, $src, 0, 0, 0, 0, $width, $height, $srcW, (int)$info[1]);

            $ok = function_exists('imagewebp')
                ? @imagewebp($dst, $target, (int)config('tw.image.webp_quality', 78))
                : @imagejpeg($dst, $target, (int)config('tw.image.quality', 82));

            imagedestroy($dst);
            imagedestroy($src);

            if ($ok) {
                $results[$key] = $target;
            }
        }

        return $results;
    }

    /**
     * 打开图片资源
     *
     * @return resource|\GdImage|false
     */
    protected static function open(string $file)
    {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        switch ($ext) {
            case 'jpg':
            case 'jpeg':
                return function_exists('imagecreatefromjpeg') ? @imagecreatefromjpeg($file) : false;
            case 'png':
                return function_exists('imagecreatefrompng') ? @imagecreatefrompng($file) : false;
            case 'gif':
                return function_exists('imagecreatefromgif') ? @imagecreatefromgif($file) : false;
            case 'webp':
                return function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($file) : false;
            case 'bmp':
                return function_exists('imagecreatefrombmp') ? @imagecreatefrombmp($file) : false;
        }

        return false;
    }

    /**
     * 取图片的 WebP 访问地址，没有则回退原图
     */
    public static function webpUrl(?string $url): string
    {
        $url = (string)$url;
        if ($url === '' || !preg_match('/\.(jpg|jpeg|png|bmp)$/i', $url)) {
            return $url;
        }

        $candidate = preg_replace('/\.[a-zA-Z0-9]+$/', '.webp', $url);
        $abs = public_path() . ltrim($candidate, '/');
        if (is_file($abs)) {
            return $candidate;
        }

        return $url;
    }
}
