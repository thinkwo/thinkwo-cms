<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * URL 生成器
 *
 * 统一的地址规则（改这里就等于全站改规则）：
 *   首页       /                       /en/
 *   栏目列表   /products/              /en/products/
 *   列表分页   /products/page/2        /en/products/page/2
 *   单页       /about.html             /en/about.html
 *   内容详情   /products/abc.html      /en/products/abc.html
 *   搜索       /search?kw=xxx          /en/search?kw=xxx
 *   询盘页     /message                /en/message
 */
class TwUrl
{
    /**
     * 语言前缀
     */
    protected static function pre(?string $code = null): string
    {
        return '/' . Lang::prefix($code);
    }

    /**
     * 首页
     */
    public static function home(?string $code = null): string
    {
        return self::pre($code);
    }

    /**
     * 栏目地址
     *
     * @param array|string $sort 栏目数组或 slug
     */
    public static function sort($sort, int $page = 1, ?string $code = null): string
    {
        $slug = is_array($sort) ? (string)($sort['slug'] ?? '') : (string)$sort;
        $type = is_array($sort) ? (string)($sort['type'] ?? 'list') : 'list';
        $base = self::pre($code) . $slug;

        if ($type === 'page') {
            return $base . '.html';
        }

        if ($page > 1) {
            return $base . '/page/' . $page;
        }

        return $base . '/';
    }

    /**
     * 内容详情地址
     */
    public static function detail(array $content, ?array $sort = null, ?string $code = null): string
    {
        $sortSlug = '';
        if ($sort !== null) {
            $sortSlug = (string)($sort['slug'] ?? '');
        } elseif (!empty($content['sort_slug'])) {
            $sortSlug = (string)$content['sort_slug'];
        }

        $slug = (string)($content['slug'] ?? '');
        if ($slug === '') {
            $slug = (string)($content['id'] ?? '0');
        }

        return self::pre($code) . ($sortSlug !== '' ? $sortSlug . '/' : '') . $slug . '.html';
    }

    /**
     * 搜索
     */
    public static function search(string $keyword = '', ?string $code = null): string
    {
        $url = self::pre($code) . 'search';

        return $keyword === '' ? $url : $url . '?kw=' . rawurlencode($keyword);
    }

    /**
     * 询盘 / 联系页
     */
    public static function message(?string $code = null): string
    {
        return self::pre($code) . 'message';
    }

    /**
     * sitemap 索引
     */
    public static function sitemap(): string
    {
        return '/sitemap.xml';
    }

    /**
     * 指定语言的 sitemap
     */
    public static function sitemapLang(string $code): string
    {
        return '/sitemap-' . $code . '.xml';
    }

    /**
     * 切换语言后的同一页面地址
     *
     * @param string $code 目标语言
     */
    public static function switchLang(string $code): string
    {
        $path = '/' . ltrim((string)request()->pathinfo(), '/');
        $def  = Lang::defaultCode();
        $cur  = Lang::code();

        // 去掉当前语言前缀
        if ($cur !== $def && str_starts_with($path, '/' . $cur . '/')) {
            $path = substr($path, strlen($cur) + 1);
        } elseif ($path === '/' . $cur) {
            $path = '/';
        }

        if ($code === $def) {
            return $path === '' ? '/' : $path;
        }

        return '/' . $code . ($path === '/' ? '/' : $path);
    }

    /**
     * 通用构建入口（供 tw_url() 使用）
     *
     * 支持的 name：
     *   ''/'home'  首页
     *   'sort'     栏目  params: sort(slug|array), page
     *   'detail'   详情  params: content(array), sort(array)
     *   'search'   搜索  params: kw
     *   'message'  询盘页
     */
    public static function build(string $name = '', array $params = []): string
    {
        switch ($name) {
            case '':
            case 'home':
                return self::home();
            case 'sort':
                return self::sort($params['sort'] ?? '', (int)($params['page'] ?? 1));
            case 'detail':
                return self::detail((array)($params['content'] ?? []), $params['sort'] ?? null);
            case 'search':
                return self::search((string)($params['kw'] ?? ''));
            case 'message':
                return self::message();
        }

        return '/' . ltrim($name, '/');
    }
}
