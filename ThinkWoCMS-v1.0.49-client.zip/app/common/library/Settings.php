<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Cache;
use think\facade\Db;

/**
 * 站点设置（tw_setting 表）
 *
 * 全部设置一次性读入内存，单次请求内只查一次库；
 * 跨请求通过文件缓存加速，后台保存时主动清理。
 */
class Settings
{
    /**
     * 当前请求内的设置缓存
     */
    protected static ?array $data = null;

    /**
     * 缓存键
     */
    protected const CACHE_KEY = 'tw_settings_all';

    /**
     * 读取全部设置
     */
    public static function all(): array
    {
        if (self::$data !== null) {
            return self::$data;
        }

        $data = null;
        try {
            $data = Cache::get(self::CACHE_KEY);
        } catch (\Throwable $e) {
            $data = null;
        }

        if (!is_array($data)) {
            $data = [];
            try {
                $rows = Db::name('setting')->select()->toArray();
                foreach ($rows as $row) {
                    $data[(string)$row['skey']] = (string)$row['svalue'];
                }
            } catch (\Throwable $e) {
                $data = [];
            }
            try {
                Cache::set(self::CACHE_KEY, $data, 3600);
            } catch (\Throwable $e) {
                // 忽略缓存写入失败
            }
        }

        self::$data = $data;

        return $data;
    }

    /**
     * 读取单个设置项
     */
    public static function get(string $key, $default = null)
    {
        $all = self::all();
        if (!array_key_exists($key, $all)) {
            return $default;
        }
        $value = $all[$key];

        return $value === '' ? $default : $value;
    }

    /**
     * 读取布尔值设置
     */
    public static function bool(string $key, bool $default = false): bool
    {
        $value = self::get($key);
        if ($value === null) {
            return $default;
        }

        return in_array(strtolower((string)$value), ['1', 'true', 'on', 'yes'], true);
    }

    /**
     * 写入单个设置项
     */
    public static function set(string $key, $value, string $group = 'base'): void
    {
        $value = is_array($value) ? json_encode($value, JSON_UNESCAPED_UNICODE) : (string)$value;

        $exists = Db::name('setting')->where('skey', $key)->find();
        if ($exists) {
            Db::name('setting')->where('skey', $key)->update(['svalue' => $value]);
        } else {
            Db::name('setting')->insert(['skey' => $key, 'svalue' => $value, 'sgroup' => $group]);
        }

        self::flush();
    }

    /**
     * 批量写入
     */
    public static function saveMany(array $pairs, string $group = 'base'): void
    {
        foreach ($pairs as $key => $value) {
            $value = is_array($value) ? json_encode($value, JSON_UNESCAPED_UNICODE) : (string)$value;

            $exists = Db::name('setting')->where('skey', $key)->find();
            if ($exists) {
                Db::name('setting')->where('skey', $key)->update(['svalue' => $value]);
            } else {
                Db::name('setting')->insert(['skey' => $key, 'svalue' => $value, 'sgroup' => $group]);
            }
        }

        self::flush();
    }

    /**
     * 清理缓存
     */
    public static function flush(): void
    {
        self::$data = null;
        try {
            Cache::delete(self::CACHE_KEY);
        } catch (\Throwable $e) {
            // 忽略
        }
    }

    /**
     * 按分组取设置
     */
    public static function group(string $group): array
    {
        $result = [];
        try {
            $rows = Db::name('setting')->where('sgroup', $group)->select()->toArray();
            foreach ($rows as $row) {
                $result[(string)$row['skey']] = (string)$row['svalue'];
            }
        } catch (\Throwable $e) {
            $result = [];
        }

        return $result;
    }
}
