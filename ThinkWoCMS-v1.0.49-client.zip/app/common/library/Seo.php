<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * SEO 输出中枢
 *
 * 全站所有 <head> 里的 SEO 相关内容都由这里统一生成：
 * title / description / keywords / canonical / robots /
 * hreflang 多语言互指 / Open Graph / Twitter Card / JSON-LD 结构化数据
 */
class Seo
{
    protected static array $meta = [];

    /**
     * 重置（每次请求开始时调用）
     */
    public static function reset(): void
    {
        self::$meta = [
            'title'       => '',
            'description' => '',
            'keywords'    => '',
            'canonical'   => '',
            'robots'      => 'index,follow',
            'og_type'     => 'website',
            'og_image'    => '',
            'alternates'  => [],
            'jsonld'      => [],
            'head'        => [],
        ];
    }

    /**
     * 批量设置
     */
    public static function set(array $meta): void
    {
        if (!self::$meta) {
            self::reset();
        }
        self::$meta = array_merge(self::$meta, $meta);
    }

    /**
     * 读取
     */
    public static function get(string $key, $default = null)
    {
        if (!self::$meta) {
            self::reset();
        }

        return self::$meta[$key] ?? $default;
    }

    /**
     * 设置标题（会自动套用后台设置的标题格式）
     */
    public static function title(string $title): void
    {
        if (!self::$meta) {
            self::reset();
        }
        self::$meta['title'] = $title;
    }

    /**
     * 追加 hreflang 备用地址
     *
     * @param array $map code => 相对路径或完整 URL
     */
    public static function alternates(array $map): void
    {
        if (!self::$meta) {
            self::reset();
        }
        foreach ($map as $code => $url) {
            if ((string)$url === '') {
                continue;
            }
            self::$meta['alternates'][(string)$code] = self::abs((string)$url);
        }
    }

    /**
     * 追加结构化数据
     */
    public static function jsonld(array $data): void
    {
        if (!self::$meta) {
            self::reset();
        }
        if ($data) {
            self::$meta['jsonld'][] = $data;
        }
    }

    /**
     * 追加 head 原始 HTML（插件用）
     */
    public static function head(string $html): void
    {
        if (!self::$meta) {
            self::reset();
        }
        if (trim($html) !== '') {
            self::$meta['head'][] = $html;
        }
    }

    /**
     * 相对路径转绝对地址
     */
    public static function abs(string $url): string
    {
        if ($url === '') {
            return '';
        }
        if (preg_match('#^https?://#i', $url)) {
            return $url;
        }

        $domain = (string)Settings::get('site_domain', '');
        if ($domain === '') {
            $domain = rtrim((string)request()->domain(), '/');
        }

        return rtrim($domain, '/') . '/' . ltrim($url, '/');
    }

    /**
     * 当前页面地址（不含查询串）
     */
    public static function currentUrl(): string
    {
        return self::abs('/' . ltrim((string)request()->pathinfo(), '/'));
    }

    /**
     * 组织信息结构化数据
     */
    public static function organization(): array
    {
        $data = [
            '@context' => 'https://schema.org',
            '@type'    => 'Organization',
            'name'     => (string)Settings::get('company', Settings::get('site_name', '')),
            'url'      => self::abs('/'),
        ];

        $logo = (string)Settings::get('logo', '');
        if ($logo !== '') {
            $data['logo'] = self::abs($logo);
        }

        $sameAs = [];
        foreach (['social_facebook', 'social_twitter', 'social_linkedin', 'social_youtube', 'social_instagram'] as $key) {
            $v = (string)Settings::get($key, '');
            if ($v !== '') {
                $sameAs[] = $v;
            }
        }
        if ($sameAs) {
            $data['sameAs'] = $sameAs;
        }

        $contact = array_filter([
            'telephone' => (string)Settings::get('phone', ''),
            'email'     => (string)Settings::get('email', ''),
        ]);
        if ($contact) {
            $data['contactPoint'] = array_merge([
                '@type'             => 'ContactPoint',
                'contactType'       => 'sales',
                'availableLanguage' => array_values(array_map(static fn ($l) => $l['code'], Lang::all())),
            ], $contact);
        }

        $address = (string)Settings::get('address', '');
        if ($address !== '') {
            $data['address'] = [
                '@type'           => 'PostalAddress',
                'streetAddress'   => $address,
                'addressCountry'  => (string)Settings::get('country', ''),
            ];
        }

        return $data;
    }

    /**
     * 站点搜索框结构化数据
     */
    public static function website(): array
    {
        return [
            '@context'        => 'https://schema.org',
            '@type'           => 'WebSite',
            'name'            => (string)Settings::get('site_name', ''),
            'url'             => self::abs('/'),
            'inLanguage'      => Lang::code(),
            'potentialAction' => [
                '@type'       => 'SearchAction',
                'target'      => self::abs(TwUrl::search() . '?kw={search_term_string}'),
                'query-input' => 'required name=search_term_string',
            ],
        ];
    }

    /**
     * 面包屑结构化数据
     *
     * @param array $items [['name'=>'Home','url'=>'/'], ...]
     */
    public static function breadcrumb(array $items): array
    {
        $list = [];
        $i    = 1;
        foreach ($items as $item) {
            $list[] = [
                '@type'    => 'ListItem',
                'position' => $i++,
                'name'     => (string)$item['name'],
                'item'     => self::abs((string)$item['url']),
            ];
        }

        return [
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => $list,
        ];
    }

    /**
     * 产品结构化数据
     */
    public static function product(array $content, array $extra = []): array
    {
        $data = [
            '@context'    => 'https://schema.org',
            '@type'       => 'Product',
            'name'        => (string)$content['title'],
            'description' => tw_cut((string)($content['seo_description'] ?: $content['summary'] ?: $content['content']), 300),
            'url'         => self::abs(TwUrl::detail($content)),
            'sku'         => (string)($content['model_no'] ?: $content['id']),
            'brand'       => [
                '@type' => 'Brand',
                'name'  => (string)Settings::get('site_name', ''),
            ],
        ];

        if (!empty($content['ico'])) {
            $data['image'] = [self::abs((string)$content['ico'])];
        }

        $price = (float)($content['price'] ?? 0);
        if ($price > 0) {
            $data['offers'] = [
                '@type'         => 'Offer',
                'price'         => number_format($price, 2, '.', ''),
                'priceCurrency' => (string)Settings::get('currency', 'USD'),
                'availability'  => 'https://schema.org/InStock',
                'url'           => self::abs(TwUrl::detail($content)),
                'seller'        => ['@type' => 'Organization', 'name' => (string)Settings::get('site_name', '')],
            ];
        }

        return array_merge($data, $extra);
    }

    /**
     * 文章结构化数据
     */
    public static function article(array $content): array
    {
        $data = [
            '@context'      => 'https://schema.org',
            '@type'         => 'Article',
            'headline'      => tw_cut((string)$content['title'], 110),
            'description'   => tw_cut((string)($content['seo_description'] ?: $content['summary']), 300),
            'datePublished' => date('c', (int)($content['publish_time'] ?: $content['createtime'])),
            'dateModified'  => date('c', (int)($content['updatetime'] ?: $content['createtime'])),
            'inLanguage'    => (string)$content['lang'],
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id'   => self::abs(TwUrl::detail($content)),
            ],
            'publisher'     => [
                '@type' => 'Organization',
                'name'  => (string)Settings::get('site_name', ''),
            ],
        ];

        if (!empty($content['ico'])) {
            $data['image'] = [self::abs((string)$content['ico'])];
        }
        if (!empty($content['author'])) {
            $data['author'] = ['@type' => 'Person', 'name' => (string)$content['author']];
        }

        return $data;
    }

    /**
     * FAQ 结构化数据
     *
     * @param array $qas [['q'=>'问题','a'=>'答案'], ...]
     */
    public static function faq(array $qas): array
    {
        $items = [];
        foreach ($qas as $qa) {
            $q = trim((string)($qa['q'] ?? ''));
            $a = trim((string)($qa['a'] ?? ''));
            if ($q === '' || $a === '') {
                continue;
            }
            $items[] = [
                '@type'          => 'Question',
                'name'           => $q,
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => $a],
            ];
        }

        return [
            '@context'   => 'https://schema.org',
            '@type'      => 'FAQPage',
            'mainEntity' => $items,
        ];
    }

    /**
     * 输出全部 SEO 头部标签
     */
    public static function render(): string
    {
        if (!self::$meta) {
            self::reset();
        }

        $siteName = (string)Settings::get('site_name', '');
        $title    = trim((string)self::$meta['title']);
        if ($title === '') {
            $title = (string)Settings::get('site_title', $siteName);
        } elseif ($siteName !== '' && $title !== $siteName) {
            $format = (string)Settings::get('seo_title_format', '{title} | {site_name}');
            $title  = str_replace(['{title}', '{site_name}'], [$title, $siteName], $format);
        }
        // 最后一层兜底：设置表为空（新装还没配置）时也不能出现空 title
        if (trim($title) === '') {
            $title = $siteName !== '' ? $siteName : 'ThinkWo CMS';
        }

        $desc = trim((string)self::$meta['description']);
        if ($desc === '') {
            $desc = (string)Settings::get('site_description', '');
        }
        $desc = tw_cut($desc, 300);

        $out   = [];
        $out[] = '<title>' . tw_e($title) . '</title>';
        if ($desc !== '') {
            $out[] = '<meta name="description" content="' . tw_e($desc) . '">';
        }
        $keywords = trim((string)self::$meta['keywords']);
        if ($keywords === '') {
            $keywords = (string)Settings::get('site_keywords', '');
        }
        if ($keywords !== '') {
            $out[] = '<meta name="keywords" content="' . tw_e($keywords) . '">';
        }

        $canonical = (string)self::$meta['canonical'];
        $out[]     = '<link rel="canonical" href="' . tw_e($canonical !== '' ? self::abs($canonical) : self::currentUrl()) . '">';

        $robots = (string)self::$meta['robots'];
        if ($robots !== '') {
            $out[] = '<meta name="robots" content="' . tw_e($robots) . '">';
        }

        // hreflang：只有多语言时才输出，且必须包含自身
        $alts = (array)self::$meta['alternates'];
        if (count(Lang::all()) > 1) {
            $alts[Lang::code()] = self::currentUrl();
            foreach (Lang::all() as $code => $lang) {
                if (!isset($alts[$code])) {
                    continue;
                }
                $region = (string)($lang['region'] ?? $code);
                $out[]  = '<link rel="alternate" hreflang="' . tw_e($region !== '' ? $region : $code) . '" href="' . tw_e($alts[$code]) . '">';
            }
            $defaultCode = Lang::defaultCode();
            if (isset($alts[$defaultCode])) {
                $out[] = '<link rel="alternate" hreflang="x-default" href="' . tw_e($alts[$defaultCode]) . '">';
            }
        }

        // Open Graph
        $out[] = '<meta property="og:type" content="' . tw_e((string)self::$meta['og_type']) . '">';
        $out[] = '<meta property="og:title" content="' . tw_e($title) . '">';
        if ($desc !== '') {
            $out[] = '<meta property="og:description" content="' . tw_e($desc) . '">';
        }
        $out[] = '<meta property="og:url" content="' . tw_e(self::currentUrl()) . '">';
        $out[] = '<meta property="og:site_name" content="' . tw_e($siteName) . '">';
        $out[] = '<meta property="og:locale" content="' . tw_e(str_replace('-', '_', Lang::region())) . '">';

        $ogImage = (string)self::$meta['og_image'];
        if ($ogImage === '') {
            $ogImage = (string)Settings::get('og_image', '');
        }
        if ($ogImage !== '') {
            $out[] = '<meta property="og:image" content="' . tw_e(self::abs($ogImage)) . '">';
        }

        $out[] = '<meta name="twitter:card" content="summary_large_image">';
        $out[] = '<meta name="twitter:title" content="' . tw_e($title) . '">';
        if ($desc !== '') {
            $out[] = '<meta name="twitter:description" content="' . tw_e($desc) . '">';
        }

        // JSON-LD
        foreach ((array)self::$meta['jsonld'] as $data) {
            $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json !== false) {
                $out[] = '<script type="application/ld+json">' . $json . '</script>';
            }
        }

        // 插件注入
        foreach (Plugin::run('head') as $html) {
            if (is_string($html) && $html !== '') {
                $out[] = $html;
            }
        }

        foreach ((array)self::$meta['head'] as $html) {
            $out[] = $html;
        }

        return implode("\n", $out);
    }
}
