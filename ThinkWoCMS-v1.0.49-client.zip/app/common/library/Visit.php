<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Db;

/**
 * 访客统计
 *
 * 前端 track.js 打点，记录两层数据：
 *  - tw_visit      一次访问（会话）一行：谁、从哪来、看了几页、待了多久
 *  - tw_visit_page 一次浏览一行：每页的进入时间与停留时长
 *
 * 不采集任何表单内容与个人身份信息，仅 IP / UA / 路径。
 */
class Visit
{
    /** 在线判定：最后活动时间在多少秒内 */
    public const ONLINE_GAP = 300;

    /**
     * 是否开启统计
     */
    public static function enabled(): bool
    {
        return (string)Settings::get('visit_enable', '1') === '1';
    }

    /**
     * 处理前端打点
     *
     * @param array  $in 前端上报数据
     * @param string $ip 访客 IP
     * @param string $ua User-Agent
     */
    public static function record(array $in, string $ip, string $ua): void
    {
        if (!self::enabled()) {
            return;
        }

        $type = (string)($in['t'] ?? 'pv');
        $sid  = self::token((string)($in['sid'] ?? ''));
        $vid  = self::token((string)($in['vid'] ?? ''));
        if ($sid === '') {
            return;
        }

        // 爬虫不记账（Google / Bing / 各种 SEO 工具），避免污染数据
        if (self::isBot($ua)) {
            return;
        }

        $url = self::cleanPath((string)($in['url'] ?? ''));
        if ($url === '') {
            return;
        }

        $now = time();

        if ($type === 'pv') {
            self::onPageview($sid, $vid, $ip, $ua, $url, (string)($in['title'] ?? ''), (string)($in['ref'] ?? ''), $now);
        } else {
            self::onLeave($sid, $url, (int)($in['dur'] ?? 0), $now);
        }
    }

    /**
     * 新页面浏览：找会话（没有就新建），写一条浏览明细
     */
    protected static function onPageview(string $sid, string $vid, string $ip, string $ua, string $url, string $title, string $ref, int $now): void
    {
        try {
            $visit = Db::name('visit')->where('sid', $sid)->find();
        } catch (\Throwable $e) {
            return;
        }

        $uaInfo = self::parseUa($ua);

        if (!$visit) {
            $refHost = self::hostOf($ref);
            $data = [
                'sid'        => $sid,
                'vid'        => $vid,
                'ip'         => mb_substr($ip, 0, 45),
                'ua'         => mb_substr($ua, 0, 500),
                'device'     => $uaInfo['device'],
                'browser'    => $uaInfo['browser'],
                'os'         => $uaInfo['os'],
                'lang'       => mb_substr(Lang::code(), 0, 10),
                'referer'    => mb_substr($ref, 0, 500),
                'ref_host'   => mb_substr($refHost, 0, 120),
                'landing'    => mb_substr($url, 0, 500),
                'pages'      => 1,
                'duration'   => 0,
                'last_url'   => mb_substr($url, 0, 500),
                'first_time' => $now,
                'last_time'  => $now,
            ];
            try {
                $id = (int)Db::name('visit')->insertGetId($data);
            } catch (\Throwable $e) {
                // 并发下唯一键冲突：回查一次
                try {
                    $row = Db::name('visit')->where('sid', $sid)->find();
                    $id  = (int)($row['id'] ?? 0);
                } catch (\Throwable $ignore) {
                    return;
                }
            }
            $visit = array_merge($data, ['id' => $id]);
        } else {
            // 同一会话换了 IP（切网络）不更新；只刷新最后活动与最后页面
            try {
                Db::name('visit')->where('id', $visit['id'])->update([
                    'pages'     => (int)$visit['pages'] + 1,
                    'last_url'  => mb_substr($url, 0, 500),
                    'last_time' => $now,
                ]);
            } catch (\Throwable $e) {
                return;
            }
        }

        if (!$visit) {
            return;
        }

        try {
            Db::name('visit_page')->insert([
                'visit_id'   => (int)$visit['id'],
                'sid'        => $sid,
                'vid'        => $vid,
                'url'        => mb_substr($url, 0, 500),
                'title'      => mb_substr($title, 0, 255),
                'referer'    => mb_substr($ref, 0, 500),
                'enter_time' => $now,
                'leave_time' => 0,
                'duration'   => 0,
            ]);
        } catch (\Throwable $e) {
            // 忽略
        }

        // 偶发清理过期数据（约 2% 概率触发，避免每次请求都扫表）
        if (random_int(1, 50) === 1) {
            self::cleanup();
        }
    }

    /**
     * 离开/心跳：更新本页停留时长与会话总时长
     */
    protected static function onLeave(string $sid, string $url, int $dur, int $now): void
    {
        $dur = max(0, min(86400, $dur));
        if ($dur <= 0) {
            return;
        }

        try {
            $visit = Db::name('visit')->where('sid', $sid)->find();
            if (!$visit) {
                return;
            }

            // 只更新本会话里该页最近一次浏览
            $page = Db::name('visit_page')
                ->where('sid', $sid)
                ->where('url', $url)
                ->order('id desc')
                ->find();

            if ($page) {
                if ($dur > (int)$page['duration']) {
                    Db::name('visit_page')->where('id', $page['id'])->update([
                        'duration'   => $dur,
                        'leave_time' => $now,
                    ]);
                } else {
                    Db::name('visit_page')->where('id', $page['id'])->update(['leave_time' => $now]);
                }
            }

            // 会话总时长 = 各页停留之和（同一页重复看只算最长那次，避免刷新翻倍）
            $sum = (int)Db::name('visit_page')->where('visit_id', $visit['id'])->sum('duration');

            Db::name('visit')->where('id', $visit['id'])->update([
                'duration'  => $sum,
                'last_time' => $now,
            ]);
        } catch (\Throwable $e) {
            // 忽略
        }
    }

    /**
     * 清理超过保留天数的数据
     */
    public static function cleanup(?int $days = null): int
    {
        $days = $days ?? (int)Settings::get('visit_keep_days', '90');
        if ($days <= 0) {
            return 0;
        }

        $before = strtotime('-' . $days . ' days');
        $count  = 0;

        try {
            $ids = Db::name('visit')->where('last_time', '<', $before)->column('id');
            if ($ids) {
                $count = Db::name('visit')->whereIn('id', $ids)->delete();
                Db::name('visit_page')->whereIn('visit_id', $ids)->delete();
            }
        } catch (\Throwable $e) {
            return $count;
        }

        return $count;
    }

    /**
     * 概览数字
     *
     * @return array{today_uv:int,today_pv:int,online:int,avg_duration:int}
     */
    public static function overview(): array
    {
        $today = strtotime('today');
        $out   = ['today_uv' => 0, 'today_pv' => 0, 'online' => 0, 'avg_duration' => 0];

        try {
            $out['today_uv'] = (int)Db::name('visit')->where('first_time', '>=', $today)->count();
            $out['today_pv'] = (int)Db::name('visit_page')->where('enter_time', '>=', $today)->count();
            $out['online']   = (int)Db::name('visit')->where('last_time', '>=', time() - self::ONLINE_GAP)->count();

            $avg = Db::name('visit')->where('first_time', '>=', $today)->where('duration', '>', 0)->avg('duration');
            $out['avg_duration'] = (int)round((float)$avg);
        } catch (\Throwable $e) {
            // 表还没建好时返回 0
        }

        return $out;
    }

    /**
     * 实时面板数据（控制台首页首屏渲染 + 轮询接口共用同一份结构）
     *
     * 返回：在线人数、今日访客/浏览、近 10 分钟浏览、今日平均停留、最近浏览流水。
     * 任何一步查询失败都只降级为空数据，绝不让后台页面报错。
     *
     * @return array<string,mixed>
     */
    public static function live(int $limit = 10): array
    {
        $limit = max(1, min(50, $limit));
        $now   = time();
        $today = strtotime('today');

        $out = [
            'enabled'   => self::enabled(),
            'online'    => 0,
            'today_uv'  => 0,
            'today_pv'  => 0,
            'recent_pv' => 0,
            'avg_txt'   => '—',
            'items'     => [],
        ];

        try {
            $out['online']    = (int)Db::name('visit')->where('last_time', '>=', $now - self::ONLINE_GAP)->count();
            $out['today_uv']  = (int)Db::name('visit')->where('first_time', '>=', $today)->count();
            $out['today_pv']  = (int)Db::name('visit_page')->where('enter_time', '>=', $today)->count();
            $out['recent_pv'] = (int)Db::name('visit_page')->where('enter_time', '>=', $now - 600)->count();

            $avg = Db::name('visit')->where('first_time', '>=', $today)->where('duration', '>', 0)->avg('duration');
            $out['avg_txt'] = self::humanDuration((int)round((float)$avg));
        } catch (\Throwable $e) {
            return $out;
        }

        // 最近浏览流水：先取页面明细，再批量补会话信息（两次小查询，避免 join 的前缀坑）
        $pages = [];
        try {
            $pages = Db::name('visit_page')
                ->field('id,visit_id,sid,vid,url,title,enter_time,duration')
                ->order('id desc')
                ->limit($limit)
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            return $out;
        }

        if (!$pages) {
            return $out;
        }

        $ids   = array_values(array_unique(array_map(static fn($p) => (int)$p['visit_id'], $pages)));
        $sess  = [];
        try {
            foreach (Db::name('visit')->whereIn('id', $ids)->select()->toArray() as $v) {
                $sess[(int)$v['id']] = $v;
            }
        } catch (\Throwable $e) {
            $sess = [];
        }

        $deviceMap = ['mobile' => '手机', 'tablet' => '平板', 'desktop' => '电脑'];

        foreach ($pages as $p) {
            $vid   = (int)$p['visit_id'];
            $v     = $sess[$vid] ?? [];
            $enter = (int)$p['enter_time'];
            $last  = (int)($v['last_time'] ?? $enter);

            $path = (string)$p['url'];
            $title = trim((string)$p['title']);

            $refHost = (string)($v['ref_host'] ?? '');
            $out['items'][] = [
                'visit_id' => $vid,
                'time'     => date('H:i:s', $enter),
                'rel'      => self::humanTime($enter),
                'title'    => $title !== '' ? $title : $path,
                'path'     => $path,
                'ip'       => (string)($v['ip'] ?? ''),
                'device'   => $deviceMap[(string)($v['device'] ?? '')] ?? '未知',
                'browser'  => (string)($v['browser'] ?? ''),
                'os'       => (string)($v['os'] ?? ''),
                'ref'      => $refHost !== '' ? $refHost : '直接访问',
                'ref_host' => $refHost,
                'pages'    => (int)($v['pages'] ?? 1),
                'duration' => self::humanDuration((int)$p['duration']),
                'online'   => $last >= $now - self::ONLINE_GAP ? 1 : 0,
                'fresh'    => $enter >= $now - 60 ? 1 : 0,
                'lang'     => (string)($v['lang'] ?? ''),
                'vid'      => substr((string)($p['vid'] ?? ''), 0, 6),
            ];
        }

        return $out;
    }

    /**
     * 解析 UA（只用关键词匹配，够用且不引依赖）
     *
     * @return array{device:string,browser:string,os:string}
     */
    public static function parseUa(string $ua): array
    {
        $device = 'desktop';
        if (preg_match('/iPad|Tablet|PlayBook|Silk/i', $ua)) {
            $device = 'tablet';
        } elseif (preg_match('/Mobile|Android|iPhone|iPod|Windows Phone|BlackBerry/i', $ua)) {
            $device = 'mobile';
        }

        $browser = 'Other';
        foreach ([
            'Edg'      => 'Edge',
            'OPR'      => 'Opera',
            'SamsungBrowser' => 'Samsung',
            'UCBrowser' => 'UC',
            'Firefox'  => 'Firefox',
            'Chrome'   => 'Chrome',
            'Safari'   => 'Safari',
            'MSIE'     => 'IE',
            'Trident'  => 'IE',
        ] as $needle => $name) {
            if (stripos($ua, $needle) !== false) {
                $browser = $name;
                break;
            }
        }

        $os = 'Other';
        foreach ([
            'Windows NT' => 'Windows',
            'iPhone'     => 'iOS',
            'iPad'       => 'iPadOS',
            'Mac OS X'   => 'macOS',
            'Android'    => 'Android',
            'Linux'      => 'Linux',
        ] as $needle => $name) {
            if (stripos($ua, $needle) !== false) {
                $os = $name;
                break;
            }
        }

        return ['device' => $device, 'browser' => $browser, 'os' => $os];
    }

    /**
     * 是否爬虫
     */
    public static function isBot(string $ua): bool
    {
        if ($ua === '') {
            return true;
        }

        return (bool)preg_match(
            '/bot|crawl|spider|slurp|bingpreview|facebookexternalhit|embedly|quora link preview|'
            . 'pinterest|vkshare|headless|python-requests|curl|wget|go-http-client|ahrefs|semrush|'
            . 'mj12|dotbot|petalbot|yandex|baiduspider|sogou|bytespider|uptime|pingdom|ltx71/i',
            $ua
        );
    }

    /**
     * 只保留站内路径，去掉域名 / 查询参数中的敏感项
     */
    public static function cleanPath(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        // 兼容传完整 URL 的情况
        if (preg_match('#^https?://[^/]+(/.*)?$#i', $url, $m)) {
            $url = $m[1] ?? '/';
        }

        $url = strtok($url, '#') ?: $url;
        $url = mb_substr($url, 0, 500);

        return $url === '' ? '/' : $url;
    }

    /**
     * 来源域名
     */
    public static function hostOf(string $ref): string
    {
        $host = parse_url($ref, PHP_URL_HOST);

        return is_string($host) ? strtolower($host) : '';
    }

    /**
     * 会话/访客 ID 只接受十六进制串，防止注入与脏数据
     */
    protected static function token(string $value): string
    {
        $value = strtolower(trim($value));
        if (!preg_match('/^[a-z0-9]{8,32}$/', $value)) {
            return '';
        }

        return $value;
    }

    /**
     * 秒数转「3分12秒」
     */
    public static function humanDuration(int $sec): string
    {
        if ($sec <= 0) {
            return '—';
        }
        if ($sec < 60) {
            return $sec . ' 秒';
        }
        $m = intdiv($sec, 60);
        $s = $sec % 60;
        if ($m < 60) {
            return $m . ' 分' . ($s > 0 ? ' ' . $s . ' 秒' : '');
        }
        $h = intdiv($m, 60);
        $m = $m % 60;

        return $h . ' 小时' . ($m > 0 ? ' ' . $m . ' 分' : '');
    }

    /**
     * 相对时间：刚刚 / 5 分钟前 / 3 小时前 / 2 天前
     */
    public static function humanTime(int $ts): string
    {
        if ($ts <= 0) {
            return '—';
        }
        $diff = time() - $ts;
        if ($diff < 60) {
            return '刚刚';
        }
        if ($diff < 3600) {
            return intdiv($diff, 60) . ' 分钟前';
        }
        if ($diff < 86400) {
            return intdiv($diff, 3600) . ' 小时前';
        }
        if ($diff < 86400 * 30) {
            return intdiv($diff, 86400) . ' 天前';
        }

        return date('Y-m-d', $ts);
    }
}
