<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * 插件在线升级（主程序内置）
 *
 * 后台「插件管理」页面直接调这里：拿授权站签名清单 → 比对本机版本 →
 * 按版本顺序逐级升级（与主程序自身升级同一规则，绝不跳版）。
 *
 * 协议沿用主程序更新的那一套：授权站下发签名清单，客户端用内置公钥验签，
 * 再用 SHA256 校验包体，解压只认 plugins/{name}/ 前缀，替换前整目录备份，
 * 任何一步失败都回滚并停在该版本。
 *
 * 不做的事：
 *  - 不新装插件（只升级本机已有的），防被塞入任意目录写文件
 *  - 不碰模板、数据库配置（插件配置在 tw_plugin.config，替换文件不影响）
 */
class PluginUpgrade
{
    /** 插件包大小上限（MB） */
    public const MAX_MB = 60;

    /** 远程清单缓存时间（秒） */
    public const CACHE_TTL = 600;

    /** 连不上授权站后的冷却时间（秒）：避免每次刷新都干等超时 */
    public const FAIL_COOL = 300;

    /** 保留最近多少个备份 */
    protected const KEEP_BACKUP = 5;

    /**
     * 检查有没有可用的解压能力
     *   zip 扩展：大多数环境都有，优先用
     *   Phar 扩展：精简 PHP 常常只留 Phar（zip 被裁掉），用 PharData 读 zip 兜底
     */
    public static function canUnzip(): bool
    {
        return class_exists('ZipArchive') || class_exists('PharData');
    }

    /* ================================================================
     * 本地信息
     * ================================================================ */

    /**
     * 本机插件清单：name => 名称/版本/是否启用/说明
     */
    public static function locals(): array
    {
        $all  = Plugin::scan();
        $on   = Plugin::enabled();
        $list = [];

        foreach ($all as $name => $m) {
            $list[(string)$name] = [
                'name'    => (string)$name,
                'title'   => (string)($m['title'] ?? $name),
                'version' => (string)($m['version'] ?? '0.0.0'),
                'desc'    => (string)($m['description'] ?? ''),
                'enabled' => isset($on[$name]),
            ];
        }

        ksort($list);

        return $list;
    }

    /**
     * 授权站与升级环境摘要（页面顶部展示用）
     */
    public static function status(): array
    {
        $st = License::state(true);

        return [
            'api'      => License::api(),
            'licensed' => (bool)($st['licensed'] ?? false),
            'edition'  => (string)($st['edition'] ?? ''),
            'reason'   => (string)($st['reason'] ?? ''),
            'unzip'    => class_exists('ZipArchive') ? 'ZipArchive' : (class_exists('PharData') ? 'PharData' : '无'),
            'writable' => is_writable(rtrim(Plugin::path(), '/\\')),
        ];
    }

    /* ================================================================
     * 远程清单
     * ================================================================ */

    /**
     * 拉取授权站插件清单（带失败冷却，避免每次进页面都卡在超时上）
     *
     * @return array{code:int,msg:string,packages?:array,at?:int,cached?:bool}
     */
    public static function remote(bool $force = false): array
    {
        self::ensureDirs();
        $failFile = self::workDir() . 'last_fail.json';

        if (!$force && is_file($failFile)) {
            $f  = json_decode((string)@file_get_contents($failFile), true);
            $at = (int)($f['at'] ?? 0);
            if ($at > 0 && time() - $at < self::FAIL_COOL) {
                $wait = (int)ceil((self::FAIL_COOL - (time() - $at)) / 60);
                return self::err('上次连授权站失败（' . (string)($f['msg'] ?? '') . '），' . $wait . ' 分钟内不再自动重试，可点「检查更新」强制重试');
            }
        }

        $res = self::remoteRaw($force);

        if (($res['code'] ?? 0) === 1) {
            @unlink($failFile);
        } else {
            @file_put_contents($failFile, (string)json_encode(['at' => time(), 'msg' => (string)($res['msg'] ?? '')], JSON_UNESCAPED_UNICODE));
        }

        return $res;
    }

    /**
     * 真正去授权站拉清单
     *
     * @return array{code:int,msg:string,packages?:array,at?:int,cached?:bool}
     */
    protected static function remoteRaw(bool $force = false): array
    {
        $api = License::api();
        if ($api === '') {
            return self::err('未配置授权站地址，请先在系统设置里填写授权域名');
        }

        self::ensureDirs();
        $cacheFile = self::workDir() . 'remote.json';

        if (!$force && is_file($cacheFile)) {
            $c = json_decode((string)@file_get_contents($cacheFile), true);
            if (is_array($c)
                && (string)($c['api'] ?? '') === $api
                && time() - (int)($c['at'] ?? 0) < self::CACHE_TTL) {
                return [
                    'code'     => 1,
                    'msg'      => 'ok',
                    'packages' => (array)($c['packages'] ?? []),
                    'at'       => (int)$c['at'],
                    'cached'   => true,
                ];
            }
        }

        $st = License::state(true);

        $plugins = [];
        foreach (self::locals() as $p) {
            $plugins[] = ['name' => $p['name'], 'version' => $p['version']];
        }

        $res = self::post($api . '/api/plugin/check', [
            'license' => (string)($st['data']['license_id'] ?? ''),
            'plugins' => (string)json_encode($plugins, JSON_UNESCAPED_UNICODE),
            'domain'  => self::host(),
            'php'     => PHP_VERSION,
        ]);

        if ($res === null) {
            return self::err('无法连接授权站（' . $api . '），请检查服务器网络或授权域名');
        }
        if ((int)($res['code'] ?? 0) !== 1) {
            return self::err((string)($res['msg'] ?? '授权站返回失败'));
        }

        $payload = (string)($res['payload'] ?? '');
        $sig     = (string)($res['sig'] ?? '');
        if ($payload === '' || $sig === '') {
            return self::err('插件清单不完整');
        }

        $data = License::verify($payload, $sig);
        if ($data === null) {
            return self::err('插件清单签名校验失败，已阻止本次检查');
        }

        $packages = array_values((array)($data['packages'] ?? []));

        // 清单里带云端状态（是否启用/是否开通/到期/价格），落成本地快照，
        // 之后前台每个请求只读快照做校验，不再连授权站
        PluginLicense::load($packages);

        @file_put_contents($cacheFile, (string)json_encode([
            'at'       => time(),
            'api'      => $api,
            'packages' => $packages,
        ], JSON_UNESCAPED_UNICODE));

        return [
            'code'     => 1,
            'msg'      => 'ok',
            'packages' => $packages,
            'at'       => time(),
            'cached'   => false,
        ];
    }

    /**
     * 把远程清单和本机版本比对，返回本机可升级的插件（含顺序升级链）
     *
     * 升级链是「从本机版本往上一级一级」的完整列表，绝不允许跳版：
     * 本机 v1.0.0、授权站有 1.0.1/1.0.2/1.0.3 => 链条就是 [1.0.1, 1.0.2, 1.0.3]。
     */
    public static function compare(array $packages): array
    {
        $locals = self::locals();
        $rows   = [];

        foreach ($packages as $p) {
            $name = (string)($p['name'] ?? '');
            if ($name === '') {
                continue;
            }

            // 本机没装：只有授权站标明「可安装」的云端插件才出现在列表里
            if (!isset($locals[$name])) {
                if (empty($p['install']) || empty($p['active']) || empty($p['authorized'])) {
                    continue;
                }
                $ver = (string)($p['version'] ?? '');
                if ($ver === '') {
                    continue;
                }
                $rows[$name] = [
                    'name'      => $name,
                    'title'     => (string)($p['title'] ?? $name),
                    'install'   => true,
                    'from'      => '',
                    'version'   => $ver,
                    'next'      => $ver,
                    'steps'     => 1,
                    'path'      => [$ver],
                    'size_text' => (string)($p['size_text'] ?? ''),
                    'changelog' => (string)($p['changelog'] ?? ''),
                    'blocked'   => '',
                    'enabled'   => false,
                    'price'     => (string)($p['price_text'] ?? ''),
                    'expire'    => (string)($p['expire_txt'] ?? ''),
                ];
                continue;
            }

            $current = $locals[$name]['version'];

            // 受限制的云端插件不下发更新提示：授权端停用 / 本站未开通 / 已到期，
            // 升级也会被拒，这里先拦住，避免客户点了才报错。
            // （老授权站不带这些字段时按不受限处理，保持兼容）
            if ((array_key_exists('active', $p) && empty($p['active']))
                || (array_key_exists('authorized', $p) && empty($p['authorized']))
                || !empty($p['expired'])) {
                continue;
            }

            $chain = self::chainOf($p, $current);

            // 缺中间版本（授权站明确告诉我们链条断了）
            $blocked = '';
            if (!empty($p['blocked']) && is_array($p['blocked'])) {
                $blocked = (string)($p['blocked']['need'] ?? '');
            }

            if (!$chain && $blocked === '') {
                continue;   // 已是最新
            }

            $last = $chain ? $chain[count($chain) - 1] : [];

            $rows[$name] = [
                'name'      => $name,
                'title'     => (string)($p['title'] ?? $locals[$name]['title']),
                'install'   => false,
                'from'      => $current,
                'version'   => (string)($last['version'] ?? ''),      // 链条终点
                'next'      => (string)($chain[0]['version'] ?? ''),  // 下一级要装的版本
                'steps'     => count($chain),
                'path'      => array_map(static fn($s) => (string)$s['version'], $chain),
                'size_text' => (string)($last['size_text'] ?? ''),
                'changelog' => (string)($last['changelog'] ?? ''),
                'blocked'   => $blocked,
                'enabled'   => $locals[$name]['enabled'],
                'price'     => (string)($p['price_text'] ?? ''),
                'expire'    => (string)($p['expire_txt'] ?? ''),
            ];
        }

        return $rows;
    }

    /**
     * 从授权站下发的包信息里取顺序升级链
     *
     * 兼容两种授权站：新版下发 chain 数组（多版本），旧版只有单个最新版本字段。
     * 客户端会自己再按版本号升序排一遍，不盲信下发顺序。
     */
    public static function chainOf(array $pkg, string $current): array
    {
        $raw = [];
        foreach ((array)($pkg['chain'] ?? []) as $s) {
            if (is_array($s)) {
                $raw[] = $s;
            }
        }

        if (!$raw && (string)($pkg['version'] ?? '') !== '') {
            $raw[] = [
                'version'     => (string)$pkg['version'],
                'url'         => (string)($pkg['url'] ?? ''),
                'sha256'      => (string)($pkg['sha256'] ?? ''),
                'size'        => (int)($pkg['size'] ?? 0),
                'size_text'   => (string)($pkg['size_text'] ?? ''),
                'min_version' => (string)($pkg['from'] ?? ''),
                'changelog'   => (string)($pkg['changelog'] ?? ''),
            ];
        }

        $chain = [];
        foreach ($raw as $s) {
            $ver = (string)($s['version'] ?? '');
            if ($ver === '') {
                continue;
            }
            $chain[] = [
                'version'     => $ver,
                'url'         => (string)($s['url'] ?? ''),
                'sha256'      => (string)($s['sha256'] ?? ''),
                'size'        => (int)($s['size'] ?? 0),
                'size_text'   => (string)($s['size_text'] ?? ''),
                'min_version' => (string)($s['min_version'] ?? ''),
                'changelog'   => (string)($s['changelog'] ?? ''),
            ];
        }

        usort($chain, static fn($a, $b) => version_compare((string)$a['version'], (string)$b['version']));

        // 只保留比本机新的版本，并按版本去重
        $out  = [];
        $seen = [];
        foreach ($chain as $s) {
            $v = (string)$s['version'];
            if (isset($seen[$v]) || version_compare($v, $current, '<=')) {
                continue;
            }
            $seen[$v] = true;
            $out[]    = $s;
        }

        return $out;
    }

    /* ================================================================
     * 升级
     * ================================================================ */

    /**
     * 升级入口：按授权站下发的插件项升级，内部自动逐级走完整条链
     *
     * 顺序铁律：不允许跨版本。链条里每一级都要单独下载、校验、替换，
     * 某一步失败就停在那一步（已装上的版本保持生效），绝不继续往上装。
     *
     * @param array $pkg 授权站下发的包信息（含 chain 顺序链）
     * @return array{code:int,msg:string,from?:string,to?:string,steps?:int}
     */
    public static function install(array $pkg): array
    {
        $name = (string)($pkg['name'] ?? '');

        if (!preg_match('/^[a-z0-9_]{2,40}$/', $name)) {
            return self::err('插件名不合法');
        }
        if (!self::canUnzip()) {
            return self::err('服务器既没有 zip 扩展也没有 Phar 扩展，无法解压插件包，请联系主机商开启');
        }

        $locals  = self::locals();
        $isNew   = !isset($locals[$name]);
        $current = $isNew ? '' : (string)$locals[$name]['version'];

        // 新装：只认授权站明确标了 install 的云端插件，并且必须「授权端启用 + 本站已开通 + 未到期」
        if ($isNew) {
            if (empty($pkg['install'])) {
                return self::err('本机没有安装插件 ' . $name . '，云端也没有下发安装包');
            }
            if (!PluginLicense::isSelf()) {
                $st = PluginLicense::of($name);
                if (!$st['active']) {
                    return self::err('授权端已停用该插件，不能安装');
                }
                if (!$st['authorized']) {
                    return self::err('本站未开通该插件，不能安装；请联系服务商开通');
                }
                if ($st['expired']) {
                    return self::err('插件授权已于 ' . $st['expire_txt'] . ' 到期，不能安装，请先续费');
                }
            }
        } elseif (Plugin::source($name) === 'local') {
            // 本地插件（自己上传/手工放进去的）不走云端升级，避免云端包覆盖客户自行修改的版本
            return self::err('本地插件不支持云端升级，请在插件管理页用「上传升级包」手动升级');
        }

        $steps = self::chainOf($pkg, $current);

        if (!$steps) {
            $need = (string)($pkg['blocked']['need'] ?? '');
            if ($need !== '') {
                return self::err('缺少 v' . $need . ' 的安装包，无法从 v' . $current . ' 按顺序升级，请联系服务商补齐');
            }
            return self::err('当前已是 v' . $current . '，无需升级');
        }

        // 到期只停升级：使用不受影响，但不能再拉新版本
        if (!PluginLicense::canUpgrade($name)) {
            $st = PluginLicense::of($name);
            if ($st['expired']) {
                return self::err('插件授权已于 ' . $st['expire_txt'] . ' 到期，插件可继续使用但不能升级，续费后恢复');
            }

            return self::err('该插件当前不可升级（授权端停用或本站未开通）');
        }

        return self::installChain($name, $steps, $current);
    }

    /**
     * 按链逐级安装：v1.0.0 → v1.0.1 → v1.0.2 → v1.0.3
     *
     * @param array  $steps 升序的各级包信息
     * @param string $from  本机当前版本
     */
    protected static function installChain(string $name, array $steps, string $from): array
    {
        $total = count($steps);
        $cur   = $from;
        $done  = [];

        foreach ($steps as $i => $step) {
            $ver  = (string)($step['version'] ?? '');
            $need = (string)($step['min_version'] ?? '');

            if (!preg_match('/^\d+\.\d+\.\d+$/', $ver)) {
                return self::err('版本号不合法：' . $ver);
            }
            // 不允许同级或降级（链上出现倒序说明数据有问题）
            if (version_compare($ver, $cur, '<=')) {
                return self::err('升级链异常：v' . $ver . ' 不高于当前 v' . $cur . '，已中止');
            }
            // 不允许跳版：当前版本低于该包要求的最低可升级版本，说明中间那版没装
            if ($need !== '' && version_compare($need, $cur, '>')) {
                return self::err('必须先从 v' . $cur . ' 升到 v' . $need . ' 才能升 v' . $ver . '，中间缺包，请联系服务商补齐');
            }

            $r = self::installOne($name, $step, $cur, $i + 1, $total);
            if (($r['code'] ?? 0) !== 1) {
                $msg = '第 ' . ($i + 1) . '/' . $total . ' 步升 v' . $ver . ' 失败：' . (string)($r['msg'] ?? '未知错误');
                if ($done) {
                    $msg .= '；已装好的版本停在 v' . $cur . '，可稍后重试剩下的版本';
                }
                return [
                    'code'   => 0,
                    'msg'    => $msg,
                    'from'   => $from,
                    'to'     => $cur,
                    'done'   => $done,
                    'steps'  => $total,
                    'failed' => $ver,
                ];
            }

            $done[] = ['from' => $cur, 'to' => $ver];
            $cur    = $ver;
        }

        // 整条链走完，作废远程清单缓存，下次进页面重新拉
        @unlink(self::workDir() . 'remote.json');

        // 打完云端标记：以后这个插件按「云端插件」对待（不能卸载、只能云端升级）
        Plugin::markCloud($name, [
            'version' => $cur,
            'entry'   => $from === '' ? 'install' : 'upgrade',
        ]);

        return [
            'code'  => 1,
            'msg'   => $from === ''
                ? '已安装 v' . $cur
                : ($total > 1
                    ? '已按顺序升级 ' . $total . ' 步：v' . $from . ' → v' . $cur
                    : '已升级到 v' . $cur),
            'from'  => $from,
            'to'    => $cur,
            'done'  => $done,
            'steps' => $total,
        ];
    }

    /**
     * 装一步：下载 → SHA256 校验 → 解压 → 校验版本 → 备份 → 换位替换 → 清缓存
     */
    protected static function installOne(string $name, array $step, string $oldVersion, int $idx, int $total): array
    {
        $version = (string)($step['version'] ?? '');
        $url     = (string)($step['url'] ?? '');
        $sha     = strtolower((string)($step['sha256'] ?? ''));
        $size    = (int)($step['size'] ?? 0);

        if (!preg_match('/^\d+\.\d+\.\d+$/', $version)) {
            return self::err('版本号不合法');
        }
        if ($url === '' || $sha === '') {
            return self::err('升级包信息不完整');
        }

        if ($size > 0 && $size > self::MAX_MB * 1048576) {
            return self::err('插件包超过 ' . self::MAX_MB . 'MB，已拒绝');
        }

        self::ensureDirs();
        $work = self::workDir();
        $tmp  = $work . 'tmp/' . $name . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(2));
        $zip  = $work . 'dl/' . $name . '-' . $version . '-' . bin2hex(random_bytes(3)) . '.zip';

        // 1. 下载
        if (!self::download($url, $zip, self::MAX_MB * 1048576)) {
            @unlink($zip);
            return self::err('下载插件包失败（服务器需能访问授权站，且下载链接 5 分钟内有效）');
        }

        // 2. 校验哈希
        $real = strtolower((string)hash_file('sha256', $zip));
        if ($real === '' || $real !== $sha) {
            @unlink($zip);
            return self::err('插件包校验失败（SHA256 不符），已丢弃');
        }

        // 3. 解压（只认 plugins/{name}/，防目录穿越）
        self::ensureDir($tmp);
        $ex = self::extract($zip, $name, $tmp);
        @unlink($zip);
        if (($ex['code'] ?? 0) !== 1) {
            self::rrmdir($tmp);
            return $ex;
        }

        // 4. 校验包内 plugin.json 与授权站记录一致
        $mf = json_decode((string)@file_get_contents($tmp . '/plugin.json'), true);
        if (!is_array($mf)) {
            self::rrmdir($tmp);
            return self::err('插件包缺少 plugin.json');
        }
        if ((string)($mf['name'] ?? '') !== $name) {
            self::rrmdir($tmp);
            return self::err('包内插件名不一致（包内 ' . (string)($mf['name'] ?? '') . '，清单 ' . $name . '）');
        }
        if ((string)($mf['version'] ?? '') !== $version) {
            self::rrmdir($tmp);
            return self::err('包内版本号不一致（包内 ' . (string)($mf['version'] ?? '') . '，清单 ' . $version . '）');
        }

        // 5. 备份旧版本 + 原子换位（新装没有旧目录，直接落位）
        $sw = self::swapDir($name, $tmp, $oldVersion);
        if (($sw['code'] ?? 0) !== 1) {
            return $sw;
        }

        // 6. 收尾：清缓存、清 opcache、留日志
        self::flushCache();
        self::pruneBackup();
        self::log($name, $oldVersion, $version, $idx, $total);

        return [
            'code' => 1,
            'msg'  => ($total > 1 ? '第 ' . $idx . '/' . $total . ' 步：' : '') . '已升级到 v' . $version,
            'from' => $oldVersion,
            'to'   => $version,
        ];
    }

    /**
     * 把解压好的插件目录换到 plugins/{name}（含旧版本备份与失败回滚）
     *
     * @param string $src  已解压到临时目录的新版本插件目录
     * @param string $oldVersion 旧版本号，新装传空字符串
     * @return array{code:int,msg:string}
     */
    protected static function swapDir(string $name, string $src, string $oldVersion): array
    {
        $work   = self::workDir();
        $target = rtrim(Plugin::path($name), '/\\');
        $exists = is_dir($target);

        // 1. 备份旧版本（新装跳过）
        $backup = '';
        if ($exists) {
            $backup = $work . 'backup/' . $name . '-' . ($oldVersion !== '' ? $oldVersion : 'old')
                . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(2));
            self::ensureDir(dirname($backup));
            if (!self::copyTree($target, $backup)) {
                self::rrmdir($src);
                return self::err('备份旧版本失败，已中止升级（请检查 runtime 目录权限）');
            }
        }

        // 2. 先铺到同级临时目录，成功后再改名换位
        $stage = dirname($target) . DIRECTORY_SEPARATOR . '.' . basename($target) . '.new';
        self::rrmdir($stage);
        self::ensureDir($stage);
        if (!self::copyTree($src, $stage)) {
            self::rrmdir($stage);
            self::rrmdir($src);
            return self::err('写入新版本失败，旧版本未受影响');
        }

        self::rrmdir($src);

        // 3. 新装：直接落位即可
        if (!$exists) {
            if (!@rename($stage, $target)) {
                self::rrmdir($stage);
                return self::err('安装失败：无法创建 plugins/' . $name . '，请检查目录权限');
            }

            return ['code' => 1, 'msg' => 'ok'];
        }

        // 4. 升级：旧目录改名让位，新目录改名上位，任一步失败立即回滚
        $oldDir = dirname($target) . DIRECTORY_SEPARATOR . '.' . basename($target) . '.old';
        self::rrmdir($oldDir);

        if (!@rename($target, $oldDir)) {
            // 目录被占用（Windows 常见）时退回「清空 + 复制」，仍保留备份
            self::rrmdir($stage);
            self::rrmdir($target);
            self::ensureDir($target);
            if (!self::copyTree($backup, $target)) {
                return self::err('替换失败且回滚失败，备份在 ' . $backup . '，请手工恢复');
            }
            return self::err('替换失败（目录被占用），已回滚到 v' . $oldVersion . '，请稍后重试');
        }

        if (!@rename($stage, $target)) {
            @rename($oldDir, $target);   // 换位失败立即回滚
            self::rrmdir($stage);
            return self::err('启用新版本失败，已回滚到 v' . $oldVersion);
        }

        self::rrmdir($oldDir);

        return ['code' => 1, 'msg' => 'ok'];
    }

    /* ================================================================
     * 本地插件包（后台手动上传）
     * ================================================================ */

    /**
     * 本地上传插件包：安装或升级「本地插件」
     *
     * 与云端升级严格分开：
     *  - 云端插件不允许被本地包覆盖（否则改几行文件就能绕过授权）
     *  - 本地包必须 plugins/{name}/plugin.json，版本必须高于本机
     *
     * @param string $zipFile 上传的临时文件路径
     * @return array{code:int,msg:string,name?:string,from?:string,to?:string}
     */
    public static function installLocal(string $zipFile): array
    {
        if (!is_file($zipFile)) {
            return self::err('没有收到上传的插件包');
        }
        if (!self::canUnzip()) {
            return self::err('服务器既没有 zip 扩展也没有 Phar 扩展，无法解压插件包，请联系主机商开启');
        }
        if ((int)@filesize($zipFile) > self::MAX_MB * 1048576) {
            return self::err('插件包超过 ' . self::MAX_MB . 'MB，已拒绝');
        }

        $mf = self::readManifestFromZip($zipFile, $name);
        if ($mf === null) {
            return self::err('插件包内找不到 plugins/{插件名}/plugin.json，请用标准结构打包');
        }
        if (!preg_match('/^[a-z0-9_]{2,40}$/', $name)) {
            return self::err('插件名不合法：' . $name . '（只能小写字母、数字、下划线）');
        }

        $version = (string)($mf['version'] ?? '');
        if (!preg_match('/^\d+\.\d+\.\d+$/', $version)) {
            return self::err('包内 plugin.json 的 version 格式应为 1.0.0');
        }

        if (Plugin::source($name) === 'cloud') {
            return self::err('插件 ' . $name . ' 是云端插件，只能从授权站升级，不能用本地包覆盖');
        }

        $locals  = self::locals();
        $current = (string)($locals[$name]['version'] ?? '');
        if ($current !== '' && version_compare($version, $current, '<=')) {
            return self::err('包内版本 v' . $version . ' 不高于本机 v' . $current . '，无需上传');
        }

        self::ensureDirs();
        $tmp = self::workDir() . 'tmp/' . $name . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(2));
        self::ensureDir($tmp);

        $ex = self::extract($zipFile, $name, $tmp);
        if (($ex['code'] ?? 0) !== 1) {
            self::rrmdir($tmp);
            return $ex;
        }

        // 解压后再核一遍，防止包头与包体不一致
        $inner = json_decode((string)@file_get_contents($tmp . '/plugin.json'), true);
        if (!is_array($inner)
            || (string)($inner['name'] ?? '') !== $name
            || (string)($inner['version'] ?? '') !== $version) {
            self::rrmdir($tmp);
            return self::err('插件包内容不一致（plugin.json 的 name/version 与包路径不符）');
        }

        $sw = self::swapDir($name, $tmp, $current);
        if (($sw['code'] ?? 0) !== 1) {
            return $sw;
        }

        // 本地包覆盖后必须清掉云端标记，确保它按本地插件对待（云端插件已在上面拦掉了）
        @unlink(Plugin::cloudFlag($name));
        @unlink(Plugin::lockFile($name));

        self::flushCache();
        self::pruneBackup();
        @unlink(self::workDir() . 'remote.json');

        return [
            'code' => 1,
            'msg'  => $current === ''
                ? '已安装本地插件 ' . $name . ' v' . $version
                : '已把 ' . $name . ' 从 v' . $current . ' 升级到 v' . $version,
            'name' => $name,
            'from' => $current,
            'to'   => $version,
        ];
    }

    /**
     * 从 zip 里读出 plugins/{name}/plugin.json
     *
     * @param string $name 出参：包内插件名
     */
    protected static function readManifestFromZip(string $zipFile, ?string &$name = null): ?array
    {
        $name = '';

        if (class_exists('ZipArchive')) {
            $zip = new \ZipArchive();
            if ($zip->open($zipFile) !== true) {
                return null;
            }
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $entry = str_replace('\\', '/', (string)$zip->getNameIndex($i));
                if (!preg_match('#^plugins/([A-Za-z0-9_]+)/plugin\.json$#', ltrim($entry, '/'), $m)) {
                    continue;
                }
                $json = json_decode((string)$zip->getFromIndex($i), true);
                $zip->close();
                if (!is_array($json)) {
                    return null;
                }
                $name = strtolower($m[1]);

                return $json;
            }
            $zip->close();

            return null;
        }

        if (class_exists('PharData')) {
            try {
                $phar = new \PharData($zipFile);
                $base = 'phar://' . str_replace('\\', '/', (string)realpath($zipFile));
                foreach (new \RecursiveIteratorIterator($phar) as $f) {
                    if (!$f->isFile()) {
                        continue;
                    }
                    $path = str_replace('\\', '/', (string)$f->getPathname());
                    if (!str_starts_with($path, $base . '/')) {
                        continue;
                    }
                    $entry = substr($path, strlen($base) + 1);
                    if (!preg_match('#^plugins/([A-Za-z0-9_]+)/plugin\.json$#', $entry, $m)) {
                        continue;
                    }
                    $json = json_decode((string)@file_get_contents($path), true);
                    unset($phar);
                    if (!is_array($json)) {
                        return null;
                    }
                    $name = strtolower($m[1]);

                    return $json;
                }
                unset($phar);
            } catch (\Throwable $e) {
                return null;
            }
        }

        return null;
    }

    /* ================================================================
     * 缓存 / 日志
     * ================================================================ */

    /**
     * 清掉会包住旧插件的缓存：
     *  - PHP opcache（插件文件已替换，必须让新文件生效）
     *  - 模板编译缓存 runtime/{app}/temp（插件视图改了要重编译）
     *  - 前台静态 HTML runtime/{app}/html（页面里可能已固化插件输出）
     */
    public static function flushCache(): void
    {
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }

        $rt = runtime_path();

        self::rrmdir($rt . 'temp');
        self::rrmdir($rt . 'cache');

        try {
            HtmlCache::clear();
        } catch (\Throwable $e) {
            // 忽略
        }
    }

    /**
     * 升级日志（最近 30 条）
     */
    public static function logs(): array
    {
        $file = self::workDir() . 'log.json';
        if (!is_file($file)) {
            return [];
        }
        $rows = json_decode((string)@file_get_contents($file), true);

        return is_array($rows) ? $rows : [];
    }

    protected static function log(string $name, string $from, string $to, int $idx = 1, int $total = 1): void
    {
        $rows = self::logs();
        $rows[] = [
            'name'  => $name,
            'from'  => $from,
            'to'    => $to,
            'idx'   => $idx,
            'total' => $total,
            'at'    => time(),
        ];
        if (count($rows) > 30) {
            $rows = array_slice($rows, -30);
        }
        @file_put_contents(self::workDir() . 'log.json', (string)json_encode($rows, JSON_UNESCAPED_UNICODE));
    }

    protected static function pruneBackup(): void
    {
        $dir = self::workDir() . 'backup';
        if (!is_dir($dir)) {
            return;
        }
        $items = array_values(array_filter((array)scandir($dir), static fn($i) => $i !== '.' && $i !== '..'));
        if (count($items) <= self::KEEP_BACKUP) {
            return;
        }
        sort($items);
        foreach (array_slice($items, 0, count($items) - self::KEEP_BACKUP) as $old) {
            self::rrmdir($dir . '/' . $old);
        }
    }

    /* ================================================================
     * 工具
     * ================================================================ */

    /**
     * 工作目录固定放在 runtime 根下（runtime/pluginupgrade）
     *
     * 多应用下 runtime_path() 会带应用名（runtime/admin/），
     * 插件升级是站点级操作，缓存和备份不该随应用目录漂移。
     */
    public static function workDir(): string
    {
        $rt = rtrim(runtime_path(), '/\\');
        if (basename($rt) !== 'runtime') {
            $rt = dirname($rt);
        }

        return $rt . DIRECTORY_SEPARATOR . 'pluginupgrade' . DIRECTORY_SEPARATOR;
    }

    public static function ensureDirs(): void
    {
        foreach (['', 'dl', 'tmp', 'backup'] as $sub) {
            self::ensureDir(self::workDir() . $sub);
        }
    }

    protected static function ensureDir(string $dir): void
    {
        $dir = rtrim($dir, '/\\');
        if ($dir !== '' && !is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
    }

    protected static function extract(string $zipFile, string $name, string $to): array
    {
        if (class_exists('ZipArchive')) {
            return self::extractZip($zipFile, $name, $to);
        }
        if (class_exists('PharData')) {
            return self::extractPhar($zipFile, $name, $to);
        }

        return self::err('服务器没有可用的解压组件');
    }

    protected static function extractZip(string $zipFile, string $name, string $to): array
    {
        $zip = new \ZipArchive();
        if ($zip->open($zipFile) !== true) {
            return self::err('插件包无法打开，可能已损坏');
        }

        $prefix = 'plugins/' . $name . '/';
        $files  = 0;
        $bytes  = 0;
        $skip   = ['installed.lock', 'menu.ver'];

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entry = str_replace('\\', '/', (string)$zip->getNameIndex($i));
            $entry = ltrim($entry, '/');

            if ($entry === '' || str_ends_with($entry, '/')) {
                continue;
            }
            // 只认目标插件目录，包里夹带别的东西一律忽略
            if (!str_starts_with($entry, $prefix)) {
                continue;
            }

            $rel = substr($entry, strlen($prefix));
            if ($rel === '' || str_contains($rel, '..') || str_contains($rel, "\0")) {
                continue;
            }
            if (in_array(strtolower(basename($rel)), $skip, true)) {
                continue;
            }

            $data = $zip->getFromIndex($i);
            if ($data === false) {
                continue;
            }

            $bytes += strlen($data);
            if ($bytes > self::MAX_MB * 1048576) {
                $zip->close();
                return self::err('插件解压后体积超限，已中止');
            }

            $dest = $to . '/' . $rel;
            self::ensureDir(dirname($dest));
            if (@file_put_contents($dest, $data) === false) {
                $zip->close();
                return self::err('写入文件失败：' . $rel . '（检查 runtime 目录权限）');
            }
            $files++;
        }

        $zip->close();

        if ($files === 0) {
            return self::err('插件包里没有 plugins/' . $name . '/ 下的文件');
        }

        return ['code' => 1, 'msg' => 'ok', 'files' => $files];
    }

    /**
     * Phar 兜底解压：用 PharData 读 zip（精简 PHP 环境常见只有 Phar 没有 zip）
     */
    protected static function extractPhar(string $zipFile, string $name, string $to): array
    {
        try {
            $phar = new \PharData($zipFile);
        } catch (\Throwable $e) {
            return self::err('插件包无法打开：' . $e->getMessage());
        }

        $prefix = 'plugins/' . $name . '/';
        $base   = 'phar://' . str_replace('\\', '/', (string)realpath($zipFile));
        $files  = 0;
        $bytes  = 0;
        $skip   = ['installed.lock', 'menu.ver'];

        try {
            $it = new \RecursiveIteratorIterator($phar);
            foreach ($it as $file) {
                /** @var \SplFileInfo $file */
                if (!$file->isFile()) {
                    continue;
                }

                $path = str_replace('\\', '/', (string)$file->getPathname());
                if (!str_starts_with($path, $base . '/')) {
                    continue;
                }

                $entry = substr($path, strlen($base) + 1);
                if ($entry === '' || !str_starts_with($entry, $prefix)) {
                    continue;
                }

                $rel = substr($entry, strlen($prefix));
                if ($rel === '' || str_contains($rel, '..')) {
                    continue;
                }
                if (in_array(strtolower(basename($rel)), $skip, true)) {
                    continue;
                }

                $data = @file_get_contents($path);
                if ($data === false) {
                    continue;
                }

                $bytes += strlen($data);
                if ($bytes > self::MAX_MB * 1048576) {
                    return self::err('插件解压后体积超限，已中止');
                }

                $dest = $to . '/' . $rel;
                self::ensureDir(dirname($dest));
                if (@file_put_contents($dest, $data) === false) {
                    return self::err('写入文件失败：' . $rel . '（检查 runtime 目录权限）');
                }
                $files++;
            }
        } catch (\Throwable $e) {
            return self::err('解压插件包失败：' . $e->getMessage());
        }

        unset($phar);   // Windows 下释放句柄，否则包文件删不掉

        if ($files === 0) {
            return self::err('插件包里没有 plugins/' . $name . '/ 下的文件');
        }

        return ['code' => 1, 'msg' => 'ok', 'files' => $files];
    }

    protected static function copyTree(string $src, string $dst): bool
    {
        $src = rtrim($src, '/\\');
        if (!is_dir($src)) {
            return false;
        }
        self::ensureDir($dst);

        $ok = true;
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($src, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($it as $item) {
            $rel  = substr($item->getPathname(), strlen($src) + 1);
            $to   = rtrim($dst, '/\\') . DIRECTORY_SEPARATOR . $rel;
            if ($item->isDir()) {
                self::ensureDir($to);
            } else {
                self::ensureDir(dirname($to));
                if (!@copy($item->getPathname(), $to)) {
                    $ok = false;
                }
            }
        }

        return $ok;
    }

    public static function rrmdir(string $dir): void
    {
        $dir = rtrim($dir, '/\\');
        if ($dir === '' || !is_dir($dir)) {
            return;
        }
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it as $item) {
            if ($item->isDir()) {
                @rmdir($item->getPathname());
            } else {
                @unlink($item->getPathname());
            }
        }
        @rmdir($dir);
    }

    protected static function download(string $url, string $to, int $maxBytes): bool
    {
        self::ensureDir(dirname($to));

        if (function_exists('curl_init')) {
            $fp = @fopen($to, 'wb');
            if ($fp === false) {
                return false;
            }
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_FILE           => $fp,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 3,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT        => 120,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_USERAGENT      => 'ThinkWoCMS-PluginUpgrade/1.0',
            ]);
            $ok   = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            fclose($fp);

            if ($ok === false || $code !== 200) {
                @unlink($to);
                return false;
            }
        } else {
            $ctx = stream_context_create([
                'http'  => ['timeout' => 120, 'user_agent' => 'ThinkWoCMS-PluginUpgrade/1.0'],
                'https' => ['timeout' => 120],
                'ssl'   => ['verify_peer' => false, 'verify_peer_name' => false],
            ]);
            $data = @file_get_contents($url, false, $ctx);
            if ($data === false || $data === '') {
                @unlink($to);
                return false;
            }
            if (!@file_put_contents($to, $data)) {
                @unlink($to);
                return false;
            }
        }

        clearstatcache(true, $to);
        $size = (int)@filesize($to);
        if ($size <= 0 || $size > $maxBytes) {
            @unlink($to);
            return false;
        }

        return true;
    }

    protected static function post(string $url, array $data): ?array
    {
        $body = http_build_query($data);

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $body,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_TIMEOUT        => 20,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
                CURLOPT_USERAGENT      => 'ThinkWoCMS-PluginUpgrade/1.0',
            ]);
            $res  = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($res === false || $code >= 400) {
                return null;
            }
        } else {
            $ctx = stream_context_create([
                'http' => [
                    'method'  => 'POST',
                    'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
                    'content' => $body,
                    'timeout' => 20,
                ],
                'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
            ]);
            $res = @file_get_contents($url, false, $ctx);
            if ($res === false || $res === '') {
                return null;
            }
        }

        $json = json_decode((string)$res, true);

        return is_array($json) ? $json : null;
    }

    protected static function host(): string
    {
        $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));

        return (string)preg_replace('/:\d+$/', '', $host);
    }

    protected static function err(string $msg): array
    {
        return ['code' => 0, 'msg' => $msg];
    }
}
