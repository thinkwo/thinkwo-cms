<?php

declare(strict_types=1);

namespace app\common\library;

/**
 * 源码归属指纹
 *
 * 作用与 Build 类不同，两者配合使用：
 *   Signature  —— 静态指纹，全部副本共用同一个序列号，用来证明「这套代码是 ThinkWoCMS」；
 *   Build      —— 动态水印，每份客户包各不相同，用来查「这份副本是谁泄露的」。
 *
 * 序列号被刻意散布在明文区域（模板注释、CSS/JS 注释、语言包、配置文件），
 * 因为这些是别人抄站时一定会连锅端走的部分；app/ 里的代码即使被 ionCube 加密，
 * 本类里也有同样的串，加密后依旧能从常量里取出来核对。
 *
 * 注意：改这里的 SERIAL 等于换掉整个项目的身份，历史副本将无法对上号。除非你
 * 要发布一个"新一代"产品，否则不要动它。
 */
final class Signature
{
    /** 项目代号 */
    public const PROJECT = 'ThinkWoCMS';

    /** 作者标识 */
    public const AUTHOR = 'ThinkWo';

    /** 项目序列号（散布在多个文件的注释里，用于源码归属认定） */
    public const SERIAL = 'TW-CMS-ZW-2026-8F3A1C';

    /** 首个版本对外时间 */
    public const SINCE = '2026-08';

    /**
     * 归属声明（人类可读）
     */
    public static function notice(): string
    {
        return self::PROJECT . ' (' . self::SERIAL . ') · 原创代码 · 未经授权不得二次分发';
    }

    /**
     * 是否为本人部署（用于后台展示，不做任何拦截）
     */
    public static function serial(): string
    {
        return self::SERIAL;
    }
}
