<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Cache;
use think\facade\Log;

/**
 * 同步翻译引擎
 *
 * 引擎分两类（站点设置 translate_driver）：
 *
 *  免费（无需密钥，开箱可用）
 *   - google    Google 翻译网页接口，免费、无需密钥（服务器需能访问 googleapis.com）
 *   - mymemory  MyMemory 公共接口，免费、无需密钥（每日字符限额，作为 google 的兜底）
 *
 *  免费额度 / 付费（需在对应平台申请密钥）
 *   - baidu     百度翻译开放平台，标准版每月 5 万字符免费，超出按量付费
 *   - youdao    有道智云，有免费体验额度，超出付费
 *   - deepl     DeepL，免费版每月 50 万字符；Pro 套餐按量付费
 *
 *  离线
 *   - none      不调接口，仅同步结构（不推荐用于多语言 SEO，会产生重复内容）
 *
 * 性能约定：一次「同步翻译」尽量只用 1~2 个请求
 *  - strings() 把多个字段合并成一次批量请求
 *  - html()    先收集全篇文本节点，合并成一次批量请求，标签与属性原样保留
 *  - 百度 / DeepL 按字节分批，超长文本自动按句切分再拼接
 */
class Translate
{
    /**
     * 引擎清单（后台下拉与提示都用这一份，避免两处不同步）
     */
    public const ENGINES = [
        'auto'     => ['label' => '自动（优先 Google，不可用时自动切 MyMemory）', 'type' => 'free', 'need_key' => false],
        'google'   => ['label' => 'Google 翻译（免费·无需密钥）', 'type' => 'free', 'need_key' => false],
        'mymemory' => ['label' => 'MyMemory（免费·无需密钥·每日限额）', 'type' => 'free', 'need_key' => false],
        'baidu'    => ['label' => '百度翻译（免费 5 万字符/月，超出付费）', 'type' => 'freemium', 'need_key' => true],
        'youdao'   => ['label' => '有道智云（免费体验额度，超出付费）', 'type' => 'freemium', 'need_key' => true],
        'deepl'    => ['label' => 'DeepL（免费 50 万字符/月，Pro 付费）', 'type' => 'freemium', 'need_key' => true],
        'none'     => ['label' => '离线复制（不翻译，仅同步结构）', 'type' => 'off', 'need_key' => false],
    ];

    /**
     * 单次请求的最大字节数（百度限制 6000 字节，留余量）
     */
    protected const MAX_BYTES = 4000;

    /**
     * 最近一次翻译失败的原因（空串表示没失败）
     */
    protected static string $lastError = '';

    /**
     * 取上次失败原因，调用方用它决定"写入译文"还是"报错跳过"
     */
    public static function lastError(): string
    {
        return self::$lastError;
    }

    public static function clearError(): void
    {
        self::$lastError = '';
    }

    /**
     * 当前驱动
     */
    public static function driver(): string
    {
        $d = (string)Settings::get('translate_driver', 'auto');

        return isset(self::ENGINES[$d]) ? $d : 'none';
    }

    /**
     * 是否可用于自动翻译（配置了真实引擎）
     */
    public static function available(): bool
    {
        return self::driver() !== 'none';
    }

    /**
     * 后台下拉选项：免费在前，付费在后
     */
    public static function engineOptions(): array
    {
        $free   = [];
        $paid   = [];
        $others = [];
        foreach (self::ENGINES as $code => $info) {
            if ($info['type'] === 'free') {
                $free[$code] = $info['label'];
            } elseif ($info['type'] === 'freemium') {
                $paid[$code] = $info['label'];
            } else {
                $others[$code] = $info['label'];
            }
        }

        return $free + $paid + $others;
    }

    /**
     * 引擎显示名
     */
    public static function label(?string $driver = null): string
    {
        $driver = $driver ?? self::driver();

        return (string)(self::ENGINES[$driver]['label'] ?? $driver);
    }

    /**
     * 是否需要密钥
     */
    public static function needKey(?string $driver = null): bool
    {
        $driver = $driver ?? self::driver();

        return (bool)(self::ENGINES[$driver]['need_key'] ?? false);
    }

    /**
     * 翻译一批纯文本（顺序与输入一致）
     *
     * 所有文本合并成一次（或少数几次）接口请求，避免每个字段一次调用。
     *
     * @param  string[] $strings
     * @return string[]
     */
    public static function strings(array $strings, string $from, string $to): array
    {
        $strings = array_map(static fn ($s) => (string)$s, $strings);
        if ($from === $to || !$strings) {
            return $strings;
        }
        if (self::driver() === 'none') {
            self::$lastError = '未启用翻译引擎（当前为「离线复制」）';

            return $strings;
        }

        // 去重（空串与纯符号不送翻）
        $unique = [];
        foreach ($strings as $s) {
            $t = trim($s);
            if ($t !== '' && preg_match('/[\p{L}]/u', $t)) {
                $unique[$t] = true;
            }
        }
        if (!$unique) {
            return $strings;
        }

        $srcs  = array_keys($unique);
        $trans = self::callDriver(self::driver(), $srcs, $from, $to);
        if (!$trans) {
            self::$lastError = '翻译接口没有返回内容';
        }

        $map = [];
        foreach ($srcs as $k => $s) {
            $dst = (string)($trans[$k] ?? '');
            $map[$s] = $dst !== '' ? html_entity_decode($dst, ENT_QUOTES | ENT_HTML5, 'UTF-8') : $s;
        }

        $out = $strings;
        foreach ($strings as $i => $s) {
            $t = trim($s);
            if (!isset($map[$t])) {
                continue;
            }
            preg_match('/^(\s*)(.*?)(\s*)$/us', $s, $m);
            $out[$i] = $m[1] . $map[$t] . $m[3];
        }

        return $out;
    }

    /**
     * 翻译 HTML：保留全部标签、属性与结构，只翻译文本节点
     *
     * script / style / pre / code 整块跳过（先替换为占位符，翻完再还原）。
     */
    public static function html(string $html, string $from, string $to): string
    {
        if ($html === '' || $from === $to) {
            return $html;
        }
        if (self::driver() === 'none') {
            self::$lastError = '未启用翻译引擎（当前为「离线复制」）';

            return $html;
        }

        // 1) 保护不翻译的整块内容
        $skips = [];
        $html  = (string)preg_replace_callback(
            '/(<(script|style|pre|code)\b[^>]*>.*?<\/\2>)/is',
            static function ($m) use (&$skips) {
                $key = "\x02TSKIP" . count($skips) . "\x03";
                $skips[$key] = $m[1];

                return $key;
            },
            $html
        );

        // 2) 按标签切分，收集纯文本段
        $pieces = preg_split('/(<[^>]+>)/u', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
        if ($pieces === false) {
            return strtr($html, $skips);
        }

        $todo = [];
        foreach ($pieces as $i => $piece) {
            if ($i % 2 === 1) {
                continue; // 标签本身
            }
            if ($piece === '' || strpos($piece, "\x02TSKIP") !== false) {
                continue; // 占位符单独成段，跳过
            }
            $text = html_entity_decode($piece, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if (trim($text) !== '' && preg_match('/[\p{L}]{2,}/u', $text)) {
                $todo[$i] = trim($text);
            }
        }

        if (!$todo) {
            return strtr($html, $skips);
        }

        // 3) 全篇文本一次批量送翻
        $unique = array_values(array_unique(array_values($todo)));
        $trans  = self::callDriver(self::driver(), $unique, $from, $to);

        $map = [];
        foreach ($unique as $k => $src) {
            $dst = (string)($trans[$k] ?? '');
            $map[$src] = $dst !== '' ? html_entity_decode($dst, ENT_QUOTES | ENT_HTML5, 'UTF-8') : $src;
        }

        foreach ($todo as $i => $src) {
            $dst = $map[$src] ?? $src;
            preg_match('/^(\s*)(.*?)(\s*)$/us', $pieces[$i], $m);
            $pieces[$i] = $m[1] . htmlspecialchars($dst, ENT_NOQUOTES, 'UTF-8') . $m[3];
        }

        // 4) 还原被保护的整块
        return strtr(implode('', $pieces), $skips);
    }

    /**
     * 调用驱动翻译一组文本
     *
     * @param  string[] $texts
     * @return string[]
     */
    protected static function callDriver(string $driver, array $texts, string $from, string $to): array
    {
        if (!$texts) {
            return [];
        }

        if ($driver === 'auto') {
            $driver = self::resolveAuto();
        }

        $appid  = (string)Settings::get('translate_appid', '');
        $secret = (string)Settings::get('translate_secret', '');

        try {
            return self::dispatch($driver, $texts, $from, $to, $appid, $secret);
        } catch (\Throwable $e) {
            // 免费引擎互为兜底：google 挂了换 mymemory，反之亦然
            $fallback = $driver === 'google' ? 'mymemory' : ($driver === 'mymemory' ? 'google' : '');
            if ($fallback !== '') {
                try {
                    return self::dispatch($fallback, $texts, $from, $to, '', '');
                } catch (\Throwable $ignore) {
                    // 兜底也失败，抛原始错误
                }
            }
            try {
                Log::error('[Translate] ' . $driver . ' ' . $e->getMessage());
            } catch (\Throwable $ignore) {
                // 日志不可用则静默
            }
            self::$lastError = mb_substr($e->getMessage(), 0, 120);
            throw $e;
        }
    }

    /**
     * 「自动」模式：探测一次哪个免费引擎可用，结果缓存 7 天
     *
     * 国内服务器访问不了 Google，会自动落到 MyMemory，不会每次都等超时。
     */
    protected static function resolveAuto(): string
    {
        try {
            $cached = (string)Cache::get('tw_trans_engine', '');
            if ($cached === 'google' || $cached === 'mymemory') {
                return $cached;
            }
        } catch (\Throwable $e) {
            // 缓存不可用则现探
        }

        $engine = 'mymemory';
        try {
            $raw = self::httpGet(
                'https://translate.googleapis.com/translate_a/single?client=gtx&dt=t&sl=en&tl=zh-CN&q=ok',
                4
            );
            if (str_contains($raw, '[')) {
                $engine = 'google';
            }
        } catch (\Throwable $e) {
            $engine = 'mymemory';
        }

        try {
            Cache::set('tw_trans_engine', $engine, 604800);
        } catch (\Throwable $e) {
            // 忽略
        }

        return $engine;
    }

    /**
     * @return string[]
     */
    protected static function dispatch(string $driver, array $texts, string $from, string $to, string $appid, string $secret): array
    {
        return match ($driver) {
            'baidu'    => self::baidu($texts, $from, $to, $appid, $secret),
            'youdao'   => self::youdao($texts, $from, $to, $appid, $secret),
            'deepl'    => self::deepl($texts, $from, $to, $appid),
            'google'   => self::google($texts, $from, $to),
            'mymemory' => self::mymemory($texts, $from, $to),
            default    => $texts,
        };
    }

    // ------------------------------------------------------------------
    // 各引擎实现
    // ------------------------------------------------------------------

    /**
     * 百度翻译：一次请求支持多行，按行返回
     */
    protected static function baidu(array $texts, string $from, string $to, string $appid, string $secret): array
    {
        if ($appid === '' || $secret === '') {
            throw new \RuntimeException('百度翻译未配置 APPID/密钥');
        }

        $units = self::units($texts, self::MAX_BYTES);
        $acc   = array_fill(0, count($texts), '');

        foreach (self::groupUnits($units, self::MAX_BYTES) as $group) {
            $q    = implode("\n", array_column($group, 'text'));
            $salt = (string)random_int(100000, 999999);
            $sign = md5($appid . $q . $salt . $secret);

            $res = self::http('https://fanyi-api.baidu.com/api/trans/vip/translate', [
                'q'     => $q,
                'from'  => self::mapCode('baidu', $from),
                'to'    => self::mapCode('baidu', $to),
                'appid' => $appid,
                'salt'  => $salt,
                'sign'  => $sign,
            ]);

            if (isset($res['error_code'])) {
                throw new \RuntimeException('百度翻译错误 ' . $res['error_code'] . ': ' . ($res['error_msg'] ?? ''));
            }
            $list = $res['trans_result'] ?? [];
            if (!is_array($list) || count($list) !== count($group)) {
                throw new \RuntimeException('百度翻译返回行数不符');
            }
            foreach ($group as $k => $unit) {
                $dst = (string)($list[$k]['dst'] ?? '');
                $acc[$unit['i']] .= ($unit['append'] && $acc[$unit['i']] !== '' ? ' ' : '') . $dst;
            }
        }

        return $acc;
    }

    /**
     * 有道智云：每次一条，串行节流
     */
    protected static function youdao(array $texts, string $from, string $to, string $appKey, string $secret): array
    {
        if ($appKey === '' || $secret === '') {
            throw new \RuntimeException('有道翻译未配置应用ID/密钥');
        }

        $units = self::units($texts, 4800);
        $acc   = array_fill(0, count($texts), '');

        foreach ($units as $unit) {
            $q       = $unit['text'];
            $salt    = (string)random_int(100000, 999999);
            $curtime = (string)time();
            $input   = mb_strlen($q) <= 20 ? $q : mb_substr($q, 0, 10) . mb_strlen($q) . mb_substr($q, -10);
            $sign    = hash('sha256', $appKey . $input . $salt . $curtime . $secret);

            $res = self::http('https://openapi.youdao.com/api', [
                'q'        => $q,
                'from'     => self::mapCode('youdao', $from),
                'to'       => self::mapCode('youdao', $to),
                'appKey'   => $appKey,
                'salt'     => $salt,
                'sign'     => $sign,
                'signType' => 'v3',
                'curtime'  => $curtime,
            ]);

            if (($res['errorCode'] ?? '0') !== '0') {
                throw new \RuntimeException('有道翻译错误码 ' . ($res['errorCode'] ?? '?'));
            }
            $dst = (string)($res['translation'][0] ?? '');
            $acc[$unit['i']] .= ($unit['append'] && $acc[$unit['i']] !== '' ? ' ' : '') . $dst;
            usleep(120000); // QPS 限制
        }

        return $acc;
    }

    /**
     * DeepL：text[] 批量
     */
    protected static function deepl(array $texts, string $from, string $to, string $authKey): array
    {
        if ($authKey === '') {
            throw new \RuntimeException('DeepL 未配置 auth_key');
        }

        $isPro = Settings::get('translate_deepl_pro', '0') === '1';
        $host  = $isPro ? 'https://api.deepl.com' : 'https://api-free.deepl.com';

        $units = self::units($texts, 30000);
        $acc   = array_fill(0, count($texts), '');

        foreach (array_chunk($units, 30) as $group) {
            $params = ['target_lang' => self::mapCode('deepl', $to)];
            if ($from !== '' && $from !== 'auto') {
                $params['source_lang'] = self::mapCode('deepl', $from);
            }
            foreach (array_values($group) as $i => $unit) {
                $params['text[' . $i . ']'] = $unit['text'];
            }

            $res  = self::http($host . '/v2/translate', $params, ['Authorization: DeepL-Auth-Key ' . $authKey]);
            $list = $res['translations'] ?? [];
            if (!is_array($list) || count($list) !== count($group)) {
                throw new \RuntimeException('DeepL 返回条数不符');
            }
            foreach ($group as $k => $unit) {
                $dst = (string)($list[$k]['text'] ?? '');
                $acc[$unit['i']] .= ($unit['append'] && $acc[$unit['i']] !== '' ? ' ' : '') . $dst;
            }
        }

        return $acc;
    }

    /**
     * Google 免费接口（translate_a/single，无需密钥）
     */
    protected static function google(array $texts, string $from, string $to): array
    {
        $sl = self::mapCode('google', $from);
        $tl = self::mapCode('google', $to);

        $units = self::units($texts, 3000);
        $acc   = array_fill(0, count($texts), '');

        foreach ($units as $n => $unit) {
            $url = 'https://translate.googleapis.com/translate_a/single?client=gtx&dt=t'
                . '&sl=' . rawurlencode($sl) . '&tl=' . rawurlencode($tl)
                . '&q=' . rawurlencode($unit['text']);

            $raw  = self::httpGet($url);
            $data = json_decode($raw, true);
            if (!is_array($data) || !isset($data[0]) || !is_array($data[0])) {
                throw new \RuntimeException('Google 翻译返回异常');
            }
            $dst = '';
            foreach ($data[0] as $seg) {
                if (is_array($seg)) {
                    $dst .= (string)($seg[0] ?? '');
                }
            }
            $acc[$unit['i']] .= ($unit['append'] && $acc[$unit['i']] !== '' ? ' ' : '') . $dst;

            if ($n > 0) {
                usleep(60000); // 温和节流，避免被限流
            }
        }

        return $acc;
    }

    /**
     * MyMemory 公共接口（免费，无需密钥）
     *
     * 单次 q 上限约 500 字节，短句用换行合并成一次请求（实测换行会被保留），
     * 行数对不上再逐条重试。
     */
    protected static function mymemory(array $texts, string $from, string $to): array
    {
        $pair  = self::mapCode('google', $from) . '|' . self::mapCode('google', $to);
        $units = self::units($texts, 400);
        $acc   = array_fill(0, count($texts), '');

        foreach (self::groupUnits($units, 450) as $group) {
            $q     = implode("\n", array_column($group, 'text'));
            $dst   = self::mymemoryCall($q, $pair);
            $lines = $dst !== '' ? (preg_split('/\r?\n/', $dst) ?: []) : [];

            if ($dst !== '' && count($lines) === count($group)) {
                foreach ($group as $k => $unit) {
                    $acc[$unit['i']] .= ($unit['append'] && $acc[$unit['i']] !== '' ? ' ' : '') . trim((string)$lines[$k]);
                }
            } else {
                // 多行合并失败（行数不符或被限流）→ 逐条重试
                foreach ($group as $unit) {
                    $one = '';
                    for ($try = 0; $try < 3 && $one === ''; $try++) {
                        $one = self::mymemoryCall($unit['text'], $pair);
                        if ($one === '') {
                            usleep(400000);
                        }
                    }
                    if ($one === '') {
                        throw new \RuntimeException('MyMemory 无返回（可能超出当日免费额度），建议改用百度/DeepL 或稍后重试');
                    }
                    $acc[$unit['i']] .= ($unit['append'] && $acc[$unit['i']] !== '' ? ' ' : '') . $one;
                    usleep(120000);
                }
            }

            usleep(120000);
        }

        return $acc;
    }

    /**
     * 单次 MyMemory 请求（失败返回空串，由调用方决定重试）
     */
    protected static function mymemoryCall(string $q, string $pair): string
    {
        try {
            $raw = self::httpGet('https://api.mymemory.translated.net/get?q=' . rawurlencode($q) . '&langpair=' . rawurlencode($pair));
        } catch (\Throwable $e) {
            return '';
        }

        $data = json_decode($raw, true);
        if (!is_array($data)) {
            return '';
        }

        return trim((string)($data['responseData']['translatedText'] ?? ''));
    }

    // ------------------------------------------------------------------
    // 文本切分与分批
    // ------------------------------------------------------------------

    /**
     * 把输入文本展开成可送翻的单元（超长文本按句切分）
     *
     * @return array<int, array{i:int, text:string, append:bool}>
     */
    protected static function units(array $texts, int $maxBytes): array
    {
        $units = [];
        foreach ($texts as $i => $t) {
            // 接口按换行拆行返回，内部换行统一压成空格，保证行数一一对应
            $t = (string)preg_replace('/[\r\n\t]+/', ' ', (string)$t);
            if (strlen($t) <= $maxBytes) {
                $units[] = ['i' => $i, 'text' => $t, 'append' => false];
                continue;
            }
            foreach (self::splitText($t, $maxBytes) as $k => $piece) {
                $units[] = ['i' => $i, 'text' => $piece, 'append' => $k > 0];
            }
        }

        return $units;
    }

    /**
     * 按句切分超长文本
     *
     * @return string[]
     */
    protected static function splitText(string $text, int $maxBytes): array
    {
        if (strlen($text) <= $maxBytes) {
            return [$text];
        }

        $sentences = preg_split('/(?<=[.!?;:。！？；：])\s*/u', $text) ?: [$text];
        $out = [];
        $cur = '';

        foreach ($sentences as $sentence) {
            if ($cur !== '' && strlen($cur) + strlen($sentence) > $maxBytes) {
                $out[] = $cur;
                $cur   = '';
            }
            $cur .= $sentence;

            while (strlen($cur) > $maxBytes) {
                $head = mb_strcut($cur, 0, $maxBytes, 'UTF-8');
                if ($head === '') {
                    break;
                }
                $out[] = $head;
                $cur   = (string)substr($cur, strlen($head));
            }
        }

        if ($cur !== '') {
            $out[] = $cur;
        }

        return $out ?: [$text];
    }

    /**
     * 按字节把单元分成若干批
     */
    protected static function groupUnits(array $units, int $maxBytes): array
    {
        $groups = [];
        $cur    = [];
        $len    = 0;

        foreach ($units as $unit) {
            $l = strlen($unit['text']) + 2;
            if ($cur && $len + $l > $maxBytes) {
                $groups[] = $cur;
                $cur      = [];
                $len      = 0;
            }
            $cur[] = $unit;
            $len  += $l;
        }

        if ($cur) {
            $groups[] = $cur;
        }

        return $groups;
    }

    // ------------------------------------------------------------------
    // HTTP
    // ------------------------------------------------------------------

    /**
     * POST 表单请求 → JSON
     */
    protected static function http(string $url, array $params, array $headers = []): array
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($params),
            CURLOPT_HTTPHEADER     => array_merge(['Content-Type: application/x-www-form-urlencoded'], $headers),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'ThinkWoCMS/1.0 (+https://thinkwo.com)',
        ]);
        $body = curl_exec($ch);
        $err  = curl_error($ch);
        // 部分服务器（尤其 Windows / 精简版 Linux）缺 CA 证书包，SSL 校验会失败 → 降级重试一次
        if ($body === false && stripos((string)$err, 'SSL') !== false) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            $body = curl_exec($ch);
            $err  = curl_error($ch);
        }
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false) {
            throw new \RuntimeException('翻译请求失败: ' . $err);
        }

        $data = json_decode((string)$body, true);
        if (!is_array($data)) {
            throw new \RuntimeException('翻译返回解析失败 (HTTP ' . $code . ')');
        }

        return $data;
    }

    /**
     * GET 请求 → 原始响应体
     */
    protected static function httpGet(string $url, int $timeout = 30): string
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => min(10, $timeout),
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
        ]);
        $body = curl_exec($ch);
        $err  = curl_error($ch);
        if ($body === false && stripos((string)$err, 'SSL') !== false) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            $body = curl_exec($ch);
            $err  = curl_error($ch);
        }
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false) {
            throw new \RuntimeException('翻译请求失败: ' . $err);
        }
        if ($code >= 400) {
            throw new \RuntimeException('翻译接口 HTTP ' . $code);
        }

        return (string)$body;
    }

    // ------------------------------------------------------------------
    // 语言代码映射
    // ------------------------------------------------------------------

    protected static function mapCode(string $driver, string $code): string
    {
        $code = strtolower(trim($code));
        if ($code === '' || $code === 'auto') {
            return $driver === 'deepl' || $driver === 'google' ? 'auto' : 'auto';
        }

        $map = [
            'baidu' => [
                'zh-cn' => 'zh', 'zh-tw' => 'cht', 'zh' => 'zh',
                'ja' => 'jp', 'ko' => 'kor', 'fr' => 'fra', 'es' => 'spa',
                'ar' => 'ara', 'th' => 'th', 'el' => 'el', 'nl' => 'nl', 'pl' => 'pl',
            ],
            'youdao' => [
                'zh-cn' => 'zh-CHS', 'zh-tw' => 'zh-CHT', 'zh' => 'zh-CHS',
                'ja' => 'ja', 'ko' => 'ko', 'fr' => 'fr', 'es' => 'es',
                'ar' => 'ar', 'th' => 'th', 'ru' => 'ru', 'pt' => 'pt',
            ],
            'deepl' => [
                'zh-cn' => 'ZH', 'zh-tw' => 'ZH', 'zh' => 'ZH',
                'en-us' => 'EN-US', 'en-gb' => 'EN-GB', 'en' => 'EN',
                'pt-br' => 'PT-BR', 'pt-pt' => 'PT-PT', 'pt' => 'PT-PT',
            ],
            'google' => [
                'zh' => 'zh-CN', 'zh-cn' => 'zh-CN', 'zh-tw' => 'zh-TW', 'zh-hk' => 'zh-TW',
                'en' => 'en', 'en-us' => 'en', 'en-gb' => 'en',
                'ja' => 'ja', 'ko' => 'ko', 'fr' => 'fr', 'de' => 'de', 'es' => 'es',
                'pt' => 'pt', 'pt-br' => 'pt', 'ru' => 'ru', 'ar' => 'ar', 'th' => 'th',
                'vi' => 'vi', 'it' => 'it', 'nl' => 'nl', 'pl' => 'pl', 'tr' => 'tr',
                'id' => 'id', 'ms' => 'ms', 'he' => 'iw', 'hi' => 'hi',
            ],
        ];

        // mymemory 与 google 同一套语言码
        $key = $driver === 'mymemory' ? 'google' : $driver;

        $d = $map[$key][$code] ?? null;
        if ($d !== null) {
            return $d;
        }

        $base = explode('-', $code)[0];

        return $driver === 'deepl' ? strtoupper($base) : $base;
    }

    /**
     * 测试连通性（后台设置页/语言页「测试」用）
     */
    public static function test(): string
    {
        $driver = self::driver();
        if ($driver === 'none') {
            return '当前离线复制模式：不调用翻译接口，只同步内容结构（多语言 SEO 不建议）';
        }

        $prefix = '';
        if ($driver === 'auto') {
            $driver = self::resolveAuto();
            $prefix = '自动模式命中「' . self::label($driver) . '」；';
        } elseif (self::needKey($driver) && (string)Settings::get('translate_appid', '') === '') {
            return self::label($driver) . ' 需要密钥，请先填写 APPID / Key';
        }

        $start = microtime(true);
        $res   = self::strings(['Hello world, this is a translation test.'], 'en', 'zh-cn');
        $ms    = (int)round((microtime(true) - $start) * 1000);

        return $prefix . self::label($driver) . ' 正常（' . $ms . 'ms）：Hello world → ' . ($res[0] ?? '');
    }
}
