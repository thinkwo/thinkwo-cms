<?php

declare(strict_types=1);

namespace app\common\library;

use PHPMailer\PHPMailer\PHPMailer;

/**
 * 邮件发送（复用后台 SMTP 设置）
 */
class Mailer
{
    /**
     * 发送邮件
     *
     * @param string $to      收件人
     * @param string $subject 主题
     * @param string $body    HTML 正文
     * @param string $toName  收件人名称
     * @return array{ok:bool,msg:string}
     */
    public static function send(string $to, string $subject, string $body, string $toName = ''): array
    {
        $host = (string)Settings::get('smtp_host', '');
        $user = (string)Settings::get('smtp_user', '');
        $pass = (string)Settings::get('smtp_pass', '');

        if ($host === '' || $user === '') {
            return ['ok' => false, 'msg' => '未配置 SMTP，请到「站点设置 → 邮件」填写'];
        }

        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return ['ok' => false, 'msg' => '收件邮箱格式不正确：' . $to];
        }

        if (!class_exists(PHPMailer::class)) {
            return ['ok' => false, 'msg' => '缺少 PHPMailer 依赖，请执行 composer install'];
        }

        try {
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host       = $host;
            $mail->SMTPAuth   = true;
            $mail->Username   = $user;
            $mail->Password   = $pass;
            $mail->Port       = (int)Settings::get('smtp_port', 465);
            $secure           = (string)Settings::get('smtp_secure', 'ssl');
            $mail->SMTPSecure = $secure === 'tls' ? PHPMailer::ENCRYPTION_STARTTLS : ($secure === 'none' ? '' : PHPMailer::ENCRYPTION_SMTPS);
            $mail->CharSet    = 'UTF-8';
            $mail->Timeout    = 15;

            $from     = (string)Settings::get('smtp_from', $user);
            $fromName = (string)Settings::get('smtp_from_name', Settings::get('site_name', ''));
            $mail->setFrom($from, $fromName);
            $mail->addAddress($to, $toName);

            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $body;
            $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $body));

            $mail->send();

            return ['ok' => true, 'msg' => '已发送'];
        } catch (\Throwable $e) {
            return ['ok' => false, 'msg' => '发送失败：' . $e->getMessage()];
        }
    }

    /**
     * 用统一模板包裹正文
     */
    public static function wrap(string $title, string $html): string
    {
        $site = (string)Settings::get('site_name', 'ThinkWo');

        return '<div style="background:#f5f6f8;padding:24px;font-family:-apple-system,Segoe UI,Arial,sans-serif">'
            . '<div style="max-width:640px;margin:0 auto;background:#fff;border-radius:10px;overflow:hidden">'
            . '<div style="background:#182e65;color:#fff;padding:18px 24px;font-size:16px">' . tw_e($site) . '</div>'
            . '<div style="padding:24px;font-size:14px;color:#333;line-height:1.8">'
            . '<h2 style="font-size:16px;margin:0 0 16px;color:#182e65">' . tw_e($title) . '</h2>'
            . $html
            . '</div></div></div>';
    }
}
