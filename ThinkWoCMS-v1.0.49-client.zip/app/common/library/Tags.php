<?php

declare(strict_types=1);

namespace app\common\library;

use app\common\library\Currency;
use think\facade\Db;

/**
 * 模板标签的数据来源
 *
 * 标签库只负责把参数翻译成对这里的调用，
 * 真正的查询逻辑集中在本文档，方便二次开发与缓存优化。
 */
class Tags
{
    /**
     * 当前请求上下文（由前台控制器注入）
     */
    protected static array $ctx = [];

    /**
     * 注入上下文
     */
    public static function context(array $ctx): void
    {
        self::$ctx = array_merge(self::$ctx, $ctx);
    }

    /**
     * 读取上下文
     */
    public static function ctx(string $key, $default = null)
    {
        return self::$ctx[$key] ?? $default;
    }

    /**
     * 栏目列表
     *
     * @param int $parent 上级栏目ID，0 为顶级
     * @param int $limit  数量限制，0 不限
     */
    public static function nav(int $parent = 0, int $limit = 0): array
    {
        try {
            $query = Db::name('sort')
                ->where('lang', Lang::code())
                ->where('pid', $parent)
                ->where('status', 1)
                ->order('sort asc, id asc');
            if ($limit > 0) {
                $query->limit($limit);
            }
            $rows = $query->select()->toArray();
        } catch (\Throwable $e) {
            return [];
        }

        $currentId = (int)(self::ctx('sort')['id'] ?? 0);

        foreach ($rows as &$row) {
            $row['url']    = $row['type'] === 'link' && $row['link'] !== '' ? $row['link'] : TwUrl::sort($row);
            $row['target'] = $row['type'] === 'link' ? ' target="_blank" rel="noopener"' : '';
            $row['active'] = $currentId > 0 && (int)$row['id'] === $currentId ? 1 : 0;
            $row['son']    = self::hasChildren((int)$row['id']);
        }
        unset($row);

        return $rows;
    }

    /**
     * 是否有子栏目
     */
    public static function hasChildren(int $sortId): int
    {
        try {
            return (int)Db::name('sort')->where('pid', $sortId)->where('lang', Lang::code())->where('status', 1)->count() > 0 ? 1 : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * 取单个栏目
     *
     * $id > 0 按ID取；否则 $slug 非空按当前语言 + slug 取
     */
    public static function sort(int $id, string $slug = ''): ?array
    {
        try {
            if ($id > 0) {
                $row = Db::name('sort')->where('id', $id)->find();
            } elseif ($slug !== '') {
                $row = Db::name('sort')->where('slug', $slug)->where('lang', Lang::code())->find();
            } else {
                return null;
            }
        } catch (\Throwable $e) {
            return null;
        }
        if (!$row) {
            return null;
        }

        $row['url'] = $row['type'] === 'link' && $row['link'] !== '' ? $row['link'] : TwUrl::sort($row);
        $row['children'] = self::nav((int)$row['id']);

        return $row;
    }

    /**
     * 多行文本拆成数组（通用：把 <br>、</p>、真实换行统一按行拆分，
     * 供模板「一行一条」的清单类版式使用，如功能清单、卖点列表）
     */
    public static function textLines(string $html): array
    {
        if (trim($html) === '') {
            return [];
        }
        $txt = preg_replace('/<br\s*\/?>/i', "\n", $html);
        $txt = preg_replace('/<\/(p|li|div|h[1-6])>/i', "\n", (string)$txt);
        $txt = strip_tags((string)$txt);
        $txt = html_entity_decode((string)$txt, ENT_QUOTES, 'UTF-8');
        $raw = preg_split('/\r\n|\r|\n/', (string)$txt) ?: [];
        return array_values(array_filter(array_map('trim', $raw), static fn($v) => $v !== ''));
    }

    /**
     * 内容列表
     *
     * 支持参数：
     *   sort    栏目ID / '*' 全部 / slug
     *   limit   数量
     *   page    当前页（0 表示不分页）
     *   order   排序，默认 publish_time desc
     *   attr    推荐属性筛选 recommend/hot/new
     *   tags    标签筛选
     *   keyword 关键词搜索
     *   exclude 排除的ID
     */
    public static function lists(array $opt): array
    {
        $page    = max(0, (int)($opt['page'] ?? 0));
        $limit   = max(1, (int)($opt['limit'] ?? 12));
        $sortIds = self::resolveSortIds($opt['sort'] ?? null);
        $result  = ['list' => [], 'total' => 0, 'page' => null];

        if ($sortIds === []) {
            return $result;
        }

        $build = function () use ($sortIds, $opt) {
            $q = Db::name('content')
                ->where('lang', Lang::code())
                ->where('status', 1);

            if ($sortIds !== ['*']) {
                $q->whereIn('sort_id', $sortIds);
            }
            if (!empty($opt['attr'])) {
                $q->whereLike('attr', '%' . (string)$opt['attr'] . '%');
            }
            if (!empty($opt['tags'])) {
                $q->whereLike('tags', '%' . (string)$opt['tags'] . '%');
            }
            if (!empty($opt['keyword'])) {
                $kw = (string)$opt['keyword'];
                $q->where(function ($sub) use ($kw) {
                    $sub->whereLike('title', '%' . $kw . '%')
                        ->whereOr('summary', 'like', '%' . $kw . '%')
                        ->whereOr('tags', 'like', '%' . $kw . '%');
                });
            }
            if (!empty($opt['exclude'])) {
                $ex = array_filter(array_map('intval', (array)$opt['exclude']));
                if ($ex) {
                    $q->whereNotIn('id', $ex);
                }
            }

            return $q;
        };

        $order = (string)($opt['order'] ?? 'publish_time desc, id desc');
        $allow = ['publish_time', 'id', 'views', 'sort', 'price'];
        $parts = explode(',', $order);
        $clean = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part === '') {
                continue;
            }
            $pieces = preg_split('/\s+/', $part);
            $field  = $pieces[0] ?? '';
            $dir    = strtolower($pieces[1] ?? 'desc') === 'asc' ? 'asc' : 'desc';
            if (in_array($field, $allow, true)) {
                $clean[] = $field . ' ' . $dir;
            }
        }
        if (!$clean) {
            $clean[] = 'id desc';
        }

        try {
            $total = (int)$build()->count();
            $list  = $build()
                ->field('id,lang,sort_id,title,slug,subtitle,ico,summary,content,tags,views,price,unit,model_no,moq,meta,attr,author,publish_time,createtime,updatetime')
                ->order(implode(',', $clean))
                ->limit($page > 0 ? ($page - 1) * $limit : 0, $limit)
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            return $result;
        }

        $sortMap = self::sortSlugMap();
        foreach ($list as &$row) {
            $sortRow = $sortMap[(int)$row['sort_id']] ?? null;

            $row['url']       = TwUrl::detail($row, $sortRow);
            $row['ico']       = ImageTool::webpUrl((string)$row['ico']);
            $row['date']      = tw_date((int)($row['publish_time'] ?: $row['createtime']), 'M d, Y');
            $row['datetime']  = date('Y-m-d', (int)($row['publish_time'] ?: $row['createtime']));
            $row['sort_url']  = TwUrl::sort($sortRow ?? (string)$row['sort_id']);
            $row['sort_name'] = (string)($sortRow['name'] ?? '');
            $row['sort_slug'] = (string)($sortRow['slug'] ?? '');
            $row['lines']     = self::textLines((string)($row['content'] ?? ''));
            $row              = self::parseCf($row);
        }
        unset($row);

        $result['list']  = $list;
        $result['total'] = $total;

        if ($page > 0) {
            $result['page'] = self::pageInfo($page, $limit, $total);
        }

        return $result;
    }

    /**
     * 解析栏目参数为ID集合
     */
    protected static function resolveSortIds($sort): array
    {
        if ($sort === '*' || $sort === null) {
            return ['*'];
        }

        // 当前栏目
        if ($sort === '' || $sort === true) {
            $id = (int)(self::ctx('sort')['id'] ?? 0);
            if ($id <= 0) {
                return ['*'];
            }
            $sort = $id;
        }

        if (is_numeric($sort)) {
            $id = (int)$sort;

            // 包含子栏目
            $all  = self::allSorts();
            $ids  = array_merge([$id], Tree::childrenIds($all, $id));

            return array_values(array_unique($ids));
        }

        // 按 slug 查
        try {
            $row = Db::name('sort')->where('slug', (string)$sort)->where('lang', Lang::code())->find();
        } catch (\Throwable $e) {
            return [];
        }

        return $row ? [(int)$row['id']] : [];
    }

    /**
     * 全部栏目（当前语言）
     */
    public static function allSorts(): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        try {
            $cache = Db::name('sort')->where('lang', Lang::code())->where('status', 1)->order('sort asc, id asc')->select()->toArray();
        } catch (\Throwable $e) {
            $cache = [];
        }

        return $cache;
    }

    /**
     * 栏目ID => 栏目
     */
    public static function sortSlugMap(): array
    {
        $map = [];
        foreach (self::allSorts() as $row) {
            $map[(int)$row['id']] = $row;
        }

        return $map;
    }

    /**
     * 取单条内容
     *
     * @param int  $id   内容ID，0 表示取当前上下文
     * @param bool $auto 是否自动补全 url / date 等派生字段
     */
    public static function content(int $id, bool $auto = true): ?array
    {
        if ($id <= 0) {
            $ctx = self::ctx('content');

            return $ctx ?: null;
        }

        try {
            $row = Db::name('content')->where('id', $id)->where('status', 1)->find();
        } catch (\Throwable $e) {
            return null;
        }

        if (!$row) {
            return null;
        }

        if ($auto) {
            $row = self::decorateContent($row);
        }

        return $row;
    }

    /**
     * 给内容补充派生字段
     */
    public static function decorateContent(array $row): array
    {
        $sortMap = self::sortSlugMap();
        $sort    = $sortMap[(int)$row['sort_id']] ?? null;

        $row['url']      = TwUrl::detail($row, $sort);
        $row['date']     = tw_date((int)($row['publish_time'] ?: $row['createtime']), 'M d, Y');
        $row['datetime'] = date('Y-m-d', (int)($row['publish_time'] ?: $row['createtime']));
        $row['ico']      = ImageTool::webpUrl((string)($row['ico'] ?? ''));
        $row['sort']     = $sort;
        $row['images']   = is_string($row['images'] ?? null) && $row['images'] !== ''
            ? (array)json_decode((string)$row['images'], true)
            : (is_array($row['images'] ?? null) ? $row['images'] : []);

        // 标签拆成数组，模板里直接 {volist name="content.tag_list" id="tag"}
        $row['tag_list'] = isset($row['tags']) && $row['tags'] !== ''
            ? array_values(array_filter(array_map('trim', explode(',', (string)$row['tags']))))
            : [];

        // 栏目自定义字段（v1.0.44）：详情页 $content.字段键 / $content.cf.字段键
        $row = self::parseCf($row);

        return $row;
    }

    /**
     * 解析 meta 里的自定义字段 JSON（v1.0.44）
     *
     * 栏目定义了自定义字段后，值以 JSON 存在 meta 列。这里解析回数组：
     *   - $row['cf']       全部字段键值数组，模板可 {volist name="list.cf" id="v" key="k"}
     *   - $row['字段键']    顶层合并，模板直接 $list.price_text 这样取（不覆盖内置列）
     * meta 不是 JSON（老的纯文本扩展）时保持原样，$list.meta 仍取原文。
     */
    public static function parseCf(array $row): array
    {
        $row['cf'] = [];
        $meta = (string)($row['meta'] ?? '');
        if ($meta !== '' && $meta[0] === '{') {
            $data = json_decode($meta, true);
            if (is_array($data)) {
                $row['cf'] = $data;
                foreach ($data as $k => $v) {
                    $k = (string)$k;
                    if (is_scalar($v) && $k !== '' && !array_key_exists($k, $row)) {
                        $row[$k] = $v;
                    }
                }
            }
        }

        return $row;
    }

    /**
     * 分页信息
     */
    public static function pageInfo(int $page, int $limit, int $total): array
    {
        $last = max(1, (int)ceil($total / max(1, $limit)));

        return [
            'current' => $page,
            'last'    => $last,
            'limit'   => $limit,
            'total'   => $total,
            'has_prev' => $page > 1,
            'has_next' => $page < $last,
        ];
    }

    /**
     * 分页条 HTML（可被模板 {tw:pagination /} 直接输出）
     */
    public static function pagination(?array $page, int $range = 2): string
    {
        if (!$page || ($page['last'] ?? 1) <= 1) {
            return '';
        }

        $sort = self::ctx('sort');
        $cur  = (int)$page['current'];
        $last = (int)$page['last'];

        $link = static function (int $p) use ($sort): string {
            if (!$sort) {
                return TwUrl::search() . '?page=' . $p;
            }

            return TwUrl::sort($sort, $p);
        };

        $html = '<nav class="tw-pager" aria-label="pagination">';
        if ($page['has_prev']) {
            $html .= '<a class="tw-pager-item" rel="prev" href="' . tw_e($link($cur - 1)) . '">&laquo;</a>';
        }

        $start = max(1, $cur - $range);
        $end   = min($last, $cur + $range);

        if ($start > 1) {
            $html .= '<a class="tw-pager-item" href="' . tw_e($link(1)) . '">1</a>';
            if ($start > 2) {
                $html .= '<span class="tw-pager-dot">…</span>';
            }
        }

        for ($i = $start; $i <= $end; $i++) {
            $active = $i === $cur ? ' is-active' : '';
            $html  .= '<a class="tw-pager-item' . $active . '" href="' . tw_e($link($i)) . '">' . $i . '</a>';
        }

        if ($end < $last) {
            if ($end < $last - 1) {
                $html .= '<span class="tw-pager-dot">…</span>';
            }
            $html .= '<a class="tw-pager-item" href="' . tw_e($link($last)) . '">' . $last . '</a>';
        }

        if ($page['has_next']) {
            $html .= '<a class="tw-pager-item" rel="next" href="' . tw_e($link($cur + 1)) . '">&raquo;</a>';
        }

        $html .= '</nav>';

        return $html;
    }

    /**
     * 面包屑 HTML
     */
    public static function position(string $separator = ' / '): string
    {
        $items = (array)self::ctx('position', []);
        if (!$items) {
            return '';
        }

        $parts = [];
        $count = count($items);
        $i     = 0;
        foreach ($items as $item) {
            $i++;
            $name = tw_e((string)$item['name']);
            if ($i === $count || empty($item['url'])) {
                $parts[] = '<span aria-current="page">' . $name . '</span>';
            } else {
                $parts[] = '<a href="' . tw_e((string)$item['url']) . '">' . $name . '</a>';
            }
        }

        return '<nav class="tw-crumb" aria-label="breadcrumb">' . implode('<em>' . tw_e($separator) . '</em>', $parts) . '</nav>';
    }

    /**
     * 语言切换数据
     */
    public static function langs(): array
    {
        $result = [];
        foreach (Lang::all() as $code => $lang) {
            $result[] = [
                'code'    => $code,
                'name'    => (string)($lang['native_name'] ?: $lang['name']),
                'region'  => (string)($lang['region'] ?: $code),
                'url'     => TwUrl::switchLang($code),
                'active'  => $code === Lang::code() ? 1 : 0,
            ];
        }

        return $result;
    }

    /**
     * 货币切换数据
     */
    public static function currencies(): array
    {
        $result = [];
        foreach (Currency::all() as $row) {
            $result[] = [
                'code'     => (string)$row['code'],
                'name'     => (string)$row['name'],
                'symbol'   => (string)$row['symbol'],
                'active'   => Currency::code() === (string)$row['code'] ? 1 : 0,
            ];
        }

        return $result;
    }

    /**
     * 推荐内容（按 attr）
     */
    public static function attr(string $attr, int $limit = 6, $sort = null): array
    {
        $r = self::lists([
            'sort'  => $sort ?? '*',
            'attr'  => $attr,
            'limit' => $limit,
        ]);

        return $r['list'];
    }

    /**
     * 上一条 / 下一条
     */
    public static function nearby(int $sortId, int $publishTime, int $id, string $dir = 'next'): ?array
    {
        try {
            $q = Db::name('content')->where('lang', Lang::code())->where('status', 1)->where('sort_id', $sortId);
            if ($dir === 'next') {
                $q->where('publish_time', '>', $publishTime);
                $row = $q->order('publish_time asc, id asc')->find();
            } else {
                $q->where('publish_time', '<', $publishTime);
                $row = $q->order('publish_time desc, id desc')->find();
            }
        } catch (\Throwable $e) {
            return null;
        }

        if (!$row || (int)$row['id'] === $id) {
            return null;
        }

        $row['url'] = TwUrl::detail($row, self::sortSlugMap()[$sortId] ?? null);

        return $row;
    }

    /**
     * 跨语言同内容地址（hreflang 用）
     */
    public static function translateUrls(string $transKey, array $sortMap = []): array
    {
        if ($transKey === '') {
            return [];
        }

        try {
            $rows = Db::name('content')
                ->where('trans_key', $transKey)
                ->where('status', 1)
                ->field('lang,id,slug,sort_id')
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            return [];
        }

        $map = [];
        foreach ($rows as $row) {
            $sort = $sortMap[(int)$row['sort_id']] ?? null;
            $map[(string)$row['lang']] = TwUrl::detail($row, $sort, (string)$row['lang']);
        }

        return $map;
    }

    /**
     * 同栏目的跨语言地址（栏目页 hreflang）
     */
    public static function translateSortUrls(string $transKey): array
    {
        if ($transKey === '') {
            return [];
        }

        try {
            $rows = Db::name('sort')->where('trans_key', $transKey)->where('status', 1)->field('lang,slug,type')->select()->toArray();
        } catch (\Throwable $e) {
            return [];
        }

        $map = [];
        foreach ($rows as $row) {
            $map[(string)$row['lang']] = TwUrl::sort($row, 1, (string)$row['lang']);
        }

        return $map;
    }

    // -----------------------------------------------------------------------
    // 幻灯片
    // -----------------------------------------------------------------------

    /**
     * 幻灯片分组原始记录（按 code 或 id，带请求内缓存）
     */
    protected static function slideGroupRow(string $group): ?array
    {
        static $cache = [];

        $group = trim($group);
        if ($group === '') {
            return null;
        }

        if (array_key_exists($group, $cache)) {
            return $cache[$group];
        }

        try {
            $q = Db::name('slide_group')->where('status', 1);
            $row = ctype_digit($group)
                ? $q->where('id', (int)$group)->find()
                : $q->where('code', $group)->find();
        } catch (\Throwable $e) {
            return $cache[$group] = null; // 老站没建表时不要报错，模板照常渲染
        }

        return $cache[$group] = ($row ?: null);
    }

    /**
     * 取一个分组（含 count 数量），模板 {tw:slidegroup code="home" /} 用
     *
     * 不写 code 时取当前栏目绑定的分组（栏目管理 → 幻灯片分组）
     */
    public static function slideGroup(string $group = ''): ?array
    {
        $group = trim($group);
        if ($group === '') {
            $cur   = self::ctx('sort');
            $group = (string)($cur['slide_group'] ?? '');
            if ($group === '') {
                return null;
            }
        }

        $g = self::slideGroupRow($group);
        if (!$g) {
            return null;
        }

        $g['count'] = count(self::slides(['group' => (string)$g['id']]));

        return $g;
    }

    /**
     * 幻灯片列表
     *
     * 参数：
     *   group  分组 code 或 id
     *   limit  数量，0 不限
     *   order  排序，默认 sort asc, id asc
     *   lang   语言，默认当前语言
     *
     * 多语言策略：当前语言这个分组没有启用的幻灯片时，整组回退默认语言，
     * 这样只做一个语言的站不用为每种语言重复上传同一张图。
     */
    public static function slides(array $opt = []): array
    {
        static $cache = [];

        $group = trim((string)($opt['group'] ?? ''));
        if ($group === '') {
            // 模板里没写 group：取当前栏目绑定的分组（栏目表单里的「幻灯片分组」），
            // 这样同一套内页模板可以给不同栏目配不同的 banner，不用在模板里写死。
            $cur   = self::ctx('sort');
            $group = (string)($cur['slide_group'] ?? '');
            if ($group === '') {
                return [];
            }
        }
        $limit = (int)($opt['limit'] ?? 0);
        $order = preg_replace('/[^a-zA-Z0-9_,. ]/', '', (string)($opt['order'] ?? '')) ?: 'sort asc, id asc';
        $lang  = (string)($opt['lang'] ?? Lang::code());
        if ($lang === '') {
            $lang = Lang::defaultCode();
        }

        $g = self::slideGroupRow($group);
        if (!$g) {
            return [];
        }

        $key = (int)$g['id'] . '|' . $lang . '|' . $limit . '|' . $order;
        if (isset($cache[$key])) {
            return $cache[$key];
        }

        $rows = self::querySlides((int)$g['id'], $lang, $limit, $order);
        if (!$rows && $lang !== Lang::defaultCode()) {
            $rows = self::querySlides((int)$g['id'], Lang::defaultCode(), $limit, $order);
        }

        $total = count($rows);
        foreach ($rows as $i => &$row) {
            $row['index']       = $i + 1;
            $row['first']       = $i === 0 ? 1 : 0;
            $row['last']        = $i === $total - 1 ? 1 : 0;
            $row['target_attr'] = ((string)($row['target'] ?? '_self') === '_blank') ? ' target="_blank" rel="noopener"' : '';
            $row['image_url']   = (string)($row['image'] ?? '');
            $row['mobile_image'] = (string)($row['image_mobile'] ?? '');
            $row['has_video']   = (string)($row['video'] ?? '') !== '' ? 1 : 0;
            $row['has_image']   = (string)($row['image'] ?? '') !== '' ? 1 : 0;
        }
        unset($row);

        return $cache[$key] = $rows;
    }

    /**
     * 按分组 + 语言 + 时间窗查条目
     */
    protected static function querySlides(int $groupId, string $lang, int $limit, string $order): array
    {
        $now = time();

        try {
            $q = Db::name('slide')
                ->where('group_id', $groupId)
                ->where('lang', $lang)
                ->where('status', 1)
                ->whereRaw('(start_time = 0 OR start_time <= ' . $now . ')')
                ->whereRaw('(end_time = 0 OR end_time >= ' . $now . ')')
                ->order($order);
            if ($limit > 0) {
                $q->limit($limit);
            }

            return $q->select()->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }
}
