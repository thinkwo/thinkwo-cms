<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Db;

/**
 * 多货币
 *
 * - 汇率以「默认货币 = 1」为基准（后台维护）
 * - 前台货币存 cookie tw_cur，tw_price() 自动换算输出
 */
class Currency
{
    protected static ?array $rows = null;

    /**
     * 启用的货币列表
     */
    public static function all(): array
    {
        if (self::$rows !== null) {
            return self::$rows;
        }

        try {
            $rows = Db::name('currency')
                ->where('status', 1)
                ->order('sort asc, id asc')
                ->select()
                ->toArray();
        } catch (\Throwable $e) {
            $rows = [];
        }

        self::$rows = $rows;

        return $rows;
    }

    /**
     * 默认（基准）货币，rate 恒为 1
     */
    public static function base(): array
    {
        foreach (self::all() as $row) {
            if ((int)$row['is_default'] === 1) {
                return $row;
            }
        }

        return self::all()[0] ?? [
            'code' => 'USD', 'symbol' => '$', 'name' => 'US Dollar',
            'rate' => 1, 'decimals' => 2,
        ];
    }

    /**
     * 当前浏览货币（cookie，缺省为基准货币）
     */
    public static function current(): array
    {
        $all = self::all();
        if (!$all) {
            return self::base();
        }

        $code = strtoupper((string)request()->cookie('tw_cur', ''));
        foreach ($all as $row) {
            if (strtoupper((string)$row['code']) === $code) {
                return $row;
            }
        }

        return self::base();
    }

    /**
     * 当前货币代码
     */
    public static function code(): string
    {
        return (string)self::current()['code'];
    }

    /**
     * 基准货币金额 → 当前货币格式化字符串，例如 €92.00
     */
    public static function format(float $amount, ?string $code = null, string $unit = ''): string
    {
        $row = $code !== null ? self::find($code) : self::current();
        if (!$row) {
            $row = self::base();
        }

        $rate     = max(0.000001, (float)$row['rate']);
        $decimals = max(0, min(4, (int)($row['decimals'] ?? 2)));
        $value    = $amount * $rate;

        $str = (string)$row['symbol'] . number_format($value, $decimals, '.', ',');
        if ($unit !== '') {
            $str .= ' / ' . $unit;
        }

        return $str;
    }

    /**
     * 按代码找货币
     */
    public static function find(string $code): ?array
    {
        $code = strtoupper($code);
        foreach (self::all() as $row) {
            if (strtoupper((string)$row['code']) === $code) {
                return $row;
            }
        }

        return null;
    }

    /**
     * 是否启用多货币（>1 种时前台才显示切换器）
     */
    public static function enabled(): bool
    {
        return count(self::all()) > 1;
    }

    public static function flush(): void
    {
        self::$rows = null;
    }
}
