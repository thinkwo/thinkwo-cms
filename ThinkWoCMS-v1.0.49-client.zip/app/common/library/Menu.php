<?php

declare(strict_types=1);

namespace app\common\library;

use think\facade\Db;

/**
 * 后台菜单与权限规则
 *
 * 菜单定义在 app/admin/menu.php，安装或升级后自动同步到 tw_admin_rule 表。
 * 插件可通过 Plugin::listen('admin_menu', ...) 追加菜单。
 */
class Menu
{
    /**
     * menu.php 的绝对路径
     *
     * 注意：多应用模式下 app_path() 会被切换到子应用目录（app/admin/），
     * 必须用容器根 basePath（app/），否则后台请求里永远找不到 menu.php，
     * 菜单同步会静默失效（首次安装后菜单为空的根源）。
     */
    protected static function menuFile(): string
    {
        return app()->getBasePath() . 'admin' . DIRECTORY_SEPARATOR . 'menu.php';
    }

    /**
     * 同步菜单到数据库（按 name 去重）
     */
    public static function sync(): void
    {
        $file = self::menuFile();
        if (!is_file($file)) {
            return;
        }

        $items = include $file;
        if (!is_array($items)) {
            return;
        }

        // 插件追加
        foreach (Plugin::run('admin_menu') as $extra) {
            if (is_array($extra)) {
                $items = array_merge($items, $extra);
            }
        }

        self::saveTree($items, 0);

        Settings::set('menu_version', (string)config('tw.version', '1.0.0'), 'system');
    }

    /**
     * 递归写入
     */
    protected static function saveTree(array $items, int $pid): void
    {
        $sort = 0;
        foreach ($items as $item) {
            $sort++;
            $name = (string)($item['name'] ?? '');
            if ($name === '') {
                continue;
            }

            $data = [
                'pid'    => $pid,
                'type'   => (string)($item['type'] ?? 'menu'),
                'title'  => (string)($item['title'] ?? $name),
                'name'   => $name,
                'path'   => (string)($item['path'] ?? ''),
                'icon'   => (string)($item['icon'] ?? ''),
                'sort'   => (int)($item['sort'] ?? $sort),
                'status' => (int)($item['status'] ?? 1),
                'plugin' => (string)($item['plugin'] ?? ''),
            ];

            $exists = Db::name('admin_rule')->where('name', $name)->find();
            if ($exists) {
                Db::name('admin_rule')->where('id', $exists['id'])->update($data);
                $id = (int)$exists['id'];
            } else {
                $data['createtime'] = time();
                $id = (int)Db::name('admin_rule')->insertGetId($data);
            }

            $children = $item['children'] ?? [];
            if (is_array($children) && $children) {
                self::saveTree($children, $id);
            }
        }
    }

    /**
     * 全部规则（扁平）
     */
    public static function all(): array
    {
        try {
            return Db::name('admin_rule')->order('sort asc, id asc')->select()->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * 当前管理员可见的菜单树
     */
    public static function tree(): array
    {
        $all = self::all();

        // 自愈：规则表为空时补一次同步（防止安装后首次同步被异常打断后永远空菜单）
        if (!$all && is_file(self::menuFile())) {
            try {
                self::sync();
                $all = self::all();
            } catch (\Throwable $e) {
                \think\facade\Log::error('菜单自动补同步失败: ' . $e->getMessage());
            }
        }

        if (!$all) {
            return [];
        }

        if (!Auth::isSuper()) {
            $group = Auth::group();
            $ids   = array_filter(array_map('intval', explode(',', (string)($group['rules'] ?? ''))));
            $all   = array_values(array_filter($all, static function ($row) use ($ids) {
                return in_array((int)$row['id'], $ids, true);
            }));
        }

        $menus = [];
        foreach ($all as $row) {
            if ((int)$row['status'] === 1 && $row['type'] === 'menu') {
                $menus[] = $row;
            }
        }

        return Tree::build($menus, 0);
    }

    /**
     * 供角色组勾选用的树
     */
    public static function flatOptions(): array
    {
        $tree = Tree::build(self::all(), 0);

        return Tree::flatten($tree);
    }

    /**
     * 菜单版本是否需要同步（版本变化，或规则表为空时都需要）
     */
    public static function needSync(): bool
    {
        $ver = (string)Settings::get('menu_version', '');
        if ($ver !== (string)config('tw.version', '1.0.0')) {
            return true;
        }

        // 版本一致但规则表为空（如同步曾被异常打断），同样需要补
        try {
            return (int)Db::name('admin_rule')->count() === 0;
        } catch (\Throwable $e) {
            return false;
        }
    }
}
