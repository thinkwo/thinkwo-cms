<?php

declare(strict_types=1);

namespace app\common\taglib;

use think\template\TagLib;

/**
 * ThinkWo 模板标签库
 *
 * 标签写法：{tw:标签名 属性="值"}...{/tw:标签名}
 * 属性值支持三种形式：
 *   1. 字符串    title="最新产品"
 *   2. 变量      parent="$sort.id"
 *   3. 表达式    :limit="$page.limit"（以冒号开头表示原样输出 PHP）
 */
class Tw extends TagLib
{
    protected $tags = [
        // 栏目导航
        'nav'        => ['attr' => 'parent,limit,alias,key', 'close' => 1],
        // 内容列表
        'list'       => ['attr' => 'sort,limit,page,order,attr,tags,keyword,exclude,alias,key', 'close' => 1],
        // 推荐内容
        'attr'       => ['attr' => 'name,limit,sort,alias,key', 'close' => 1],
        // 栏目信息
        'sort'       => ['attr' => 'id,slug,alias', 'close' => 0],
        // 内容详情
        'content'    => ['attr' => 'id,alias,auto', 'close' => 0],
        // 面包屑
        'position'   => ['attr' => '', 'close' => 0],
        // 分页条
        'pagination' => ['attr' => '', 'close' => 0],
        // 语言切换
        'lang'       => ['attr' => 'alias,key', 'close' => 1],
        // 货币切换
        'currency'   => ['attr' => 'alias,key', 'close' => 1],
        // 幻灯片列表
        'slide'      => ['attr' => 'group,limit,order,lang,alias,key', 'close' => 1],
        // 幻灯片分组信息（宽高、数量）
        'slidegroup' => ['attr' => 'code,alias', 'close' => 0],
        // SEO 头部
        'seo'        => ['attr' => '', 'close' => 0],
    ];

    /**
     * 属性值转 PHP 代码
     */
    protected function toPhp(?string $value, string $default = 'null'): string
    {
        if ($value === null) {
            return $default;
        }

        $value = trim($value);
        if ($value === '') {
            return $default;
        }

        $first = substr($value, 0, 1);

        if ($first === ':') {
            return substr($value, 1);
        }

        if ($first === '$') {
            $this->autoBuildVar($value);

            return $value;
        }

        if (is_numeric($value) || in_array($value, ['true', 'false', 'null'], true)) {
            return $value;
        }

        return var_export($value, true);
    }

    /**
     * 生成唯一变量名
     */
    protected function varName(string $prefix = 'tw'): string
    {
        return '__' . $prefix . '_' . substr(md5(uniqid('', true)), 0, 8);
    }

    /**
     * 栏目导航
     *
     * 用法：{tw:nav parent="0" limit="8"}{$nav.title}{/tw:nav}
     * 当前栏目：{tw:nav parent="$sort.id"}...{/tw:nav}
     */
    public function tagNav(array $tag, string $content): string
    {
        $parent = $this->toPhp($tag['parent'] ?? null, '0');
        $limit  = $this->toPhp($tag['limit'] ?? null, '0');
        $alias  = isset($tag['alias']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['alias']) : 'nav';
        $key    = isset($tag['key']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['key']) : 'key';
        $var    = $this->varName('nav');

        return '<?php $' . $var . ' = \app\common\library\Tags::nav(' . $parent . ', ' . $limit . ');'
            . ' foreach ($' . $var . ' as $' . $key . ' => $' . $alias . '): ?>'
            . $content
            . '<?php endforeach; unset($' . $var . '); ?>';
    }

    /**
     * 内容列表
     *
     * 用法：{tw:list sort="12" limit="9" page="1"}{$list.title}{/tw:list}
     * 分页时同时生成 $page 数组，配合 {tw:pagination /}
     */
    public function tagList(array $tag, string $content): string
    {
        $alias = isset($tag['alias']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['alias']) : 'list';
        $key   = isset($tag['key']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['key']) : 'key';

        $sort    = $this->toPhp($tag['sort'] ?? null, "''");
        $limit   = $this->toPhp($tag['limit'] ?? null, '12');
        $page    = $this->toPhp($tag['page'] ?? null, '($tw_page ?? 0)');
        $order   = $this->toPhp($tag['order'] ?? null, "'publish_time desc, id desc'");
        $attr    = $this->toPhp($tag['attr'] ?? null, "''");
        $tags    = $this->toPhp($tag['tags'] ?? null, "''");
        $keyword = $this->toPhp($tag['keyword'] ?? null, "''");
        $exclude = $this->toPhp($tag['exclude'] ?? null, '[]');

        $var = $this->varName('list');

        $options = '[\'sort\' => ' . $sort . ', \'limit\' => ' . $limit . ', \'page\' => ' . $page
            . ', \'order\' => ' . $order . ', \'attr\' => ' . $attr . ', \'tags\' => ' . $tags
            . ', \'keyword\' => ' . $keyword . ', \'exclude\' => ' . $exclude . ']';

        return '<?php $' . $var . ' = \app\common\library\Tags::lists(' . $options . ');'
            . ' $page = $' . $var . '[\'page\']; $total = $' . $var . '[\'total\'];'
            . ' foreach ($' . $var . '[\'list\'] as $' . $key . ' => $' . $alias . '): ?>'
            . $content
            . '<?php endforeach; unset($' . $var . '); ?>';
    }

    /**
     * 推荐内容
     *
     * 用法：{tw:attr name="recommend" limit="6"}{$list.title}{/tw:attr}
     */
    public function tagAttr(array $tag, string $content): string
    {
        $name  = $this->toPhp($tag['name'] ?? null, "'recommend'");
        $limit = $this->toPhp($tag['limit'] ?? null, '6');
        $sort  = $this->toPhp($tag['sort'] ?? null, "''");
        $alias = isset($tag['alias']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['alias']) : 'list';
        $key   = isset($tag['key']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['key']) : 'key';
        $var   = $this->varName('attr');

        return '<?php $' . $var . ' = \app\common\library\Tags::attr(' . $name . ', ' . $limit . ', ' . $sort . ');'
            . ' foreach ($' . $var . ' as $' . $key . ' => $' . $alias . '): ?>'
            . $content
            . '<?php endforeach; unset($' . $var . '); ?>';
    }

    /**
     * 栏目信息（不写 id 则使用当前栏目）
     */
    public function tagSort(array $tag): string
    {
        $alias = isset($tag['alias']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['alias']) : 'sort';
        $id    = $this->toPhp($tag['id'] ?? null, '0');
        $slug  = $this->toPhp($tag['slug'] ?? null, "''");

        return '<?php $' . $alias . ' = \app\common\library\Tags::sort((int)(' . $id . '), (string)(' . $slug . ')) ?: ($sort ?? []); ?>';
    }

    /**
     * 内容详情（不写 id 则使用当前内容）
     */
    public function tagContent(array $tag): string
    {
        $alias = isset($tag['alias']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['alias']) : 'content';
        $id    = $this->toPhp($tag['id'] ?? null, '0');
        $auto  = $this->toPhp($tag['auto'] ?? null, '1');

        return '<?php $' . $alias . ' = \app\common\library\Tags::content((int)(' . $id . '), (bool)' . $auto . ') ?: ($content ?? []); ?>';
    }

    /**
     * 面包屑
     */
    public function tagPosition(array $tag): string
    {
        $sep = $this->toPhp($tag['separator'] ?? null, "' / '");

        return '<?php echo \app\common\library\Tags::position(' . $sep . '); ?>';
    }

    /**
     * 分页条
     */
    public function tagPagination(array $tag): string
    {
        $range = $this->toPhp($tag['range'] ?? null, '2');

        return '<?php echo \app\common\library\Tags::pagination($page ?? null, ' . $range . '); ?>';
    }

    /**
     * 语言切换
     */
    public function tagLang(array $tag, string $content): string
    {
        $alias = isset($tag['alias']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['alias']) : 'lang';
        $key   = isset($tag['key']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['key']) : 'key';
        $var   = $this->varName('lang');

        return '<?php $' . $var . ' = \app\common\library\Tags::langs();'
            . ' foreach ($' . $var . ' as $' . $key . ' => $' . $alias . '): ?>'
            . $content
            . '<?php endforeach; unset($' . $var . '); ?>';
    }

    /**
     * 货币切换
     *
     * 用法：{tw:currency alias="cur"}...{$cur.code}...{/tw:currency}
     */
    public function tagCurrency(array $tag, string $content): string
    {
        $alias = isset($tag['alias']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['alias']) : 'cur';
        $key   = isset($tag['key']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['key']) : 'key';
        $var   = $this->varName('currency');

        return '<?php $' . $var . ' = \app\common\library\Tags::currencies();'
            . ' foreach ($' . $var . ' as $' . $key . ' => $' . $alias . '): ?>'
            . $content
            . '<?php endforeach; unset($' . $var . '); ?>';
    }

    /**
     * 幻灯片列表
     *
     * 用法：{tw:slide group="home" limit="5"}{$slide.image}{/tw:slide}
     * group 可写分组 code（home）或 id（1）；不写则用当前栏目绑定的分组
     * 可用字段：id/title/subtitle/summary/image/image_mobile/video/url/btn_text
     *           index/first/last/target_attr/has_image/has_video
     */
    public function tagSlide(array $tag, string $content): string
    {
        $alias = isset($tag['alias']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['alias']) : 'slide';
        $key   = isset($tag['key']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['key']) : 'key';

        // 不写 group：栏目可以绑自己的幻灯片分组（sort.slide_group），没绑就输出空
        $group = $this->toPhp($tag['group'] ?? null, "''");
        $limit = $this->toPhp($tag['limit'] ?? null, '0');
        $order = $this->toPhp($tag['order'] ?? null, "''");
        $lang  = $this->toPhp($tag['lang'] ?? null, "''");

        $var    = $this->varName('slide');
        $swiper = $this->varName('slideTotal');

        $options = '[\'group\' => ' . $group . ', \'limit\' => ' . $limit
            . ', \'order\' => ' . $order . ', \'lang\' => ' . $lang . ']';

        return '<?php $' . $var . ' = \app\common\library\Tags::slides(' . $options . ');'
            . ' $' . $swiper . ' = count($' . $var . ');'
            . ' foreach ($' . $var . ' as $' . $key . ' => $' . $alias . '): ?>'
            . $content
            . '<?php endforeach; unset($' . $var . ', $' . $swiper . '); ?>';
    }

    /**
     * 幻灯片分组信息
     *
     * 用法：{tw:slidegroup code="home" alias="g"}{$g.name} 共 {$g.count} 张{/tw:slidegroup}
     * 也可单独用：{tw:slidegroup code="home" /} 之后用 {$g.width} / {$g.count}
     */
    public function tagSlidegroup(array $tag): string
    {
        $alias = isset($tag['alias']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $tag['alias']) : 'g';
        $code  = $this->toPhp($tag['code'] ?? null, "''");

        return '<?php $' . $alias . ' = \app\common\library\Tags::slideGroup(' . $code . ') ?: ['
            . "'id' => 0, 'name' => '', 'code' => '', 'width' => 0, 'height' => 0, 'count' => 0, 'remark' => ''"
            . ']; ?>';
    }

    /**
     * SEO 头部标签
     */
    public function tagSeo(array $tag): string
    {
        return '<?php echo tw_seo(); ?>';
    }
}
