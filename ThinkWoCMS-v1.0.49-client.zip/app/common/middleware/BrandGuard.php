<?php

// [TW-CMS-ZW-2026-8F3A1C] ThinkWoCMS 原创代码 · 未经授权不得二次分发
// +----------------------------------------------------------------------
// | 版权兜底中间件：前台页面缺版权链接时补一个右下角小徽标
// +----------------------------------------------------------------------

declare(strict_types=1);

namespace app\common\middleware;

use app\common\library\Brand;
use think\Request;
use think\Response;

/**
 * 版权防篡改兜底
 *
 * 只在「前台 HTML 页面里一句版权链接都没有」时才动手，补一个右下角小徽标。
 * 客户自己排版、换主题、改页脚都没问题——只要版权链接还在，这个中间件
 * 一个字节都不会碰他的页面。副作用仅为一次字符串查找。
 *
 * 不做的事（很重要）：
 *   - 不改后台页面（后台版权由视图保证，且改后台属于改程序）
 *   - 不动接口 JSON / 静态资源 / 404 之外的任何二进制响应
 *   - 不阻断、不报错：任何异常都原样放行
 */
class BrandGuard
{
    public function handle(Request $request, \Closure $next): Response
    {
        $response = $next($request);

        try {
            if (!Brand::guardEnabled() || !$response instanceof Response) {
                return $response;
            }

            // 只处理 HTML
            $type = strtolower((string)$response->getHeader('content-type'));
            if ($type !== '' && !str_contains($type, 'text/html')) {
                return $response;
            }

            // 跳过后台与接口
            $path = strtolower('/' . ltrim($request->pathinfo(), '/'));
            $base = strtolower((string)$request->baseUrl());
            if (str_contains($base, 'admin') || str_starts_with($path, '/api')) {
                return $response;
            }

            $html = (string)$response->getContent();
            if ($html === '' || Brand::hasCredit($html)) {
                return $response;
            }

            // 补一条极简徽标：内联样式，不依赖站点 CSS，也不改客户任何样式
            $url   = htmlspecialchars(Brand::url(), ENT_QUOTES);
            $name  = htmlspecialchars(Brand::name(), ENT_QUOTES);
            $badge = '<a class="tw-brand-badge" href="' . $url . '" target="_blank" rel="noopener"'
                . ' style="position:fixed;right:14px;bottom:14px;z-index:9998;'
                . 'padding:6px 12px;border-radius:999px;background:rgba(17,24,39,.78);'
                . 'color:#fff;font:12px/1.5 -apple-system,BlinkMacSystemFont,\'Segoe UI\',Arial,sans-serif;'
                . 'text-decoration:none;opacity:.82">' . $name . '</a>';

            $pos = stripos($html, '</body>');
            $html = $pos !== false
                ? substr($html, 0, $pos) . $badge . substr($html, $pos)
                : $html . $badge;

            $response->content($html);
        } catch (\Throwable $e) {
            // 兜底逻辑永远不许影响页面输出
        }

        return $response;
    }
}
