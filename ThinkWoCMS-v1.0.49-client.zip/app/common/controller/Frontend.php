<?php

declare(strict_types=1);

namespace app\common\controller;

use app\BaseController;
use app\common\library\Lang;
use app\common\library\Seo;
use app\common\library\Settings;
use app\common\library\Tags;
use app\common\library\Theme;
use think\facade\View;
use think\Response;

/**
 * 前台控制器基类
 */
abstract class Frontend extends BaseController
{
    protected function initialize(): void
    {
        // 版本升级自动补表/补配置
        \app\common\library\Upgrade::run();

        Seo::reset();
    }

    /**
     * 设定模板目录为当前主题
     */
    protected function setupView(): void
    {
        $engine = View::engine();
        if (is_object($engine) && method_exists($engine, 'config')) {
            $engine->config([
                'view_path' => Theme::path(),
            ]);
        }
    }

    /**
     * 全站公共模板变量（静态版，异常处理器也会用到）
     */
    public static function siteVars(): array
    {
        $site = Settings::all();

        // 兜底默认值：后台某项没填、或设置表缺记录时，模板取 $site.xxx 不会报错
        $site = array_merge([
            'site_name'        => 'ThinkWo CMS',
            'site_title'       => '',
            'company'          => '',
            'site_description' => '',
            'site_keywords'    => '',
            'logo'             => '',
            'logo_text'        => '',
            'favicon'          => '',
            'copyright'        => '',
            'site_icp'         => '',
            'phone'            => '',
            'email'            => '',
            'address'          => '',
            'whatsapp'         => '',
            'wechat_qr'        => '',
            'currency'         => 'USD',
            'analytics_code'   => '',
            'head_code'        => '',
            'footer_code'      => '',
            'social_facebook'  => '',
            'social_linkedin'  => '',
            'social_youtube'   => '',
            'og_image'         => '',
            'seo_index_title'  => '',
        ], $site);

        // 这几项留空时回落到网站名称
        $name = (string)($site['site_name'] ?? '');
        foreach (['company', 'seo_index_title', 'logo_text'] as $k) {
            if (trim((string)($site[$k] ?? '')) === '') {
                $site[$k] = $name;
            }
        }
        if (trim((string)($site['copyright'] ?? '')) === '') {
            $site['copyright'] = '© ' . $name;
        }

        // 站点级 SEO 文案按当前语言输出（品牌名、公司名、地址等专有名词保持原文）
        foreach (['seo_index_title', 'site_description', 'site_keywords'] as $k) {
            if (trim((string)($site[$k] ?? '')) !== '') {
                $site[$k] = Lang::text((string)$site[$k]);
            }
        }

        return [
            'site'   => $site,
            'theme'  => Theme::current(),
            'navs'   => Tags::nav(0, 12),
            'langs'  => Tags::langs(),
            'lang'   => Lang::code(),
            'currencies' => Tags::currencies(),
            'region' => Lang::region(),
            'rtl'    => Lang::isRtl(),
            'is_home' => 0,
            // 询盘验证码开关（config/tw.php → inquiry.captcha），模板据此决定是否渲染验证码行
            'inq_captcha' => (bool)config('tw.inquiry.captcha', true),
        ];
    }

    /**
     * 实例版（控制器内部使用）
     */
    protected function commonVars(): array
    {
        return self::siteVars();
    }

    /**
     * 渲染模板
     */
    protected function render(string $template, array $vars = [], int $status = 200): Response
    {
        $data = array_merge($this->commonVars(), $vars);

        View::assign($data);

        // 模板名必须以 / 开头：否则模板引擎会把「控制器名」拼到前面
        // （例：fetch('index') 会去渲染 dispatch/index.html）
        $file = '/' . ltrim(str_replace('\\', '/', $template), '/');
        $html = View::fetch($file);

        return Response::create($this->injectTracker($html), 'html', $status);
    }

    /**
     * 注入访客统计脚本（所有主题通用，无需改模板）
     *
     * 注入发生在写静态缓存之前，因此缓存页同样带统计。
     */
    protected function injectTracker(string $html): string
    {
        try {
            if (!\app\common\library\Visit::enabled()) {
                return $html;
            }
        } catch (\Throwable $e) {
            return $html;
        }

        if ($this->request->isAjax() || strpos($html, '/static/track.js') !== false) {
            return $html;
        }

        $tag = '<script src="/static/track.js" defer></script>';
        $pos = strripos($html, '</body>');

        return $pos === false ? $html . $tag : substr_replace($html, $tag, $pos, 0);
    }

    /**
     * 渲染 404
     */
    protected function render404(): Response
    {
        Seo::set(['robots' => 'noindex,follow', 'title' => 'Page Not Found']);

        $vars = [
            'is_404' => 1,
        ];

        $file = Theme::path() . '404.html';
        if (!is_file($file)) {
            return Response::create('<h1>404 Not Found</h1>', 'html', 404);
        }

        return $this->render('404', $vars, 404);
    }
}
