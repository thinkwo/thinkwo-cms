<?php

declare(strict_types=1);

namespace app\common\controller;

use app\BaseController;
use app\common\library\Auth;
use app\common\library\Menu;
use think\exception\HttpResponseException;
use think\facade\View;
use think\Response;

/**
 * 后台控制器基类
 */
abstract class Backend extends BaseController
{
    /**
     * 不需要登录的方法，格式：控制器/方法 或 控制器
     */
    protected array $noNeedLogin = [];

    /**
     * 不需要鉴权的方法
     */
    protected array $noNeedRight = [];

    protected function initialize(): void
    {
        // 版本升级自动补表/补配置（一次性，执行后写 db_version 标记）
        \app\common\library\Upgrade::run();

        // 菜单版本变化时自动同步（升级或首次安装）
        try {
            if (Menu::needSync()) {
                Menu::sync();
            }
        } catch (\Throwable $e) {
            // 安装未完成时忽略，但留痕便于排障
            \think\facade\Log::error('菜单同步失败: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
        }

        $controller = strtolower((string)$this->request->controller());
        $action     = strtolower((string)$this->request->action());
        $rule       = $controller . '/' . $action;

        $free = in_array($rule, $this->noNeedLogin, true)
            || in_array($controller, $this->noNeedLogin, true)
            || in_array('*', $this->noNeedLogin, true);

        if (!$free) {
            if (!Auth::check()) {
                $this->deny('登录已过期，请重新登录', '/admin.php/login/index', 401);
            }

            $noRight = in_array($rule, $this->noNeedRight, true)
                || in_array($controller, $this->noNeedRight, true)
                || in_array('*', $this->noNeedRight, true);

            if (!$noRight && !Auth::can($rule)) {
                $this->deny('没有权限执行该操作（' . $rule . '）', '', 403);
            }
        }

        View::assign([
            'admin'      => Auth::user(),
            'menus'      => $free ? [] : Menu::tree(),
            'version'    => (string)config('tw.version', '1.0.0'),
            'meta_title' => 'ThinkWo CMS',
        ]);
    }

    /**
     * 拒绝访问
     *
     * @return never
     */
    protected function deny(string $msg, string $url = '', int $code = 403): void
    {
        if ($this->request->isAjax() || $this->request->isJson()) {
            throw new HttpResponseException(json(['code' => 0, 'msg' => $msg, 'url' => $url], $code));
        }

        if ($url !== '') {
            throw new HttpResponseException(redirect($url));
        }

        throw new HttpResponseException(Response::create($msg, 'html', $code));
    }

    /**
     * 成功响应
     */
    protected function ok(string $msg = 'ok', array $data = []): Response
    {
        return json(['code' => 1, 'msg' => $msg, 'data' => $data]);
    }

    /**
     * 失败响应
     */
    protected function fail(string $msg = 'error', array $data = []): Response
    {
        return json(['code' => 0, 'msg' => $msg, 'data' => $data]);
    }

    /**
     * 成功响应并带跳转
     */
    protected function okJump(string $msg, string $url = ''): Response
    {
        return json(['code' => 1, 'msg' => $msg, 'url' => $url]);
    }

    /**
     * 渲染后台页面
     */
    protected function view(string $template, array $vars = []): string
    {
        View::assign($vars);

        // 同上：模板名必须以 / 开头，避免被拼上控制器目录
        return View::fetch('/' . ltrim(str_replace('\\', '/', $template), '/'));
    }

    /**
     * 取分页参数
     *
     * @return array{0:int,1:int} [page, limit]
     */
    protected function pageParam(int $defaultLimit = 20, int $maxLimit = 200): array
    {
        $page  = max(1, (int)$this->request->param('page', 1));
        $limit = (int)$this->request->param('limit', $defaultLimit);
        $limit = max(1, min($maxLimit, $limit));

        return [$page, $limit];
    }
}
