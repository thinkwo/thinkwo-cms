-- --------------------------------------------------------
-- ThinkWo CMS 演示数据 v1.0.0
-- 安装时可选导入。全部为通用外贸制造题材，不含任何客户站点信息。
-- 表前缀统一使用 __PREFIX__ 占位，安装时自动替换
-- 图片位于 /uploads/demo/ 与 /static/brand/，由安装包自带
-- --------------------------------------------------------

SET NAMES utf8mb4;

-- ============================================================
-- 栏目（英文）
-- ============================================================
INSERT INTO `__PREFIX__sort`
(`id`,`lang`,`pid`,`type`,`name`,`subname`,`slug`,`ico`,`pic`,`description`,`seo_title`,`seo_keywords`,`seo_description`,`canonical`,`trans_key`,`template_list`,`template_detail`,`template_page`,`link`,`status`,`sort`,`createtime`,`updatetime`) VALUES

(1,'en',0,'list','Products','Precision components for global buyers','products','','',
 'CNC machining, casting, forging and sheet metal fabrication for industrial customers worldwide.',
 'Precision Machined & Fabricated Components','CNC machining, casting, sheet metal, custom parts',
 'Custom manufacturing of precision components. Tolerances to ±0.01 mm, materials in aluminum, stainless steel and brass. OEM and ODM welcome.',
 '','sort-products','lists','detail','page','',1,1,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(2,'en',1,'list','CNC Machining','Milling and turning to ±0.01 mm','cnc-machining','','',
 '3-axis to 5-axis milling and turning for complex geometries and tight tolerances.',
 'CNC Machining Services - Milling & Turning','CNC machining, 5-axis milling, turning',
 'CNC machining service for aluminum, stainless steel and engineering plastics. Tolerance ±0.01 mm, anodizing and passivation available.',
 '','sort-cnc','lists','detail','page','',1,1,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(3,'en',1,'list','Casting & Forging','Investment casting and closed-die forging','casting-forging','','',
 'Investment casting, sand casting and closed-die forging with full heat treatment.',
 'Casting and Forging Components','investment casting, die forging, heat treatment',
 'Investment casting and closed-die forging service. Materials include carbon steel, alloy steel and stainless steel, with machining and surface finishing in house.',
 '','sort-casting','lists','detail','page','',1,2,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(4,'en',1,'list','Sheet Metal','Laser cutting, bending and stamping','sheet-metal','','',
 'Laser cutting, CNC bending, stamping and welded assemblies from 0.5 mm to 12 mm.',
 'Sheet Metal Fabrication - Laser Cut & Bending','sheet metal fabrication, laser cutting, CNC bending',
 'Sheet metal fabrication from prototype to volume. Laser cutting, CNC bending, stamping, welding and powder coating under one roof.',
 '','sort-sheet','lists','detail','page','',1,3,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(5,'en',0,'list','Solutions','From drawing to shipped part','solutions','','',
 'How we support your project: DFM review, tooling, sampling and mass production.',
 'Manufacturing Solutions for OEM Projects','OEM manufacturing, DFM review, tooling',
 'One-stop manufacturing solutions: design for manufacturability review, tooling, first article inspection and repeatable mass production.',
 '','sort-solutions','lists','detail','page','',1,2,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(6,'en',0,'page','About Us','A factory you can audit','about','','',
 'Established manufacturing base with in-house QC, engineering and export team.',
 'About Us - Our Factory and Team','manufacturer, factory audit, quality control',
 'Learn about our manufacturing base, quality system and export experience. Factory audit and video tour available on request.',
 '','sort-about','lists','detail','page','',1,3,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(7,'en',0,'list','News','Guides and company updates','news','','',
 'Technical notes, sourcing guides and production updates from our engineering team.',
 'News and Technical Guides','manufacturing news, sourcing guide',
 'Technical articles and sourcing guides on machining, casting and sheet metal fabrication, plus company production updates.',
 '','sort-news','lists','detail','page','',1,4,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(8,'en',0,'page','Contact','Send your drawing for a quote','contact','','',
 'Reach our export team by email, phone or WhatsApp. Reply within one working day.',
 'Contact Us - Request a Quotation','contact manufacturer, request quotation',
 'Contact our export team for quotation. Send drawings, material and quantity, we reply within one working day.',
 '','sort-contact','lists','detail','page','',1,5,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

-- ============================================================
-- 栏目（中文）
-- ============================================================
(9,'zh-cn',0,'list','产品中心','面向全球客户的精密零部件','products','','',
 '提供数控加工、铸造锻造、钣金加工等精密零部件定制服务。',
 '精密加工与定制零部件','数控加工, 铸造, 钣金, 定制零件',
 '精密零部件定制加工，公差可达 ±0.01 毫米，支持铝、不锈钢、黄铜等材料，接受 OEM 与 ODM。',
 '','sort-products','lists','detail','page','',1,1,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(10,'zh-cn',9,'list','数控加工','公差 ±0.01 毫米','cnc-machining','','',
 '三轴至五轴铣削与车削，适合复杂结构与高精度要求。',
 '数控加工服务 - 铣削与车削','数控加工, 五轴铣削, 车削',
 '数控加工服务，支持铝、不锈钢与工程塑料，公差 ±0.01 毫米，可做阳极氧化与钝化处理。',
 '','sort-cnc','lists','detail','page','',1,1,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(11,'zh-cn',9,'list','铸造锻造','精密铸造与模锻','casting-forging','','',
 '熔模铸造、砂型铸造与闭式模锻，配套完整热处理。',
 '铸造与锻造零部件','熔模铸造, 模锻, 热处理',
 '熔模铸造与模锻服务，覆盖碳钢、合金钢与不锈钢，机加工与表面处理均在厂内完成。',
 '','sort-casting','lists','detail','page','',1,2,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(12,'zh-cn',9,'list','钣金加工','激光切割、折弯与冲压','sheet-metal','','',
 '0.5 至 12 毫米板材的激光切割、数控折弯、冲压与焊接总成。',
 '钣金加工 - 激光切割与折弯','钣金加工, 激光切割, 数控折弯',
 '钣金加工从样件到批量，激光切割、数控折弯、冲压、焊接与喷涂一体化完成。',
 '','sort-sheet','lists','detail','page','',1,3,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(13,'zh-cn',0,'list','解决方案','从图纸到出货','solutions','','',
 '可制造性评审、模具开发、样品验证与批量生产。',
 'OEM 项目制造解决方案','OEM 制造, 可制造性评审, 模具',
 '一站式制造方案：可制造性评审、模具开发、首件检测与稳定批量生产。',
 '','sort-solutions','lists','detail','page','',1,2,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(14,'zh-cn',0,'page','关于我们','经得起验厂的工厂','about','','',
 '自有生产基地，配备质检、工程与外贸团队。',
 '关于我们 - 工厂与团队','制造商, 验厂, 质量控制',
 '了解我们的生产基地、质量体系与出口经验，可安排验厂与视频看厂。',
 '','sort-about','lists','detail','page','',1,3,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(15,'zh-cn',0,'list','新闻资讯','技术文章与公司动态','news','','',
 '工程团队撰写的技术要点、采购指南与生产动态。',
 '新闻资讯与技术指南','制造新闻, 采购指南',
 '加工、铸造与钣金工艺的技术文章与采购指南，以及公司生产动态。',
 '','sort-news','lists','detail','page','',1,4,UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(16,'zh-cn',0,'page','联系我们','把图纸发来报价','contact','','',
 '通过邮件、电话或 WhatsApp 联系外贸团队，一个工作日内回复。',
 '联系我们 - 索取报价','联系制造商, 索取报价',
 '联系外贸团队索取报价，提供图纸、材料与数量，一个工作日内回复。',
 '','sort-contact','lists','detail','page','',1,5,UNIX_TIMESTAMP(),UNIX_TIMESTAMP());


-- ============================================================
-- 内容（英文产品）
-- ============================================================
INSERT INTO `__PREFIX__content`
(`id`,`lang`,`sort_id`,`title`,`slug`,`subtitle`,`ico`,`images`,`summary`,`content`,`tags`,`seo_title`,`seo_keywords`,`seo_description`,`canonical`,`noindex`,`attr`,`author`,`source`,`views`,`price`,`unit`,`model_no`,`moq`,`trans_key`,`status`,`sort`,`publish_time`,`createtime`,`updatetime`) VALUES

(1,'en',2,'CNC Machined Aluminum Housing','cnc-machined-aluminum-housing','TW-CNC-1001','/uploads/demo/p1.jpg','["/uploads/demo/p1.jpg"]',
 'Anodized aluminum housing machined from solid billet, tolerance ±0.01 mm, for industrial control equipment.',
 '<p>This housing is machined from a single AL6061-T6 billet, which removes the porosity risk of casting and gives a clean anodized surface without filler.</p><h3>Specifications</h3><ul><li>Material: AL6061-T6, AL7075 optional</li><li>Process: 3-axis and 4-axis CNC milling</li><li>Tolerance: ±0.01 mm on critical features</li><li>Surface: black anodizing, sandblasting, laser marking</li><li>Sealing: IP65 with gasket groove</li></ul><h3>Quality control</h3><p>First article inspection report with CMM data is issued before mass production. Each batch is checked for wall thickness, thread depth and anodizing film thickness.</p>',
 'cnc machining,aluminum,anodizing','CNC Machined Aluminum Housing','CNC machined housing, aluminum enclosure',
 'Anodized aluminum housing machined from solid billet, tolerance ±0.01 mm, suitable for industrial control and outdoor equipment.',
 '','0','recommend,hot','','',128,'18.50','pcs','TW-CNC-1001','50 pcs','prod-cnc-housing',1,1,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(2,'en',2,'Stainless Steel Turned Shaft','stainless-steel-turned-shaft','TW-CNC-1002','/uploads/demo/p2.jpg','["/uploads/demo/p2.jpg"]',
 'SUS304 turned shaft with ground bearing seats, Ra 0.4 surface finish and concentricity within 0.005 mm.',
 '<p>Turned on Swiss-type lathes, this shaft combines a ground bearing seat with a threaded end for axial fixing. Typical applications are pump rotors, sensor shafts and small gearbox input shafts.</p><h3>Specifications</h3><ul><li>Material: SUS304, SUS316L, 42CrMo4</li><li>Diameter range: 4 mm to 60 mm</li><li>Concentricity: 0.005 mm</li><li>Surface roughness: Ra 0.4</li><li>Heat treatment: quenching and tempering optional</li></ul><h3>Inspection</h3><p>Roundness and runout are measured on a profile projector; material certificates are supplied with every shipment.</p>',
 'turning,stainless steel,shaft','Stainless Steel Turned Shaft','turned shaft, SUS304 shaft, precision turning',
 'SUS304 turned shaft with ground bearing seats, Ra 0.4 finish and 0.005 mm concentricity for pumps and gearboxes.',
 '','0','recommend','','',96,'6.80','pcs','TW-CNC-1002','100 pcs','prod-cnc-shaft',1,2,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(3,'en',3,'Investment Casting Bracket','investment-casting-bracket','TW-CAST-2001','/uploads/demo/p3.jpg','["/uploads/demo/p3.jpg"]',
 'Lost-wax cast stainless bracket with machining allowance removed, ideal for low to medium volume structural parts.',
 '<p>Investment casting keeps tooling cost low compared with die casting while allowing thin walls and complex ribs. This bracket is cast in SUS316 and then machined on the mounting faces.</p><h3>Specifications</h3><ul><li>Process: lost-wax investment casting</li><li>Material: SUS304, SUS316, carbon steel</li><li>Weight range: 0.05 kg to 8 kg</li><li>Wall thickness: from 2.5 mm</li><li>Secondary: CNC machining, passivation, polishing</li></ul><h3>Tooling</h3><p>Wax injection tool is included in the quotation. Sample lead time is about 20 days after drawing approval.</p>',
 'casting,stainless steel,bracket','Investment Casting Bracket','investment casting, lost wax casting, SUS316 bracket',
 'Lost-wax cast stainless bracket, thin walls from 2.5 mm, machining and passivation available. Low tooling cost for medium volume.',
 '','0','recommend','','',74,'12.00','pcs','TW-CAST-2001','200 pcs','prod-cast-bracket',1,3,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(4,'en',3,'Closed-die Forged Connecting Rod','forged-steel-connecting-rod','TW-CAST-2002','/uploads/demo/p4.jpg','["/uploads/demo/p4.jpg"]',
 'Closed-die forged 42CrMo4 rod, quenched and tempered to HRC 28-32, with shot-blasted surface.',
 '<p>Forging aligns the grain flow along the load path, which gives noticeably better fatigue life than a machined-from-solid part. This rod is forged, normalized, quenched and tempered, then machined at both ends.</p><h3>Specifications</h3><ul><li>Material: 42CrMo4, 40Cr</li><li>Hardness: HRC 28-32 after tempering</li><li>Forging tolerance: GB/T 12362 grade D</li><li>Surface: shot blasting, phosphating</li><li>Nondestructive test: MPI on request</li></ul>',
 'forging,steel,connecting rod','Closed-die Forged Connecting Rod','forged connecting rod, 42CrMo4 forging',
 'Closed-die forged 42CrMo4 connecting rod, quenched and tempered to HRC 28-32, MPI inspection available.',
 '','0','','','',58,'26.00','pcs','TW-CAST-2002','100 pcs','prod-cast-rod',1,4,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(5,'en',4,'Laser Cut Sheet Metal Enclosure','laser-cut-sheet-metal-enclosure','TW-SM-3001','/uploads/demo/p5.jpg','["/uploads/demo/p5.jpg"]',
 '1.5 mm cold rolled steel enclosure, laser cut and CNC bent, powder coated RAL 7035 with silk-screen printing.',
 '<p>A typical control cabinet body: flat parts are laser cut, deburred, then bent on a CNC press brake with dedicated tooling to keep the bend angle within ±0.5°.</p><h3>Specifications</h3><ul><li>Material: SPCC, SECC, SUS304, aluminum</li><li>Thickness: 0.5 mm to 12 mm</li><li>Bending accuracy: ±0.5°</li><li>Surface: powder coating, zinc plating, brushing</li><li>Assembly: rivet nuts, welded studs, hinges</li></ul><h3>Prototyping</h3><p>No hard tooling is needed below 50 pieces, so design changes stay cheap during the prototype stage.</p>',
 'sheet metal,enclosure,laser cutting','Laser Cut Sheet Metal Enclosure','sheet metal enclosure, laser cutting, powder coating',
 'Laser cut and CNC bent steel enclosure, 1.5 mm SPCC with RAL powder coating. No hard tooling needed for prototypes.',
 '','0','recommend','','',142,'9.90','pcs','TW-SM-3001','30 pcs','prod-sm-enclosure',1,5,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(6,'en',4,'Stamped Metal Contact Plate','stamped-metal-contact-plate','TW-SM-3002','/uploads/demo/p6.jpg','["/uploads/demo/p6.jpg"]',
 'Progressive-die stamped brass contact plate, 0.8 mm thick, silver plated for low contact resistance.',
 '<p>Produced on a progressive die with in-line deburring and selective silver plating. The die is built in house, so lead time for a new part is around 25 days including sample approval.</p><h3>Specifications</h3><ul><li>Material: H62 brass, phosphor bronze, beryllium copper</li><li>Thickness: 0.2 mm to 2.0 mm</li><li>Plating: silver, tin, nickel, selective plating</li><li>Die: progressive die, up to 60 strokes per minute</li><li>Packing: tape and reel available</li></ul>',
 'stamping,brass,contact','Stamped Metal Contact Plate','stamped contact plate, brass stamping, silver plating',
 'Progressive-die stamped brass contact plate with selective silver plating, 0.2 to 2.0 mm thickness.',
 '','0','new','','',63,'0.35','pcs','TW-SM-3002','5000 pcs','prod-sm-contact',1,6,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

-- ============================================================
-- 内容（英文新闻）
-- ============================================================
(7,'en',7,'How to Choose the Right Surface Finish for CNC Parts','choose-surface-finish-cnc-parts','','/uploads/demo/p1.jpg','',
 'Anodizing, powder coating, passivation or electropolishing - a short guide to picking the finish that matches your environment.',
 '<p>Surface finish is usually the last decision and the first one customers notice. Here is how we advise buyers to choose.</p><h3>1. Match the environment, not the catalogue</h3><p>Indoor aluminum parts rarely need more than clear anodizing. Outdoor or marine parts need hard anodizing or a proper powder coat with pre-treatment.</p><h3>2. Thickness changes fits</h3><p>Hard anodizing can add 25 to 50 microns per surface. On a shaft with a 0.02 mm clearance, that matters. Tell us the finish before we set the machining dimensions.</p><h3>3. Cost ordering</h3><p>From cheapest to most expensive for aluminum: as-machined, sandblast, clear anodize, dyed anodize, hard anodize. For steel: phosphating, zinc plating, powder coating, electropolishing.</p>',
 'surface finish,anodizing,guide','How to Choose the Right Surface Finish for CNC Parts','surface finish, anodizing, powder coating guide',
 'A practical guide to choosing anodizing, powder coating, passivation or electropolishing for CNC machined parts.',
 '','0','','Engineering Team','',210,'0.00','','','','news-surface-finish',1,1,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(8,'en',7,'Five Ways to Reduce Tooling Cost on Custom Parts','reduce-tooling-cost-custom-parts','','/uploads/demo/p5.jpg','',
 'Tooling often decides whether a project is viable. These five design choices cut die and fixture cost without hurting function.',
 '<p>Tooling is a one-off cost that has to be amortised over the order quantity, so small design changes can have a large effect on unit price.</p><h3>1. Avoid undercuts</h3><p>Every undercut adds a slide to the die. Moving a feature to a secondary machining step is often cheaper.</p><h3>2. Use a standard material thickness</h3><p>Non-standard sheet thickness means a custom rolling order. Staying on 1.5 mm or 2.0 mm can save weeks.</p><h3>3. Tolerances only where they matter</h3><p>Blanket ±0.01 mm on a drawing forces extra operations. Mark the functional dimensions and leave the rest general.</p><h3>4. Share one die across part numbers</h3><p>Family tooling is common for brackets and clips with the same mounting pattern.</p><h3>5. Ask for a tooling amortisation plan</h3><p>We can quote tooling separately or build it into the first order, whichever suits your cash flow.</p>',
 'tooling,cost,design','Five Ways to Reduce Tooling Cost on Custom Parts','reduce tooling cost, die cost, custom parts',
 'Five design choices that reduce die and fixture cost for custom manufactured parts without affecting function.',
 '','0','recommend','Engineering Team','',178,'0.00','','','','news-tooling-cost',1,2,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(9,'en',7,'Understanding Tolerance Stack-Up Before You Approve a Drawing','tolerance-stack-up-guide','','/uploads/demo/p3.jpg','',
 'Individual tolerances can pass inspection while the assembly still fails. Here is how stack-up analysis prevents that.',
 '<p>A common scene: every part is within drawing tolerance, yet the assembly does not close. The reason is tolerance stack-up.</p><h3>Worst case method</h3><p>Add every tolerance in the chain in the same direction. It is simple and conservative, and it is what most inspectors assume.</p><h3>Statistical method</h3><p>Root-sum-square gives a more realistic result when many dimensions contribute, but it accepts a small failure rate. For safety parts, stay with worst case.</p><h3>What we need from you</h3><p>Send the assembly drawing, not only the single part drawing. We will point out where the chain is likely to break before cutting metal.</p>',
 'tolerance,GD&T,engineering','Understanding Tolerance Stack-Up','tolerance stack-up, GD&T, assembly tolerance',
 'Why parts within tolerance still fail to assemble, and how worst case and statistical stack-up analysis prevent it.',
 '','0','','Engineering Team','',134,'0.00','','','','news-tolerance',1,3,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(10,'en',7,'New Five-Axis Machining Cell Now in Production','five-axis-machining-cell','','/uploads/demo/p2.jpg','',
 'We added a five-axis machining cell for complex aluminum and titanium parts, cutting setup time on multi-face work.',
 '<p>Multi-face parts used to need three or four setups, each one adding error and queue time. The new cell machines five faces in a single clamping.</p><h3>What it changes for buyers</h3><ul><li>Shorter lead time on complex housings</li><li>Better position accuracy between faces</li><li>Lower fixture cost, because one fixture replaces several</li></ul><p>Capacity is available from this quarter. Send STEP files for a feasibility check within two working days.</p>',
 'company,five-axis,capacity','New Five-Axis Machining Cell in Production','five-axis machining, capacity, lead time',
 'A new five-axis machining cell reduces setup time and improves accuracy for complex multi-face parts.',
 '','0','new','','',87,'0.00','','','','news-five-axis',1,4,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

-- ============================================================
-- 内容（英文单页）
-- ============================================================
(11,'en',6,'About ThinkWo','about-us','','/uploads/demo/about.jpg','',
 'A manufacturing partner built around engineering review, in-house tooling and repeatable quality.',
 '<p>ThinkWo is a contract manufacturing partner for industrial buyers. We machine, cast, forge and fabricate metal components, and we ship them with the documents your quality team expects.</p><h3>What we do</h3><ul><li>CNC machining from prototype to 100k pieces per year</li><li>Investment casting and closed-die forging with in-house finishing</li><li>Sheet metal fabrication including progressive die stamping</li></ul><h3>How we work</h3><p>Every enquiry starts with a manufacturability review. We tell you what will be expensive before you commit to tooling, and we quote the tolerance we can actually hold rather than the one that looks good on paper.</p><h3>Quality</h3><p>ISO 9001 based quality system, first article inspection with CMM reports, and full material traceability. Third-party inspection such as SGS or BV can be arranged at your request.</p><h3>Visit us</h3><p>Factory audits and video tours are welcome. Contact our export team to schedule a visit.</p>',
 'company,about,factory','About ThinkWo - Manufacturing Partner','about ThinkWo, contract manufacturer',
 'ThinkWo is a contract manufacturing partner for CNC machining, casting, forging and sheet metal fabrication.',
 '','0','','','',0,'0.00','','','','page-about',1,1,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(12,'en',8,'Contact Us','contact-us','','','',
 'Send drawings, material and quantity. We reply within one working day.',
 '<p>To quote accurately we need three things: a drawing in PDF, STEP or DXF, the material and surface finish, and the quantity you expect for the first order and per year.</p><h3>Export team</h3><ul><li>Email: sales@example.com</li><li>Phone: +86 138 0000 0000</li><li>WhatsApp: +86 138 0000 0000</li><li>Address: 88 Industrial Road, Dongguan, Guangdong, China</li></ul><h3>Working hours</h3><p>Monday to Saturday, 08:30 to 18:00 China time. Enquiries received outside these hours are answered the next working day.</p>',
 'contact,quotation','Contact Us - Request a Quotation','contact, request quotation, send drawing',
 'Contact our export team with drawings, material and quantity for a quotation within one working day.',
 '','0','','','',0,'0.00','','','','page-contact',1,2,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP());


-- ============================================================
-- 内容（中文产品）
-- ============================================================
INSERT INTO `__PREFIX__content`
(`id`,`lang`,`sort_id`,`title`,`slug`,`subtitle`,`ico`,`images`,`summary`,`content`,`tags`,`seo_title`,`seo_keywords`,`seo_description`,`canonical`,`noindex`,`attr`,`author`,`source`,`views`,`price`,`unit`,`model_no`,`moq`,`trans_key`,`status`,`sort`,`publish_time`,`createtime`,`updatetime`) VALUES

(13,'zh-cn',10,'铝合金数控加工外壳','cnc-machined-aluminum-housing','TW-CNC-1001','/uploads/demo/p1.jpg','["/uploads/demo/p1.jpg"]',
 '整块铝材加工成型并阳极氧化，公差 ±0.01 毫米，适用于工业控制设备。',
 '<p>外壳由 AL6061-T6 铝块整体加工而成，避免了铸件的气孔风险，阳极氧化后表面无需腻子修补。</p><h3>规格参数</h3><ul><li>材料：AL6061-T6，可选 AL7075</li><li>工艺：三轴与四轴数控铣削</li><li>公差：关键尺寸 ±0.01 毫米</li><li>表面：黑色阳极氧化、喷砂、激光打标</li><li>防护：带密封槽，可做到 IP65</li></ul><h3>质量控制</h3><p>批量生产前提供首件检测报告与三坐标数据，每批抽检壁厚、螺纹深度与氧化膜厚度。</p>',
 '数控加工,铝,阳极氧化','铝合金数控加工外壳','数控加工外壳, 铝外壳',
 '整块铝材加工成型的阳极氧化外壳，公差 ±0.01 毫米，适用于工业控制与户外设备。',
 '','0','recommend,hot','','',128,'18.50','件','TW-CNC-1001','50 件','prod-cnc-housing',1,1,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(14,'zh-cn',10,'不锈钢车削轴','stainless-steel-turned-shaft','TW-CNC-1002','/uploads/demo/p2.jpg','["/uploads/demo/p2.jpg"]',
 'SUS304 车削轴，轴承位磨削，表面粗糙度 Ra 0.4，同轴度 0.005 毫米。',
 '<p>采用走心式车床加工，轴承位经过磨削，端部带螺纹用于轴向固定。常见于泵转子、传感器轴与小减速箱输入轴。</p><h3>规格参数</h3><ul><li>材料：SUS304、SUS316L、42CrMo4</li><li>直径范围：4 至 60 毫米</li><li>同轴度：0.005 毫米</li><li>表面粗糙度：Ra 0.4</li><li>热处理：可选调质</li></ul>',
 '车削,不锈钢,轴','不锈钢车削轴','车削轴, SUS304 轴, 精密车削',
 'SUS304 车削轴，轴承位磨削，Ra 0.4，同轴度 0.005 毫米，适用于泵与减速箱。',
 '','0','recommend','','',96,'6.80','件','TW-CNC-1002','100 件','prod-cnc-shaft',1,2,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(15,'zh-cn',11,'熔模铸造支架','investment-casting-bracket','TW-CAST-2001','/uploads/demo/p3.jpg','["/uploads/demo/p3.jpg"]',
 '失蜡铸造不锈钢支架，去除加工余量后精加工，适合中小批量结构件。',
 '<p>与压铸相比，熔模铸造的模具成本更低，同时可以做出薄壁与复杂加强筋。本支架采用 SUS316 铸造，安装面再行机加工。</p><h3>规格参数</h3><ul><li>工艺：失蜡熔模铸造</li><li>材料：SUS304、SUS316、碳钢</li><li>单件重量：0.05 至 8 公斤</li><li>壁厚：最薄 2.5 毫米</li><li>后处理：数控加工、钝化、抛光</li></ul>',
 '铸造,不锈钢,支架','熔模铸造支架','熔模铸造, 失蜡铸造, SUS316 支架',
 '失蜡铸造不锈钢支架，最薄壁厚 2.5 毫米，可做机加工与钝化，中小批量模具成本低。',
 '','0','recommend','','',74,'12.00','件','TW-CAST-2001','200 件','prod-cast-bracket',1,3,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP());


-- ============================================================
-- 内容（中文新闻与单页）
-- ============================================================
INSERT INTO `__PREFIX__content`
(`id`,`lang`,`sort_id`,`title`,`slug`,`subtitle`,`ico`,`images`,`summary`,`content`,`tags`,`seo_title`,`seo_keywords`,`seo_description`,`canonical`,`noindex`,`attr`,`author`,`source`,`views`,`price`,`unit`,`model_no`,`moq`,`trans_key`,`status`,`sort`,`publish_time`,`createtime`,`updatetime`) VALUES

(16,'zh-cn',15,'数控零件表面处理怎么选','choose-surface-finish-cnc-parts','','/uploads/demo/p1.jpg','',
 '阳极氧化、喷粉、钝化还是电解抛光，按使用环境挑选匹配的表面处理。',
 '<p>表面处理往往是最后一个决定，却是客户最先看到的部分。</p><h3>先看使用环境</h3><p>室内铝件一般做本色阳极氧化即可；户外或海边使用的零件需要硬质氧化，或者做完整前处理的喷粉。</p><h3>膜厚会影响配合</h3><p>硬质氧化每面可增加 25 至 50 微米。对于间隙只有 0.02 毫米的轴，这个厚度必须提前告知，否则加工尺寸要重新设定。</p>',
 '表面处理,阳极氧化,指南','数控零件表面处理选择指南','表面处理, 阳极氧化, 喷粉',
 '按使用环境选择阳极氧化、喷粉、钝化或电解抛光，避免膜厚影响配合尺寸。',
 '','0','','工程部','',210,'0.00','','','','news-surface-finish',1,1,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(17,'zh-cn',15,'定制件降低模具成本的五个办法','reduce-tooling-cost-custom-parts','','/uploads/demo/p5.jpg','',
 '模具费往往决定项目是否可行，这五个设计调整能明显降低开模成本。',
 '<p>模具是一次性投入，需要摊到订单数量上，所以小幅设计改动可能带来明显的单价变化。</p><h3>避免侧向倒扣</h3><p>每个倒扣都要增加滑块。把该特征改为二次机加工往往更便宜。</p><h3>使用标准板厚</h3><p>非标板厚意味着专门订轧，改用 1.5 或 2.0 毫米标准板可省下数周时间。</p>',
 '模具,成本,设计','定制件降低模具成本的五个方法','降低模具成本, 开模费用',
 '五个设计调整降低定制件的模具与工装成本，同时不影响功能。',
 '','0','','工程部','',178,'0.00','','','','news-tooling-cost',1,2,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(18,'zh-cn',14,'关于 ThinkWo','about-us','','/uploads/demo/about.jpg','',
 '以工程评审、自有模具与稳定质量为核心的制造伙伴。',
 '<p>ThinkWo 面向工业采购客户提供代工制造服务，涵盖机加工、铸造、锻造与钣金，并按质量团队的要求交付完整文件。</p><h3>我们做什么</h3><ul><li>数控加工，从样件到年产十万件</li><li>熔模铸造与模锻，后处理在厂内完成</li><li>钣金加工，含连续模冲压</li></ul><h3>质量</h3><p>基于 ISO 9001 的质量体系，首件检测附三坐标报告，材料全程可追溯，可安排 SGS 或 BV 第三方验货。</p>',
 '公司,关于,工厂','关于 ThinkWo - 制造伙伴','关于 ThinkWo, 代工制造',
 'ThinkWo 提供数控加工、铸造、锻造与钣金代工制造服务。',
 '','0','','','',0,'0.00','','','','page-about',1,1,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP()),

(19,'zh-cn',16,'联系我们','contact-us','','','',
 '提供图纸、材料与数量，一个工作日内回复。',
 '<p>为了准确报价，我们需要三样东西：PDF、STEP 或 DXF 格式的图纸，材料与表面处理要求，以及首单与年度的预计数量。</p><h3>外贸团队</h3><ul><li>邮箱：sales@example.com</li><li>电话：+86 138 0000 0000</li><li>WhatsApp：+86 138 0000 0000</li><li>地址：广东省东莞市工业路 88 号</li></ul><h3>工作时间</h3><p>周一至周六 08:30 至 18:00（北京时间），非工作时间收到的询盘于下一个工作日回复。</p>',
 '联系,报价','联系我们 - 索取报价','联系, 索取报价, 发送图纸',
 '联系外贸团队，提供图纸、材料与数量，一个工作日内回复报价。',
 '','0','','','',0,'0.00','','','','page-contact',1,2,UNIX_TIMESTAMP(),UNIX_TIMESTAMP(),UNIX_TIMESTAMP());


-- ============================================================
-- 示例询盘
-- ============================================================
INSERT INTO `__PREFIX__inquiry`
(`no`,`lang`,`name`,`email`,`phone`,`whatsapp`,`company`,`country`,`subject`,`message`,`product_id`,`product_name`,`amount`,`currency`,`source_url`,`ip`,`ua`,`status`,`priority`,`remark`,`admin_id`,`createtime`,`updatetime`) VALUES

('TWQ20260101001','en','Michael Braun','michael.braun@example.de','+49 170 0000000','','Braun Automation GmbH','Germany',
 'Quotation for CNC Machined Aluminum Housing','Hello, we need 500 pcs of the aluminum housing for a control unit. Please quote with black anodizing and IP65 gasket. Drawing attached in the next email.',1,'CNC Machined Aluminum Housing','9250.00','USD','/en/products/cnc-machined-aluminum-housing.html','203.0.113.10','Mozilla/5.0','new',1,'','',UNIX_TIMESTAMP()-86400*2,UNIX_TIMESTAMP()-86400*2),

('TWQ20260101002','en','Sofia Rossi','sofia.rossi@example.it','','393330000000','Rossi Meccanica Srl','Italy',
 'Sheet metal enclosure - sample order','Good morning, can you produce 20 pcs as a trial order? Material 1.5 mm SECC, powder coating RAL 7035. We also need silk screen printing on the front panel.',5,'Laser Cut Sheet Metal Enclosure','198.00','USD','/en/products/laser-cut-sheet-metal-enclosure.html','203.0.113.22','Mozilla/5.0','read',2,'','',UNIX_TIMESTAMP()-86400,UNIX_TIMESTAMP()-86400),

('TWQ20260101003','zh-cn','王先生','wang@example.cn','13800000000','','示例机械有限公司','中国',
 '熔模铸造支架询价','你好，我们需要 300 件铸造支架，材质 SUS316，请问模具费多少？样品交期多久？',15,'熔模铸造支架','3600.00','USD','/zh-cn/products/investment-casting-bracket.html','203.0.113.35','Mozilla/5.0','replied',2,'已回复模具费与交期','',UNIX_TIMESTAMP()-3600*8,UNIX_TIMESTAMP()-3600*4);
