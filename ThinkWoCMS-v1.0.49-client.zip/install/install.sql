-- --------------------------------------------------------
-- ThinkWo CMS 数据库结构 v1.0.0
-- 表前缀统一使用 __PREFIX__ 占位，安装时自动替换
-- 全部使用 CREATE TABLE IF NOT EXISTS，重复执行不会破坏已有数据
-- --------------------------------------------------------

SET NAMES utf8mb4;

-- ----------------------------
-- 管理员
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '角色组ID',
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '登录账号',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '密码哈希',
  `salt` varchar(16) NOT NULL DEFAULT '' COMMENT '密码盐',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '邮箱',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `login_ip` varchar(50) NOT NULL DEFAULT '' COMMENT '最后登录IP',
  `login_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `login_fail` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '连续失败次数',
  `lock_until` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '锁定到期时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1启用 0禁用',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_group` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';

-- ----------------------------
-- 角色组
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__admin_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '角色名称',
  `rules` text COMMENT '权限规则ID，* 表示全部',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色组表';

-- ----------------------------
-- 后台菜单 / 权限规则
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__admin_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级ID',
  `type` varchar(10) NOT NULL DEFAULT 'menu' COMMENT 'menu菜单 button按钮 link外链',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '名称',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '权限标识',
  `path` varchar(200) NOT NULL DEFAULT '' COMMENT 'URL路径',
  `icon` varchar(50) NOT NULL DEFAULT '' COMMENT '图标',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `plugin` varchar(50) NOT NULL DEFAULT '' COMMENT '所属插件，空为核心',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pid` (`pid`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='后台菜单与权限';

-- ----------------------------
-- 语言
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__language` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL DEFAULT '' COMMENT '语言代码 en',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '显示名称 English',
  `native_name` varchar(50) NOT NULL DEFAULT '' COMMENT '本地名称 English',
  `region` varchar(20) NOT NULL DEFAULT '' COMMENT 'hreflang 区域 en-US',
  `dir` varchar(3) NOT NULL DEFAULT 'ltr' COMMENT '文字方向 ltr/rtl',
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否默认语言',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='多语言';

-- ----------------------------
-- 栏目
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__sort` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL DEFAULT 'en' COMMENT '语言代码',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级栏目',
  `type` varchar(10) NOT NULL DEFAULT 'list' COMMENT 'list列表 page单页 link外链',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `subname` varchar(200) NOT NULL DEFAULT '' COMMENT '副标题',
  `slug` varchar(100) NOT NULL DEFAULT '' COMMENT 'URL别名',
  `ico` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  `pic` varchar(255) NOT NULL DEFAULT '' COMMENT '栏目大图',
  `slide_group` varchar(60) NOT NULL DEFAULT '' COMMENT '幻灯片分组 code，留空则内页不用幻灯片',
  `description` text COMMENT '栏目简介',
  `seo_title` varchar(200) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `seo_keywords` varchar(255) NOT NULL DEFAULT '' COMMENT 'SEO关键词',
  `seo_description` varchar(500) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `canonical` varchar(255) NOT NULL DEFAULT '' COMMENT '自定义canonical',
  `trans_key` varchar(64) NOT NULL DEFAULT '' COMMENT '跨语言配对键',
  `trans_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0原文 1机器翻译 2人工修改',
  `trans_at` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '译文生成时间',
  `template_list` varchar(50) NOT NULL DEFAULT 'lists' COMMENT '列表模板',
  `template_detail` varchar(50) NOT NULL DEFAULT 'detail' COMMENT '详情模板',
  `template_page` varchar(50) NOT NULL DEFAULT 'page' COMMENT '单页模板',
  `link` varchar(255) NOT NULL DEFAULT '' COMMENT '外链地址',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(11) NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_lang_slug` (`lang`,`slug`),
  KEY `idx_pid` (`pid`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='栏目表';

-- ----------------------------
-- 内容
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL DEFAULT 'en' COMMENT '语言代码',
  `sort_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(200) NOT NULL DEFAULT '' COMMENT '标题',
  `slug` varchar(120) NOT NULL DEFAULT '' COMMENT 'URL别名',
  `subtitle` varchar(255) NOT NULL DEFAULT '' COMMENT '副标题/型号',
  `ico` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图',
  `images` text COMMENT '图集 JSON',
  `summary` varchar(500) NOT NULL DEFAULT '' COMMENT '摘要',
  `content` mediumtext COMMENT '正文',
  `tags` varchar(255) NOT NULL DEFAULT '' COMMENT '标签，逗号分隔',
  `seo_title` varchar(200) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `seo_keywords` varchar(255) NOT NULL DEFAULT '' COMMENT 'SEO关键词',
  `seo_description` varchar(500) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `canonical` varchar(255) NOT NULL DEFAULT '' COMMENT '自定义canonical',
  `noindex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '禁止收录',
  `attr` varchar(50) NOT NULL DEFAULT '' COMMENT '推荐属性 recommend,hot,new',
  `author` varchar(50) NOT NULL DEFAULT '',
  `source` varchar(100) NOT NULL DEFAULT '',
  `views` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '参考价',
  `unit` varchar(20) NOT NULL DEFAULT '' COMMENT '价格单位',
  `model_no` varchar(100) NOT NULL DEFAULT '' COMMENT '产品型号',
  `moq` varchar(50) NOT NULL DEFAULT '' COMMENT '最小起订量',
  `meta` varchar(1000) NOT NULL DEFAULT '' COMMENT '扩展属性（自定义字段JSON或模板自定义文本）',
  `trans_key` varchar(64) NOT NULL DEFAULT '' COMMENT '跨语言配对键',
  `trans_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0原文 1机器翻译 2人工修改',
  `trans_at` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '译文生成时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1发布 0草稿',
  `sort` int(11) NOT NULL DEFAULT '0',
  `publish_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发布时间',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_lang_slug` (`lang`,`slug`),
  KEY `idx_sort` (`lang`,`sort_id`,`status`),
  KEY `idx_trans` (`trans_key`),
  KEY `idx_publish` (`publish_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='内容表';

-- ----------------------------
-- 附件
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__attachment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '相对路径',
  `url` varchar(500) NOT NULL DEFAULT '' COMMENT '访问地址',
  `ext` varchar(20) NOT NULL DEFAULT '' COMMENT '扩展名',
  `mime` varchar(100) NOT NULL DEFAULT '' COMMENT 'MIME',
  `size` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '字节',
  `width` int(11) unsigned NOT NULL DEFAULT '0',
  `height` int(11) unsigned NOT NULL DEFAULT '0',
  `webp` varchar(255) NOT NULL DEFAULT '' COMMENT 'WebP 版本路径',
  `hash` varchar(64) NOT NULL DEFAULT '' COMMENT '文件哈希',
  `admin_id` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hash` (`hash`),
  KEY `idx_ext` (`ext`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='附件表';

-- ----------------------------
-- 站点设置
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__setting` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `skey` varchar(64) NOT NULL DEFAULT '' COMMENT '键',
  `svalue` text COMMENT '值',
  `sgroup` varchar(30) NOT NULL DEFAULT 'base' COMMENT '分组',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_skey` (`skey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='站点设置';

-- ----------------------------
-- 301 跳转
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__redirect` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_path` varchar(255) NOT NULL DEFAULT '' COMMENT '旧地址',
  `to_path` varchar(255) NOT NULL DEFAULT '' COMMENT '新地址',
  `code` smallint(4) NOT NULL DEFAULT '301' COMMENT '301/302',
  `hits` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '命中次数',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_from` (`from_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='301跳转表';

-- ----------------------------
-- 询盘
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__inquiry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `no` varchar(32) NOT NULL DEFAULT '' COMMENT '询盘编号',
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '客户姓名',
  `email` varchar(120) NOT NULL DEFAULT '',
  `phone` varchar(50) NOT NULL DEFAULT '',
  `whatsapp` varchar(50) NOT NULL DEFAULT '',
  `company` varchar(150) NOT NULL DEFAULT '',
  `country` varchar(80) NOT NULL DEFAULT '',
  `subject` varchar(200) NOT NULL DEFAULT '' COMMENT '主题',
  `message` text COMMENT '询盘内容',
  `product_id` int(11) unsigned NOT NULL DEFAULT '0',
  `product_name` varchar(255) NOT NULL DEFAULT '' COMMENT '产品名称快照',
  `items` text COMMENT '询价车明细 JSON',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '合计金额',
  `currency` varchar(10) NOT NULL DEFAULT 'USD',
  `source_url` varchar(500) NOT NULL DEFAULT '' COMMENT '来源页面',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `ua` varchar(255) NOT NULL DEFAULT '',
  `status` varchar(20) NOT NULL DEFAULT 'new' COMMENT 'new/read/quoted/replied/won/closed',
  `priority` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1高 2中 3低',
  `remark` text COMMENT '跟进备注',
  `admin_id` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_no` (`no`),
  KEY `idx_status` (`status`),
  KEY `idx_time` (`createtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='询盘表';

-- ----------------------------
-- 询价车
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__cart` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sid` varchar(64) NOT NULL DEFAULT '' COMMENT '浏览器会话ID',
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `product_id` int(11) unsigned NOT NULL DEFAULT '0',
  `product_name` varchar(255) NOT NULL DEFAULT '',
  `product_url` varchar(500) NOT NULL DEFAULT '',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `qty` int(11) unsigned NOT NULL DEFAULT '1',
  `currency` varchar(10) NOT NULL DEFAULT 'USD',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='询价车';

-- ----------------------------
-- 阶梯价
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__price` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `min_qty` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '起订量',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `unit` varchar(20) NOT NULL DEFAULT 'pcs',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_product` (`product_id`,`min_qty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='产品阶梯价';

-- ----------------------------
-- 多货币
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__currency` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL DEFAULT '' COMMENT '货币代码 USD',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '名称 US Dollar',
  `symbol` varchar(10) NOT NULL DEFAULT '$' COMMENT '符号',
  `rate` decimal(12,6) NOT NULL DEFAULT '1.000000' COMMENT '对基准货币汇率',
  `decimals` tinyint(1) NOT NULL DEFAULT '2' COMMENT '小数位',
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '基准货币',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='多货币';

-- ----------------------------
-- 访客统计：访问会话（一个访客一次访问一行）
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__visit` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sid` varchar(32) NOT NULL DEFAULT '' COMMENT '会话ID（前端生成）',
  `vid` varchar(32) NOT NULL DEFAULT '' COMMENT '访客ID（cookie 一年）',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `ua` varchar(500) NOT NULL DEFAULT '',
  `device` varchar(10) NOT NULL DEFAULT 'desktop' COMMENT 'desktop/mobile/tablet',
  `browser` varchar(30) NOT NULL DEFAULT '',
  `os` varchar(30) NOT NULL DEFAULT '',
  `lang` varchar(10) NOT NULL DEFAULT '',
  `referer` varchar(500) NOT NULL DEFAULT '' COMMENT '首次来源',
  `ref_host` varchar(120) NOT NULL DEFAULT '' COMMENT '来源域名',
  `landing` varchar(500) NOT NULL DEFAULT '' COMMENT '落地页',
  `pages` int(11) NOT NULL DEFAULT '0' COMMENT '浏览页数',
  `duration` int(11) NOT NULL DEFAULT '0' COMMENT '停留秒数',
  `last_url` varchar(500) NOT NULL DEFAULT '' COMMENT '最后访问页',
  `first_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sid` (`sid`),
  KEY `idx_vid` (`vid`),
  KEY `idx_first` (`first_time`),
  KEY `idx_last` (`last_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='访客访问会话';

-- ----------------------------
-- 访客统计：页面浏览明细（一次浏览一行）
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__visit_page` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `visit_id` int(11) unsigned NOT NULL DEFAULT '0',
  `sid` varchar(32) NOT NULL DEFAULT '',
  `vid` varchar(32) NOT NULL DEFAULT '',
  `url` varchar(500) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `sort_id` int(11) NOT NULL DEFAULT '0',
  `content_id` int(11) NOT NULL DEFAULT '0',
  `referer` varchar(500) NOT NULL DEFAULT '',
  `enter_time` int(11) unsigned NOT NULL DEFAULT '0',
  `leave_time` int(11) unsigned NOT NULL DEFAULT '0',
  `duration` int(11) NOT NULL DEFAULT '0' COMMENT '本页停留秒数',
  PRIMARY KEY (`id`),
  KEY `idx_visit` (`visit_id`),
  KEY `idx_sid` (`sid`),
  KEY `idx_enter` (`enter_time`),
  KEY `idx_url` (`url`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='访客页面浏览明细';

-- ----------------------------
-- 插件
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '插件目录名',
  `title` varchar(100) NOT NULL DEFAULT '',
  `version` varchar(20) NOT NULL DEFAULT '',
  `author` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(500) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `config` text COMMENT '插件配置 JSON',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='插件状态';

-- ----------------------------
-- 幻灯片分组（首页轮播、内页横幅等，模板用 {tw:slide group="code"} 调用）
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__slide_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL DEFAULT '' COMMENT '分组名称',
  `code` varchar(60) NOT NULL DEFAULT '' COMMENT '调用标识',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '用途说明/尺寸建议',
  `width` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '建议宽度',
  `height` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '建议高度',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(11) NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片分组';

-- ----------------------------
-- 幻灯片条目
-- ----------------------------
CREATE TABLE IF NOT EXISTS `__PREFIX__slide` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属分组',
  `lang` varchar(10) NOT NULL DEFAULT '' COMMENT '语言',
  `title` varchar(200) NOT NULL DEFAULT '' COMMENT '主标题',
  `subtitle` varchar(200) NOT NULL DEFAULT '' COMMENT '副标题',
  `summary` varchar(500) NOT NULL DEFAULT '' COMMENT '描述',
  `image` varchar(500) NOT NULL DEFAULT '' COMMENT '图片（PC）',
  `image_mobile` varchar(500) NOT NULL DEFAULT '' COMMENT '图片（手机）',
  `video` varchar(500) NOT NULL DEFAULT '' COMMENT '视频地址 mp4，可空',
  `url` varchar(500) NOT NULL DEFAULT '' COMMENT '跳转链接',
  `target` varchar(10) NOT NULL DEFAULT '_self' COMMENT '打开方式',
  `btn_text` varchar(60) NOT NULL DEFAULT '' COMMENT '按钮文字',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `start_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '定时开始，0 不限',
  `end_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '定时结束，0 不限',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_group` (`group_id`,`lang`,`status`,`sort`),
  KEY `idx_time` (`start_time`,`end_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片条目';

CREATE TABLE IF NOT EXISTS `__PREFIX__sort_field` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sort_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属栏目',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '字段名称（后台表单标签）',
  `fkey` varchar(50) NOT NULL DEFAULT '' COMMENT '字段键（模板调用）',
  `type` varchar(10) NOT NULL DEFAULT 'text' COMMENT 'text/textarea/select/switch',
  `options` varchar(500) NOT NULL DEFAULT '' COMMENT '下拉选项，每行一个',
  `defval` varchar(200) NOT NULL DEFAULT '' COMMENT '默认值',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sort` (`sort_id`,`status`,`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='栏目自定义字段定义';

-- ----------------------------
-- 默认幻灯片分组（后台「内容管理 → 幻灯片」里往里面加图）
-- ----------------------------
INSERT IGNORE INTO `__PREFIX__slide_group` (`name`, `code`, `remark`, `width`, `height`, `status`, `sort`, `createtime`, `updatetime`) VALUES
('首页轮播', 'home', '首页首屏大图轮播，建议 1920×900；手机图另传 750×1000', 1920, 900, 1, 1, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
('内页横幅', 'inner', '栏目页/详情页顶部横幅，建议 1920×520，单张即可', 1920, 520, 1, 2, UNIX_TIMESTAMP(), UNIX_TIMESTAMP());

-- ----------------------------
-- 默认语言
-- ----------------------------
INSERT INTO `__PREFIX__language` (`code`, `name`, `native_name`, `region`, `dir`, `is_default`, `sort`, `status`, `createtime`) VALUES
('en', 'English', 'English', 'en-US', 'ltr', 1, 0, 1, UNIX_TIMESTAMP()),
('zh-cn', 'Chinese', '简体中文', 'zh-CN', 'ltr', 0, 1, 1, UNIX_TIMESTAMP());

-- ----------------------------
-- 默认角色组
-- ----------------------------
INSERT INTO `__PREFIX__admin_group` (`id`, `name`, `rules`, `remark`, `status`, `createtime`) VALUES
(1, '超级管理员', '*', '拥有全部权限', 1, UNIX_TIMESTAMP());

-- ----------------------------
-- 默认设置
-- ----------------------------
INSERT INTO `__PREFIX__setting` (`skey`, `svalue`, `sgroup`) VALUES
('site_name', 'ThinkWo', 'base'),
('site_title', 'ThinkWo - Precision Manufacturing Partner', 'base'),
('site_keywords', '', 'base'),
('site_description', 'Professional manufacturer and exporter. OEM & ODM service available.', 'base'),
('logo', '/static/brand/logo.svg', 'base'),
('logo_text', 'ThinkWo', 'base'),
('favicon', '/static/brand/favicon.svg', 'base'),
('theme', 'default', 'base'),
('company', 'ThinkWo Industrial Co., Ltd.', 'contact'),
('phone', '', 'contact'),
('email', '', 'contact'),
('whatsapp', '', 'contact'),
('address', '', 'contact'),
('copyright', '', 'contact'),
('smtp_host', '', 'smtp'),
('smtp_port', '465', 'smtp'),
('smtp_user', '', 'smtp'),
('smtp_pass', '', 'smtp'),
('smtp_secure', 'ssl', 'smtp'),
('smtp_from', '', 'smtp'),
('smtp_from_name', '', 'smtp'),
('notify_email', '', 'smtp'),
('inquiry_autoreply', '1', 'smtp'),
('seo_index_title', 'Precision Manufacturing Partner for Global Buyers', 'seo'),
('seo_title_format', '{title} | {site_name}', 'seo'),
('og_image', '/static/brand/og-default.png', 'seo'),
('analytics_code', '', 'seo'),
('head_code', '', 'seo'),
('footer_code', '', 'seo'),
('sitemap_enable', '1', 'seo'),
('sitemap_include_pages', '1', 'seo'),
('currency', 'USD', 'base'),
('translate_driver', 'auto', 'base'),
('translate_appid', '', 'base'),
('translate_secret', '', 'base'),
('translate_deepl_pro', '0', 'base'),
('translate_auto', '1', 'base'),
('translate_auto_body', '1', 'base'),
('indexnow_enable', '0', 'seo'),
('indexnow_key', '', 'seo'),
('visit_enable', '1', 'seo'),
('visit_keep_days', '90', 'seo'),
('db_version', '', 'base');

-- ----------------------------
-- 默认货币（汇率仅为演示值，上线后请在后台更新）
-- ----------------------------
INSERT INTO `__PREFIX__currency` (`code`, `name`, `symbol`, `rate`, `decimals`, `is_default`, `sort`, `status`, `createtime`) VALUES
('USD', 'US Dollar', '$', 1.000000, 2, 1, 0, 1, UNIX_TIMESTAMP()),
('EUR', 'Euro', '€', 0.920000, 2, 0, 1, 1, UNIX_TIMESTAMP()),
('GBP', 'British Pound', '£', 0.790000, 2, 0, 2, 1, UNIX_TIMESTAMP()),
('JPY', 'Japanese Yen', '¥', 155.000000, 0, 0, 3, 1, UNIX_TIMESTAMP()),
('CNY', 'Chinese Yuan', '¥', 7.200000, 2, 0, 4, 1, UNIX_TIMESTAMP()),
('AUD', 'Australian Dollar', 'A$', 1.520000, 2, 0, 5, 1, UNIX_TIMESTAMP()),
('CAD', 'Canadian Dollar', 'C$', 1.360000, 2, 0, 6, 1, UNIX_TIMESTAMP());
