<?php

/**
 * 开发环境路由（仅 php -S 内置服务器需要，线上用 Nginx / Apache）
 *
 *   php -S 127.0.0.1:8000 router.php
 *
 * 处理两件事：
 * 1. public 下真实存在的静态文件直接交给内置服务器
 * 2. /admin.php/login/check 这种 PATH_INFO 形式，手动补好 $_SERVER 再执行入口
 */

$uri    = urldecode((string)parse_url((string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH));
$public = __DIR__ . '/public';

if ($uri !== '/' && is_file($public . $uri)) {
    return false;
}

if (preg_match('#^/([^/]+\.php)(/.*)?$#', $uri, $m) && is_file($public . '/' . $m[1])) {
    $_SERVER['SCRIPT_NAME']     = '/' . $m[1];
    $_SERVER['SCRIPT_FILENAME'] = $public . '/' . $m[1];
    $_SERVER['PATH_INFO']       = $m[2] ?? '';
    $_SERVER['PHP_SELF']        = '/' . $m[1] . ($m[2] ?? '');
    require $public . '/' . $m[1];
    return true;
}

$_SERVER['SCRIPT_NAME'] = '/index.php';
require $public . '/index.php';
