<?php

// +----------------------------------------------------------------------
// | ThinkWo CMS 前台入口
// +----------------------------------------------------------------------

use think\App;

require __DIR__ . '/../vendor/autoload.php';

// 安装检测
if (!is_file(__DIR__ . '/../install.lock')) {
    header('Location: /install.php');
    exit;
}

$http     = (new App())->http;
$response = $http->run();
$response->send();
$http->end($response);
