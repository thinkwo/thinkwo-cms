<?php

// +----------------------------------------------------------------------
// | ThinkWo CMS 后台入口
// | 建议上线后重命名为自定义文件名，例如 manage.php
// +----------------------------------------------------------------------

use think\App;

require __DIR__ . '/../vendor/autoload.php';

if (!is_file(__DIR__ . '/../install.lock')) {
    header('Location: /install.php');
    exit;
}

$http     = (new App())->http;
$response = $http->name('admin')->run();
$response->send();
$http->end($response);
