<?php

// +----------------------------------------------------------------------
// | ThinkWo CMS 一键安装向导（独立脚本，不依赖框架与 composer）
// | 安装完成后自动写 install.lock 上锁
// +----------------------------------------------------------------------

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

$root     = dirname(__DIR__);
$lockFile = $root . '/install.lock';
$envFile  = $root . '/.env';

// ---------------------------------------------------------------
// 定位 SQL 文件（兼容 install/ 子目录与同级两种情况）
// ---------------------------------------------------------------
$findSql = static function (string $name) use ($root): string {
    foreach ([$root . '/install/' . $name, __DIR__ . '/' . $name] as $p) {
        if (is_file($p)) {
            return $p;
        }
    }
    return '';
};

$sqlFile  = $findSql('install.sql');
$demoFile = $findSql('demo.sql');

function h(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/**
 * 按分号切分 SQL，忽略引号内的分号
 */
function splitSql(string $sql): array
{
    $out   = [];
    $buf   = '';
    $len   = strlen($sql);
    $inStr = false;

    for ($i = 0; $i < $len; $i++) {
        $c = $sql[$i];

        if ($inStr) {
            if ($c === '\\') {
                $buf .= $c . ($sql[$i + 1] ?? '');
                $i++;
                continue;
            }
            if ($c === "'") {
                $inStr = false;
            }
            $buf .= $c;
            continue;
        }

        if ($c === "'") {
            $inStr = true;
            $buf .= $c;
            continue;
        }

        // 跳过 -- 行注释
        if ($c === '-' && ($sql[$i + 1] ?? '') === '-') {
            while ($i < $len && $sql[$i] !== "\n") {
                $i++;
            }
            continue;
        }

        if ($c === ';') {
            $t = trim($buf);
            if ($t !== '') {
                $out[] = $t;
            }
            $buf = '';
            continue;
        }

        $buf .= $c;
    }

    $t = trim($buf);
    if ($t !== '') {
        $out[] = $t;
    }

    return $out;
}

/**
 * 执行一个 SQL 文件
 */
function runSql(PDO $pdo, string $file, string $prefix, array &$errors): bool
{
    $sql = (string)file_get_contents($file);
    $sql = str_replace('__PREFIX__', $prefix, $sql);
    $sql = preg_replace('/^INSERT\s+INTO/im', 'INSERT IGNORE INTO', $sql) ?? $sql;

    foreach (splitSql($sql) as $stmt) {
        $stmt = preg_replace('/^\s*(--[^\n]*\n\s*)+/', '', $stmt) ?? $stmt;
        if (trim($stmt) === '') {
            continue;
        }
        try {
            $pdo->exec($stmt);
        } catch (Throwable $e) {
            $errors[] = 'SQL 执行失败：' . h($e->getMessage())
                . '<br><span style="font-family:monospace;font-size:12px;color:#8a919f">'
                . h(mb_substr(trim($stmt), 0, 160)) . '…</span>';
            return false;
        }
    }

    return true;
}

/**
 * 环境检测项：[名称, 当前值, 是否通过, 是否必检]
 */
function checkEnv(string $root): array
{
    $items = [];

    $items[] = ['PHP 版本 ≥ 8.0', PHP_VERSION, version_compare(PHP_VERSION, '8.0.0', '>='), true];

    foreach (['pdo_mysql', 'gd', 'mbstring', 'json', 'fileinfo', 'openssl'] as $ext) {
        $on      = extension_loaded($ext);
        $items[] = ['扩展 ' . $ext, $on ? '已启用' : '未启用', $on, $ext !== 'openssl'];
    }

    $webp    = function_exists('imagewebp');
    $items[] = ['GD WebP 支持', $webp ? '支持' : '不支持（不影响安装）', $webp, false];

    $autoload = $root . '/vendor/autoload.php';
    $items[]  = ['依赖库 vendor/', is_file($autoload) ? '完整' : '缺失', is_file($autoload), true];

    $dirs = [
        ''               => '网站根目录',
        'runtime'        => 'runtime（缓存）',
        'public/uploads' => 'public/uploads（上传）',
        'template'       => 'template（模板）',
    ];
    foreach ($dirs as $dir => $label) {
        $path = $dir === '' ? $root : $root . '/' . $dir;
        if (!is_dir($path)) {
            @mkdir($path, 0755, true);
        }
        $ok      = is_dir($path) && is_writable($path);
        $items[] = [$label, $ok ? '可写' : '不可写', $ok, true];
    }

    return $items;
}

$errors = [];
$step   = is_file($lockFile) ? 'locked' : 'form';

// POST 变量回填默认值（避免未定义变量告警）
$v = static function (string $key, string $default = '') {
    return (string)($_POST[$key] ?? $default);
};

$adminUser = '';
$siteName  = 'ThinkWo';
$withDemo  = true;

// ---------------------------------------------------------------
// 提交处理
// ---------------------------------------------------------------
if ($step === 'form' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $dbHost     = trim($v('db_host', '127.0.0.1'));
    $dbPort     = (int)($_POST['db_port'] ?? 3306);
    $dbName     = trim($v('db_name'));
    $dbUser     = trim($v('db_user'));
    $dbPass     = (string)($_POST['db_pass'] ?? '');
    $dbPrefix   = trim($v('db_prefix', 'tw_'));
    $adminUser  = trim($v('admin_user'));
    $adminPass  = (string)($_POST['admin_pass'] ?? '');
    $adminPass2 = (string)($_POST['admin_pass2'] ?? '');
    $adminMail  = trim($v('admin_email'));
    $siteName   = trim($v('site_name', 'ThinkWo')) ?: 'ThinkWo';
    $withDemo   = !empty($_POST['with_demo']);

    if ($dbName === '') {
        $errors[] = '数据库名不能为空';
    }
    if ($dbUser === '') {
        $errors[] = '数据库用户名不能为空';
    }
    if (!preg_match('/^[a-zA-Z0-9_]{1,20}$/', $dbPrefix)) {
        $errors[] = '表前缀只能是字母、数字、下划线，且不超过 20 个字符';
    }
    if (strlen($adminUser) < 3) {
        $errors[] = '管理员账号至少 3 个字符';
    } elseif (!preg_match('/^[a-zA-Z0-9_@.\-]{3,50}$/', $adminUser)) {
        $errors[] = '管理员账号只能包含字母、数字和 _ @ . -';
    }
    if (strlen($adminPass) < 6) {
        $errors[] = '管理员密码至少 6 位';
    }
    if ($adminPass !== $adminPass2) {
        $errors[] = '两次输入的管理员密码不一致';
    }
    if ($adminMail !== '' && !filter_var($adminMail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = '管理员邮箱格式不正确';
    }
    if ($sqlFile === '') {
        $errors[] = '找不到 install/install.sql，安装包可能不完整';
    }
    if (!is_file($root . '/vendor/autoload.php')) {
        $errors[] = '找不到 vendor/autoload.php，安装包可能不完整';
    }

    $pdo = null;
    if (!$errors) {
        try {
            $dsn = "mysql:host={$dbHost};port={$dbPort};charset=utf8mb4";
            $pdo = new PDO($dsn, $dbUser, $dbPass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_TIMEOUT => 10,
            ]);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
            $pdo->exec("USE `{$dbName}`");
        } catch (Throwable $e) {
            $errors[] = '数据库连接失败：' . h($e->getMessage());
        }
    }

    if (!$errors && $pdo instanceof PDO) {
        if (runSql($pdo, $sqlFile, $dbPrefix, $errors)) {
            if ($withDemo && $demoFile !== '') {
                runSql($pdo, $demoFile, $dbPrefix, $errors);
            }

            if (!$errors) {
                try {
                    $stmt = $pdo->prepare("SELECT id FROM `{$dbPrefix}admin` WHERE username = ?");
                    $stmt->execute([$adminUser]);
                    $adminId = $stmt->fetchColumn();

                    $hash = password_hash($adminPass, PASSWORD_DEFAULT);
                    $now  = time();

                    if ($adminId) {
                        $pdo->prepare("UPDATE `{$dbPrefix}admin` SET password = ?, salt = '', nickname = ?, email = ?, status = 1, updatetime = ? WHERE id = ?")
                            ->execute([$hash, $adminUser, $adminMail, $now, $adminId]);
                    } else {
                        $pdo->prepare("INSERT INTO `{$dbPrefix}admin` (group_id, username, password, salt, nickname, email, status, createtime, updatetime) VALUES (1, ?, ?, '', ?, ?, 1, ?, ?)")
                            ->execute([$adminUser, $hash, $adminUser, $adminMail, $now, $now]);
                    }

                    $pdo->prepare("UPDATE `{$dbPrefix}setting` SET svalue = ? WHERE skey = 'site_name'")
                        ->execute([$siteName]);
                    $pdo->prepare("UPDATE `{$dbPrefix}setting` SET svalue = ? WHERE skey = 'logo_text'")
                        ->execute([$siteName]);
                } catch (Throwable $e) {
                    $errors[] = '写入管理员信息失败：' . h($e->getMessage());
                }
            }
        }
    }

    // 写 .env
    if (!$errors) {
        $quote = static function (string $val): string {
            if ($val === '') {
                return '';
            }
            return preg_match('/[\s#"\'\\\\]/', $val) ? '"' . addslashes($val) . '"' : $val;
        };

        $env = "APP_DEBUG = false\n\n"
            . "[APP]\n"
            . "DEFAULT_TIMEZONE = Asia/Shanghai\n\n"
            . "[DATABASE]\n"
            . "TYPE = mysql\n"
            . "HOSTNAME = " . $quote($dbHost) . "\n"
            . "DATABASE = " . $quote($dbName) . "\n"
            . "USERNAME = " . $quote($dbUser) . "\n"
            . "PASSWORD = " . $quote($dbPass) . "\n"
            . "HOSTPORT = {$dbPort}\n"
            . "CHARSET = utf8mb4\n"
            . "PREFIX = " . $quote($dbPrefix) . "\n"
            . "DEBUG = false\n\n"
            . "[LANG]\n"
            . "DEFAULT_LANG = en\n";

        if (@file_put_contents($envFile, $env) === false) {
            $errors[] = '写入 .env 失败，请检查网站根目录写权限';
        }
    }

    // 建运行目录并上锁
    if (!$errors) {
        foreach (['runtime', 'runtime/cache', 'runtime/log', 'runtime/html', 'runtime/session', 'public/uploads'] as $dir) {
            $path = $root . '/' . $dir;
            if (!is_dir($path)) {
                @mkdir($path, 0755, true);
            }
        }

        if (@file_put_contents($lockFile, "installed at " . date('Y-m-d H:i:s') . "\nadmin: " . $adminUser . "\n") === false) {
            $errors[] = '写入 install.lock 失败，请检查根目录写权限';
        } else {
            $step = 'done';
        }
    }
}

$envItems = $step === 'form' ? checkEnv($root) : [];
$allOk    = $envItems ? !in_array(false, array_column($envItems, 2), true) : true;
$hasDemo  = $demoFile !== '';

// 装机后权限自检：程序目录不可写（多为面板解压导致文件属主为 root）时，
// 后台「在线更新」会失败，这里提前告知修复方法
$permIssues = [];
if ($step === 'done') {
    foreach (['app', 'config', 'public', 'template', 'runtime'] as $p) {
        $abs = $root . '/' . $p;
        if (is_dir($abs) && !is_writable($abs)) {
            $permIssues[] = $p;
        }
    }
}
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>ThinkWo CMS 安装向导</title>
<link rel="icon" type="image/svg+xml" href="/static/brand/favicon.svg">
<style>
* { box-sizing: border-box; }
:root {
  --nav: #12254d;
  --nav-d: #0b1733;
  --accent: #e0762e;
  --line: #e4e7ec;
  --muted: #8a919f;
  --bg: #f4f6f9;
}
body {
  margin: 0;
  font: 14px/1.7 -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
  background: var(--bg);
  color: #1f2329;
  -webkit-font-smoothing: antialiased;
}
.topbar { background: linear-gradient(135deg, var(--nav) 0%, var(--nav-d) 100%); padding: 26px 0; margin-bottom: 32px; }
.topbar-in { max-width: 880px; margin: 0 auto; padding: 0 20px; display: flex; align-items: center; gap: 14px; }
.topbar h1 { font-size: 19px; margin: 0; font-weight: 600; color: #fff; letter-spacing: .3px; }
.topbar .ver { font-size: 12px; color: rgba(255,255,255,.55); margin-left: auto; letter-spacing: .5px; }
.topbar .sub { font-size: 12.5px; color: rgba(255,255,255,.6); margin-top: 2px; }

.wrap { max-width: 880px; margin: 0 auto 90px; padding: 0 20px; }

.steps { display: flex; gap: 8px; margin-bottom: 20px; }
.steps span { flex: 1; font-size: 12.5px; color: var(--muted); padding: 9px 14px; background: #fff; border: 1px solid var(--line); border-radius: 8px; }
.steps span.on { color: var(--nav); border-color: var(--nav); font-weight: 600; background: #f2f5fb; }
.steps span.done { color: #0f7b4f; border-color: #b7e2c6; background: #f3fbf6; }

.card { background: #fff; border: 1px solid var(--line); border-radius: 12px; padding: 26px 28px; margin-bottom: 18px; }
.card > h2 { font-size: 14.5px; margin: 0 0 18px; font-weight: 600; padding-bottom: 12px; border-bottom: 1px solid #f0f1f3; display: flex; align-items: center; gap: 8px; }
.card > h2::before { content: ""; width: 3px; height: 14px; background: var(--accent); border-radius: 2px; }

table.chk { width: 100%; border-collapse: collapse; }
table.chk td { padding: 8px 0; font-size: 13px; border-bottom: 1px dashed #f0f1f3; }
table.chk tr:last-child td { border-bottom: 0; }
table.chk td:last-child { text-align: right; width: 150px; }
.ok { color: #0f7b4f; }
.bad { color: #c62828; font-weight: 500; }
.warn { color: #b26a00; }

.row { display: flex; gap: 14px; margin-bottom: 14px; }
.f { flex: 1; min-width: 0; }
.f.sm { flex: 0 0 132px; }
label { display: block; font-size: 12.5px; color: #5b6472; margin-bottom: 6px; }
input[type=text], input[type=password], input[type=email] {
  width: 100%; padding: 9px 12px; border: 1px solid #dcdfe6; border-radius: 7px;
  font-size: 13.5px; font-family: inherit; color: #1f2329; background: #fff;
  transition: border-color .15s, box-shadow .15s;
}
input:focus { outline: none; border-color: var(--nav); box-shadow: 0 0 0 3px rgba(18,37,77,.08); }
.hint { font-size: 11.5px; color: var(--muted); margin-top: 5px; line-height: 1.5; }

.check { display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; background: #f8fafc; border: 1px solid var(--line); border-radius: 8px; margin-top: 6px; cursor: pointer; }
.check input { margin-top: 3px; width: 15px; height: 15px; accent-color: var(--nav); cursor: pointer; }
.check b { font-size: 13px; font-weight: 600; display: block; }
.check small { color: var(--muted); font-size: 11.5px; line-height: 1.6; display: block; margin-top: 3px; }

.btn { display: inline-block; padding: 11px 32px; background: var(--nav); color: #fff; border: none; border-radius: 8px; font-size: 14px; font-family: inherit; cursor: pointer; text-decoration: none; transition: background .15s; font-weight: 500; }
.btn:hover { background: var(--nav-d); }
.btn[disabled] { background: #b6bdcc; cursor: not-allowed; }
.btn.ghost { background: #fff; color: var(--nav); border: 1px solid var(--nav); }
.btn.ghost:hover { background: #f2f5fb; }
.btn.accent { background: var(--accent); }
.btn.accent:hover { background: #c9631f; }

.err { background: #fdecec; border: 1px solid #f5c2c2; color: #a12020; padding: 13px 16px; border-radius: 8px; margin-bottom: 18px; font-size: 13px; }
.err ul { margin: 0; padding-left: 18px; }
.err li { margin-bottom: 4px; }

.good { background: #f3fbf6; border: 1px solid #b7e2c6; border-radius: 10px; padding: 20px 22px; }
.good h3 { margin: 0 0 14px; font-size: 15px; color: #0f7b4f; }
.good dl { margin: 0; display: grid; grid-template-columns: 110px 1fr; gap: 10px 0; font-size: 13.5px; }
.good dt { color: var(--muted); }
.good dd { margin: 0; font-weight: 600; color: #1f2329; }

code { background: #eef1f6; padding: 2px 7px; border-radius: 4px; font-size: 12.5px; font-family: ui-monospace, Consolas, monospace; }
.alert { background: #fff8ec; border: 1px solid #f5deb5; border-radius: 8px; padding: 13px 16px; font-size: 12.5px; color: #8a5c00; margin-top: 16px; line-height: 1.9; }
.alert b { color: #7a4d00; }
.foot { text-align: center; font-size: 11.5px; color: var(--muted); margin-top: 30px; }

@media (max-width: 620px) {
  .row { flex-wrap: wrap; }
  .f.sm { flex: 1 1 100%; }
  .card { padding: 20px; }
  .good dl { grid-template-columns: 1fr; gap: 4px 0; }
  .good dt { margin-top: 8px; }
}
</style>
</head>
<body>

<div class="topbar">
  <div class="topbar-in">
    <svg width="38" height="38" viewBox="0 0 48 48" aria-hidden="true">
      <rect x="1" y="1" width="46" height="46" rx="10.5" fill="#fff" fill-opacity=".1"/>
      <rect x="1" y="1" width="46" height="46" rx="10.5" fill="none" stroke="#fff" stroke-opacity=".22"/>
      <path d="M14 17.5h20" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/>
      <path d="M24 17.5v14.5" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/>
      <rect x="29.5" y="27.5" width="6.5" height="6.5" rx="1.8" fill="#e0762e"/>
    </svg>
    <div>
      <h1>ThinkWo CMS</h1>
      <div class="sub">面向外贸企业站的多语言内容管理系统</div>
    </div>
    <span class="ver">v1.0.0</span>
  </div>
</div>

<div class="wrap">

<?php if ($step === 'locked'): ?>
  <div class="card">
    <h2>系统已安装</h2>
    <div class="good">
      <h3>检测到 install.lock，安装程序已锁定</h3>
      <p style="margin:0;font-size:13px;color:#3d6b52">
        如果要重新安装，请先删除网站根目录下的 <code>install.lock</code>，
        再清空数据库里的旧表，然后刷新本页。
      </p>
    </div>
    <p style="margin-top:22px;display:flex;gap:12px">
      <a class="btn" href="/admin.php">进入后台</a>
      <a class="btn ghost" href="/">查看前台</a>
    </p>
  </div>

<?php elseif ($step === 'done'): ?>
  <div class="steps">
    <span class="done">1. 环境检测</span>
    <span class="done">2. 数据库配置</span>
    <span class="on">3. 安装完成</span>
  </div>

  <div class="card">
    <h2>安装成功</h2>
    <div class="good">
      <h3>✓ 数据库已导入，站点可以访问了</h3>
      <dl>
        <dt>后台地址</dt><dd><code>/admin.php</code></dd>
        <dt>登录账号</dt><dd><?= h($adminUser) ?></dd>
        <dt>站点名称</dt><dd><?= h($siteName) ?></dd>
        <dt>演示数据</dt><dd><?= ($withDemo && $hasDemo) ? '已导入' : '未导入' ?></dd>
      </dl>
    </div>

    <div class="alert">
      <b>上线前请完成这三件事：</b><br>
      1. 删除网站根目录下的 <code>install/</code> 文件夹<br>
      2. 把 <code>public/admin.php</code> 重命名成只有你知道的名字，例如 <code>manage_8f2c.php</code><br>
      3. 用 <code>https</code> 打开后台，核对「系统设置」里的站点信息与 SMTP
    </div>

    <?php if ($permIssues): ?>
    <div class="alert" style="background:#fff7ef;border-color:#ffe2c8;color:#8a5a2b">
      <b>⚠ 检测到程序目录不可写（<?= h(implode('、', $permIssues)) ?>）</b><br>
      原因：用面板「解压」上传的文件属主是 root，而网站以 www 身份运行，以后后台「在线更新」会失败。<br>
      <b>修复（二选一，只做一次）：</b><br>
      · 宝塔 → 文件 → 进入网站根目录 → 顶部「权限」→ 所有者选 <code>www</code> → 勾选「应用到子目录」→ 确定<br>
      · 或宝塔【终端】执行：<code>chown -R www:www <?= h($root) ?></code>
    </div>
    <?php endif; ?>

    <p style="margin-top:24px;display:flex;gap:12px;flex-wrap:wrap">
      <a class="btn accent" href="/admin.php">进入后台管理</a>
      <a class="btn ghost" href="/">打开前台首页</a>
    </p>
  </div>

<?php else: ?>

  <div class="steps">
    <span class="<?= $allOk ? 'done' : 'on' ?>">1. 环境检测</span>
    <span class="<?= $allOk ? 'on' : '' ?>">2. 数据库配置</span>
    <span>3. 安装完成</span>
  </div>

  <?php if ($errors): ?>
  <div class="err">
    <ul><?php foreach ($errors as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul>
  </div>
  <?php endif; ?>

  <div class="card">
    <h2>环境检测</h2>
    <table class="chk">
      <?php foreach ($envItems as $item): ?>
      <tr>
        <td><?= h($item[0]) ?></td>
        <td class="<?= $item[2] ? 'ok' : ($item[3] ? 'bad' : 'warn') ?>">
          <?= h($item[1]) ?> <?= $item[2] ? '✓' : ($item[3] ? '✗' : '!') ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
    <?php if (!$allOk): ?>
      <div class="alert">
        <b>有必检项未通过。</b>请在宝塔面板里补齐对应扩展或目录权限后刷新本页。
        标 <span class="warn">!</span> 的只是建议项，不影响安装。
      </div>
    <?php endif; ?>
  </div>

  <form method="post" autocomplete="off">
    <div class="card">
      <h2>数据库配置</h2>
      <div class="row">
        <div class="f"><label>数据库地址</label>
          <input type="text" name="db_host" value="<?= h($v('db_host', '127.0.0.1')) ?>" required>
        </div>
        <div class="f sm"><label>端口</label>
          <input type="text" name="db_port" value="<?= h($v('db_port', '3306')) ?>">
        </div>
      </div>
      <div class="row">
        <div class="f"><label>数据库名</label>
          <input type="text" name="db_name" value="<?= h($v('db_name')) ?>" placeholder="thinkwo" required>
          <div class="hint">数据库不存在时会自动创建，需要该账号有 CREATE 权限</div>
        </div>
        <div class="f"><label>用户名</label>
          <input type="text" name="db_user" value="<?= h($v('db_user')) ?>" required>
        </div>
      </div>
      <div class="row">
        <div class="f"><label>密码</label>
          <input type="password" name="db_pass" value="<?= h((string)($_POST['db_pass'] ?? '')) ?>">
        </div>
        <div class="f sm"><label>表前缀</label>
          <input type="text" name="db_prefix" value="<?= h($v('db_prefix', 'tw_')) ?>">
          <div class="hint">建议保持 tw_</div>
        </div>
      </div>
    </div>

    <div class="card">
      <h2>管理员账号</h2>
      <div class="row">
        <div class="f"><label>登录账号</label>
          <input type="text" name="admin_user" value="<?= h($v('admin_user', 'admin')) ?>" required>
        </div>
        <div class="f"><label>登录密码</label>
          <input type="password" name="admin_pass" value="" placeholder="至少 6 位" required>
        </div>
      </div>
      <div class="row">
        <div class="f"><label>确认密码</label>
          <input type="password" name="admin_pass2" value="" placeholder="再输一次" required>
        </div>
        <div class="f"><label>邮箱（接收询盘通知，可留空）</label>
          <input type="email" name="admin_email" value="<?= h($v('admin_email')) ?>" placeholder="sales@yourdomain.com">
        </div>
      </div>
      <div class="row">
        <div class="f"><label>网站名称</label>
          <input type="text" name="site_name" value="<?= h($v('site_name', 'ThinkWo')) ?>" required>
          <div class="hint">之后可以在后台「系统设置」里修改</div>
        </div>
      </div>
    </div>

    <div class="card">
      <h2>演示数据</h2>
      <label class="check">
        <input type="checkbox" name="with_demo" value="1" <?= $withDemo ? 'checked' : '' ?> <?= $hasDemo ? '' : 'disabled' ?>>
        <span>
          <b>导入演示数据<?= $hasDemo ? '' : '（安装包里缺少 demo.sql）' ?></b>
          <small>包含 5 个栏目、19 条内容、3 条示例询盘与全套配图，装完就能看到完整站点效果。
          正式建站时也可以先导入，再逐条替换成自己的内容。</small>
        </span>
      </label>
    </div>

    <p style="margin-top:26px;display:flex;gap:12px;align-items:center">
      <button class="btn accent" type="submit" <?= $allOk ? '' : 'disabled' ?>>开始安装</button>
      <?php if (!$allOk): ?>
      <span style="font-size:12.5px;color:#c62828">请先解决上面标红的检测项</span>
      <?php endif; ?>
    </p>
  </form>

<?php endif; ?>

  <div class="foot">
    <a href="https://www.thinkwocms.com" target="_blank" rel="noopener" style="color:#2d6cdf;text-decoration:none"><b>ThinkWo CMS</b></a>
    · 基于 ThinkPHP 8 + LayUI 构建 · 安装完成后请删除 install 目录<br>
    <span style="font-size:12px">版权所有 © <?php echo date('Y'); ?> 东莞市至邦电子科技有限公司 · 官网 https://www.thinkwocms.com · 仅限授权用户自用，禁止转售或分发 · 详见根目录 LICENSE.txt</span>
  </div>
</div>

</body>
</html>
