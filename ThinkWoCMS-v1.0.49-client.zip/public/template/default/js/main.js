/* ThinkWo Default Theme - 交互脚本（首屏不依赖 JS，脚本延迟加载） */

(function () {
  'use strict';

  /* ---------- 询盘表单 ---------- */
  var form = document.getElementById('twInq');
  if (form) {
    var btn = document.getElementById('inqBtn');
    var msg = document.getElementById('inqMsg');

    var show = function (text, ok) {
      if (!msg) { return; }
      msg.textContent = text;
      msg.className = 'inq-msg ' + (ok ? 'ok' : 'err');
    };

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (btn.disabled) { return; }

      var name = form.querySelector('[name=name]').value.trim();
      var email = form.querySelector('[name=email]').value.trim();
      var message = form.querySelector('[name=message]').value.trim();
      var captcha = form.querySelector('[name=captcha]');

      if (!name) { show('Please enter your name.', false); return; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { show('Please enter a valid email address.', false); return; }
      if (!message) { show('Please enter your message.', false); return; }
      if (captcha && !captcha.value.trim()) { show('Please enter the verification code.', false); return; }

      var src = form.querySelector('[name=source_url]');
      if (src) { src.value = location.href; }

      btn.disabled = true;
      var label = btn.textContent;
      btn.textContent = 'Sending...';
      show('', true);

      fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      }).then(function (r) { return r.json(); }).then(function (res) {
        if (res.code === 1) {
          show(res.msg || 'Thank you! Your inquiry has been sent.', true);
          form.reset();
          var code = document.getElementById('inqCode');
          if (code) { code.src = '/captcha?t=' + Date.now(); }
        } else {
          show(res.msg || 'Submission failed, please try again.', false);
          var c2 = document.getElementById('inqCode');
          if (c2) { c2.src = '/captcha?t=' + Date.now(); }
        }
        btn.disabled = false;
        btn.textContent = label;
      }).catch(function () {
        show('Network error, please retry.', false);
        btn.disabled = false;
        btn.textContent = label;
      });
    });
  }

  /* ---------- 询价车 ---------- */
  window.twAddCart = function (id, el) {
    var fd = new FormData();
    fd.append('id', id);
    fd.append('qty', 1);

    var origin = el ? el.textContent : '';

    fetch('/api/cart/add', {
      method: 'POST', body: fd, headers: { 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function (r) { return r.json(); }).then(function (res) {
      if (el) {
        el.textContent = res.code === 1 ? '✓ Added' : 'Failed';
        setTimeout(function () { el.textContent = origin; }, 2000);
      }
    }).catch(function () {
      if (el) {
        el.textContent = 'Failed';
        setTimeout(function () { el.textContent = origin; }, 2000);
      }
    });
  };

  /* ---------- 点击外部关闭语言下拉 ---------- */
  document.addEventListener('click', function (e) {
    var lang = document.querySelector('.lang.is-open');
    if (lang && !lang.contains(e.target)) {
      lang.classList.remove('is-open');
    }
  });

  /* ---------- 移动端菜单点击后收起 ---------- */
  document.querySelectorAll('.nav a').forEach(function (a) {
    a.addEventListener('click', function () {
      document.body.classList.remove('nav-open');
    });
  });
})();

// ---- 货币切换：写 cookie 后刷新 ----
document.querySelectorAll('[data-cur]').forEach(function (a) {
  a.addEventListener('click', function (e) {
    e.preventDefault();
    document.cookie = 'tw_cur=' + a.getAttribute('data-cur') + ';path=/;max-age=31536000';
    location.reload();
  });
});
