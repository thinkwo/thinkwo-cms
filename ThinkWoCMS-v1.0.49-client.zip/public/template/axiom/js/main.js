/* AXIOM × ThinkWoCMS — 交互脚本（导航/吸顶/图集切换 + 询盘表单 AJAX） */

(function () {
  'use strict';

  /* ---- sticky header state ---- */
  var header = document.querySelector('.site-header');
  if (header) {
    var onScroll = function () {
      header.classList.toggle('scrolled', window.scrollY > 8);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---- mobile menu ---- */
  var toggle = document.getElementById('navToggle');
  var nav = document.getElementById('nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('open');
    });
    nav.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') { nav.classList.remove('open'); }
    });
  }

  /* ---- 点击外部关闭语言下拉 ---- */
  document.addEventListener('click', function (e) {
    var lang = document.querySelector('.lang-box.is-open');
    if (lang && !lang.contains(e.target)) {
      lang.classList.remove('is-open');
    }
  });

  /* ---- detail gallery: thumbnail switcher ---- */
  document.querySelectorAll('.pd-thumbs, .gallery-thumbs').forEach(function (row) {
    var main = row.parentElement.querySelector('.pd-gallery img, .gallery-main img');
    if (!main) { return; }
    row.querySelectorAll('.pd-thumb, .gallery-thumbs img').forEach(function (t) {
      t.addEventListener('click', function () {
        var img = t.tagName === 'IMG' ? t : t.querySelector('img');
        if (img) { main.src = img.src; main.alt = img.alt; }
        row.querySelectorAll('.pd-thumb').forEach(function (x) { x.classList.toggle('active', x === t); });
      });
    });
  });

  /* ---- 询盘表单（POST /api/inquiry，返回 {code:1} 成功） ---- */
  var form = document.getElementById('rfqForm');
  if (form) {
    var btn = document.getElementById('rfqBtn');
    var msg = document.getElementById('formMsg');

    var show = function (text, ok) {
      if (!msg) { return; }
      msg.textContent = text;
      msg.style.display = text ? 'block' : 'none';
      msg.style.borderColor = ok ? 'var(--ok)' : '#e24b4a';
      msg.style.color = ok ? 'var(--ok)' : '#e24b4a';
    };

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (btn.disabled) { return; }

      var name = form.querySelector('[name=name]');
      var email = form.querySelector('[name=email]');
      var message = form.querySelector('[name=message]');
      var captcha = form.querySelector('[name=captcha]');

      if (!name.value.trim()) { show('Please enter your name.', false); name.focus(); return; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim())) { show('Please enter a valid email address.', false); email.focus(); return; }
      if (!message.value.trim()) { show('Please enter your message.', false); message.focus(); return; }
      if (captcha && !captcha.value.trim()) { show('Please enter the verification code.', false); captcha.focus(); return; }

      var src = form.querySelector('[name=source_url]');
      if (src) { src.value = location.href; }

      btn.disabled = true;
      var label = btn.innerHTML;
      btn.innerHTML = 'Sending...';
      show('', true);

      fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      }).then(function (r) { return r.json(); }).then(function (res) {
        if (res.code === 1) {
          show(res.msg || 'Thank you! Your inquiry has been sent.', true);
          form.reset();
        } else {
          show(res.msg || 'Submission failed, please try again.', false);
        }
        var code = document.getElementById('rfqCode');
        if (code) { code.src = '/captcha?t=' + Date.now(); }
        btn.disabled = false;
        btn.innerHTML = label;
      }).catch(function () {
        show('Network error, please retry.', false);
        btn.disabled = false;
        btn.innerHTML = label;
      });
    });
  }
})();

// ---- 货币切换：写 cookie 后刷新 ----
document.querySelectorAll('[data-cur]').forEach(function (a) {
  a.addEventListener('click', function (e) {
    e.preventDefault();
    document.cookie = 'tw_cur=' + a.getAttribute('data-cur') + ';path=/;max-age=31536000';
    location.reload();
  });
});
