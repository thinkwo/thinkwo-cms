/* =========================================================
   THEME JS — 进场渐显（渐进增强）
   只在 JS 可用时给章节内容加 .rv；爬虫 / 无 JS 环境内容照常显示。
   触发范围：每个 .sec 版块内的主要块级元素，进入视口后按顺序
   做 60ms 阶梯延迟，形成「次第浮现」的节奏。
   ========================================================= */
(function () {
  "use strict";

  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

  var blocks = document.querySelectorAll(
    ".sec .wrap > *, .hero .wrap > *, .cta-band .wrap > *"
  );
  if (!("IntersectionObserver" in window) || blocks.length === 0) return;

  blocks.forEach(function (el) { el.classList.add("rv"); });

  var io = new IntersectionObserver(
    function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        var el = entry.target;
        // 同一帧内一起出现的兄弟元素做阶梯延迟
        var parent = el.parentElement;
        var siblings = parent
          ? Array.prototype.slice.call(parent.children).filter(function (c) {
              return c.classList.contains("rv");
            })
          : [el];
        var i = siblings.indexOf(el);
        el.style.transitionDelay = Math.max(i, 0) * 60 + "ms";
        el.classList.add("rv-in");
        el.style.transitionDelay = ""; // 动画结束后清掉，hover 不被拖慢
        io.unobserve(el);
      });
    },
    { rootMargin: "0px 0px -8% 0px", threshold: 0.05 }
  );

  blocks.forEach(function (el) { io.observe(el); });
})();
