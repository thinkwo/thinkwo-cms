/* RapidFab — interactions (vanilla, no dependencies) */

(function () {
  "use strict";

  /* ---- mobile menu ---- */
  var toggle = document.getElementById("navToggle");
  var nav = document.getElementById("nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      document.body.classList.toggle("nav-open", open);
    });
    nav.addEventListener("click", function (e) {
      var a = e.target.closest ? e.target.closest("a") : null;
      if (!a) return;
      // 有子菜单的父项：先展开/收起，不跳转（仅移动端行为由 CSS 控制）
      var li = a.parentElement;
      var mega = li ? li.querySelector(":scope > .mega") : null;
      if (mega) {
        e.preventDefault();
        li.classList.toggle("open");
        return;
      }
      nav.classList.remove("open");
      document.body.classList.remove("nav-open");
    });
  }

  /* ---- drawings upload: list preview ---- */
  var fileEl = document.getElementById("file");
  var uploadList = document.getElementById("uploadList");
  var MAX_FILES = 5;
  if (fileEl && uploadList) {
    var render = function () {
      uploadList.innerHTML = "";
      var files = Array.from(fileEl.files);
      files.forEach(function (f, idx) {
        var li = document.createElement("div");
        li.className = "uitem";
        var size = f.size / 1048576;
        var span = document.createElement("span");
        span.textContent = f.name + "  ·  " + (size >= 1 ? size.toFixed(1) + " MB" : Math.round(f.size / 1024) + " KB");
        var btn = document.createElement("button");
        btn.type = "button";
        btn.textContent = "Remove";
        btn.addEventListener("click", function () {
          var dt = new DataTransfer();
          files.forEach(function (x, i) { if (i !== idx) dt.items.add(x); });
          fileEl.files = dt.files;
          render();
        });
        li.appendChild(span);
        li.appendChild(btn);
        uploadList.appendChild(li);
      });
    };
    fileEl.addEventListener("change", function () {
      if (fileEl.files.length > MAX_FILES) {
        var dt = new DataTransfer();
        Array.from(fileEl.files).slice(0, MAX_FILES).forEach(function (f) { dt.items.add(f); });
        fileEl.files = dt.files;
      }
      render();
    });
    render();
  }

  /* ---- RFQ form → POST /api/inquiry ---- */
  var form = document.getElementById("rfqForm");
  if (form) {
    var msgBox = document.getElementById("formMsg");
    var submitBtn = document.getElementById("rfqBtn");
    var submitHtml = submitBtn ? submitBtn.innerHTML : "";
    var captchaImg = document.getElementById("rfqCode");

    var say = function (text, ok) {
      if (!msgBox) return;
      msgBox.textContent = text;
      msgBox.className = "form-msg " + (ok ? "ok" : "err");
      msgBox.style.display = "block";
      msgBox.scrollIntoView({ behavior: "smooth", block: "center" });
    };

    var refreshCaptcha = function () {
      if (captchaImg) captchaImg.src = "/captcha?t=" + Date.now();
    };

    var release = function () {
      form.dataset.busy = "0";
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = submitHtml;
      }
      refreshCaptcha();
    };

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (form.dataset.busy === "1") return;

      var firstInvalid = null;
      ["name", "email", "message"].forEach(function (id) {
        var el = document.getElementById(id);
        if (!el) return;
        var ok = el.value.trim().length > 0;
        el.style.borderColor = ok ? "" : "#e24b4a";
        if (!ok && !firstInvalid) firstInvalid = el;
      });

      var mail = document.getElementById("email");
      if (mail && mail.value.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail.value.trim())) {
        mail.style.borderColor = "#e24b4a";
        if (!firstInvalid) firstInvalid = mail;
      }

      var privacy = document.getElementById("privacy");
      if (privacy) {
        var line = privacy.closest(".checkline");
        if (line) line.style.color = privacy.checked ? "" : "#e24b4a";
        if (!privacy.checked && !firstInvalid) firstInvalid = privacy;
      }

      if (firstInvalid) {
        firstInvalid.focus();
        return;
      }

      var fd = new FormData(form);
      // 勾选的 Service 拼进 message，后台询盘单里可见
      var svcs = Array.prototype.map.call(
        form.querySelectorAll('input[name="svc"]:checked'),
        function (c) { return c.value; }
      );
      if (svcs.length) {
        var msgEl = document.getElementById("message");
        var note = "[Services: " + svcs.join(", ") + "]\n";
        if (msgEl && msgEl.value.indexOf("[Services:") !== 0) {
          fd.set("message", note + msgEl.value);
        }
      }
      fd.set("source_url", location.href);

      form.dataset.busy = "1";
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = "Sending&hellip;";
      }

      fetch(form.action, {
        method: "POST",
        body: fd,
        headers: { "X-Requested-With": "XMLHttpRequest" }
      })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (res && Number(res.code) === 1) {
            form.reset();
            if (uploadList) uploadList.innerHTML = "";
            refreshCaptcha();
            form.dataset.busy = "0";
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = "Sent &#10003;";
            }
            say(res.msg || "Thank you — your request is in. An engineer will reply within 24 hours.", true);
            return;
          }
          say((res && res.msg) || "Something went wrong. Please email us instead.", false);
          release();
        })
        .catch(function () {
          say("Network error — please try again, or email us the drawing.", false);
          release();
        });
    });
  }
})();


/* ---- language / region switcher + IP-country auto select ---- */
(function () {
  "use strict";

  var box = document.getElementById("langBox");
  if (!box) return;

  var btn = box.querySelector(".lang-btn");
  var list = box.querySelector(".lang-list");

  /* --- dropdown open / close --- */
  if (btn && list) {
    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      var open = box.classList.toggle("open");
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    });
    document.addEventListener("click", function (e) {
      if (box.contains(e.target)) return;
      box.classList.remove("open");
      btn.setAttribute("aria-expanded", "false");
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && box.classList.contains("open")) {
        box.classList.remove("open");
        btn.setAttribute("aria-expanded", "false");
        btn.focus();
      }
    });
  }

  if (!list) return;
  var links = Array.prototype.slice.call(list.querySelectorAll("a[data-code]"));
  if (links.length < 2) return;

  var hrefs = {};
  links.forEach(function (a) { hrefs[a.getAttribute("data-code")] = a.getAttribute("href"); });

  var KEY_MANUAL = "twLangManual", KEY_GEO = "twLangGeo", TTL = 3 * 864e5;

  var store = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };

  /* 用户手动点选语言 → 永久记住，之后不再按 IP 自动切换 */
  function markManual(e) {
    var a = e.target && e.target.closest ? e.target.closest("a[data-code]") : null;
    if (a) store.set(KEY_MANUAL, a.getAttribute("data-code"));
  }
  box.addEventListener("click", markManual);
  var nl = document.querySelector(".nl-list");
  if (nl) nl.addEventListener("click", markManual);

  if (store.get(KEY_MANUAL)) return;                                    // 已手动选过
  // 首段是已知语言代码 → 已在某个语言版页面，尊重 URL 不再自动跳
  var seg = (location.pathname.split("/")[1] || "").toLowerCase();
  if (seg && hrefs[seg] !== undefined) return;
  if (/bot|crawl|spider|slurp|bingpreview|facebookexternalhit|whatsapp|telegram|headless|preview|monitor/i.test(navigator.userAgent)) return;

  /* ISO 3166-1 alpha-2 → 语言代码（只对后台已启用的语言生效） */
  var C2L = {
    CN: "zh-cn", TW: "zh-tw", HK: "zh-hk", MO: "zh-hk",
    JP: "ja", KR: "ko",
    DE: "de", AT: "de", CH: "de", LI: "de",
    FR: "fr", MC: "fr", LU: "fr", BE: "fr", SN: "fr", CI: "fr", CM: "fr", ML: "fr", BF: "fr", NE: "fr", TG: "fr", BJ: "fr", GA: "fr", CG: "fr", CD: "fr", MG: "fr", HT: "fr",
    ES: "es", MX: "es", AR: "es", CL: "es", CO: "es", PE: "es", VE: "es", EC: "es", UY: "es", PY: "es", BO: "es", CR: "es", PA: "es", DO: "es", GT: "es", HN: "es", SV: "es", NI: "es", CU: "es", PR: "es",
    PT: "pt", BR: "pt-br", AO: "pt", MZ: "pt", CV: "pt", TL: "pt",
    RU: "ru", BY: "ru", KZ: "ru", KG: "ru",
    IT: "it", SM: "it", VA: "it",
    NL: "nl", SR: "nl",
    PL: "pl", TR: "tr",
    SA: "ar", AE: "ar", EG: "ar", DZ: "ar", MA: "ar", TN: "ar", LY: "ar", SD: "ar", IQ: "ar", KW: "ar", QA: "ar", OM: "ar", BH: "ar", JO: "ar", LB: "ar", SY: "ar", YE: "ar", PS: "ar", MR: "ar",
    TH: "th", VN: "vi", ID: "id", MY: "ms", BN: "ms",
    GR: "el", CY: "el",
    SE: "sv", NO: "no", DK: "da", FI: "fi",
    CZ: "cs", SK: "sk", HU: "hu", RO: "ro", MD: "ro", BG: "bg", UA: "uk",
    HR: "hr", RS: "sr", SI: "sl", LT: "lt", LV: "lv", EE: "et",
    IL: "he", IR: "fa", PK: "ur", BD: "bn"
  };

  function go(cc) {
    var code = C2L[String(cc || "").toUpperCase()];
    if (!code) return;                                 // 无法识别 → 保持当前（默认英文）
    var href = hrefs[code];
    if (!href) return;                                 // 该语言后台未启用（英语国家通常走这里）
    var t;
    try { t = new URL(href, location.origin); } catch (e) { return; }
    if (t.pathname === location.pathname && t.search === location.search) return;   // 防自跳
    location.replace(t.href);
  }

  var cached = store.get(KEY_GEO);
  if (cached) {
    var pc = cached.split("|");
    if (pc[0] && Date.now() - Number(pc[1] || 0) < TTL) { go(pc[0]); return; }
  }

  /* 依次尝试免费 IP 归属接口，拿到国家码即停 */
  var apis = [
    "https://api.country.is/",
    "https://ipwho.is/?fields=country_code",
    "https://ipapi.co/country/"
  ];
  var i = 0;
  function next() {
    if (i >= apis.length) return;
    var url = apis[i++];
    var done = false;
    var timer = setTimeout(function () { if (!done) { done = true; next(); } }, 2500);
    fetch(url, { mode: "cors", credentials: "omit", cache: "no-store" })
      .then(function (r) { return r.text(); })
      .then(function (txt) {
        if (done) return;
        done = true; clearTimeout(timer);
        var cc = "";
        try {
          var j = JSON.parse(txt);
          cc = j.country || j.country_code || "";
        } catch (e) {
          cc = (txt || "").trim();
        }
        cc = String(cc).trim().toUpperCase();
        if (cc.length !== 2) { next(); return; }
        store.set(KEY_GEO, cc + "|" + Date.now());
        go(cc);
      })
      .catch(function () {
        if (done) return;
        done = true; clearTimeout(timer); next();
      });
  }
  next();
})();
