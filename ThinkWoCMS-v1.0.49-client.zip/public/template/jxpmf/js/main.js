/* JINXIN PRECISION — demo interactions (vanilla, no dependencies) */

(function () {
  "use strict";

  /* ---- sticky header state ---- */
  var header = document.querySelector(".site-header");
  if (header) {
    var onScroll = function () {
      header.classList.toggle("scrolled", window.scrollY > 8);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  /* ---- mobile menu ---- */
  var toggle = document.getElementById("navToggle");
  var nav = document.getElementById("nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      nav.classList.toggle("open");
    });
    nav.addEventListener("click", function (e) {
      if (e.target.tagName === "A") nav.classList.remove("open");
    });
  }

  /* ---- language dropdown ---- */
  var langBoxes = document.querySelectorAll(".lang-box");
  if (langBoxes.length) {
    langBoxes.forEach(function (box) {
      var btn = box.querySelector(".lang-btn");
      if (btn) {
        btn.addEventListener("click", function (e) {
          e.stopPropagation();
          var open = box.classList.contains("is-open");
          langBoxes.forEach(function (b) { b.classList.remove("is-open"); });
          box.classList.toggle("is-open", !open);
          btn.setAttribute("aria-expanded", open ? "false" : "true");
        });
      }
    });
    document.addEventListener("click", function (e) {
      if (!e.target.closest(".lang-box")) {
        langBoxes.forEach(function (b) { b.classList.remove("is-open"); });
      }
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        langBoxes.forEach(function (b) { b.classList.remove("is-open"); });
      }
    });
  }

  /* ---- product filter ---- */
  var bar = document.getElementById("filterBar");
  var list = document.getElementById("plist");
  if (bar && list) {
    bar.addEventListener("click", function (e) {
      var btn = e.target.closest("button");
      if (!btn) return;
      var filter = btn.dataset.filter;

      bar.querySelectorAll("button").forEach(function (b) {
        b.classList.toggle("active", b === btn);
      });

      list.querySelectorAll(".pitem").forEach(function (item) {
        var show = filter === "all" || item.dataset.cat === filter;
        item.style.display = show ? "" : "none";
      });
    });
  }

  /* ---- drawing upload label (multi-file) ---- */
  var fileInput = document.getElementById("file");
  var fileName = document.getElementById("fileName");
  if (fileInput && fileName) {
    var defaultLabel = fileName.textContent;
    fileInput.addEventListener("change", function () {
      var files = fileInput.files;
      if (!files || !files.length) {
        fileName.textContent = defaultLabel;
        return;
      }
      var total = 0;
      for (var i = 0; i < files.length; i++) total += files[i].size;
      var mb = total / (1024 * 1024);
      var size = mb >= 1 ? mb.toFixed(1) + " MB" : Math.round(total / 1024) + " KB";
      if (files.length === 1) {
        fileName.textContent = files[0].name + "  ·  " + size;
      } else {
        fileName.textContent =
          files.length + " files  ·  " + size + "  ·  " + files[0].name + " +" + (files.length - 1);
      }
    });
  }

  /* ---- RFQ form → POST /api/inquiry ---- */
  var form = document.getElementById("rfqForm");
  if (form) {
    var msgBox = document.getElementById("formMsg");
    var submitBtn = document.getElementById("rfqBtn");
    var submitHtml = submitBtn ? submitBtn.innerHTML : "";
    var captchaImg = document.getElementById("rfqCode");

    var say = function (text, ok) {
      if (!msgBox) return;
      msgBox.textContent = text;
      msgBox.className = "form-msg " + (ok ? "ok" : "err");
      msgBox.style.display = "block";
      msgBox.scrollIntoView({ behavior: "smooth", block: "center" });
    };

    var refreshCaptcha = function () {
      if (captchaImg) captchaImg.src = "/captcha?t=" + Date.now();
    };

    var release = function () {
      form.dataset.busy = "0";
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = submitHtml;
      }
      refreshCaptcha();
    };

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (form.dataset.busy === "1") return;

      var firstInvalid = null;
      ["name", "email", "message"].forEach(function (id) {
        var el = document.getElementById(id);
        if (!el) return;
        var ok = el.value.trim().length > 0;
        el.style.borderColor = ok ? "" : "#e24b4a";
        if (!ok && !firstInvalid) firstInvalid = el;
      });

      var mail = document.getElementById("email");
      if (mail && mail.value.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail.value.trim())) {
        mail.style.borderColor = "#e24b4a";
        if (!firstInvalid) firstInvalid = mail;
      }

      var privacy = document.getElementById("privacy");
      if (privacy) {
        var line = privacy.closest(".checkline");
        if (line) line.style.color = privacy.checked ? "" : "#e24b4a";
        if (!privacy.checked && !firstInvalid) firstInvalid = privacy;
      }

      if (firstInvalid) {
        firstInvalid.focus();
        return;
      }

      // 图纸超过 5 个直接拦下，省一次无谓请求
      var fileEl = document.getElementById("file");
      if (fileEl && fileEl.files && fileEl.files.length > 5) {
        say("Please attach at most 5 files — send the rest by email.", false);
        return;
      }

      var fd = new FormData(form);
      fd.set("source_url", location.href);

      form.dataset.busy = "1";
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = "Sending&hellip;";
      }

      fetch(form.action, {
        method: "POST",
        body: fd,
        headers: { "X-Requested-With": "XMLHttpRequest" }
      })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (res && Number(res.code) === 1) {
            form.reset();
            if (fileEl) {
              var label = document.getElementById("fileName");
              if (label) label.textContent = label.dataset.default || label.textContent;
            }
            refreshCaptcha();
            form.dataset.busy = "0";
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = "Sent &#10003;";
            }
            say(res.msg || "Thank you — your request is in. An engineer will reply within 24 hours.", true);
            return;
          }
          say((res && res.msg) || "Something went wrong. Please email us instead.", false);
          release();
        })
        .catch(function () {
          say("Network error — please try again, or email us the drawing.", false);
          release();
        });
    });
  }


  /* ---- generic category filter (case studies / insights) ---- */
  document.querySelectorAll(".filter-bar").forEach(function (bar) {
    var btns = bar.querySelectorAll("button[data-cat]");
    if (!btns.length) return;
    var container =
      document.getElementById("caseGrid") || document.getElementById("postGrid");
    if (!container) return;
    bar.addEventListener("click", function (e) {
      var btn = e.target.closest("button");
      if (!btn) return;
      var filter = btn.dataset.cat;
      btns.forEach(function (b) {
        b.classList.toggle("active", b === btn);
      });
      container.querySelectorAll("[data-cat]").forEach(function (item) {
        var show = filter === "all" || item.dataset.cat === filter;
        item.style.display = show ? "" : "none";
      });
    });
  });


  /* ---- detail gallery: thumbnail switcher ---- */
  document.querySelectorAll(".pd-thumbs").forEach(function (row) {
    var main = row.parentElement.querySelector(".pd-gallery img");
    if (!main) return;
    row.querySelectorAll(".pd-thumb").forEach(function (t) {
      t.addEventListener("click", function () {
        var img = t.querySelector("img");
        if (img) { main.src = img.src; main.alt = img.alt; }
        row.querySelectorAll(".pd-thumb").forEach(function (x) { x.classList.toggle("active", x === t); });
      });
    });
  });

  /* ---- tabs: highlight on click ---- */
  document.querySelectorAll(".tabs a").forEach(function (link) {
    link.addEventListener("click", function () {
      var strip = link.parentElement;
      strip.querySelectorAll("a").forEach(function (a) {
        a.classList.remove("active");
      });
      link.classList.add("active");
    });
  });
})();
