/* [TW-CMS-ZW-2026-8F3A1C] ThinkWoCMS(template: static001) 原创脚本 · 未经授权不得二次分发 */
/* STATIC 001 × ThinkWoCMS — 交互脚本（导航/吸顶/图集切换/筛选 + 询盘表单 AJAX） */

(function () {
  'use strict';

  /* 界面词条来自 window.TW_DICT（head 中由 lang/{语言}.php 注入） */
  var D = window.TW_DICT || {};
  var L = function (k, d) { return D[k] || d || k; };
  var R = function (k, map) { return L(k).replace(/\{([a-z]+)\}/g, function (m, key) { return map[key] !== undefined ? map[key] : m; }); };

  /* ---- sticky header state ---- */
  var header = document.querySelector('.site-header');
  if (header) {
    var onScroll = function () {
      header.classList.toggle('scrolled', window.scrollY > 8);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---- mobile menu ---- */
  var toggle = document.getElementById('navToggle');
  var nav = document.getElementById('nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('open');
    });
    nav.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') { nav.classList.remove('open'); }
    });
  }

  /* ---- 点击外部关闭语言/货币下拉 ---- */
  document.addEventListener('click', function (e) {
    document.querySelectorAll('.lang-box.is-open').forEach(function (lang) {
      if (!lang.contains(e.target)) { lang.classList.remove('is-open'); }
    });
  });

  /* ---- detail gallery: thumbnail switcher ---- */
  document.querySelectorAll('.pd-thumbs').forEach(function (row) {
    var main = row.parentElement.querySelector('.pd-gallery img');
    if (!main) { return; }
    row.querySelectorAll('.pd-thumb').forEach(function (t) {
      t.addEventListener('click', function () {
        var img = t.querySelector('img');
        if (img) { main.src = img.src; main.alt = img.alt; }
        row.querySelectorAll('.pd-thumb').forEach(function (x) { x.classList.toggle('active', x === t); });
      });
    });
  });

  /* ---- generic category filter（列表页标签筛选，可选） ---- */
  document.querySelectorAll('.filter-bar').forEach(function (bar) {
    var btns = bar.querySelectorAll('button[data-cat]');
    if (!btns.length) { return; }
    var container = document.getElementById('caseGrid') || document.getElementById('postGrid') || document.getElementById('plist');
    if (!container) { return; }
    bar.addEventListener('click', function (e) {
      var btn = e.target.closest('button');
      if (!btn) { return; }
      var filter = btn.dataset.cat;
      btns.forEach(function (b) { b.classList.toggle('active', b === btn); });
      container.querySelectorAll('[data-cat]').forEach(function (item) {
        var show = filter === 'all' || item.dataset.cat === filter;
        item.style.display = show ? '' : 'none';
      });
    });
  });

  /* ---- 图纸上传：文件名回显 + 拖拽投放 + 前端大小校验 ---- */
  var fileInput = document.getElementById('rfqFiles');
  var fileLabel = document.getElementById('rfqFileName');
  window.__twFilesReset = null;
  if (fileInput && fileLabel) {
    var defaultLabel = fileLabel.textContent;
    var MAX_NUM = 5;
    var MAX_BYTE = 50 * 1024 * 1024;

    var human = function (n) {
      return n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
    };

    var paint = function () {
      var fs = fileInput.files;
      if (!fs || !fs.length) { fileLabel.textContent = defaultLabel; return; }
      var total = 0;
      for (var i = 0; i < fs.length; i++) { total += fs[i].size; }
      fileLabel.textContent = fs.length === 1
        ? fs[0].name + '  ·  ' + human(fs[0].size)
        : fs.length + ' ' + L('s001_js_files', 'files') + '  ·  ' + human(total) + '  ·  ' + fs[0].name + ' +' + (fs.length - 1);
    };

    fileInput.addEventListener('change', paint);
    window.__twFilesReset = paint;

    var box = fileInput.closest('.upload-box');
    if (box) {
      var hot = function (on) {
        box.style.borderColor = on ? 'var(--accent)' : '';
        box.style.background = on ? '#fdf1e8' : '';
      };
      ['dragenter', 'dragover'].forEach(function (t) {
        box.addEventListener(t, function (e) { e.preventDefault(); hot(true); });
      });
      ['dragleave', 'drop'].forEach(function (t) {
        box.addEventListener(t, function (e) { e.preventDefault(); hot(false); });
      });
      box.addEventListener('drop', function (e) {
        if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
          fileInput.files = e.dataTransfer.files;
          paint();
        }
      });
    }
  }

  /* ---- 询盘表单（POST /api/inquiry，返回 {code:1} 成功） ---- */
  var form = document.getElementById('rfqForm');
  if (form) {
    var btn = document.getElementById('rfqBtn');
    var msg = document.getElementById('formMsg');

    var show = function (text, ok) {
      if (!msg) { return; }
      msg.textContent = text;
      msg.style.display = text ? 'block' : 'none';
      msg.style.borderColor = ok ? 'var(--ok)' : '#e24b4a';
      msg.style.color = ok ? 'var(--ok)' : '#e24b4a';
    };

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (btn.disabled) { return; }

      var name = form.querySelector('[name=name]');
      var email = form.querySelector('[name=email]');
      var message = form.querySelector('[name=message]');
      var captcha = form.querySelector('[name=captcha]');

      if (!name.value.trim()) { show(L('name_required'), false); name.focus(); return; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim())) { show(L('email_invalid'), false); email.focus(); return; }
      if (!message.value.trim()) { show(L('message_required'), false); message.focus(); return; }
      if (captcha && !captcha.value.trim()) { show(L('captcha_required'), false); captcha.focus(); return; }

      /* 其余标记 required 的字段（公司、国家、隐私勾选等）统一兜底校验 */
      var missing = null;
      form.querySelectorAll('[required]').forEach(function (el) {
        if (missing || el === name || el === email || el === message || el === captcha) { return; }
        if (el.type === 'checkbox') {
          if (!el.checked) { missing = el; }
        } else if (!String(el.value || '').trim()) {
          missing = el;
        }
      });
      if (missing) {
        show(L('s001_js_required'), false);
        missing.focus();
        return;
      }

      /* 定制/报价页的额外字段（工艺、材料、数量、公差、表面处理）拼进 message 一并提交 */
      var rawMessage = message.value;
      var extras = [];
      form.querySelectorAll('[data-rfq-extra]').forEach(function (el) {
        var v = String(el.value || '').trim();
        if (v) { extras.push(el.getAttribute('data-rfq-extra') + ': ' + v); }
      });
      var nda = form.querySelector('[name=nda]');
      if (nda && nda.checked) { extras.push('NDA: mutual NDA requested before the drawing is opened'); }
      if (extras.length) { message.value = extras.join('\n') + '\n\n' + rawMessage; }

      var src = form.querySelector('[name=source_url]');
      if (src) { src.value = location.href; }

      /* 附件前端预检：数量与单文件大小，避免白传 50MB */
      var files = document.getElementById('rfqFiles');
      if (files && files.files && files.files.length) {
        if (MAX_NUM && files.files.length > MAX_NUM) {
          show(R('s001_js_files_max', { n: MAX_NUM }), false);
          return;
        }
        for (var fi = 0; fi < files.files.length; fi++) {
          if (MAX_BYTE && files.files[fi].size > MAX_BYTE) {
            show(R('s001_js_file_big', { name: files.files[fi].name }), false);
            return;
          }
        }
      }

      btn.disabled = true;
      var label = btn.innerHTML;
      btn.innerHTML = L('sending');
      show('', true);

      fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      }).then(function (r) { return r.json(); }).then(function (res) {
        if (res.code === 1) {
          show(res.msg || L('inquiry_success'), true);
          form.reset();
          if (window.__twFilesReset) { window.__twFilesReset(); }
        } else {
          message.value = rawMessage;
          show(res.msg || L('inquiry_fail'), false);
        }
        var code = document.getElementById('rfqCode');
        if (code) { code.src = '/captcha?t=' + Date.now(); }
        btn.disabled = false;
        btn.innerHTML = label;
      }).catch(function () {
        message.value = rawMessage;
        show(L('s001_js_network'), false);
        btn.disabled = false;
        btn.innerHTML = label;
      });
    });
  }
})();

/* ---- 货币切换：写 cookie 后刷新 ---- */
document.querySelectorAll('[data-cur]').forEach(function (a) {
  a.addEventListener('click', function (e) {
    e.preventDefault();
    document.cookie = 'tw_cur=' + a.getAttribute('data-cur') + ';path=/;max-age=31536000';
    location.reload();
  });
});
