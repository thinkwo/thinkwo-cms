/* ThinkWo CMS 访客统计打点（约 2KB，无依赖）
 * 记录：页面浏览、每页停留时长、会话总时长、来源
 * 不采集表单内容与任何个人身份信息；用户开启「请勿追踪」时完全不上报
 */
(function () {
  try {
    if (navigator.doNotTrack === '1' || window.doNotTrack === '1' || navigator.msDoNotTrack === '1') {
      return;
    }

    var API = '/api/visit';
    var VID = 'tw_vid', SID = 'tw_sid';
    var IDLE = 1800000; /* 30 分钟不活动算新会话 */

    function rid() {
      var s = '', h = '0123456789abcdef';
      for (var i = 0; i < 32; i++) { s += h.charAt(Math.floor(Math.random() * 16)); }
      return s;
    }
    function getCookie(n) {
      var m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
      return m ? decodeURIComponent(m[1]) : '';
    }
    function setCookie(n, v, days) {
      document.cookie = n + '=' + encodeURIComponent(v) + ';path=/;max-age=' + (days * 86400) + ';SameSite=Lax';
    }

    /* 访客 ID：cookie 保留一年，用来区分回访 */
    var vid = getCookie(VID);
    if (!/^[a-z0-9]{8,32}$/.test(vid)) {
      vid = rid();
      setCookie(VID, vid, 365);
    }

    /* 会话 ID：sessionStorage，30 分钟不活动就换新的（= 一次访问） */
    var sid = '', ts = 0, now = Date.now();
    try {
      sid = sessionStorage.getItem(SID) || '';
      ts = parseInt(sessionStorage.getItem(SID + '_t') || '0', 10) || 0;
    } catch (e) {}
    if (!/^[a-z0-9]{8,32}$/.test(sid) || (ts && now - ts > IDLE)) {
      sid = rid();
    }
    function touch() {
      try {
        sessionStorage.setItem(SID, sid);
        sessionStorage.setItem(SID + '_t', String(Date.now()));
      } catch (e) {}
    }
    touch();

    var url = location.pathname + location.search;
    var active = 0;          /* 真实可见时长（毫秒） */
    var lastTick = now;
    var finalSent = false;

    function tick() {
      var t = Date.now();
      if (document.visibilityState !== 'hidden') { active += t - lastTick; }
      lastTick = t;
    }
    function dur() {
      tick();
      return Math.round(active / 1000);
    }
    function send(data, beacon) {
      var body = JSON.stringify(data);
      if (beacon && navigator.sendBeacon) {
        try {
          navigator.sendBeacon(API, new Blob([body], { type: 'application/json' }));
          return;
        } catch (e) {}
      }
      try {
        fetch(API, {
          method: 'POST',
          body: body,
          headers: { 'Content-Type': 'application/json' },
          credentials: 'same-origin',
          keepalive: true
        });
      } catch (e) {}
    }

    /* 1. 页面浏览 */
    send({ t: 'pv', sid: sid, vid: vid, url: url, title: document.title, ref: document.referrer || '' });

    /* 2. 心跳：每 20 秒把本页停留时长同步一次，用户直接关页面也不会丢数据 */
    var hb = setInterval(function () {
      if (document.visibilityState === 'hidden') { return; }
      var d = dur();
      if (d > 0) { send({ t: 'hb', sid: sid, url: url, dur: d }); }
      touch();
    }, 20000);

    /* 3. 切走 / 关闭：立即结算本页时长 */
    function stay() {
      var d = dur();
      if (d > 0) { send({ t: 'bye', sid: sid, url: url, dur: d }, true); }
      touch();
    }
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'hidden') {
        stay();
      } else {
        lastTick = Date.now();
      }
    });
    window.addEventListener('pagehide', function () {
      if (finalSent) { return; }
      finalSent = true;
      clearInterval(hb);
      stay();
    });
  } catch (e) {}
})();
