/* ThinkWo CMS 轻量富文本编辑器（无外部依赖） */

function twInitEditor() {
  var body = document.getElementById('twEditorBody');
  var source = document.getElementById('twEditorSource');
  var toolbar = document.querySelector('.tw-editor-toolbar');
  if (!body || !toolbar) { return; }

  var sourceMode = false;

  toolbar.addEventListener('click', function (e) {
    var a = e.target.closest('a');
    if (!a) { return; }
    e.preventDefault();

    var cmd = a.dataset.cmd;
    var act = a.dataset.act;

    if (cmd) {
      body.focus();
      document.execCommand(cmd, false, a.dataset.val || null);
      return;
    }

    if (act === 'link') {
      var url = prompt('请输入链接地址', 'https://');
      if (url) {
        body.focus();
        document.execCommand('createLink', false, url);
      }
      return;
    }

    if (act === 'image') {
      if (typeof twUploadOne !== 'function') { return; }
      var sel = window.getSelection();
      twUploadOne(function (imgUrl) {
        body.focus();
        if (sel && sel.rangeCount) {
          var range = sel.getRangeAt(0);
          range.deleteContents();
          range.insertNode(document.createRange().createContextualFragment('<img src="' + imgUrl + '" alt="">'));
        } else {
          document.execCommand('insertHTML', false, '<img src="' + imgUrl + '" alt="">');
        }
      });
      return;
    }

    if (act === 'table') {
      var html = '<table style="width:100%;border-collapse:collapse"><tbody>'
        + '<tr><th style="border:1px solid #ddd;padding:8px">Spec</th><th style="border:1px solid #ddd;padding:8px">Value</th></tr>'
        + '<tr><td style="border:1px solid #ddd;padding:8px">&nbsp;</td><td style="border:1px solid #ddd;padding:8px">&nbsp;</td></tr>'
        + '</tbody></table><p><br></p>';
      body.focus();
      document.execCommand('insertHTML', false, html);
      return;
    }

    if (act === 'html') {
      sourceMode = !sourceMode;
      if (sourceMode) {
        source.value = body.innerHTML.trim();
        body.style.display = 'none';
        source.style.display = 'block';
        a.textContent = '可视';
      } else {
        body.innerHTML = source.value;
        source.style.display = 'none';
        body.style.display = 'block';
        a.textContent = '源码';
      }
      return;
    }
  });

  // 粘贴时清理 Word 冗余样式
  body.addEventListener('paste', function (e) {
    var text = (e.clipboardData || window.clipboardData).getData('text/html')
      || (e.clipboardData || window.clipboardData).getData('text/plain');
    if (!text) { return; }
    e.preventDefault();
    var cleaned = text
      .replace(/<o:p>[\s\S]*?<\/o:p>/gi, '')
      .replace(/<(\w+) [^>]*style="[^"]*"[^>]*>/gi, '<$1>')
      .replace(/class="[^"]*"/gi, '');
    document.execCommand('insertHTML', false, cleaned);
  });
}

function twSyncEditor() {
  var body = document.getElementById('twEditorBody');
  var source = document.getElementById('twEditorSource');
  var target = document.getElementById('twContent');
  if (!target) { return; }

  if (source && source.style.display !== 'none') {
    target.value = source.value;
  } else if (body) {
    target.value = body.innerHTML;
  }
}
