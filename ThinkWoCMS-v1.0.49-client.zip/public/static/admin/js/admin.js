/* ThinkWo CMS 后台公共脚本 */

/**
 * 统一请求（自动带 CSRF 无关的 XHR 头，方便后端识别 ajax）
 */
function twPost(url, data, done, fail) {
  var fd = new FormData();
  Object.keys(data || {}).forEach(function (k) {
    var v = data[k];
    if (Array.isArray(v)) {
      v.forEach(function (item) { fd.append(k + '[]', item); });
    } else if (v !== undefined && v !== null) {
      fd.append(k, v);
    }
  });

  fetch(url, {
    method: 'POST',
    body: fd,
    headers: { 'X-Requested-With': 'XMLHttpRequest' }
  }).then(function (r) {
    if (r.status === 401) { top.location.href = '/admin.php/login/index'; throw new Error('未登录'); }
    return r.json();
  }).then(function (res) {
    if (res.code === 1) {
      if (done) { done(res); } else { layer.msg(res.msg || '操作成功', { icon: 1 }); }
    } else {
      if (fail) { fail(res); } else { layer.msg(res.msg || '操作失败', { icon: 2 }); }
    }
  }).catch(function (e) {
    if (e && e.message === '未登录') { return; }
    layer.msg('请求失败，请重试', { icon: 2 });
  });
}

/**
 * 确认后请求
 */
function twConfirm(msg, url, data, done) {
  layer.confirm(msg, { title: '确认操作', btn: ['确定', '取消'] }, function (idx) {
    layer.close(idx);
    twPost(url, data, function (res) {
      layer.msg(res.msg || '操作成功', { icon: 1 }, function () {
        if (done) { done(res); }
      });
    });
  });
}

/**
 * 打开表单弹层（iframe）
 */
function twOpenForm(title, url, w, h) {
  return layer.open({
    type: 2,
    title: title,
    area: [w || '760px', h || '86%'],
    content: url
  });
}

/* ------------------------------------------------------------------
 * 媒体库选择器
 * 后台所有「选图片 / 选文件」的地方都走这里：
 * 弹层里可以复用已上传的文件，也可以直接上传本地文件
 * ------------------------------------------------------------------ */

var TW_MEDIA_API = '/admin.php/attachment/picker';

/**
 * 取 layui.layer（部分页面只把 layer 挂在 layui 上，没有全局 layer）
 */
function twLayer() {
  if (window.layui && layui.layer) { return layui.layer; }
  return window.layer;
}

/**
 * 打开媒体库
 *
 * @param {Function} cb   选中回调 cb(url, item)；多选时按选中顺序逐个回调
 * @param {Object}   opts { multiple:false, max:0, ext:'image'|'all', title:'选择图片' }
 */
function twMediaPicker(cb, opts) {
  if (typeof cb !== 'function') { return; }
  opts = opts || {};

  var layer = twLayer();

  var st = {
    ext: opts.ext === 'all' ? 'all' : 'image',
    keyword: '',
    page: 1,
    rows: [],
    sel: {},
    order: [],
    multiple: !!opts.multiple,
    max: opts.max || (opts.multiple ? 0 : 1),
    loading: false,
    hasMore: false,
    timer: null
  };

  var idx  = 0;
  var root = null;

  var html = ''
    + '<div class="tw-media">'
    + '  <div class="tw-media-bar">'
    + '    <div class="tw-media-tabs">'
    + '      <a href="javascript:;" data-ext="image" class="on">图片</a>'
    + '      <a href="javascript:;" data-ext="all">全部文件</a>'
    + '    </div>'
    + '    <div class="tw-media-search"><i class="layui-icon layui-icon-search"></i>'
    + '      <input type="text" class="tw-media-kw" placeholder="搜索文件名，回车确认">'
    + '    </div>'
    + '    <button type="button" class="layui-btn layui-btn-sm tw-media-up">上传本地文件</button>'
    + '  </div>'
    + '  <div class="tw-media-body">'
    + '    <div class="tw-media-grid"></div>'
    + '    <div class="tw-media-state"></div>'
    + '    <div class="tw-media-more" style="display:none">'
    + '      <button type="button" class="layui-btn layui-btn-sm layui-btn-primary tw-media-more-btn">加载更多</button>'
    + '    </div>'
    + '  </div>'
    + '  <div class="tw-media-foot">'
    + '    <span class="tw-media-count">已选 0 个</span>'
    + '    <button type="button" class="layui-btn layui-btn-sm layui-btn-primary tw-media-cancel">取消</button>'
    + '    <button type="button" class="layui-btn layui-btn-sm tw-media-ok">确定</button>'
    + '  </div>'
    + '</div>';

  var vw = Math.max(320, (window.innerWidth || 1024) - 40);
  var vh = Math.max(320, (window.innerHeight || 720) - 30);

  idx = layer.open({
    type: 1,
    title: opts.title || (st.multiple ? '选择已上传的文件（可多选）' : '选择图片'),
    area: [Math.min(960, vw) + 'px', Math.min(640, vh) + 'px'],
    shadeClose: false,
    content: html,
    success: function (layero) {
      root = layero[0] ? layero[0].querySelector('.tw-media') : null;
      if (!root) { return; }
      bind();
      refreshFoot();
      load(true);
    }
  });

  /* ---------------- 基础工具 ---------------- */

  function q(sel) { return root ? root.querySelector(sel) : null; }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function findItem(url) {
    for (var i = 0; i < st.rows.length; i++) {
      if (st.rows[i].url === url) { return st.rows[i]; }
    }
    return null;
  }

  function stateText(msg) {
    var el = q('.tw-media-state');
    if (!el) { return; }
    if (msg) {
      el.textContent = msg;
      el.style.display = '';
      return;
    }
    if (!st.rows.length) {
      el.textContent = st.keyword
        ? '没有匹配「' + st.keyword + '」的文件'
        : '还没有上传过文件，点右上角「上传本地文件」开始';
      el.style.display = '';
    } else {
      el.style.display = 'none';
    }
  }

  /* ---------------- 数据加载 ---------------- */

  function load(reset) {
    if (st.loading) { return; }
    st.loading = true;
    if (reset) { st.page = 1; st.rows = []; }
    stateText('加载中…');

    var url = TW_MEDIA_API + '?page=' + st.page + '&limit=24'
      + '&ext=' + encodeURIComponent(st.ext)
      + '&keyword=' + encodeURIComponent(st.keyword);

    fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
      .then(function (r) {
        if (r.status === 401 || r.status === 403) {
          layer.msg('登录已过期，请重新登录', { icon: 2 });
          throw new Error('deny');
        }
        return r.json();
      })
      .then(function (res) {
        st.loading = false;
        if (!res || res.code !== 1) {
          stateText((res && res.msg) || '加载失败');
          return;
        }
        var d = res.data || {};
        st.rows   = st.rows.concat(d.rows || []);
        st.hasMore = !!d.has_more;
        renderAll();
      })
      .catch(function (e) {
        st.loading = false;
        if (e && e.message === 'deny') { return; }
        stateText('加载失败，请检查网络后重试');
      });
  }

  /* ---------------- 渲染 ---------------- */

  function itemNode(it) {
    var div = document.createElement('div');
    div.className = 'tw-media-item' + (st.sel[it.url] ? ' on' : '');
    div.setAttribute('data-url', it.url);
    div.title = (it.name || '') + (it.date ? ' · ' + it.date : '') + (it.size_text ? ' · ' + it.size_text : '');

    var thumb = it.is_image == 1
      ? '<img src="' + esc(it.thumb || it.url) + '" alt="" loading="lazy">'
      : '<i class="layui-icon layui-icon-file"></i><em>' + esc(String(it.ext || '').toUpperCase()) + '</em>';

    div.innerHTML = '<div class="tw-media-thumb">' + thumb + '</div>'
      + '<div class="tw-media-name">' + esc(it.name) + '</div>'
      + '<b class="tw-media-check">✓</b>';

    return div;
  }

  function renderAll() {
    var grid = q('.tw-media-grid');
    if (!grid) { return; }
    grid.innerHTML = '';
    st.rows.forEach(function (it) { grid.appendChild(itemNode(it)); });
    stateText('');
    var more = q('.tw-media-more');
    if (more) { more.style.display = st.hasMore ? '' : 'none'; }
    refreshFoot();
  }

  function refreshFoot() {
    var cnt = q('.tw-media-count');
    if (cnt) {
      cnt.textContent = st.order.length
        ? '已选 ' + st.order.length + ' 个' + (st.max && st.multiple ? ' / 最多 ' + st.max + ' 个' : '')
        : '未选择';
    }
    var ok = q('.tw-media-ok');
    if (ok) { ok.classList.toggle('layui-btn-disabled', !st.order.length); }
  }

  /* ---------------- 选中 ---------------- */

  function syncClass() {
    var all = root.querySelectorAll('.tw-media-item');
    for (var i = 0; i < all.length; i++) {
      all[i].classList.toggle('on', !!st.sel[all[i].getAttribute('data-url')]);
    }
  }

  function toggle(it, forceOff) {
    if (st.sel[it.url] || forceOff) {
      delete st.sel[it.url];
      var i = st.order.indexOf(it.url);
      if (i > -1) { st.order.splice(i, 1); }
    } else {
      if (!st.multiple) {
        st.sel = {};
        st.order = [];
      } else if (st.max && st.order.length >= st.max) {
        layer.msg('最多选择 ' + st.max + ' 个文件');
        return;
      }
      st.sel[it.url] = it;
      st.order.push(it.url);
    }
    syncClass();
    refreshFoot();
  }

  /* ---------------- 上传 ---------------- */

  function pickLocal() {
    var input = document.createElement('input');
    input.type = 'file';
    input.multiple = st.multiple;
    if (st.ext === 'image') { input.accept = 'image/*'; }
    input.onchange = function () { doUpload(input.files); };
    input.click();
  }

  function doUpload(files) {
    if (!files || !files.length) { return; }
    var fd = new FormData();
    for (var i = 0; i < files.length; i++) { fd.append('file[]', files[i]); }

    var loading = layer.load(2);
    fetch('/admin.php/attachment/upload', {
      method: 'POST',
      body: fd,
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function (r) { return r.json(); }).then(function (res) {
      layer.close(loading);
      if (!res || res.code !== 1) {
        layer.msg((res && res.msg) || '上传失败', { icon: 2 });
        return;
      }
      var list = (res.data && res.data.files) || [];
      if (!list.length) { return; }

      // 新上传的置顶显示，并自动选中
      if (!st.multiple) { st.sel = {}; st.order = []; }
      st.rows = list.concat(st.rows);
      list.slice().reverse().forEach(function (it) {
        if (st.multiple && st.max && st.order.length >= st.max) { return; }
        if (!st.multiple && st.order.length) { return; }
        st.sel[it.url] = it;
        st.order.push(it.url);
      });
      renderAll();
      var body = q('.tw-media-body');
      if (body) { body.scrollTop = 0; }

      layer.msg('已上传 ' + list.length + ' 个文件' + (st.multiple ? '，已自动选中' : ''), { icon: 1 });
    }).catch(function () {
      layer.close(loading);
      layer.msg('上传失败，请重试', { icon: 2 });
    });
  }

  /* ---------------- 事件 ---------------- */

  function bind() {
    // 类型切换
    var tabs = root.querySelectorAll('.tw-media-tabs a');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].onclick = function () {
        var ext = this.getAttribute('data-ext');
        if (ext === st.ext) { return; }
        st.ext = ext;
        for (var j = 0; j < tabs.length; j++) { tabs[j].classList.remove('on'); }
        this.classList.add('on');
        st.sel = {};
        st.order = [];
        load(true);
      };
    }

    // 搜索（防抖）
    var kw = q('.tw-media-kw');
    if (kw) {
      kw.oninput = function () {
        var val = this.value;
        clearTimeout(st.timer);
        st.timer = setTimeout(function () {
          st.keyword = String(val || '').trim();
          load(true);
        }, 320);
      };
      kw.onkeydown = function (e) {
        if (e.keyCode === 13) {
          clearTimeout(st.timer);
          st.keyword = String(this.value || '').trim();
          load(true);
        }
      };
    }

    // 网格点击 / 双击
    var grid = q('.tw-media-grid');
    if (grid) {
      grid.onclick = function (e) {
        var el = e.target;
        while (el && el !== grid && !el.classList.contains('tw-media-item')) { el = el.parentNode; }
        if (!el || el === grid) { return; }
        var it = findItem(el.getAttribute('data-url'));
        if (it) { toggle(it, false); }
      };
      grid.ondblclick = function (e) {
        var el = e.target;
        while (el && el !== grid && !el.classList.contains('tw-media-item')) { el = el.parentNode; }
        if (!el || el === grid) { return; }
        var it = findItem(el.getAttribute('data-url'));
        if (!it) { return; }
        if (!st.sel[it.url]) { toggle(it, false); }
        confirmPick();
      };
    }

    var up = q('.tw-media-up');
    if (up) { up.onclick = pickLocal; }

    var moreBtn = q('.tw-media-more-btn');
    if (moreBtn) {
      moreBtn.onclick = function () {
        st.page += 1;
        load(false);
      };
    }

    var cancel = q('.tw-media-cancel');
    if (cancel) { cancel.onclick = function () { layer.close(idx); }; }

    var ok = q('.tw-media-ok');
    if (ok) { ok.onclick = confirmPick; }
  }

  function confirmPick() {
    if (!st.order.length) {
      layer.msg('请先选择一个文件');
      return;
    }
    var items = st.order.map(function (u) { return st.sel[u]; });
    layer.close(idx);
    items.forEach(function (it) { cb(it.url, it); });
  }
}

/**
 * 选择图片（兼容旧调用：各表单里的「选择图片」都走这里）
 */
function twUploadOne(cb, opts) {
  twMediaPicker(cb, opts || {});
}

/**
 * 直接上传本地文件，不弹媒体库
 *
 * @param {Function} cb   cb(url, item)，多选时逐个回调
 * @param {Object}   opts { multiple:false, ext:'image'|'all' }
 */
function twUploadDirect(cb, opts) {
  opts = opts || {};
  var layer = twLayer();
  var input = document.createElement('input');
  input.type = 'file';
  input.multiple = !!opts.multiple;
  if (opts.ext !== 'all') { input.accept = 'image/*'; }
  input.onchange = function () {
    if (!input.files.length) { return; }
    var fd = new FormData();
    for (var i = 0; i < input.files.length; i++) { fd.append('file[]', input.files[i]); }
    var loading = layer.load(2);
    fetch('/admin.php/attachment/upload', {
      method: 'POST',
      body: fd,
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function (r) { return r.json(); }).then(function (res) {
      layer.close(loading);
      if (res.code !== 1) {
        layer.msg(res.msg || '上传失败', { icon: 2 });
        return;
      }
      var list = (res.data && res.data.files) || [];
      list.forEach(function (it) { cb(it.url, it); });
    }).catch(function () {
      layer.close(loading);
      layer.msg('上传失败', { icon: 2 });
    });
  };
  input.click();
}

/**
 * 分页跳转（保留查询参数）
 */
function twGoto(page) {
  var url = new URL(location.href);
  url.searchParams.set('page', page);
  location.href = url.toString();
}

/**
 * 状态文案
 */
var TW_STATUS = {
  new: '新询盘', read: '已读', quoted: '已报价',
  replied: '已回复', won: '已成交', closed: '已关闭'
};
