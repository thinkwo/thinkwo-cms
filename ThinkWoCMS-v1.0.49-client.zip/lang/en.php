<?php

// [TW-CMS-ZW-2026-8F3A1C] ThinkWoCMS 原创语言包 · 未经授权不得二次分发
// +----------------------------------------------------------------------
// | 前台界面文案（英文）
// +----------------------------------------------------------------------

return [
    'home'            => 'Home',
    'search'          => 'Search',
    'search_placeholder' => 'Search products...',
    'contact_us'      => 'Contact Us',
    'about_us'        => 'About Us',
    'products'        => 'Products',
    'news'            => 'News',
    'categories'      => 'Categories',
    'all'             => 'All',
    'read_more'       => 'Read more',
    'view_more'       => 'View more',
    'prev'            => 'Previous',
    'next'            => 'Next',
    'no_result'       => 'No results found',
    'no_content'      => 'No content yet',

    'inquiry'         => 'Inquiry',
    'inquiry_title'   => 'Send Your Inquiry',
    'inquiry_desc'    => 'Please fill in the form below and we will reply within 24 hours.',
    'name'            => 'Your Name',
    'email'           => 'Email Address',
    'phone'           => 'Phone',
    'whatsapp'        => 'WhatsApp',
    'company'         => 'Company',
    'country'         => 'Country',
    'subject'         => 'Subject',
    'message'         => 'Message',
    'captcha'         => 'Verification Code',
    'submit'          => 'Send Inquiry',
    'sending'         => 'Sending...',
    'inquiry_success' => 'Thank you! Your inquiry has been sent successfully.',
    'inquiry_fail'    => 'Submission failed, please try again later.',

    'name_required'     => 'Please enter your name',
    'email_invalid'     => 'Please enter a valid email address',
    'message_required'  => 'Please enter your message',
    'captcha_required'  => 'Please enter the verification code',
    'captcha_error'     => 'Verification code is incorrect',
    'too_frequent'      => 'You have submitted recently, please try again later',

    'add_to_cart'     => 'Add to Inquiry',
    'added_to_cart'   => 'Added to inquiry list',
    'cart'            => 'Inquiry List',
    'cart_empty'      => 'Your inquiry list is empty',
    'quantity'        => 'Qty',
    'product'         => 'Product',
    'remove'          => 'Remove',
    'clear'           => 'Clear',
    'total'           => 'Total',
    'price'           => 'Price',
    'price_tip'       => 'Price is for reference only, please contact us for an exact quotation.',
    'model_no'        => 'Model No.',
    'moq'             => 'MOQ',

    'language'        => 'Language',
    'related'         => 'Related Products',
    'share'           => 'Share',
    'tags'            => 'Tags',
    'page_not_found'  => 'Page Not Found',
    'back_home'       => 'Back to Home',
];
