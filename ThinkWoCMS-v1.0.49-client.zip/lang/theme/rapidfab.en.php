<?php

// RAPIDFAB · 按需制造外贸主题词条（English）
// 只覆盖需要改口径的通用词条，其余继承系统默认语言包

return [
    'products'      => 'Services',
    'news'          => 'Insights',
    'about_us'      => 'About',
    'categories'    => 'All services',
    'read_more'     => 'Read more',
    'related'       => 'Related services',
    'search'        => 'Search',
    'submit'        => 'Get Instant Quote',
    'no_content'    => 'Nothing published here yet.',
    'prev'          => 'Previous',
    'next'          => 'Next',
    'home'          => 'Home',
];
