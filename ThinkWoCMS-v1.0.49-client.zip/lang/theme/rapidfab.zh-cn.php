<?php

// RAPIDFAB · 按需制造外贸主题词条（简体中文）

return [
    'products'      => '服务',
    'news'          => '洞察',
    'about_us'      => '关于我们',
    'categories'    => '全部服务',
    'read_more'     => '阅读更多',
    'related'       => '相关服务',
    'search'        => '搜索',
    'submit'        => '立即报价',
    'no_content'    => '暂无内容。',
    'prev'          => '上一篇',
    'next'          => '下一篇',
    'home'          => '首页',
];
