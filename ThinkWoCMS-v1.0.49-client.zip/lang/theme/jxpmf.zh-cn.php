<?php

// JXPMF · 精密制造外贸主题词条（简体中文，后台预览用）
// 前台正文为英文，站点默认语言为英文时请把「多语言」里的默认语言设为 English

return [
    'products'      => '产品',
    'news'          => '技术文章',
    'about_us'      => '关于我们',
    'categories'    => '全部产品',
    'read_more'     => '查看详情',
    'related'       => '相关内容',
    'search'        => '搜索',
    'submit'        => '提交询价',
    'no_content'    => '该栏目暂无内容。',
    'prev'          => '上一篇',
    'next'          => '下一篇',
    'home'          => '首页',
];
