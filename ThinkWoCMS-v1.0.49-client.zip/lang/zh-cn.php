<?php

// [TW-CMS-ZW-2026-8F3A1C] ThinkWoCMS 原创语言包 · 未经授权不得二次分发
// +----------------------------------------------------------------------
// | 前台界面文案（简体中文）
// +----------------------------------------------------------------------

return [
    'home'            => '首页',
    'search'          => '搜索',
    'search_placeholder' => '搜索产品...',
    'contact_us'      => '联系我们',
    'about_us'        => '关于我们',
    'products'        => '产品中心',
    'news'            => '新闻资讯',
    'categories'      => '分类',
    'all'             => '全部',
    'read_more'       => '阅读更多',
    'view_more'       => '查看更多',
    'prev'            => '上一篇',
    'next'            => '下一篇',
    'no_result'       => '没有找到相关内容',
    'no_content'      => '暂无内容',

    'inquiry'         => '询盘',
    'inquiry_title'   => '在线询盘',
    'inquiry_desc'    => '请填写下方表单，我们会在 24 小时内回复您。',
    'name'            => '您的姓名',
    'email'           => '电子邮箱',
    'phone'           => '联系电话',
    'whatsapp'        => 'WhatsApp',
    'company'         => '公司名称',
    'country'         => '国家 / 地区',
    'subject'         => '主题',
    'message'         => '留言内容',
    'captcha'         => '验证码',
    'submit'          => '提交询盘',
    'sending'         => '提交中...',
    'inquiry_success' => '感谢您的询盘，我们已收到并会尽快联系您。',
    'inquiry_fail'    => '提交失败，请稍后重试。',

    'name_required'     => '请填写您的姓名',
    'email_invalid'     => '请填写正确的邮箱地址',
    'message_required'  => '请填写留言内容',
    'captcha_required'  => '请填写验证码',
    'captcha_error'     => '验证码不正确',
    'too_frequent'      => '您刚刚提交过，请稍后再试',

    'add_to_cart'     => '加入询价',
    'added_to_cart'   => '已加入询价单',
    'cart'            => '询价单',
    'cart_empty'      => '询价单还是空的',
    'quantity'        => '数量',
    'product'         => '产品',
    'remove'          => '移除',
    'clear'           => '清空',
    'total'           => '合计',
    'price'           => '价格',
    'price_tip'       => '价格仅供参考，准确报价请联系我们。',
    'model_no'        => '型号',
    'moq'             => '起订量',

    'language'        => '语言',
    'related'         => '相关产品',
    'share'           => '分享',
    'tags'            => '标签',
    'page_not_found'  => '页面不存在',
    'back_home'       => '返回首页',
];
