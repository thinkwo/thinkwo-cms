<?php

// +----------------------------------------------------------------------
// | 中间件设置
// +----------------------------------------------------------------------

return [
    // 别名或分组
    'alias'    => [
        'auth'  => \app\admin\middleware\Auth::class,
        'front' => \app\index\middleware\Front::class,
    ],
    // 优先级设置，此数组中的中间件会按照优先级从高到低执行
    'priority' => [
        \think\middleware\SessionInit::class,
    ],
];
