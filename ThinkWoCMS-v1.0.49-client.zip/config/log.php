<?php

// +----------------------------------------------------------------------
// | 日志设置
// +----------------------------------------------------------------------

return [
    // 默认日志记录通道
    'default'      => env('log.channel', 'file'),
    // 日志记录级别
    'level'        => ['error', 'warning', 'notice', 'info'],
    // 日志类型记录的通道
    'type_channel' => [],
    // 关闭全局日志写入
    'close'        => false,

    // 通道配置
    'channels'     => [
        'file' => [
            'type'           => 'File',
            'path'           => '',
            'single'         => false,
            'apart_level'    => ['error'],
            'max_files'      => 30,
            'json'           => false,
            'processor'      => null,
            'close'          => false,
            'format'         => '[%s][%s] %s',
            'realtime_write' => false,
        ],
    ],
];
