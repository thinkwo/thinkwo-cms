<?php
// [TW-BUILD] 51B485F04182 | - | 868A150A3E6F28B9 | v1.0.49 | plain
// +----------------------------------------------------------------------
// | ThinkWo CMS 授权与在线更新配置
// | 版本类型（自用 / 分发）不在本文件：它写在 app/common/library/Build.php，
// | 由 build/build.php 出包时自动改写。config 目录客户可改，不能放判断依据。
// +----------------------------------------------------------------------

return [
    // 产品标识（授权站据此区分产品）
    'product' => 'thinkwocms',

    // 授权站地址（后台「系统 → 授权与更新」可覆盖此项）
    'api' => 'https://license.thinkwocms.com',

    // RSA 公钥，只用于验签。私钥保存在你的授权站，绝不放进出包
    'public_key' => <<<'TW_PUBKEY'
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAseuBfVJE+u967IkCfSPa
w/86CI4v2xukZYkXTW9TS8XOoLZYYccH26qAl+jJCKxa4aiskevnmYie5RQO4UqW
czXtBfna7Kn4GD3zK/LvxYLtXKSMsWPW5G83IyiOg3qhNvFn2sVRk4SdnY698ujT
RP1CMDgLvtUb/VpWECzdhR8sOr1C5ibDlGHRslDCITzVFSz+IL9MeU9ydYEuioPq
X9jCIKwKQqfrzOM4Q0uV80y04CRD8ZulF49C/nsgQE9T7VRKJj7HPCcpZG5VGvGA
nTT91QWiF2imBuUehpQj5t1wWng2NKLH6XUQJ//wjmsV2m2Wf/NjxW6TYlAaCPew
6wIDAQAB
-----END PUBLIC KEY-----
TW_PUBKEY,

    // 授权过期后的宽限天数（宽限期内仍可正常使用，只做提醒）
    'grace_days' => 30,

    // 授权无效时是否禁止进入后台。
    // 默认 false：只提醒不拦截。远程锁站有法律风险，且客户断网会造成事故
    'block_admin' => false,

    // 升级前备份保留份数
    'backup_keep' => 3,

    // 允许更新的最大包体积（MB），防止恶意超大包撑爆磁盘
    'max_package_mb' => 200,
];
