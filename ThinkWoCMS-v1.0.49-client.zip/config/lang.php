<?php

// +----------------------------------------------------------------------
// | 语言包设置
// | ThinkWo CMS 的多语言内容由数据库 tw_language 表管理
// | 这里的配置只影响框架自身提示语
// +----------------------------------------------------------------------

return [
    // 默认语言
    'default_lang'    => env('lang.default', 'en'),
    // 允许的语言列表（留空表示不限制）
    'allow_lang_list' => [],
    // 是否使用 Cookie 记录语言
    'use_cookie'      => false,
    // 是否自动检测浏览器语言
    'accept_language' => false,
    // 语言变量名
    'var_lang'        => 'lang',
    // 是否开启多语言分组
    'allow_group'     => false,
    // 扩展语言包
    'extend_list'     => [],
];
