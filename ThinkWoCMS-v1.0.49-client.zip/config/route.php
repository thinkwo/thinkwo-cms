<?php

// +----------------------------------------------------------------------
// | 路由设置
// +----------------------------------------------------------------------

return [
    // pathinfo 分隔符
    'pathinfo_depr'        => '/',
    // 路由是否完全匹配
    'route_complete_match' => false,
    // 是否开启路由延迟解析
    'url_lazy_route'       => false,
    // 是否强制使用路由
    'url_route_must'       => false,
    // 合并路由规则
    'route_rule_merge'     => false,
    // 路由是否进行分组
    'url_route_group'      => false,
    // 是否使用严格模式
    'route_check_cache'    => false,
    // 默认的路由变量规则
    'default_route_pattern' => '[\w\.\-]+',
    // 是否开启请求缓存
    'request_cache'        => false,
    // 请求缓存有效期
    'request_cache_expire' => null,
    // 全局请求缓存排除规则
    'request_cache_except' => [],
    // 默认的 URL 后缀（ThinkWo 使用干净的 .html，由 TwUrl 手动拼接，这里留空避免重复）
    'url_html_suffix'      => '',
    // 是否允许使用通用参数
    'url_common_param'     => true,
    // PATHINFO 变量名
    'var_pathinfo'         => 's',
    // 默认的控制器层名
    'controller_layer'     => 'controller',
    // 空控制器名
    'empty_controller'     => 'Error',
];
