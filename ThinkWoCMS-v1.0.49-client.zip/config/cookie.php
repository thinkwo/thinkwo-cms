<?php

// +----------------------------------------------------------------------
// | Cookie设置
// +----------------------------------------------------------------------

return [
    // cookie 保存时间（秒），0 表示随浏览器关闭失效
    'expire'   => 0,
    // cookie 保存路径
    'path'     => '/',
    // cookie 有效域名
    'domain'   => '',
    // cookie 启用安全传输
    'secure'   => false,
    // httponly设置
    'httponly' => true,
    // 是否使用 setcookie
    'setcookie' => true,
    // samesite 设置（None / Lax / Strict）
    'samesite' => 'Lax',
];
