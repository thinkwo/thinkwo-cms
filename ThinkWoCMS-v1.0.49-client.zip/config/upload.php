<?php

// +----------------------------------------------------------------------
// | 上传设置
// +----------------------------------------------------------------------

return [
    // 默认上传驱动
    'default'  => 'local',
    // 上传根目录（相对 public）
    'root'     => 'uploads',
    // 允许的扩展名
    'exts'     => ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'ico', 'pdf', 'zip', 'rar', 'txt', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'mp4'],
    // 单文件最大体积（字节），默认 20MB
    'maxsize'  => 20 * 1024 * 1024,
    // 目录命名规则 date=按年月日 hash=按哈希散列
    'dirname'  => 'date',
    // 文件名规则 md5=随机哈希 uniqid=唯一ID keep=保留原名
    'filename' => 'md5',
];
